"""Targeted CNINFO 2008 annual reports only. Sequential PDF parsing, low memory."""
import csv, hashlib, io, json, re, resource
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from pypdf import PdfReader

OUT=Path(__file__).resolve().parent
CACHE=OUT/'evidence_cache'
codes=[r['firm_id'] for r in csv.DictReader((OUT/'downloaded_names_2008_snapshot.csv').open(encoding='utf-8-sig'))]
def request(url,data=None):
 headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.cninfo.com.cn/'}
 if data is not None: headers['Content-Type']='application/x-www-form-urlencoded'
 with urlopen(Request(url,data=data,headers=headers),timeout=35) as r:return r.read()
existing={r['firm_id']:r for r in json.loads((OUT/'primary_report_retrieval.json').read_text())} if (OUT/'primary_report_retrieval.json').exists() else {}
results=[]
for code in sorted(codes):
 if existing.get(code,{}).get('status')=='retrieved_primary':
  results.append(existing[code]);continue
 item=dict(firm_id=code,status='',source_url='',pdf_path='',text_path='',error='')
 try:
  org='9900002722' if code=='601008' else 'gssh0'+code
  data=urlencode(dict(pageNum=1,pageSize=30,tabName='fulltext',stock=f'{code},{org}',searchkey='',column='sse',category='category_ndbg_szsh',seDate='2009-01-01~2009-06-30',isHLtitle='true')).encode()
  metadata=json.loads(request('https://www.cninfo.com.cn/new/hisAnnouncement/query',data))
  announcements=metadata.get('announcements') or []
  pp=[r for r in announcements if '2008' in r['announcementTitle'] and '年度报告' in r['announcementTitle'] and '摘要' not in r['announcementTitle'] and '取消' not in r['announcementTitle']]
  item['candidates']=[dict(title=r['announcementTitle'],url=r['adjunctUrl'],time=r['announcementTime']) for r in pp]
  if not pp: item['status']='not_found';results.append(item);print(code,item['status'],flush=True);continue
  selected=max(pp,key=lambda r:r['announcementTime']);url='https://static.cninfo.com.cn/'+selected['adjunctUrl']
  raw=request(url);assert raw.startswith(b'%PDF'),url
  pdfpath=CACHE/f'{code}_2008_primary.pdf';pdfpath.write_bytes(raw)
  reader=PdfReader(io.BytesIO(raw)); texts=[]
  for i in range(min(35,len(reader.pages))):
   texts.append(f'\n===== PDF PAGE {i+1} =====\n'+reader.pages[i].extract_text(extraction_mode='layout'))
  txtpath=CACHE/f'{code}_2008_primary_first35pages.txt';txtpath.write_text('\n'.join(texts),encoding='utf-8')
  item.update(status='retrieved_primary',source_url=url,pdf_path=str(pdfpath),text_path=str(txtpath),pdf_pages=len(reader.pages),sha256=hashlib.sha256(raw).hexdigest())
  del reader,raw,texts
 except Exception as e:item.update(status='error',error=str(e))
 results.append(item);print(code,item['status'],item.get('pdf_pages',''),item['error'],flush=True)
 (OUT/'primary_report_retrieval.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'primary_retrieval_runtime.json').write_text(json.dumps(dict(peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,target_firms=len(codes),read_only_sources=True,no_merge=True,no_SYN_recalculation=True,no_regressions=True),indent=2))
