from pathlib import Path
import hashlib,json,pandas as pd
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True)
assert not (W/'run_started.json').exists(),'Already launched; inspect artifacts, never rerun automatically'
src=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((W.parent/'huang_mapping_SYN_lineage_audit_20261104/outputs/protected_before.json').read_text());assert all(sha(r['path'])==r['sha256'] for r in manifest)
manifest += [dict(path=str(p),sha256=sha(p)) for p in [W/'PLAN.md',W/'run_transition.do']]
(O/'protected_before.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
cols=['firm_id','year','Treat','Post','TreatPost','event_time','SYN_w','Size_w','Age_w','Lev_w','Cent_w','Top10_w','Dual','Board_w','Big4','old_H8_sample']
d=pd.read_stata(src/'fixed_analysis.dta',columns=cols,convert_categoricals=False);s=d[d.old_H8_sample.eq(1)]
assert len(s)==7609 and s.firm_id.nunique()==648 and s.loc[s.Treat.eq(1),'firm_id'].nunique()==439
assert not s.duplicated(['firm_id','year']).any() and s.groupby('firm_id').size().min()>1
assert s[cols].notna().all().all() and s.TreatPost.eq(s.Treat*s.Post).all() and s.event_time.eq(s.year-2015).all()
assert s.groupby('firm_id').Treat.nunique().max()==1 and s.Post.eq(s.year.ge(2015)).all()
s[['firm_id','year','Treat','Post','event_time']].to_csv(O/'expected_sample_keys_private.csv',index=False,encoding='utf-8-sig')
(O/'preflight.json').write_text(json.dumps(dict(N=len(s),clusters=648,treated_firms=439,controls=['Size_w','Age_w','Lev_w','Cent_w','Top10_w','Dual','Board_w','Big4'],minimum_firm_rows=int(s.groupby('firm_id').size().min()),additional_fits_authorized=2,SYN_recomputed=False),indent=2),encoding='utf-8')
print('PREFLIGHT COMPLETE: 7609 rows, 648 firms; no input mutation')
