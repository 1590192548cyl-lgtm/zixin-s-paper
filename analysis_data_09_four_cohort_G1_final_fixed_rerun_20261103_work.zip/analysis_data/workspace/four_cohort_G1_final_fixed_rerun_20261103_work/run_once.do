version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/four_cohort_G1_final_fixed_rerun_20261103_work/outputs"
local old "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028"
log using "`out'/final_fixed_rerun.log", text replace
which reghdfe
use "`out'/input_snapshot/latest_G1_analysis_original.dta", clear
isid firm_id stack_id annual_report_year
assert _N==26711
assert annual_report_year==syn_year-1
assert TreatPost==treated_in_stack*Post
assert event_time==annual_report_year-cohort_report_year
assert inrange(event_time,-3,2)
quietly count if sample_g1==1
assert r(N)==24659
tempname mh eh jh vh
tempfile main events joint matrices
postfile `mh' str24 model long N long clusters long treated_firms long control_firms long cohorts double TreatPost double SE double t double p double CI_low double CI_high double df_r using `main', replace
postfile `eh' str24 model int event_time long N long clusters double coefficient double SE double t double p double CI_low double CI_high using `events', replace
postfile `jh' str24 model str12 test long N long clusters double F double df_num double df_den double p using `joint', replace
postfile `vh' str12 model double max_abs_b_difference double max_abs_V_difference long old_N long new_N long old_clusters long new_clusters using `matrices', replace

* Exactly one static regression.
reghdfe SYN_CSRC_FAMILY_w_exact TreatPost Size_w_exact MB_parent_w_exact Lev_w_exact if sample_g1==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
assert e(N)==24659 & e(N_clust)==1770
assert _se[TreatPost]>0 & !missing(_se[TreatPost])
gen byte static_es=e(sample)
assert static_es==sample_g1
estimates store NEW_STATIC
estimates save "`out'/final_G1_static.ster", replace
tempvar ft fc fg
egen byte `ft'=tag(firm_id) if e(sample)&treated_in_stack==1
egen byte `fc'=tag(firm_id) if e(sample)&treated_in_stack==0
egen byte `fg'=tag(cohort_report_year) if e(sample)
quietly count if `ft'==1
local nt=r(N)
quietly count if `fc'==1
local nc=r(N)
quietly count if `fg'==1
local ng=r(N)
assert `nt'==636 & `nc'==1300 & `ng'==4
local crit=invttail(e(df_r),.025)
post `mh' ("final_fixed_G1") (e(N)) (e(N_clust)) (`nt') (`nc') (`ng') (_b[TreatPost]) (_se[TreatPost]) (_b[TreatPost]/_se[TreatPost]) (2*ttail(e(df_r),abs(_b[TreatPost]/_se[TreatPost]))) (_b[TreatPost]-`crit'*_se[TreatPost]) (_b[TreatPost]+`crit'*_se[TreatPost]) (e(df_r))
display as result "STATIC_ONE_DONE"

* Original dynamic specification: -3 remains the only omitted reference.
gen byte D_m2=treated_in_stack==1 & event_time==-2
gen byte D_m1=treated_in_stack==1 & event_time==-1
gen byte D_0=treated_in_stack==1 & event_time==0
gen byte D_p1=treated_in_stack==1 & event_time==1
gen byte D_p2=treated_in_stack==1 & event_time==2
foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
    assert inlist(`term',0,1)
    assert `term'==0 if treated_in_stack==0 | event_time==-3
}
assert D_m2+D_m1+D_0+D_p1+D_p2==1 if treated_in_stack==1 & event_time!=-3

* Exactly one event-study regression.
reghdfe SYN_CSRC_FAMILY_w_exact D_m2 D_m1 D_0 D_p1 D_p2 Size_w_exact MB_parent_w_exact Lev_w_exact if sample_g1==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
assert e(N)==24659 & e(N_clust)==1770
gen byte event_es=e(sample)
assert event_es==static_es & event_es==sample_g1
estimates store NEW_EVENT
estimates save "`out'/final_G1_event.ster", replace
local crit=invttail(e(df_r),.025)
foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
    local k=-2
    if "`term'"=="D_m1" local k=-1
    if "`term'"=="D_0" local k=0
    if "`term'"=="D_p1" local k=1
    if "`term'"=="D_p2" local k=2
    assert _se[`term']>0 & !missing(_se[`term'])
    post `eh' ("final_fixed_G1") (`k') (e(N)) (e(N_clust)) (_b[`term']) (_se[`term']) (_b[`term']/_se[`term']) (2*ttail(e(df_r),abs(_b[`term']/_se[`term']))) (_b[`term']-`crit'*_se[`term']) (_b[`term']+`crit'*_se[`term'])
}
test D_m2 D_m1
post `jh' ("final_fixed_G1") ("pre_joint") (e(N)) (e(N_clust)) (r(F)) (r(df)) (r(df_r)) (r(p))
test D_0 D_p1 D_p2
post `jh' ("final_fixed_G1") ("post_joint") (e(N)) (e(N_clust)) (r(F)) (r(df)) (r(df_r)) (r(p))
display as result "EVENT_ONE_DONE"
preserve
keep firm_id stack_id annual_report_year syn_year cohort_report_year event_time treated_in_stack TreatPost sample_g1 static_es event_es
export delimited using "`out'/actual_estimation_sample_private.csv", replace
restore

* Read archived estimates, not additional regressions.
foreach kind in STATIC EVENT {
    if "`kind'"=="STATIC" local archive "`old'/latest_G1.ster"
    if "`kind'"=="EVENT" local archive "`old'/latest_G1_event.ster"
    estimates use "`archive'"
    matrix OB=e(b)
    matrix OV=e(V)
    local oldN=e(N)
    local oldC=e(N_clust)
    estimates restore NEW_`kind'
    matrix DB=e(b)-OB
    matrix DV=e(V)-OV
    mata: st_numscalar("b_diff",max(abs(st_matrix("DB"))))
    mata: st_numscalar("V_diff",max(abs(st_matrix("DV"))))
    assert b_diff<1e-10 & V_diff<1e-10
    assert e(N)==`oldN' & e(N_clust)==`oldC'
    post `vh' ("`kind'") (b_diff) (V_diff) (`oldN') (e(N)) (`oldC') (e(N_clust))
}
postclose `mh'
postclose `eh'
postclose `jh'
postclose `vh'
use `main', clear
export delimited using "`out'/final_G1_static.csv", replace
use `joint', clear
export delimited using "`out'/final_G1_joint_tests.csv", replace
use `matrices', clear
export delimited using "`out'/archived_ster_matrix_comparison.csv", replace
use `events', clear
sort event_time
export delimited using "`out'/final_G1_event_study.csv", replace

set obs `=_N+1'
replace event_time=-3 if missing(event_time)
replace coefficient=0 if event_time==-3
sort event_time
twoway (rcap CI_low CI_high event_time,lcolor(navy)) (connected coefficient event_time,lcolor(navy) mcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-3 reference)") ytitle("SYN coefficient") legend(off) title("Four-cohort G1: final fixed rerun",size(medium)) note("95% firm-clustered CI; original Size, MB and Lev; unchanged sample",size(small)) graphregion(color(white)) xsize(8) ysize(5)
graph export "`out'/final_G1_event_plot.png", width(2200) replace
display as result "FINAL_FIXED_RERUN_COMPLETE"
log close
exit, clear
