# 四批次G1：最新核验名单、历史差异与平行趋势

## Material Passport

- 日期：2026-10-28。
- 用户明确选择四批次G1路径，使用最新核验名单，维持Size、MB、Lev、原FE及公司聚类，不加新批次。
- 本方案在本轮重估前写入。历史p值已知，本轮不是历史预注册；不按新结果回退名单。

## 冻结模型

- 四批次：cohort_report_year=2013、2015、2016、2017。
- 静态因变量：原四批次SYN_CSRC_FAMILY_w_exact，不能换为另一套W2的SYN_w_Gao。
- 处理项：TreatPost；控制：Size_w_exact、MB_parent_w_exact、Lev_w_exact，保留原定义和缩尾值。
- FE：firm_stack_id、cohort_year_id；cluster：原数值股票代码firm_id。
- 不使用W2熵平衡权重，不新增控制；[-3,+2]事件窗不变；annual_report_year=syn_year-1。

## 三个固定版本及最新名单

1. OLD_0345：读取p=0.034527916对应的official_table3_rebuild/official_table3_stack_analysis.dta，重估用于历史checksum。
2. STRICT_2013：读取gao_treatment_eligibility_strict_recheck/official_table3_stack_analysis.dta。该版本包含24条strict_include=1的2013公司—指引核验决定；其归档G1 p=0.050250899，仅用于确认差异链条。
3. LATEST：在STRICT_2013基础上，应用截至本轮已经确认的政策暴露证据库。只排除确实在stack窗口内已经受处理的控制公司—stack；不改变原处理组、不新增批次。预审计确认影响5家公司、13个公司—stack、73条控制观测，无更早已处理的处理组。
4. 候选、可能适用、没有文本及strict_include=0不作为新增或自动否定依据；不重新扫描年报。
5. 仅有明确证据的控制污染修正，不因p值选择是否应用。全部剔除记录保留对应证据ID、源文件和既有决定摘要；原始DTA及映射只读。

## 差异核对

- 分别比较OLD→STRICT和STRICT→LATEST的键、G1样本、处理身份和共同观测的冻结SYN/控制值。
- FE编号的任意重新编码只检查分类分组是否等价，不把编号不同当作设计改变。
- 另在OLD与LATEST共同G1观测上分别运行同一G1，诊断共同观测处理编码与样本组成的贡献。它们只是预先固定差异分解，不用于挑选主模型。
- 本轮静态估计仅上述三版checksum/主结果及两次共同样本对照，共五次同一控制组合。

## 平行趋势

- 只重跑OLD与LATEST两版G1事件研究；不重跑M0或FULL19。
- 沿用历史四批次代码的-3省略基准，不混用此前W2的-1基准。
- 解释变量：treated_in_stack×1(event_time=-2,-1,0,+1,+2)。控制组交互项全为0。
- 联合检验政策前D_m2=D_m1=0；政策后D_0=D_p1=D_p2=0。
- 检查所有五项可估计、无窗口外时期混入、各cohort×event有处理/控制支持、事件研究与对应静态G1的e(sample)一致。
- 记录F、p、系数、聚类SE及95%CI；不以联合p值筛公司或cohort。

## 输出与停止

输入指纹、名单变化与证据、逐行样本变化、共同值与FE检查、三版及共同样本静态比较、事件研究与联合检验、旧新事件图、Stata日志、最新分析DTA、中文报告和固定脚本。所有结果另存four_cohort_G1_latest_recheck_20261028，不覆盖历史结果。

完整执行上述固定审计和回归后停止，不继续增加批次、换控制、删公司试显著性或运行机制/异质性。
