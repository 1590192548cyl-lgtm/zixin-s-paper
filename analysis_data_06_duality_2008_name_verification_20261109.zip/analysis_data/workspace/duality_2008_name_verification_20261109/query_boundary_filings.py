"""Only metadata and specific appointment notices, not a regression pipeline."""
import json
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
OUT=Path(__file__).resolve().parent
def get(url,data=None):
 h={'User-Agent':'Mozilla/5.0','Referer':'https://www.cninfo.com.cn/'}
 if data:h['Content-Type']='application/x-www-form-urlencoded'
 with urlopen(Request(url,data=data,headers=h),timeout=30) as r:return r.read()
stocks=json.loads(get('https://www.cninfo.com.cn/new/data/szse_stock.json'))
stocklist=stocks.get('stockList',[])
selected=[r for r in stocklist if r.get('code')=='601008']
(OUT/'601008_public_security_identity.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2))
print('601008',selected,flush=True)
tasks=[('600029','2008-12-01~2009-01-31'),('600050','2008-05-01~2009-04-10'),('600509','2008-12-01~2009-01-31'),('600841','2008-12-20~2009-01-31'),('600790','2008-12-01~2009-03-31')]
results=[]
for code,dates in tasks:
 d=urlencode(dict(pageNum=1,pageSize=100,tabName='fulltext',stock=f'{code},gssh0{code}',searchkey='',column='sse',category='category_dshgg_szsh',seDate=dates,isHLtitle='true')).encode()
 try:
  r=json.loads(get('https://www.cninfo.com.cn/new/hisAnnouncement/query',d))
  aa=r.get('announcements') or []
  selected=[dict(title=a['announcementTitle'],url='https://static.cninfo.com.cn/'+a['adjunctUrl']) for a in aa]
  results.append(dict(firm_id=code,date_range=dates,total=r.get('totalAnnouncement'),announcements=selected))
  print(code,json.dumps(selected,ensure_ascii=False),flush=True)
 except Exception as e:results.append(dict(firm_id=code,error=str(e)))
 (OUT/'boundary_filing_metadata.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
