from pathlib import Path
import csv
import importlib.util
import json
import math

import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"
STACK = OUT / "gao_confirmed_four_cohort_stack.dta"
INVENTORY = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/年报指引识别/output/"
    "annual_report_inventory.csv"
)
PRIOR = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_replication_refinement/"
    "length_mda_firm_year_2009_2025.csv"
)
EXTRACTOR = Path(
    "/Users/macpro/Documents/New project/gao_replication_refinement_work/"
    "extract_full_mda_length.py"
)
CHECKPOINT = OUT / "mda_early_completion_checkpoint.csv"


def load_extractor():
    spec = importlib.util.spec_from_file_location("mda_extract", EXTRACTOR)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.extract_one


def main():
    extract_one = load_extractor()
    stack = pd.read_stata(STACK, convert_categoricals=False)
    stack["firm_id"] = pd.to_numeric(stack["firm_id"], errors="raise").astype(int)
    stack["annual_report_year"] = pd.to_numeric(
        stack["annual_report_year"], errors="raise"
    ).astype(int)
    target = stack[["firm_id", "annual_report_year"]].drop_duplicates()
    target_keys = set(map(tuple, target.to_numpy()))

    prior = pd.read_csv(PRIOR, low_memory=False)
    prior["firm_id"] = pd.to_numeric(prior["firm_id"], errors="coerce").astype("Int64")
    prior["report_year"] = pd.to_numeric(prior["report_year"], errors="coerce").astype("Int64")
    prior = prior[
        prior.apply(
            lambda r: (int(r.firm_id), int(r.report_year)) in target_keys
            if pd.notna(r.firm_id) and pd.notna(r.report_year)
            else False,
            axis=1,
        )
    ].copy()
    completed = set(
        zip(prior["firm_id"].astype(int), prior["report_year"].astype(int))
    )

    inv = []
    with INVENTORY.open(encoding="utf-8-sig", newline="") as fh:
        for row in csv.DictReader(fh):
            if row.get("preferred_version") != "1" or row.get("is_full_annual_report") != "1":
                continue
            if row.get("decode_status") != "decoded":
                continue
            try:
                key = (int(row["stock_code"]), int(row["report_year"]))
            except (TypeError, ValueError):
                continue
            if key in target_keys and key not in completed:
                row["firm_id"], row["report_year"] = key
                inv.append(row)

    new_rows = []
    prior_checkpoint = pd.DataFrame()
    if CHECKPOINT.exists():
        prior_checkpoint = pd.read_csv(CHECKPOINT, low_memory=False)
        new_rows = prior_checkpoint.to_dict("records")
        done_new = set(
            zip(prior_checkpoint["firm_id"].astype(int), prior_checkpoint["report_year"].astype(int))
        )
    else:
        done_new = set()

    for row in inv:
        key = (row["firm_id"], row["report_year"])
        if key in done_new:
            continue
        path = Path(row["source_path"])
        try:
            text = path.read_text(
                encoding=row.get("encoding") or "utf-8-sig", errors="strict"
            )
            result = extract_one(text)
        except Exception as exc:
            result = {
                "extraction_status": "read_error",
                "start_line": None,
                "end_line": None,
                "start_anchor": "",
                "end_anchor": "",
                "raw_mda_chars": None,
                "text_mda_chars": None,
                "removed_table_lines": 0,
                "start_excerpt": "",
                "end_excerpt": "",
                "error": f"{type(exc).__name__}: {exc}",
            }
        new_rows.append(
            {
                "firm_id": row["firm_id"],
                "report_year": row["report_year"],
                "company_name": row.get("company_name", ""),
                "source_path": row["source_path"],
                "report_file_chars": int(row.get("text_length") or 0),
                **result,
            }
        )
        if len(new_rows) % 500 == 0:
            pd.DataFrame(new_rows).to_csv(CHECKPOINT, index=False, encoding="utf-8-sig")
            print(f"checkpoint {len(new_rows)}/{len(inv)}", flush=True)

    new = pd.DataFrame(new_rows)
    if len(new):
        new["Length_MDA"] = new["text_mda_chars"].where(
            new["extraction_status"].eq("matched_valid")
        ).map(lambda x: math.log(x) if pd.notna(x) and x > 0 else math.nan)
    combined = pd.concat([prior, new], ignore_index=True, sort=False)
    combined = combined.sort_values(["firm_id", "report_year"]).drop_duplicates(
        ["firm_id", "report_year"], keep="last"
    )
    valid = combined["Length_MDA"].dropna()
    p1, p99 = float(valid.quantile(0.01)), float(valid.quantile(0.99))
    combined["Length_MDA_w"] = combined["Length_MDA"].clip(p1, p99)
    combined.to_csv(OUT / "length_mda_exact_stack_firm_year.csv", index=False, encoding="utf-8-sig")

    coverage = (
        target.merge(
            combined[["firm_id", "report_year", "Length_MDA_w", "extraction_status"]],
            left_on=["firm_id", "annual_report_year"],
            right_on=["firm_id", "report_year"],
            how="left",
            validate="one_to_one",
        )
        .groupby("annual_report_year")
        .agg(
            target_firm_years=("firm_id", "size"),
            valid_mda=("Length_MDA_w", "count"),
            files_found=("report_year", "count"),
        )
        .reset_index()
    )
    coverage["coverage_rate"] = coverage["valid_mda"] / coverage["target_firm_years"]
    coverage.to_csv(OUT / "length_mda_exact_stack_coverage.csv", index=False)
    meta = {
        "target_unique_firm_years": len(target),
        "prior_rows_reused": len(prior),
        "new_files_processed": len(new),
        "final_valid_mda": int(combined.Length_MDA.notna().sum()),
        "winsor_p1": p1,
        "winsor_p99": p99,
    }
    (OUT / "length_mda_exact_stack_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    CHECKPOINT.unlink(missing_ok=True)
    print(json.dumps(meta, ensure_ascii=False, indent=2), flush=True)
    print(coverage.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
