"""Render only relevant pages, sequentially; never modify source PDF."""
import json,os,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent
R=O/'page_checks';R.mkdir(exist_ok=True)
(O/'fontcache').mkdir(exist_ok=True)
env=dict(os.environ,FONTCONFIG_FILE=str(O/'fontconfig.xml'))
manifest=json.loads((O/'selected_notice_retrieval.json').read_text())
sources={(r['firm_id'],r['id']):r for r in manifest}
tasks=[('600029','47340119',1),('601008','48019836',1),('600345','39160205',3),
 ('600329','35269685',1),('600805','35340748',2),('600305','35238178',5)]
out=[]
for code,id,page in tasks:
 p=R/f'{code}_{id}_p{page}.png'
 if not p.exists():
  with (R/f'{code}_{id}_render.log').open('w') as log:
   subprocess.run(['pdftoppm','-f',str(page),'-l',str(page),'-scale-to','1600','-singlefile','-png',sources[(code,id)]['pdf_path'],str(p.with_suffix(''))],env=env,stdout=log,stderr=log,check=True,timeout=45)
 out.append(dict(firm_id=code,notice_id=id,pdf_page=page,image=str(p)))
(O/'rendered_page_manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('Rendered',len(out),'pages')
