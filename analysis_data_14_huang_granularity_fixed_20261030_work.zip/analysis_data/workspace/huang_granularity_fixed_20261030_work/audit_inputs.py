from pathlib import Path
import json
import pandas as pd
from openpyxl import load_workbook

OUT=Path(__file__).resolve().parent
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
review=json.loads((P/'huang_industry_review_20261030/source_inspection.json').read_text())
ids={int(r['firm_id']) for r in review['invalid_source_code_audit']['affected_current_keys']}
files=[Path('/Users/macpro/Desktop/毕业论文/行业分类/STK_IndustryClassAnl.xlsx'),
       Path('/Users/macpro/Desktop/毕业论文/原始数据/行业分类.xlsx'),
       Path('/Users/macpro/Desktop/毕业论文/控制变量/2207-2008行业分类/STK_INDUSTRYCLASS.xlsx'),
       Path('/Users/macpro/Desktop/毕业论文/控制变量/07-08年度行业分类表/STK_IndustryClassAnl.xlsx')]
heads=[]
for f in files:
    wb=load_workbook(f,read_only=True,data_only=True)
    for ws in wb:
        ws.reset_dimensions()
        first=[]
        for i,row in enumerate(ws.iter_rows(values_only=True)):
            first.append(list(row))
            if i>=4: break
        heads.append({'file':str(f),'sheet':ws.title,'first5':first})
    wb.close()
(OUT/'xlsx_headers.json').write_text(json.dumps(heads,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print(json.dumps(heads,ensure_ascii=False,indent=2,default=str),flush=True)
raw=P/'data_work/industry_old_standardized.dta'
d=pd.read_stata(raw,convert_categoricals=False)
fid=pd.to_numeric(d.Symbol,errors='coerce')
q=d.loc[fid.isin(ids)].copy()
q.to_json(OUT/'old_industry_candidate_rows.json',orient='records',force_ascii=False,indent=2,date_format='iso')
print('Old industry target rows',len(q),flush=True)
