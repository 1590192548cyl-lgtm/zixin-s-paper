from pathlib import Path
import ast,hashlib,json,re,resource,sqlite3
from typing import Iterable
from zipfile import ZipFile
from xml.etree.ElementTree import iterparse
import numpy as np
import pandas as pd
from openpyxl import load_workbook

W=Path(__file__).resolve().parent;O=W/'outputs'
R=Path('/Users/macpro/Desktop/毕业论文');P=R/'堆叠DID重跑'
IND=P/'data_work/industry_new_standardized.dta'
BASE=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
PARSER=Path('/Users/macpro/Documents/New project/gao_full_controls_work/construct_gao_full_controls.py')
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig',float_format='%.17g')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
ns={'re':re,'ZipFile':ZipFile,'iterparse':iterparse,'Path':Path,'Iterable':Iterable,
    'NS':'{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'}
names={'cell_text','load_shared_strings','iter_xlsx_records'}
nodes=[n for n in ast.parse(PARSER.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(PARSER),'exec'),ns)
records=ns['iter_xlsx_records']
primary_hashes={str(p):sha(p) for p in [IND,BASE]}
cols=['InstitutionID','EndDate','IndustryClassificationID','Symbol','IndustryClassification','IndustryCode2','IndustryName2']
d=pd.read_stata(IND,columns=cols,convert_categoricals=False)
d['firm_id']=pd.to_numeric(d.Symbol,errors='coerce')
d['industry_year']=pd.to_datetime(d.EndDate,errors='coerce').dt.year
d=d.loc[d.IndustryClassificationID.eq('P0201')&d.industry_year.between(2009,2011)].copy()
d=d.sort_values(['firm_id','industry_year','EndDate']).drop_duplicates(['firm_id','industry_year'],keep='last')
code=d.IndustryCode2.astype(str).str.strip()
d['code2_placeholder']=code.str.lower().isin(['','none','nan','<na>','nat','.'])
bad=d.loc[d.code2_placeholder].copy()
bad['firm_id']=bad.firm_id.astype(int);bad['firm_code']=bad.firm_id.astype(str).str.zfill(6)
save(bad,'early_industry_placeholder_pool_private.csv')
stack=pd.read_stata(BASE,convert_categoricals=False)
affected=stack.merge(bad[['firm_id','industry_year','IndustryClassification','IndustryCode2','IndustryName2','InstitutionID']],
                     left_on=['firm_id','syn_year'],right_on=['firm_id','industry_year'],how='inner',validate='many_to_one')
save(affected,'early_industry_directly_affected_stack_private.csv')

rawfiles=[R/'行业分类/STK_IndustryClassAnl.xlsx',R/'原始数据/行业分类.xlsx',
          R/'控制变量/07-08年度行业分类表/STK_IndustryClassAnl.xlsx',
          R/'控制变量/2007-2008行业分类年度表/STK_IndustryClassAnl.xlsx',
          R/'控制变量/2207-2008行业分类/STK_INDUSTRYCLASS.xlsx']
inventory=[];events=[]
badids=set(bad.firm_id);badkeys=set(zip(bad.firm_id,bad.industry_year.astype(int)))
for path in rawfiles:
    before_digest=sha(path)
    wb=load_workbook(path,read_only=True,data_only=True);s=wb.worksheets[0];s.reset_dimensions()
    headers=next(s.iter_rows(max_row=1,values_only=True));wb.close()
    rows=matched=0;yrs=set();standards=set()
    for rownum,r in records(path):
        rows+=1
        standard=r.get('IndustryClassificationID','')
        if standard!='P0201':continue
        date=r.get('EndDate',r.get('ImplementDate',''))
        try:year=int(date[:4])
        except (TypeError,ValueError):continue
        yrs.add(year);standards.add(r.get('IndustryClassification',r.get('IndustryClassificationName','')))
        try:fid=int(r.get('Symbol','').removesuffix('.0'))
        except ValueError:continue
        if fid in badids and year<=2011 and r.get('IndustryCode','').strip():
            events.append({'firm_id':fid,'firm_code':f'{fid:06d}','record_date':date,'industry_code':r['IndustryCode'],
                           'industry_name':r.get('IndustryName',''),'standard_id':standard,
                           'standard_name':r.get('IndustryClassificationName',''),'source_file':str(path),'source_row':rownum})
            matched+=1
    inventory.append({'file':str(path),'bytes':path.stat().st_size,'sha256_before':before_digest,'fields':'|'.join(str(x) for x in headers if x is not None),
                      'P0201_actual_years':','.join(map(str,sorted(yrs))),'P0201_actual_names':'|'.join(sorted(standards)),
                      'contains_level1_code':int('IndustryCode1' in headers),'contains_level1_name':int('IndustryName1' in headers),
                      'contains_generic_industry_code':int('IndustryCode' in headers),'contains_stock_code':int('Symbol' in headers),
                      'rows_read':rows,'target_historical_event_records':matched})
events=pd.DataFrame(events).drop_duplicates() if events else pd.DataFrame()
save(events,'available_historical_industry_events_private.csv')
target2011=affected.loc[affected.syn_year.eq(2011),['firm_id','syn_year']].drop_duplicates()
direct=[]
for r in target2011.itertuples():
    q=events.loc[events.firm_id.eq(r.firm_id)&events.record_date.le(f'{r.syn_year}-12-31')] if not events.empty else events
    direct.append({'firm_id':r.firm_id,'firm_code':f'{r.firm_id:06d}','industry_year':r.syn_year,
                   'direct_historical_record_available':int(len(q)>0),'observed_codes':'|'.join(sorted(set(q.industry_code))) if len(q) else '',
                   'observed_names':'|'.join(sorted(set(q.industry_name))) if len(q) else '',
                   'repair_applied':0,'status':'historical_record_only_complete_annual_pool_not_certified' if len(q) else 'need_contemporaneous_classification_source'})
save(pd.DataFrame(direct),'industry_30_evidence_status.csv')
inv=pd.DataFrame(inventory);inv['sha256_after']=[sha(Path(p)) for p in inv.file]
inv['unchanged']=inv.sha256_before.eq(inv.sha256_after);assert inv.unchanged.all()
save(inv,'early_industry_source_inventory.csv')
coverage=d.groupby('industry_year').agg(total_firms=('firm_id','nunique'),placeholder_code2_firms=('code2_placeholder','sum')).reset_index()
save(coverage,'early_industry_pool_coverage.csv')

# Review causal timing only; never alter controls or estimate a treatment->control regression.
timing=[]
for role,g in stack.loc[stack.sample_g1.eq(1)].groupby(['cohort_report_year','event_time','treated_in_stack']):
    cohort,event,treated=map(int,role)
    timing.append({'cohort_report_year':cohort,'event_time':event,'treated_in_stack':treated,'N':len(g),
                   'control_fiscal_year':int(g.annual_report_year.iloc[0]),'syn_year':int(g.syn_year.iloc[0]),
                   'financial_asof_date':f'{int(g.annual_report_year.iloc[0])}-12-31',
                   'classification':'pre_first_applicable_fiscal_year' if treated and event<0 else ('first_applicable_fiscal_year_check_policy_issue_date' if treated and event==0 else ('later_applicable_fiscal_year_not_pretreatment' if treated else 'unchanged_control_group_role')),
                   'controls_replaced':0})
save(pd.DataFrame(timing),'G1_control_timing_audit.csv')
review=pd.DataFrame([
 {'variable':'Size','original_formula':'ln(A001000000)','source_asof':'fiscal_year-12-31; consolidated A',
  'potential_policy_path':'Disclosure may affect financing and investment and subsequently total assets. Causal risk, not proof of realized effect.',
  'timing_conclusion':'syn_year-1 alignment is reproduced, but later policy-year values are not strict pre-policy covariates.','automatic_replacement':0},
 {'variable':'MB_parent','original_formula':'Ysmvttl*1000/A003100000; parent equity>0','source_asof':'year-end total market value and same-year consolidated parent equity',
  'potential_policy_path':'Year-end market valuation can respond directly to disclosure regulation; possible mediator/bad-control concern.',
  'timing_conclusion':'Calendar alignment correction does not prove the market value was unaffected by treatment.','automatic_replacement':0},
 {'variable':'Lev','original_formula':'A002000000/A001000000; total assets>0','source_asof':'fiscal_year-12-31; consolidated A',
  'potential_policy_path':'Disclosure may affect debt financing; observed annual leverage may lie on the treatment path.',
  'timing_conclusion':'Review requires causal assumptions, not which specification has a smaller p-value.','automatic_replacement':0}])
save(review,'G1_three_control_causal_review.csv')
primary_integrity=pd.DataFrame([{'path':p,'sha256_before':h,'sha256_after':sha(Path(p)),
                                 'unchanged':h==sha(Path(p))} for p,h in primary_hashes.items()])
assert primary_integrity.unchanged.all()
save(primary_integrity,'industry_and_stack_input_integrity.csv')
result={'early_pool_placeholder_firm_years':len(bad),'directly_affected_stack_observations':len(affected),
        'directly_affected_current_G1_observations':int(affected.sample_g1.sum()),
        'target2011_firms':len(target2011),'target2011_with_direct_historical_event':sum(r['direct_historical_record_available'] for r in direct),
        'target2011_without_direct_historical_event':sum(not r['direct_historical_record_available'] for r in direct),
        'all_current_annual_classification_sources_lack_level1_fields':bool(inv.contains_level1_code.eq(0).all()),
        'classification_repairs_applied':0,'control_variables_replaced':0,'regressions_run':0,
        'Python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
(O/'industry_and_control_review_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
print(coverage.to_string(index=False),flush=True)
