from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert 'HUANG_POSTHOC_WINDOW_COMPLETE' in (O/'fixed_models.log').read_text()
full=pd.read_stata(B/'fixed_analysis.dta',convert_categoricals=False).set_index(['firm_id','year']);q=pd.read_stata(O/'window_analysis.dta',convert_categoricals=False).set_index(['firm_id','year']);assert q.index.isin(full.index).all()
for c in full.columns:assert q[c].equals(full.loc[q.index,c]),c
audit=[]
for model in ['H0','H8']:
 s=pd.read_csv(O/f'{model}_sample_private.csv');actual=set(map(tuple,s.loc[s.static_sample.eq(1),['firm_id','year']].to_numpy()));expect=set(map(tuple,q.loc[q[f'window_{model}_sample'].eq(1)].index))
 assert actual==expect and s.static_sample.eq(s.event_sample).all()
 audit.append(dict(model=model,N=len(actual),clusters=s.loc[s.static_sample.eq(1),'firm_id'].nunique(),same_static_dynamic_sample=True,additional_exclusions=0,all_source_values_unchanged=True))
pd.DataFrame(audit).to_csv(O/'actual_sample_audit.csv',index=False)
for name in ['static_results','event_results','joint_tests']:
 frames=[]
 for label,folder in [('full_2009_2021',B),('posthoc_2012_2018',O)]:
  d=pd.read_csv(folder/f'{name}.csv');d.insert(0,'window',label);frames.append(d)
 d=pd.concat(frames,ignore_index=True);d.to_csv(O/f'{name}_comparison.csv',index=False)
 if name=='event_results':assert len(d)==36 and d.SE.gt(0).all()
manifest=json.loads((O/'protected_inputs.json').read_text());after=[dict(**r,unchanged=sha(r['file'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);(O/'input_integrity_after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'run_completed.json').write_text(json.dumps(dict(status='complete',label='literature-motivated post-hoc comparison',static_models=2,event_models=2,additional_specifications=0,original_G1_unchanged=True,SYN_recomputed=False,winsor_recomputed=False),indent=2),encoding='utf-8')
print(pd.DataFrame(audit).to_string(index=False))
