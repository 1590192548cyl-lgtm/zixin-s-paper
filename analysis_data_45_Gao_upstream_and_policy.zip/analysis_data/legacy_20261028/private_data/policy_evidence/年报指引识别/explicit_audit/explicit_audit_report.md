# 年报明确指引严格审计报告（已合并人工复核）

1. 214条中 strict_confirmed_explicit：137
2. explicit_other_iidg：29
3. generic_only：0
4. heading_only：0
5. negative：48
6. context_only：0
7. conflicting：0
8. manual_review：0
9. 960条中 earlier_treatment_confirmed：481
10. earlier_same_iidg_or_renumbering：0
11. earlier_negative：479
12. earlier_manual_review：0
13. 下一步进入 MD&A 业务判断的实际任务数：2943
14. Excel核对表：explicit_audit_review.xlsx
15. 需要立即修复的程序错误：是。旧程序会把特定指引提示行后紧随的“否”误判为 positive_specific，并会用邻近业务词误配具体IIDG。

## 人工复核合并说明

- 候选年度4条冲突记录均确认适用，已合并为 strict_confirmed_explicit。
- 更早记录4条依次合并为：不适用、适用且需遵守、不适用、不适用。
- 合并后 conflicting、candidate manual_review 和 earlier_manual_review 均为0。

本阶段未修改 first_treat_year，未进入 MD&A、Treat 或回归。