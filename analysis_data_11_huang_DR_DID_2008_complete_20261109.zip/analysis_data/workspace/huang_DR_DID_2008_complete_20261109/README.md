# DR-DID固定分析，2026-11-09

这是新增结果包，不覆盖H8/G1。最终报告位于 `outputs/DR_DID结果报告.md`，排除名单位于 `outputs/excluded_firms_private.csv`。估计、前趋势及重叠警示以报告为准，不挑选年份结果。

规范执行目录为 `/Users/macpro/Documents/New project/huang_DR_DID_2008_complete_20261109`。项目目录中的同名文件夹是归档副本。脚本使用当前本机绝对来源和工作区相邻缓存路径，不应直接在归档副本启动，更不应重复全流程。12项估计已经全部完成，导出/核验阶段无重新估计。

包含原始来源校验、固定方案、排除原因、真实基线来源、影响函数、权重诊断、逐年ATT、联合协方差、日志与Stata估计存档。带private文件及分析DTA含受限CSMAR公司数据，不应公开上传GitHub。无需下载年报或重算SYN。
