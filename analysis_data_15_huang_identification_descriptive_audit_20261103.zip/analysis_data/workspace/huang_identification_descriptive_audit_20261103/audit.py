"""Frozen-data descriptive audit only. No regressions or new analysis DTA."""
from pathlib import Path
import hashlib,json,resource,time
import pandas as pd
import numpy as np
W=Path(__file__).resolve().parent; O=W/'outputs'; O.mkdir(exist_ok=True)
BASE=W.parent; FULL=BASE/'huang_week_calendar_repair_20261103/fixed_rerun/outputs'
WIN=BASE/'huang_posthoc_window_2012_2018_20261103/outputs'; B=BASE/'huang_basic_reconstruction_20261103/outputs'
G1=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta')
PDF=Path('/Users/macpro/Desktop/毕业论文/参考文献/黄炳艺，2025_分行业信息披露监管影响资本市场定价效率吗.pdf')
start=time.time()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def js(x,name):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(x,name):pd.DataFrame(x).to_csv(O/name,index=False,encoding='utf-8-sig')
protected=[G1,PDF,B/'policy_mapping_private.csv',FULL/'fixed_analysis.dta',WIN/'window_analysis.dta']
for folder in [FULL,WIN]:protected+=list(folder.glob('*.ster'))+[folder/f for f in ['static_results.csv','event_results.csv','joint_tests.csv']]
manifest=[dict(path=str(p),sha256=sha(p)) for p in protected];js(manifest,'protected_before.json')
d=pd.read_stata(FULL/'fixed_analysis.dta',convert_categoricals=False)
assert not d.duplicated(['firm_id','year']).any()
assert d.groupby('firm_id').Treat.nunique().max()==1
assert (d.TreatPost==d.Treat*d.Post).all() and (d.event_time==d.year-2015).all()
mapping=pd.read_csv(B/'policy_mapping_private.csv').set_index('firm_id'); assert mapping.index.is_unique
d['industry2014']=d.firm_id.map(mapping.industry2014)
assert d.industry2014.notna().all() and (d.Treat==d.firm_id.map(mapping.Treat)).all()
# These columns are audit labels, never exported as an estimation data file.
d['SYN_industry2014']=np.where(d.industry2014.str.startswith('C'),d.industry2014,d.industry2014.str[0])
controls=['Size_w','Age_w','Lev_w','Cent_w','Top10_w','Dual','Board_w','Big4']
annual=[]; gaps=[]; comp=[]; balances=[]; pairrows=[]; contributions=[]; mix=[]; missing=[]; rosterrows=[]; checks=[]
for model,expected in [('H0',7883),('H8',7609)]:
 s=d[d[f'old_{model}_sample'].eq(1)].copy(); assert len(s)==expected
 roster=s[['firm_id','Treat','industry2014','SYN_industry2014']].drop_duplicates(); assert roster.firm_id.is_unique
 preids=set(s[s.year.lt(2015)].groupby('firm_id').year.nunique().loc[lambda x:x==6].index)
 allids=set(s.groupby('firm_id').year.nunique().loc[lambda x:x==13].index)
 for label,ids in [('frozen_original',set(roster.firm_id)),('pre2009_2014_complete_roster',preids),('all2009_2021_complete_descriptive_only',allids)]:
  z=s[s.firm_id.isin(ids)]
  rosterrows.append(dict(model=model,roster=label,firms=len(ids),treated_firms=z[z.Treat.eq(1)].firm_id.nunique(),rows=len(z),note='descriptive subset only; original estimation sample unchanged; all-years completeness conditions on post availability'))
  for (y,t),g in z.groupby(['year','Treat']):
   annual.append(dict(model=model,roster=label,year=y,Treat=t,n=len(g),SYN_w_mean=g.SYN_w.mean(),SYN_raw_mean=g.SYN.mean(),SYN_w_sd=g.SYN_w.std(),SYN_w_median=g.SYN_w.median(),n_weeks_mean=g.n_weeks.mean(),available_share=len(g)/len(roster[roster.firm_id.isin(ids)&roster.Treat.eq(t)])))
  m=z.groupby(['year','Treat']).SYN_w.mean().unstack()
  for y,row in m.iterrows():gaps.append(dict(model=model,roster=label,year=y,gap_treated_minus_control=row[1]-row[0],gap_relative_to_2014=(row[1]-row[0])-(m.loc[2014,1]-m.loc[2014,0])))
 # Exact descriptive year-to-year identity, not a coefficient decomposition.
 for t in [0,1]:
  g=s[s.Treat.eq(t)]
  for y in range(2010,2022):
   a=g[g.year.eq(y-1)].set_index('firm_id').SYN_w;b=g[g.year.eq(y)].set_index('firm_id').SYN_w
   common=a.index.intersection(b.index);within=(b.loc[common]-a.loc[common]).mean()
   entry=b.mean()-b.loc[common].mean();exitpart=a.loc[common].mean()-a.mean();delta=b.mean()-a.mean()
   assert abs(delta-within-entry-exitpart)<1e-12
   comp.append(dict(model=model,Treat=t,year=y,n_prev=len(a),n_current=len(b),n_common=len(common),entries=len(b.index.difference(a.index)),exits=len(a.index.difference(b.index)),total_mean_change=delta,common_firm_change=within,entry_composition=entry,exit_composition=exitpart))
 # Baseline industry composition; do not find/drop "bad" industries.
 for (code,t),g in roster.groupby(['industry2014','Treat']):
  mix.append(dict(model=model,industry2014=code,Treat=t,firms=len(g),share_within_group=len(g)/len(roster[roster.Treat.eq(t)])))
 # 2014 levels; one value per firm for pooled pre-period averages; no p-values.
 for label,z in [('year2014',s[s.year.eq(2014)].set_index('firm_id')),('pre2009_2014_firm_mean',s[s.year.lt(2015)].groupby('firm_id')[['Treat','SYN_w']+controls].mean()),('pre2012_2014_firm_mean',s[s.year.between(2012,2014)].groupby('firm_id')[['Treat','SYN_w']+controls].mean())]:
  for v in ['SYN_w']+controls:
   a=z.loc[z.Treat.eq(1),v].dropna();b=z.loc[z.Treat.eq(0),v].dropna();den=np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2)
   balances.append(dict(model=model,comparison=label,variable=v,n_treat=len(a),n_control=len(b),mean_treat=a.mean(),mean_control=b.mean(),sd_treat=a.std(),sd_control=b.std(),SMD=(a.mean()-b.mean())/den if den>0 else np.nan,control_p05=b.quantile(.05),control_p95=b.quantile(.95),treated_outside_control_p05_p95=((a<b.quantile(.05))|(a>b.quantile(.95))).mean(),note='descriptive SMD, not a test or propensity-score overlap criterion'))
 # Pair every year with 2014: same firms for that pair, zero imputation.
 pivot=s.pivot(index='firm_id',columns='year',values='SYN_w')
 for y in range(2009,2022):
  if y==2014:continue
  q=pivot[[2014,y]].dropna();q['delta']=q[y]-q[2014];q['Treat']=q.index.map(roster.set_index('firm_id').Treat);q['industry']=q.index.map(roster.set_index('firm_id').industry2014)
  a=q[q.Treat.eq(1)];b=q[q.Treat.eq(0)];dd=a.delta.mean()-b.delta.mean()
  pairrows.append(dict(model=model,year=y,baseline_year=2014,paired_firms=len(q),n_treat=len(a),n_control=len(b),treated_change=a.delta.mean(),control_change=b.delta.mean(),difference_in_changes=dd))
  centered=q.delta-q.delta.mean();q['centered']=centered
  subtotal=0.
  for (code,t),g in q.groupby(['industry','Treat']):
   ngrp=len(a) if t==1 else len(b);c=(1 if t==1 else -1)*g.centered.sum()/ngrp;subtotal+=c
   contributions.append(dict(model=model,comparison=f'{y}_minus_2014',industry2014=code,Treat=t,firms=len(g),mean_change=g.delta.mean(),group_share=len(g)/ngrp,centered_descriptive_contribution=c,note='sums to paired unadjusted difference in changes; NOT contribution to FE regression beta'))
  assert abs(subtotal-dd)<1e-12
 # Baseline-to-post averages for an exactly fixed full-coverage descriptive roster.
 q=pivot.loc[sorted(allids)].copy(); info=roster.set_index('firm_id')
 for period,years in [('early_pre',range(2009,2012)),('near_pre',range(2012,2015)),('near_post',range(2015,2019)),('late_post',range(2019,2022)),('all_post',range(2015,2022))]:
  q['delta']=q[list(years)].mean(axis=1)-q[list(range(2009,2015))].mean(axis=1);q['Treat']=q.index.map(info.Treat);q['industry']=q.index.map(info.industry2014)
  cen=q.delta-q.delta.mean();q['centered']=cen;dd=q[q.Treat.eq(1)].delta.mean()-q[q.Treat.eq(0)].delta.mean();subtotal=0.
  for (code,t),g in q.groupby(['industry','Treat']):
   ngrp=(q.Treat==t).sum();c=(1 if t==1 else -1)*g.centered.sum()/ngrp;subtotal+=c
   contributions.append(dict(model=model,comparison=f'fixed13_{period}_minus_pre2009_2014',industry2014=code,Treat=t,firms=len(g),mean_change=g.delta.mean(),group_share=len(g)/ngrp,centered_descriptive_contribution=c,note='full-coverage diagnostic roster, not estimation sample; baseline pre2009-2014, annual equal weights'))
  assert abs(subtotal-dd)<1e-12
 checks.append(dict(model=model,N=len(s),firms=s.firm_id.nunique(),treated_firms=s[s.Treat.eq(1)].firm_id.nunique(),industry_codes=roster.industry2014.nunique(),mixed_Treat_industry_codes=int((roster.groupby('industry2014').Treat.nunique()>1).sum()),duplicates=int(s.duplicated(['firm_id','year']).sum()),Treat_changes=int((s.groupby('firm_id').Treat.nunique()>1).sum())))
for (y,t),s in d[d.old_H0_sample.eq(1)].groupby(['year','Treat']):
 for v in controls:missing.append(dict(year=y,Treat=t,variable=v,N_H0=len(s),missing=int(s[v].isna().sum()),H8_excluded=int((s.old_H8_sample!=1).sum())))
for data,name in [(annual,'annual_group_means.csv'),(gaps,'annual_treatment_control_gaps.csv'),(comp,'year_change_composition_identity.csv'),(balances,'prepolicy_balance.csv'),(pairrows,'same_firm_change_vs_2014.csv'),(contributions,'industry_descriptive_contributions.csv'),(mix,'baseline_industry_composition.csv'),(missing,'control_missingness_by_group_year.csv'),(rosterrows,'descriptive_roster_audit.csv'),(checks,'frozen_sample_checks.csv')]:save(data,name)
# Period summaries equally weight calendar years; they are not static DID estimates.
periods=[]
gapdf=pd.DataFrame(gaps)
for (model,roster),z in gapdf.groupby(['model','roster']):
 for period,lo,hi in [('early_pre',2009,2011),('near_pre',2012,2014),('near_post',2015,2018),('late_post',2019,2021),('all_pre',2009,2014),('all_post',2015,2021)]:
  g=z[z.year.between(lo,hi)];periods.append(dict(model=model,roster=roster,period=period,years=len(g),mean_annual_gap=g.gap_treated_minus_control.mean()))
save(periods,'period_mean_gaps.csv')
events=pd.read_csv(FULL/'event_results.csv');save(events,'existing_full_event_results_readonly.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(x['unchanged'] for x in after);js(after,'protected_after.json')
js(dict(regressions_run=0,new_DTA_files=0,original_data_modified=False,original_G1_unchanged=True,regression_sample_changed=False,source_data_rows=len(d),peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start,all_decomposition_identities_verified=True),'audit_execution.json')
print(pd.DataFrame(rosterrows).to_string(index=False));print(pd.DataFrame(periods).query('model=="H8"').to_string(index=False));print(pd.DataFrame(balances).query('model=="H8" and comparison=="year2014"')[['variable','n_treat','n_control','mean_treat','mean_control','SMD']].to_string(index=False))
