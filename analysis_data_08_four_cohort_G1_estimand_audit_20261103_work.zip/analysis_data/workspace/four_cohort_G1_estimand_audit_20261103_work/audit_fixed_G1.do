version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/four_cohort_G1_estimand_audit_20261103_work/outputs"
log using "`out'/G1_estimand_audit.log", text replace
which reghdfe
use "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta", clear
isid firm_id stack_id annual_report_year
assert TreatPost==treated_in_stack*Post
assert Post==(event_time>=0)
assert event_time==annual_report_year-cohort_report_year
assert annual_report_year==syn_year-1
assert inrange(event_time,-3,2)
keep if sample_g1==1
assert _N==24659
local x "Size_w_exact MB_parent_w_exact Lev_w_exact"
tempname mh eh jh lh vh
tempfile main events joint contrasts covar
postfile `mh' str24 model long N clusters double coefficient SE t p CI_low CI_high df_r df_m df_a using `main', replace
postfile `eh' str24 term int event_time double coefficient SE t p CI_low CI_high using `events', replace
postfile `jh' str32 test double F df_num df_den p using `joint', replace
postfile `lh' str40 contrast double coefficient SE t p CI_low CI_high df_r using `contrasts', replace
postfile `vh' str24 row_term str24 col_term double covariance using `covar', replace

* The unchanged formal static model.
reghdfe SYN_CSRC_FAMILY_w_exact TreatPost `x', absorb(firm_stack_id cohort_year_id) vce(cluster firm_id) residuals(u_static)
assert e(N)==24659
gen byte static_es=e(sample)
assert static_es==1
estimates store static_G1
estimates save "`out'/static_G1_audit.ster", replace
scalar b_static=_b[TreatPost]
scalar b_size=_b[Size_w_exact]
scalar b_mb=_b[MB_parent_w_exact]
scalar b_lev=_b[Lev_w_exact]
scalar se_static=_se[TreatPost]
scalar df_static=e(df_r)
scalar cr=invttail(e(df_r),.025)
post `mh' ("static_G1") (e(N)) (e(N_clust)) (_b[TreatPost]) (_se[TreatPost]) (_b[TreatPost]/_se[TreatPost]) (2*ttail(e(df_r),abs(_b[TreatPost]/_se[TreatPost]))) (_b[TreatPost]-cr*_se[TreatPost]) (_b[TreatPost]+cr*_se[TreatPost]) (e(df_r)) (e(df_m)) (e(df_a))

* Auxiliary projections only; no alternative outcome/control specifications.
quietly reghdfe TreatPost `x', absorb(firm_stack_id cohort_year_id) residuals(rd) tolerance(1e-12)
assert e(N)==24659
quietly reghdfe TreatPost, absorb(firm_stack_id cohort_year_id) residuals(d_fe) tolerance(1e-12)
assert e(N)==24659
gen double ry=u_static+b_static*rd
gen double y_adjusted=SYN_CSRC_FAMILY_w_exact-b_size*Size_w_exact-b_mb*MB_parent_w_exact-b_lev*Lev_w_exact
gen double rd_sq=rd^2
quietly summarize rd_sq, meanonly
scalar ss_rd=r(sum)
gen double outcome_weight=rd/ss_rd
gen double score_contribution=rd*ry/ss_rd

gen byte D_m2=treated_in_stack==1 & event_time==-2
gen byte D_m1=treated_in_stack==1 & event_time==-1
gen byte D_0=treated_in_stack==1 & event_time==0
gen byte D_p1=treated_in_stack==1 & event_time==1
gen byte D_p2=treated_in_stack==1 & event_time==2
foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
    assert inlist(`term',0,1)
    assert `term'==0 if treated_in_stack==0 | event_time==-3
    quietly summarize rd if `term'==1, meanonly
    local a_`term' : display %24.17g r(sum)/ss_rd
}

* The unchanged formal dynamic model; -3 remains the omitted reference.
reghdfe SYN_CSRC_FAMILY_w_exact D_m2 D_m1 D_0 D_p1 D_p2 `x', absorb(firm_stack_id cohort_year_id) vce(cluster firm_id) residuals(u_dynamic)
assert e(N)==24659
gen byte dynamic_es=e(sample)
assert dynamic_es==static_es
estimates save "`out'/dynamic_G1_audit.ster", replace
matrix V=e(V)
local terms "D_m2 D_m1 D_0 D_p1 D_p2"
local k=-2
foreach term of local terms {
    if "`term'"=="D_m1" local k=-1
    if "`term'"=="D_0" local k=0
    if "`term'"=="D_p1" local k=1
    if "`term'"=="D_p2" local k=2
    scalar cr=invttail(e(df_r),.025)
    post `eh' ("`term'") (`k') (_b[`term']) (_se[`term']) (_b[`term']/_se[`term']) (2*ttail(e(df_r),abs(_b[`term']/_se[`term']))) (_b[`term']-cr*_se[`term']) (_b[`term']+cr*_se[`term'])
    foreach other of local terms {
        local i=colnumb(V,"`term'")
        local j=colnumb(V,"`other'")
        post `vh' ("`term'") ("`other'") (V[`i',`j'])
    }
}
test D_m2 D_m1
post `jh' ("pre_joint") (r(F)) (r(df)) (r(df_r)) (r(p))
test D_0 D_p1 D_p2
post `jh' ("post_joint") (r(F)) (r(df)) (r(df_r)) (r(p))
test (D_m2=0) (D_m1=0) (D_0=D_p1) (D_0=D_p2)
post `jh' ("static_restrictions_joint") (r(F)) (r(df)) (r(df_r)) (r(p))

lincom (D_0+D_p1+D_p2)/3
post `lh' ("post_mean_vs_m3") (r(estimate)) (r(se)) (r(t)) (r(p)) (r(lb)) (r(ub)) (r(df))
lincom (D_m2+D_m1)/3
post `lh' ("pre_mean_vs_m3") (r(estimate)) (r(se)) (r(t)) (r(p)) (r(lb)) (r(ub)) (r(df))
lincom (D_0+D_p1+D_p2-D_m2-D_m1)/3
post `lh' ("post_mean_minus_pre_mean") (r(estimate)) (r(se)) (r(t)) (r(p)) (r(lb)) (r(ub)) (r(df))
lincom (`a_D_m2')*D_m2+(`a_D_m1')*D_m1+(`a_D_0')*D_0+(`a_D_p1')*D_p1+(`a_D_p2')*D_p2
assert abs(r(estimate)-b_static)<1e-8
post `lh' ("exact_static_projection_dynamic_V") (r(estimate)) (r(se)) (r(t)) (r(p)) (r(lb)) (r(ub)) (r(df))

gen double static_beta=b_static
gen double static_control_size=b_size
gen double static_control_mb=b_mb
gen double static_control_lev=b_lev
format rd d_fe ry y_adjusted u_static u_dynamic outcome_weight score_contribution %24.17g
export delimited firm_id stack_id annual_report_year syn_year cohort_report_year event_time treated_in_stack Post TreatPost firm_stack_id cohort_year_id SYN_CSRC_FAMILY_w_exact Size_w_exact MB_parent_w_exact Lev_w_exact static_es dynamic_es rd d_fe ry y_adjusted u_static u_dynamic outcome_weight score_contribution static_beta static_control_size static_control_mb static_control_lev using "`out'/observation_weight_audit_private.csv", replace
postclose `mh'
postclose `eh'
postclose `jh'
postclose `lh'
postclose `vh'
use `main', clear
export delimited using "`out'/static_reproduction.csv", replace
use `events', clear
export delimited using "`out'/dynamic_reproduction.csv", replace
use `joint', clear
export delimited using "`out'/joint_tests.csv", replace
use `contrasts', clear
export delimited using "`out'/static_dynamic_contrasts.csv", replace
use `covar', clear
export delimited using "`out'/dynamic_covariance.csv", replace
display as result "G1_ESTIMAND_AUDIT_COMPLETE"
log close
exit, clear
