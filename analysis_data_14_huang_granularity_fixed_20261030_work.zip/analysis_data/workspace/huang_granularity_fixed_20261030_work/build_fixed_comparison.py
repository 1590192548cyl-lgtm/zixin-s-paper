"""One prespecified industry-granularity check; bounded yearly memory."""
from __future__ import annotations
import ast
import gc
import hashlib
import json
import os
from pathlib import Path
import resource
import sqlite3
import time
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent
O=W/'outputs'; O.mkdir(exist_ok=True)
C=W/'cache'; C.mkdir(exist_ok=True)
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
RAW=P.parent/'原始数据'
OLD_CODE=P/'gao_exact_replication/01_build_csrc_family_syn.py'
IND=P/'data_work/industry_new_standardized.dta'
LATEST=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
OLD_SYN=P/'gao_exact_replication/outputs/syn_csrc_family_2010_2020.dta'
CUTS=P/'gao_exact_replication/outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_winsor_cutoffs.csv'
FILES=[RAW/'周度数据重下'/n for n in ['TRD_Week.dta','TRD_Week1.dta','TRD_Week2.dta']]
START=time.time()

def log(message):
    s=f'{time.strftime("%H:%M:%S")} {message}'
    print(s,flush=True)
    with (O/'build_progress.log').open('a',encoding='utf-8') as f:f.write(s+'\n')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def jsave(obj,name):
    (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(d,name):d.to_csv(O/name,index=False,encoding='utf-8-sig')

inputs=[OLD_CODE,IND,LATEST,OLD_SYN,CUTS,RAW/'公司基本信息/IPO_Cobasic.dta',W/'PRE_ANALYSIS_PLAN.md']+FILES
manifest=[{'file':str(f),'bytes':f.stat().st_size,'sha256':sha(f)} for f in inputs]
jsave(manifest,'input_manifest_before.json')
log(f'PID={os.getpid()}; one process; start input audit')

# Extract original pure functions, never execute the old top-level main/ETL.
source=OLD_CODE.read_text()
names={'firm_int','report_year_from_week','load_industry','add_market_returns','estimate_groups'}
nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names]
scope={'np':np,'pd':pd,'IND':IND,'FIN_PATTERN':r'银行|证券|保险|金融|信托',
       'CSRC_RULE':{**{y:'P0201' for y in range(2009,2012)},**{y:'P0207' for y in range(2012,2021)}}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(OLD_CODE),'exec'),scope)
firm_int=scope['firm_int']; year_from_week=scope['report_year_from_week']
ind=scope['load_industry']()
assert not ind.fykey.duplicated().any()
code=ind.IndustryCode2.astype(str).str.strip()
valid=code.str.fullmatch(r'[A-Z][0-9]+',na=False)
ind['alt_key']=(ind.selected_standard.astype(str)+'|'+code.where(code.str.startswith('C'),code.str[0])).where(valid)
ind['alt_id']=np.where(valid,pd.factorize(ind.alt_key,sort=True)[0]+1,np.nan)
lookup=ind.set_index('fykey')
save(ind[['firm_int','year','selected_standard','IndustryCode2','IndustryName2','industry_key','alt_key']], 'industry_granularity_keys.csv')

db=sqlite3.connect(C/'weekly_cache.sqlite')
db.execute('PRAGMA cache_size=-24000'); db.execute('PRAGMA temp_store=FILE')
done=C/'weekly_cache_complete.json'
week_hashes=[r['sha256'] for r in manifest if Path(r['file']) in FILES]
if not done.exists():
    assert not db.execute("SELECT name FROM sqlite_master WHERE name='weekly'").fetchone(), 'Partial cache requires review; no auto retry'
    db.execute('CREATE TABLE weekly(firm_int INTEGER, week_key INTEGER, report_year INTEGER, ret REAL, cap REAL, PRIMARY KEY(firm_int,week_key))')
    aset=set(firm_int(pd.read_stata(RAW/'公司基本信息/IPO_Cobasic.dta',columns=['Stkcd'],convert_categoricals=False).Stkcd).dropna().astype(int))
    audit=[]
    for file in FILES:
        read=kept=0
        with pd.read_stata(file,columns=['Stkcd','Trdwnt','Wsmvosd','Wretwd'],chunksize=75000,convert_categoricals=False) as reader:
            for ch in reader:
                read+=len(ch)
                fid=firm_int(ch.Stkcd)
                week=pd.to_numeric(ch.Trdwnt.astype(str).str.replace('-','',regex=False),errors='coerce')
                year=pd.Series(np.nan,index=ch.index)
                good=week.notna()
                year.loc[good]=year_from_week(week[good].astype(np.int64))
                keep=fid.notna()&good&year.between(2010,2020)&ch.Wretwd.notna()&ch.Wsmvosd.notna()&ch.Wsmvosd.gt(0)&fid.isin(aset)
                z=pd.DataFrame({'firm_int':fid[keep].astype(np.int32),'week_key':week[keep].astype(np.int32),
                                'report_year':year[keep].astype(np.int16),'ret':ch.loc[keep,'Wretwd'].astype(float),'cap':ch.loc[keep,'Wsmvosd'].astype(float)})
                db.executemany('INSERT INTO weekly VALUES(?,?,?,?,?)',z.itertuples(index=False,name=None))
                kept+=len(z)
                del ch,z,fid,week,year,keep
            db.commit()
        audit.append({'file':str(file),'rows_read':read,'rows_kept':kept})
        log(f'Weekly stream {file.name}: read {read:,}, kept {kept:,}')
    db.execute('CREATE INDEX year_idx ON weekly(report_year)');db.execute('CREATE INDEX week_idx ON weekly(week_key)');db.commit()
    done.write_text(json.dumps({'hashes':week_hashes,'audit':audit},ensure_ascii=False,indent=2),encoding='utf-8')
else:
    cached=json.loads(done.read_text());assert cached['hashes']==week_hashes
    audit=cached['audit'];log('Reuse complete hash-matched weekly cache')
jsave(audit,'weekly_read_audit.json')
weeks=pd.read_sql_query('SELECT DISTINCT week_key,report_year FROM weekly ORDER BY week_key',db)
wk=weeks.week_key.to_numpy()
prev=pd.Series(np.r_[np.nan,wk[:-1]],index=wk)
prevyear=pd.Series(weeks.report_year.to_numpy(),index=wk)

def industry_returns(d,field):
    a=d.copy()
    a['ind_id']=a[field]
    it=a.groupby(['week_key','ind_id'],sort=True).agg(inum=('num','sum'),iden=('cap','sum'),ifirms=('firm_int','nunique')).reset_index()
    a=a.merge(it,on=['week_key','ind_id'],how='left',validate='many_to_one')
    den=a.iden-a.cap
    a['INDRET']=np.where((den>0)&(a.ifirms>1),(a.inum-a.num)/den,np.nan)
    pair=a.firm_int.astype(np.int64)*10000+pd.to_numeric(a.prev_report_year,errors='coerce').fillna(-999).astype(np.int64)
    a['ind_id_lag']=pair.map(lookup[field])
    lag=it.rename(columns={'week_key':'prev_week_key','ind_id':'ind_id_lag','inum':'inum_lag','iden':'iden_lag','ifirms':'ifirms_lag'})
    a=a.merge(lag,on=['prev_week_key','ind_id_lag'],how='left',validate='many_to_one')
    # Original firm/week ordering is retained by left merges, as in old code.
    same=a.groupby('firm_int',sort=False).ind_id.shift(1).eq(a.ind_id_lag)&a.groupby('firm_int',sort=False).week_key.shift(1).eq(a.prev_week_key)
    owncap=a.own_cap_lag.where(same,0.0);ownnum=a.own_num_lag.where(same,0.0)
    denlag=a.iden_lag-owncap
    a['INDRET_lag']=np.where((denlag>0)&((a.ifirms_lag-same.astype(int))>0),(a.inum_lag-ownnum)/denlag,np.nan)
    return a

for year in range(2010,2021):
    oldfile=C/f'old_syn_{year}.csv';newfile=C/f'new_syn_{year}.csv'
    if oldfile.exists() and newfile.exists():
        log(f'Reuse completed SYN year {year}');continue
    first=int(weeks.loc[weeks.report_year.eq(year),'week_key'].min())
    extra=prev.loc[first]
    query='SELECT * FROM weekly WHERE report_year=?'
    params=[year]
    if pd.notna(extra):query+=' OR week_key=?';params.append(int(extra))
    d=pd.read_sql_query(query+' ORDER BY firm_int,week_key',db,params=params)
    d['prev_week_key']=d.week_key.map(prev);d['prev_report_year']=d.prev_week_key.map(prevyear)
    d['num']=d.ret*d.cap
    consec=d.groupby('firm_int',sort=False).week_key.shift(1).eq(d.prev_week_key)
    d['own_cap_lag']=d.groupby('firm_int',sort=False).cap.shift(1).where(consec,0.0)
    d['own_num_lag']=d.groupby('firm_int',sort=False).num.shift(1).where(consec,0.0)
    fy=d.firm_int.astype(np.int64)*10000+d.report_year.astype(np.int64)
    d['ind_id']=fy.map(lookup.ind_id);d['alt_id']=fy.map(lookup.alt_id)
    financial=fy.map(lookup.financial).fillna(True)
    d=d.loc[d.ind_id.notna()&~financial].copy()
    d=scope['add_market_returns'](d)
    # Unknown industry members remain in the ORIGINAL market pool.
    old=scope['estimate_groups'](industry_returns(d,'ind_id'))
    new=scope['estimate_groups'](industry_returns(d,'alt_id'))
    old.loc[old.syn_year.eq(year)].to_csv(oldfile,index=False)
    new.loc[new.syn_year.eq(year)].to_csv(newfile,index=False)
    log(f'Year {year}: {len(d):,} weekly rows incl lag; old/new annual {len(old):,}/{len(new):,}; peak RSS {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2:.1f} MiB')
    del d,old,new,fy,consec,financial
    gc.collect()
db.close()

old=pd.concat([pd.read_csv(C/f'old_syn_{y}.csv') for y in range(2010,2021)],ignore_index=True)
new=pd.concat([pd.read_csv(C/f'new_syn_{y}.csv') for y in range(2010,2021)],ignore_index=True)
stored=pd.read_stata(OLD_SYN,convert_categoricals=False)
key=['firm_int','syn_year']
check=stored.merge(old,on=key,how='outer',suffixes=('_stored','_rebuilt'),indicator=True,validate='one_to_one')
assert check._merge.eq('both').all(), 'Old SYN keys do not reproduce'
check['SYN_abs_diff']=(check.SYN_CSRC_FAMILY_stored-check.SYN_CSRC_FAMILY_rebuilt).abs()
check['R2_abs_diff']=(check.R2_CSRC_FAMILY_stored-check.R2_CSRC_FAMILY_rebuilt).abs()
assert check.SYN_abs_diff.max()<1e-8
assert check.R2_abs_diff.max()<1e-10
assert check.n_weeks_CSRC_FAMILY_stored.eq(check.n_weeks_CSRC_FAMILY_rebuilt).all()
save(check[key+['SYN_abs_diff','R2_abs_diff']],'old_syn_reproduction_check.csv')
log(f'Old SYN reproduced: {len(check):,}; max |difference| {check.SYN_abs_diff.max():.3g}')
assert not new.duplicated(key).any()
new=new.rename(columns={'firm_int':'firm_id','SYN_CSRC_FAMILY':'SYN_huang_grain',
                        'R2_CSRC_FAMILY':'R2_huang_grain','n_weeks_CSRC_FAMILY':'n_weeks_huang_grain'})
save(new,'alternative_syn_firm_year.csv')
base=pd.read_stata(LATEST,convert_categoricals=False)
frozen=base.copy()
data=base.merge(new.drop(columns=['rank_CSRC_FAMILY']),on=['firm_id','syn_year'],how='left',validate='many_to_one')
cut=pd.read_csv(CUTS).set_index('variable').loc['SYN_CSRC_FAMILY']
lo,hi=float(cut.p1),float(cut.p99)
assert np.allclose(data.SYN_CSRC_FAMILY_w_exact,np.clip(data.SYN_CSRC_FAMILY,lo,hi),rtol=0,atol=1e-12,equal_nan=True)
data['SYN_huang_grain_w']=data.SYN_huang_grain.clip(lo,hi)
original=data.sample_g1.eq(1)
common=original&data.SYN_huang_grain_w.notna()
data['common_sample']=common.astype(np.int8)
attrition=[]
for ix in data.index[original&~common]:
    attrition.append({**data.loc[ix,['firm_id','stack_id','syn_year','cohort_report_year','event_time']].to_dict(),
                      'reason':'new_SYN_unavailable_no_valid_historical_code2'})
while True:
    s=data.loc[common]
    prepost=s.groupby(['firm_id','stack_id']).Post.nunique()
    bad_pairs=set(prepost.loc[prepost.lt(2)].index)
    bad_pair_mask=pd.MultiIndex.from_frame(data[['firm_id','stack_id']]).isin(bad_pairs)&common
    singleton=np.zeros(len(data),dtype=bool)
    for fe in ['firm_stack_id','cohort_year_id']:
        count=s[fe].value_counts();singleton|=common&data[fe].map(count).eq(1).fillna(False)
    remove=bad_pair_mask|singleton
    if not remove.any():break
    for ix in data.index[remove]:
        attrition.append({**data.loc[ix,['firm_id','stack_id','syn_year','cohort_report_year','event_time']].to_dict(),
                          'reason':'no_prepost_after_common_case' if bad_pair_mask[ix] else 'mechanical_FE_singleton'})
    common=common&~remove
data['common_sample']=common.astype(np.int8)
save(pd.DataFrame(attrition),'common_sample_attrition.csv')
for col in frozen:
    assert data[col].equals(frozen[col]),f'Frozen original column changed: {col}'
assert sorted(data.loc[common,'cohort_report_year'].unique())==[2013,2015,2016,2017]
cells=data.loc[common].groupby(['cohort_report_year','event_time','treated_in_stack']).size().reset_index(name='N')
assert len(cells)==48 and cells.N.gt(0).all()
save(cells,'common_event_support.csv')
data.to_stata(O/'analysis_granularity_compare.dta',write_index=False,version=118)
save(data.loc[original,['firm_id','stack_id','syn_year','cohort_report_year','event_time','treated_in_stack','sample_g1','common_sample']], 'frozen_sample_keys.csv')
summaries=[]
for var in ['SYN_CSRC_FAMILY','SYN_huang_grain','SYN_CSRC_FAMILY_w_exact','SYN_huang_grain_w']:
    v=data.loc[common,var]
    summaries.append({'variable':var,'N':len(v),'mean':v.mean(),'sd':v.std(),'median':v.median(),'min':v.min(),'max':v.max()})
save(pd.DataFrame(summaries),'outcome_descriptives_common.csv')
stats={'old_syn_reproduction_N':len(check),'old_syn_max_abs_difference':check.SYN_abs_diff.max(),
       'original_G1_N':int(original.sum()),'common_G1_N':int(common.sum()),'excluded_stack_rows':int((original&~common).sum()),
       'cohorts':[2013,2015,2016,2017],'controls':['Size_w_exact','MB_parent_w_exact','Lev_w_exact'],
       'corr_raw_common':data.loc[common,['SYN_CSRC_FAMILY','SYN_huang_grain']].corr().iloc[0,1],
       'corr_winsor_common':data.loc[common,['SYN_CSRC_FAMILY_w_exact','SYN_huang_grain_w']].corr().iloc[0,1],
       'new_low_clips_common':int(data.loc[common,'SYN_huang_grain'].lt(lo).sum()),
       'new_high_clips_common':int(data.loc[common,'SYN_huang_grain'].gt(hi).sum()),
       'fixed_syn_cutoffs':[lo,hi],'baseline':-3,'peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,
       'elapsed_seconds':time.time()-START,'no_source_modified':None}
after=[{**r,'sha256_after':sha(r['file']),'unchanged':sha(r['file'])==r['sha256']} for r in manifest]
assert all(r['unchanged'] for r in after)
stats['no_source_modified']=True
jsave(after,'input_integrity_after_build.json');jsave(stats,'pre_regression_audit.json')
log(f'PREPARE_COMPLETE common_N={common.sum():,}; no new regression yet')
