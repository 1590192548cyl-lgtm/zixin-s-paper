# 收到补充数据后的断点续跑

当前已完成01/02/03/04，正式回归次数为0。不要重新流式扫描已完成的约285万条财务记录，也不要扫描年报。

1. 先读outputs/continuation_status.json、G1_true_data_repair_status_report.md、CSMAR下载清单.md及REPAIR_PLAN.md。
2. 原stack读取four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta，26711行、原G1=24659；其SHA256在primary_input_manifest_before.csv，原缩尾点在frozen_winsor_cutoffs.csv。
3. 用户新数据必须按CSMAR真实字段和说明检查，重点P0201同期一级/完整行业码及全A股同行成员。不要把10条已知M记录与20条未知记录任意拼接。
4. 当前missing-control分类已核清：608个IPO前年度、68个非正权益年度、10个上市后缺市值年度。未找到真实缺失字段可新增填补值，applied_repair_ledger.csv为空。不要把这些损失当作尚未执行的补齐工作。
5. 如新市值资料确有相同定义、相同日期的原始值，单独核验后写新修复清单；不得套用IPO价、前值或以后年度值。年度市值原单位千元，母公司权益/资产/负债为元。
6. 三控制因果属性仅审查，未替换。继续冻结Size_w_exact、MB_parent_w_exact、Lev_w_exact。
7. 如必须复核SYN，只复用huang_granularity_fixed_20261030_work/cache/weekly_cache.sqlite（只读、按年），不重载原周收益；保持原二级分组原则及P0201/P0207年度规则，不把黄文式非制造业一级方案混入。
8. 生成新的修复副本，保留所有原设计字段和值的对照，以及每条真实修复/不可修复原因，不覆盖原DTA。不新增stack外记录。
9. 完成来源核验与冻结设计检查后，原静态G1和原-3基准事件研究各运行一次；核对actual e(sample)，公司firm_id聚类，[-3,+2]，两FE不变；不用p值决定回退任何修复。
10. 报告全部结果与限制后停止。不要进行新权重、新控制组合、删批次、机制或异质性。

本轮报告中的已核验输入指纹应与源文件对照；新下载仅做增量审计。归档不包含328MB财务SQLite或103MB周缓存，避免复制大文件。
