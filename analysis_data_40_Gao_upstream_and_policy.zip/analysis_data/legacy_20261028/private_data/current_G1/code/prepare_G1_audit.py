from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

WORK=Path('/Users/macpro/Documents/New project/four_cohort_G1_latest_recheck_20261028_work')
O=WORK/'outputs'
O.mkdir(parents=True,exist_ok=True)
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
OLD=P/'gao_exact_replication/outputs/official_table3_rebuild'
STRICT=P/'gao_treatment_eligibility_strict_recheck'
INPUTS={'old_stack':OLD/'official_table3_stack_analysis.dta','strict_stack':STRICT/'official_table3_stack_analysis.dta',
        'old_models':OLD/'official_table3_main_models.csv','old_events':OLD/'official_table3_event_study.csv','old_joint':OLD/'official_table3_joint_tests.csv',
        'strict_models':STRICT/'strict_2013_manual_recheck_main_models.csv','strict_events':STRICT/'strict_2013_manual_recheck_event_study.csv','strict_joint':STRICT/'strict_2013_manual_recheck_joint_tests.csv',
        'strict_decisions':STRICT/'strict_2013_manual_eligibility_decisions.csv','strict_first_treat':STRICT/'official_table3_corrected_first_treat.csv',
        'confirmed_evidence':P/'static_model_correction_20261028/confirmed_policy_evidence.csv',
        'confirmed_earlier57':P/'first_treatment_validity_audit/confirmed_earlier_treatment_corrections.csv',
        'historical_G1_code':Path('/Users/macpro/Documents/New project/gao_exact_replication_work/24_run_strict_2013_manual_recheck.do'),
        'plan':WORK/'PRE_ANALYSIS_PLAN.md'}
K=['firm_id','stack_id','annual_report_year']
X=['Size_w_exact','MB_parent_w_exact','Lev_w_exact']
Y='SYN_CSRC_FAMILY_w_exact'
COLS=K+['syn_year','cohort_report_year','event_time','treated_in_stack','Post','TreatPost','firm_stack_id','cohort_year_id',
         'sample_g1','sample_g1_raw','SYN_CSRC_FAMILY','R2_CSRC_FAMILY','n_weeks_CSRC_FAMILY',Y,'Size','MB_parent','Lev']+X


def sha(f):
    h=hashlib.sha256()
    with Path(f).open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(d,f):d.to_csv(O/f,index=False,encoding='utf-8-sig')


save(pd.DataFrame([{'role':role,'path':str(f),'bytes':f.stat().st_size,'sha256_before':sha(f)} for role,f in INPUTS.items()]),'input_manifest.csv')
old=pd.read_stata(INPUTS['old_stack'],columns=COLS,convert_categoricals=False)
strict=pd.read_stata(INPUTS['strict_stack'],columns=COLS,convert_categoricals=False)
checks=[]


def audit_stack(d,label):
    assert not d.duplicated(K).any()
    assert d.event_time.between(-3,2).all()
    assert d.annual_report_year.eq(d.syn_year-1).all()
    assert d.event_time.eq(d.annual_report_year-d.cohort_report_year).all()
    assert d.Post.eq(d.event_time.ge(0)).all()
    assert d.TreatPost.eq(d.treated_in_stack*d.Post).all()
    assert sorted(d.cohort_report_year.unique().tolist())==[2013,2015,2016,2017]
    assert d.groupby(['firm_id','stack_id']).treated_in_stack.nunique().eq(1).all()
    assert d.groupby('firm_stack_id').apply(lambda g:len(g[['firm_id','stack_id']].drop_duplicates()),include_groups=False).eq(1).all()
    assert d.groupby('cohort_year_id').apply(lambda g:len(g[['cohort_report_year','annual_report_year']].drop_duplicates()),include_groups=False).eq(1).all()
    s=d.loc[d.sample_g1.eq(1)]
    assert np.isfinite(s[[Y,'TreatPost']+X]).all().all()
    assert s.groupby(['firm_id','stack_id']).Post.nunique().eq(2).all()
    assert s.n_weeks_CSRC_FAMILY.ge(30).all()
    cells=s.groupby(['cohort_report_year','event_time','treated_in_stack']).size()
    assert len(cells)==4*6*2 and cells.gt(0).all()
    checks.append({'version':label,'check':'structural_checks','violations':0,'stack_N':len(d),'G1_N':len(s),'cohorts':4})


audit_stack(old,'OLD_0345')
audit_stack(strict,'STRICT_2013')
ev=pd.read_csv(INPUTS['confirmed_evidence'],dtype={'firm_id':str})
ev['firm_id']=ev.firm_id.str.zfill(6)
first=ev.sort_values(['firm_id','report_year','evidence_id']).drop_duplicates('firm_id')
first=first[['firm_id','report_year','evidence_id','source_file','iidg_id','basis','evidence_excerpt']].rename(columns={'firm_id':'firm_code','report_year':'confirmed_report_year'})
q=strict.copy()
q['firm_code']=q.firm_id.astype(int).astype(str).str.zfill(6)
q=q.merge(first,on='firm_code',how='left',validate='many_to_one')
q['polluted_control']=q.treated_in_stack.eq(0)&q.confirmed_report_year.le(q.cohort_report_year+2)
q['prior_exposed_treated']=q.treated_in_stack.eq(1)&q.confirmed_report_year.lt(q.cohort_report_year)
assert not q.prior_exposed_treated.any(),'Unexpected additional treatment conflict; do not silently reassign treatment.'
bad=q.loc[q.polluted_control].copy()
bad['exclusion_reason']='confirmed_policy_exposure_within_stack_window'
save(bad[K+['firm_code','cohort_report_year','event_time','syn_year','sample_g1','confirmed_report_year','evidence_id','source_file','iidg_id','basis','exclusion_reason']], 'latest_control_exclusions.csv')
save(bad[['firm_code','cohort_report_year','confirmed_report_year','evidence_id','source_file','iidg_id','basis','evidence_excerpt']].drop_duplicates(), 'latest_control_exclusion_evidence.csv')
latest=q.loc[~q.polluted_control,COLS].copy()
audit_stack(latest,'LATEST')

decisions=pd.read_csv(INPUTS['strict_decisions'],dtype={'firm_id':str})
positive=decisions.loc[decisions.strict_include.eq(1)].copy()
assert len(positive)==24
save(positive[['firm_id','company_name','iidg_id','cohort_year','strict_include','decision_rule','report_url']], 'frozen_2013_positive_decisions.csv')

diff_summary=[]
frozen=['syn_year','cohort_report_year','event_time','Post','SYN_CSRC_FAMILY',Y,'Size','MB_parent','Lev']+X
for name,a,b in [('old_to_strict',old,strict),('strict_to_latest',strict,latest),('old_to_latest',old,latest)]:
    z=a.merge(b,on=K,how='outer',suffixes=('_old','_new'),indicator=True,validate='one_to_one')
    common=z._merge.eq('both')
    z['treatment_changed']=common&z.treated_in_stack_old.ne(z.treated_in_stack_new)
    z['TreatPost_changed']=common&z.TreatPost_old.ne(z.TreatPost_new)
    for v in frozen:
        neq=~np.isclose(z.loc[common,v+'_old'],z.loc[common,v+'_new'],rtol=0,atol=0,equal_nan=True)
        assert not neq.any(),(name,v,int(neq.sum()))
        checks.append({'version':name,'check':'common_frozen_'+v,'violations':int(neq.sum()),'stack_N':int(common.sum()),'G1_N':None,'cohorts':4})
    for v in ['firm_stack_id','cohort_year_id']:
        c=z.loc[common,[v+'_old',v+'_new']].drop_duplicates()
        assert c.groupby(v+'_old')[v+'_new'].nunique().eq(1).all()
        assert c.groupby(v+'_new')[v+'_old'].nunique().eq(1).all()
        checks.append({'version':name,'check':'categorical_FE_equivalence_'+v,'violations':0,'stack_N':len(c),'G1_N':None,'cohorts':4})
    g1old=z.sample_g1_old.eq(1);g1new=z.sample_g1_new.eq(1)
    diff_summary.append({'comparison':name,'old_stack_N':len(a),'new_stack_N':len(b),'common_stack_N':int(common.sum()),
                         'old_only_stack_N':int(z._merge.eq('left_only').sum()),'new_only_stack_N':int(z._merge.eq('right_only').sum()),
                         'common_treatment_changed':int(z.treatment_changed.sum()),'common_TreatPost_changed':int(z.TreatPost_changed.sum()),
                         'old_G1_N':int(g1old.sum()),'new_G1_N':int(g1new.sum()),'common_G1_N':int((g1old&g1new).sum()),
                         'old_only_G1_N':int((g1old&~g1new).sum()),'new_only_G1_N':int((g1new&~g1old).sum())})
    keep=K+['_merge','treated_in_stack_old','treated_in_stack_new','TreatPost_old','TreatPost_new','sample_g1_old','sample_g1_new','treatment_changed','TreatPost_changed']
    save(z.loc[z._merge.ne('both')|z.treatment_changed|g1old.ne(g1new),keep],name+'_changed_rows.csv')
save(pd.DataFrame(diff_summary),'sample_and_coding_difference_summary.csv')
save(pd.DataFrame(checks),'frozen_values_and_design_audit.csv')

common_keys=old.loc[old.sample_g1.eq(1),K].merge(latest.loc[latest.sample_g1.eq(1),K],on=K,how='inner',validate='one_to_one')
key_index=pd.MultiIndex.from_frame(common_keys)
for label,d in [('old',old),('strict',strict),('latest',latest)]:
    d=d.copy()
    d['common_G1_sample']=(pd.MultiIndex.from_frame(d[K]).isin(key_index)&d.sample_g1.eq(1)).astype(np.int8)
    d.to_stata(O/(label+'_G1_analysis.dta'),write_index=False,version=118)
    save(d.loc[d.sample_g1.eq(1),K+['syn_year','cohort_report_year','event_time','treated_in_stack','TreatPost','common_G1_sample']],label+'_G1_sample_keys.csv')

cells=[]
for label,d in [('old',old),('strict',strict),('latest',latest)]:
    g=d.loc[d.sample_g1.eq(1)].groupby(['cohort_report_year','event_time','treated_in_stack']).agg(N=('firm_id','size'),firms=('firm_id','nunique')).reset_index()
    g.insert(0,'version',label)
    cells.append(g)
save(pd.concat(cells),'event_period_support.csv')
times=latest[['cohort_report_year','annual_report_year','syn_year','event_time']].drop_duplicates().sort_values(['cohort_report_year','event_time'])
save(times,'four_cohort_time_mapping.csv')
summary={'old_stack_N':len(old),'strict_stack_N':len(strict),'latest_stack_N':len(latest),
         'old_G1_N':int(old.sample_g1.sum()),'strict_G1_N':int(strict.sample_g1.sum()),'latest_G1_N':int(latest.sample_g1.sum()),
         'latest_additional_control_rows_excluded':len(bad),'latest_affected_control_firms':int(bad.firm_id.nunique()),
         'latest_affected_firm_stacks':len(bad[['firm_id','stack_id']].drop_duplicates()),'old_latest_common_G1_N':len(common_keys),
         'strict_positive_decisions':len(positive),'cohorts':[2013,2015,2016,2017],'event_baseline':-3,
         'controls':X,'outcome':Y,'fixed_effects':['firm_stack_id','cohort_year_id'],'cluster':'firm_id'}
(O/'pre_regression_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(pd.DataFrame(diff_summary).to_string(index=False))
