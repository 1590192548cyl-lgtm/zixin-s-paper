from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs'
m=pd.read_csv(O/'static_results.csv');e=pd.read_csv(O/'event_results.csv');j=pd.read_csv(O/'joint_tests.csv');d=pd.read_stata(O/'final_analysis.dta',convert_categoricals=False)
assert (O/'fixed_models.log').read_text().count('HUANG_BASIC_FIXED_COMPLETE')>=1
assert len(m)==2 and len(e)==24 and len(j)==6
controls=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4']
for v in ['Dual','Big4']:assert d[v].dropna().isin([0,1]).all()
assert d.SYN_w.notna().all() and d.Treat.isin([0,1]).all()
audit=[];excluded=[]
for model in ['H0','H8']:
 s=pd.read_csv(O/f'{model}_sample_private.csv');a=s.static_sample.eq(1);r=m.set_index('model').loc[model]
 assert a.sum()==r.N and s.loc[a,'firm_id'].nunique()==r.clusters
 assert s.static_sample.eq(s.event_sample).all()
 assert e[e.model.eq(model)].SE.gt(0).all()
 keys=pd.MultiIndex.from_frame(s[['firm_id','year']]);ds=d.set_index(['firm_id','year']).reindex(keys)
 complete=ds.SYN_w.notna() if model=='H0' else ds.sample8.eq(1)
 for row in s.loc[complete.to_numpy()&~a,['firm_id','year']].to_dict('records'):excluded.append(dict(model=model,**row,reason='reghdfe_singleton'))
 audit.append(dict(model=model,N=int(a.sum()),clusters=int(r.clusters),treated_firms=int(r.treated_firms),control_firms=int(r.clusters-r.treated_firms),pre2015_obs=int((a&s.year.lt(2015)).sum()),post2015_obs=int((a&s.year.ge(2015)).sum()),Treat_observation_share=float(s.loc[a,'Treat'].mean()),same_static_dynamic_sample=True,all_12_dynamic_coefficients_estimable=True))
pd.DataFrame(audit).to_csv(O/'model_sample_audit.csv',index=False);pd.DataFrame(excluded).to_csv(O/'FE_singleton_exclusions_private.csv',index=False)
miss=pd.DataFrame([dict(variable=v,missing_observations=int(d[v].isna().sum()),nonmissing_observations=int(d[v].notna().sum()),mean=d[v].mean(),sd=d[v].std(),min=d[v].min(),max=d[v].max()) for v in controls]);miss.to_csv(O/'eight_controls_audit.csv',index=False)
assert (O/'event_study_plot.png').exists()
def tab(frame,columns):
 out=['|'+'|'.join(columns)+'|','|'+'|'.join(['---']*len(columns))+'|']
 for _,r in frame.iterrows():
  out.append('|'+'|'.join(f'{r[c]:.6f}' if isinstance(r[c],(float,np.floating)) else str(r[c]) for c in columns)+'|')
 return '\n'.join(out)
main=tab(m,['model','N','clusters','treated_firms','coefficient','SE','p','CI_low','CI_high'])
jt=tab(j,['model','test','F','p']);ev=tab(e[e.event_time.isin([-3,-2,0,1,2,3,4,5,6])],['model','event_time','coefficient','SE','p','CI_low','CI_high'])
report=f'''# 黄文基础重建复现结果

日期2026-11-03。**未经作者确认的重建复现；不是黄文完整13控制复现，不是原G1。**

## 结论

按事先固定规则，H0、H8静态系数均为负并达到5%，未达到1%。但是全事前联合检验均拒绝为零，**本轮不能声称平行趋势通过或已确认政策因果效应**。仅邻近两期联合不拒绝，不能替代全事前检验。没有据结果缩短窗口、删除批次、改行业边界或继续试模型。

## 静态结果

{main}

两模型均公司、年度FE，公司聚类。H0无控制，H8为Size、Age、Lev、Cent、Top10、Dual、Board、Big4。回归前分别7,888和7,614条，reghdfe各自动删除1条公司FE singleton，最终N如上，清单见FE_singleton_exclusions_private.csv。共648家公司、439家处理公司、209家对照公司。静态与对应动态的实际样本完全相同。

H0和H8可用样本不同，系数变化不能全部归因于控制变量。没有额外估计共同样本模型。变量非缺失和范围见eight_controls_audit.csv；没有均值/前后填补。

## 联合检验

pre_all：2009—2013全部五个事前交互项联合为0；pre_near：仅2012、2013两期联合为0；post_all：2015—2021全部七个事后交互项联合为0。均以2014为省略期。

{jt}

完整事前检验H0 p={j[(j.model=='H0')&(j.test=='pre_all')].p.iloc[0]:.6f}、H8 p={j[(j.model=='H8')&(j.test=='pre_all')].p.iloc[0]:.6f}，5%下均不通过。2011（事件期-4）系数分别约-0.1751、-0.1725，单项p约0.0322、0.0335，说明政策前已有值得关注的相对差异；不能据此直接断言2011数据错误，也不能把它删除。

## 动态结果

{ev}

完整12期动态输出含-6和-5，见event_results.csv。2014基准点在图中设0，不估计该项，不给基准点人为添加置信区间。所有12项均可估计，无吸收或零标准误。图横轴覆盖全样本年，不为显示效果改变系数或CI。

H8的政策当年、+1、+2均为负但均未达到10%；+3达到10%，+4达到5%，+6达到1%。这些单期结果不推翻全事前拒绝的结论，也不是选择主结果的依据。未做多重检验校正，不把单期显著性当成额外已验证发现。

## 与黄文的比较和重要偏离

黄文表3报告：无控制列(1)系数-0.129、t=-2.17；完整13控制列(3)系数-0.153、t=-2.67，均N=7,227、625家公司。当前H8少5控制，当前H0未限制在原文13控制共同完整样本，因此不能宣称数值复制成功。公司数和样本数接近也不是复制证明。

1. 用户确认保留2015年前已上市公司；原文印为剔除此类公司，解释性修正未经作者确认。
2. Treat取2014行业固定分组。设备C34—C40、化工C26、零售F52、A/B/D/G/I门类、医药C27、地产K70；金融J排除。这是冻结的研究者行业代码解释，11名称有官方依据，但完整代码边界未获作者确认；不因本次系数改变映射。
3. 2009—2011行业用本公司2012 P0207回溯，这是前视且可能错分的重建假设，不是已获得历史2012版原始数据；没有把P0201和P0207字母直接混用。
4. 缺完整ST历史，使用行业源2009—2021所有可见简称识别ST/*ST等；无法排除仅在2009前或年内未被来源捕捉的ST情况。退市只按截至2021末，不用之后的退市状态。筛选后资格692家公司，但不一定每家有可估计SYN。
5. 新计算SYN使用全部有有效周收益与流通市值的上海A股构造市场池，不先剔除金融/ST；行业池要求行业可识别。市场不留一、行业留一，市场及行业均包含同一周原始可用成员；五月至次年四月，ISO周的周一归属，完整周>=30、矩阵满秩。这些周历和最小周数细节原文没有充分交代。没有复用原G1的SYN。
6. 8控制没有ROA、BM、Turn、List、SOE；未猜国企编码，未拿换手率累加或总股数比值伪装缺失指标。期初资产取真实2008等前一年资产；不套Gao控制滞后规则。连续变量固定1%/99%缩尾，二元变量不缩尾，原G1缩尾点不动。
7. 研究年5月1日之前上市的规则在估计前执行，排除45条IPO时点不合格观测，留有清单。IPO600018两条历史记录取最早，留有原记录。程序在估计前有路径/完整性校验修正，但未据任何估计结果修样本；完成的DID估计只有2静态+2动态。
8. 原文图示-3至+3但尾期处理未交代；本次全年度单列、2014唯一基准。不能截取只显示两项事前且不显著的图来宣称全期平行趋势通过。

## 保护、资源及后续

原始输入和原G1的前后SHA256一致，见input_integrity_after_build.json。原G1的四批次结果未覆盖、未重跑。年报未扫描。周数据40,000行分块、SYN按年保存、Stata单线程；周收益缓存约44 MB，仅保留于工作目录以便断点恢复。构造进程结束时峰值内存指标未成功落盘，本报告不虚报整个流程的实测峰值。

下一步若要更接近原文，应核实作者/官方行业名单、早期行业回溯和完整ST历史；这是识别核验，不是再搜索显著规格。补齐缺失控制可以提高完整复现程度，但不能预先保证消除事前差异或达到1%。**本轮完成后停止。**

## 主要文件

- PRE_ANALYSIS_PLAN.md：估计前口径及偏离；final_pre_regression_audit.json记录计划SHA256。
- static_results.csv、event_results.csv、joint_tests.csv：实际结果。
- event_study_plot.png：两个模型全期图。
- final_analysis.dta：仅本轮分析数据；含CSMAR衍生信息，不公开上传。
- model_sample_audit.csv、各模型sample_private.csv：实际估计样本及识别检查。
- pre_regression_listing_cutoff_exclusions.csv、FE_singleton_exclusions_private.csv：客观排除记录。
- fixed_models.log、四份ster：Stata日志和估计存档。

数据和private清单受CSMAR许可约束；不能直接作为公开GitHub交接包发布。
'''
(O/'huang_basic_reconstruction_report.md').write_text(report,encoding='utf-8')
print(m.to_string(index=False));print(j.to_string(index=False));print('QA AND REPORT COMPLETE')
