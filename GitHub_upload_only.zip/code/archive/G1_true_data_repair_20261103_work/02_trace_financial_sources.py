"""Indexed checkpoint queries and streamed genuine CSMAR source checks."""
from pathlib import Path
import ast,gc,hashlib,json,re,resource,sqlite3,time
from typing import Iterable
from zipfile import ZipFile
from xml.etree.ElementTree import iterparse
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
R=Path('/Users/macpro/Desktop/毕业论文');P=R/'堆叠DID重跑'
DB=Path('/Users/macpro/Documents/New project/gao_full_controls_work/gao_controls_staging.sqlite')
PARSER=Path('/Users/macpro/Documents/New project/gao_full_controls_work/construct_gao_full_controls.py')
BASE=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
targets=pd.read_csv(O/'G1_financial_target_keys.csv',dtype={'firm_code':str})
targetkeys={(int(r.firm_id),int(r.annual_report_year)) for r in targets.itertuples()}
def save(x,n):x.to_csv(O/n,index=False,encoding='utf-8-sig',float_format='%.17g')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def log(s):
    v=time.strftime('%H:%M:%S')+' '+s
    print(v,flush=True)
    with (O/'financial_source_trace.log').open('a',encoding='utf-8') as f:f.write(v+'\n')
ns={'re':re,'ZipFile':ZipFile,'iterparse':iterparse,'Path':Path,'Iterable':Iterable,
    'NS':'{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'}
names={'cell_text','load_shared_strings','iter_xlsx_records'}
nodes=[n for n in ast.parse(PARSER.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(PARSER),'exec'),ns)
records=ns['iter_xlsx_records']
def firm(v):
    try:return int(str(v).strip().removesuffix('.0'))
    except (TypeError,ValueError):return None
def number(v):
    try:
        a=float(v)
        return a if np.isfinite(a) else np.nan
    except (TypeError,ValueError):return np.nan

c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True)
c.execute('PRAGMA cache_size=-12000')
raw=[]
for t in targets.itertuples():
    r={'firm_id':int(t.firm_id),'firm_code':f'{t.firm_id:06d}','fiscal_year':int(t.annual_report_year)}
    for v in ['total_assets','total_liabilities','equity_parent','market_value_thousand']:
        q=c.execute('SELECT value,conflict,source_id,rows_seen FROM num_values WHERE variable=? AND firm_id=? AND year=?',
                    (v,f'{t.firm_id:06d}',int(t.annual_report_year))).fetchone()
        r[v]=q[0] if q and q[1]==0 else np.nan
        r[v+'_checkpoint_conflict']=int(q[1]) if q else 0
    raw.append(r)
raw=pd.DataFrame(raw)
ipo=pd.read_stata(R/'原始数据/公司基本信息/IPO_Cobasic.dta',columns=['Stkcd','Listdt'],convert_categoricals=False)
ipo['firm_id']=pd.to_numeric(ipo.Stkcd,errors='coerce');ipo['listing_date']=pd.to_datetime(ipo.Listdt,errors='coerce')
ipo=ipo.sort_values('listing_date').drop_duplicates('firm_id',keep='first')
raw=raw.merge(ipo[['firm_id','listing_date']],on='firm_id',how='left',validate='many_to_one')
assert raw.listing_date.notna().all()
raw['fiscal_year_before_listing']=raw.fiscal_year.lt(raw.listing_date.dt.year)
raw['reason']=np.select([raw.fiscal_year_before_listing,raw.equity_parent.le(0),raw.market_value_thousand.isna()],
    ['before_A_share_listing_year','nonpositive_parent_equity_under_frozen_rule','missing_annual_market_value_after_listing'],default='needs_further_validation')
assert not raw.reason.eq('needs_further_validation').any()
save(raw,'financial_gap_source_diagnosis_private.csv')
sources=[
 ('balance',R/'控制变量/资产合计负债合计所有者权益合计/FS_Combas.xlsx'),
 ('old_assets',R/'原始数据/资产总计.xlsx'),
 ('liabilities',R/'控制变量/负债合计/FS_Combas.xlsx'),
 ('equity_report',R/'控制变量/归属于母公司权益/RM_BSGen.xlsx'),
 ('equity_report_part2',R/'控制变量/归属于母公司权益/RM_BSGen1.xlsx'),
 ('market',R/'控制变量/总市值/TRD_Year.xlsx'),
 ('market_duplicate',R/'控制变量/年个股回报率/TRD_Year.xlsx')]
manifest=[];candidates=[];seenhash={}
for typ,p in sources:
    digest=sha(p)
    cache=c.execute('SELECT path,signature,rows_seen FROM source_done WHERE source_id=?',(typ,)).fetchone()
    signature=f'{p.stat().st_size}:{p.stat().st_mtime_ns}'
    m={'source_type':typ,'path':str(p),'bytes':p.stat().st_size,'sha256':digest,
       'checkpoint_signature_match':int(cache is not None and cache[1]==signature)}
    if digest in seenhash:
        m.update({'duplicate_of':seenhash[digest],'rows_streamed':0,'target_records':0})
        manifest.append(m);continue
    seenhash[digest]=str(p)
    n=nt=0
    log('Stream '+typ)
    for rownum,r in records(p):
        n+=1
        fid=firm(r.get('Stkcd',r.get('Symbol')))
        if fid is None:continue
        date=r.get('Accper',r.get('EndDate',r.get('Trdynt','')))
        try:yr=int(str(date)[:4])
        except ValueError:continue
        if (fid,yr) not in targetkeys:continue
        if typ.startswith('market'):
            fields={'market_value_thousand':'Ysmvttl'}
        else:
            if not re.match(r'^\d{4}-12-31',str(date)):continue
            if r.get('Typrep',r.get('StateTypeCode','')).strip()!='A':continue
            if typ.startswith('equity_report'):
                if r.get('DataType')!='1' or r.get('DataSource')!='0' or r.get('Source')!='年报':continue
            fields={'total_assets':'A001000000','total_liabilities':'A002000000','equity_parent':'A003100000'}
        for variable,field in fields.items():
            if field not in r:continue
            value=number(r[field])
            if not np.isfinite(value):continue
            candidates.append({'firm_id':fid,'firm_code':f'{fid:06d}','fiscal_year':yr,'variable':variable,'value':value,
                               'source_file':str(p),'source_row':rownum,'asof_date':str(date),
                               'DataSign':r.get('DataSign',''),'ActRelDate':r.get('ActRelDate','')})
            nt+=1
    m.update({'duplicate_of':'','rows_streamed':n,'target_records':nt})
    manifest.append(m)
    log(f'{typ}: rows {n:,}, target numeric records {nt:,}; peak RSS {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2:.1f} MiB')
    gc.collect()
c.close()
save(pd.DataFrame(manifest),'financial_source_manifest_before.csv')
cand=pd.DataFrame(candidates)
save(cand,'genuine_financial_candidate_records_private.csv')

# Preserve all contradictory/revised source values instead of selecting positive equity.
comparison=[];patches=[]
look=raw.set_index(['firm_id','fiscal_year'])
for (fid,yr,var),g in cand.groupby(['firm_id','fiscal_year','variable']):
    old=look.loc[(fid,yr),var]
    values=g.value.to_numpy(); unique=np.unique(values)
    consistent=bool(np.allclose(values,values[0],atol=1e-6,rtol=1e-10))
    comparison.append({'firm_id':fid,'firm_code':f'{fid:06d}','fiscal_year':yr,'variable':var,'checkpoint_value':old,
                       'candidate_min':values.min(),'candidate_max':values.max(),'source_records':len(g),'distinct_values':len(unique),
                       'same_definition_source_consistent':int(consistent),'old_nonmissing_matches':int(pd.notna(old) and np.allclose(values,old,atol=1e-6,rtol=1e-10))})
    if pd.isna(old) and consistent:
        patches.append({'firm_id':fid,'firm_code':f'{fid:06d}','fiscal_year':yr,'variable':var,'old_value':np.nan,'new_value':values[0],
                        'source_file':g.iloc[0].source_file,'source_row':int(g.iloc[0].source_row),'rule':'same_field_same_year_consolidated_genuine_value_only'})
save(pd.DataFrame(comparison),'financial_source_crosscheck_private.csv')
patch=pd.DataFrame(patches,columns=['firm_id','firm_code','fiscal_year','variable','old_value','new_value','source_file','source_row','rule'])
save(patch,'proposed_raw_field_repairs_private.csv')
new=raw.copy()
for r in patch.itertuples():new.loc[new.firm_id.eq(r.firm_id)&new.fiscal_year.eq(r.fiscal_year),r.variable]=r.new_value
new['Size_candidate']=np.log(new.total_assets.where(new.total_assets.gt(0)))
new['Lev_candidate']=new.total_liabilities/new.total_assets.where(new.total_assets.gt(0))
new['MB_parent_candidate']=1000*new.market_value_thousand/new.equity_parent.where(new.equity_parent.gt(0))
new['G1_controls_complete_after_source_check']=new[['Size_candidate','Lev_candidate','MB_parent_candidate']].notna().all(axis=1).astype(int)
save(new,'financial_repair_feasibility_private.csv')

stack=pd.read_stata(BASE,convert_categoricals=False)
z=stack.merge(raw[['firm_id','fiscal_year','reason','listing_date','fiscal_year_before_listing']],
              left_on=['firm_id','annual_report_year'],right_on=['firm_id','fiscal_year'],how='left',validate='many_to_one')
direct=z.loc[z[['Size','MB_parent','Lev']].isna().any(axis=1)]
summary=direct.groupby('reason').agg(stack_observations=('firm_id','size'),treated_stack_observations=('treated_in_stack','sum')).reset_index()
summary['unique_firm_years']=[len(raw.loc[raw.reason.eq(v)]) for v in summary.reason]
save(summary,'financial_missingness_by_structural_reason.csv')
details=z.loc[z.sample_g1.eq(0),['firm_id','stack_id','annual_report_year','cohort_report_year','event_time','Post','treated_in_stack','sample_g1_raw','reason']].copy()
# Every support-only loss is linked to the missing observations in its own pair.
pair_causes=direct.groupby(['firm_id','stack_id']).reason.agg(lambda v:';'.join(sorted(set(v))))
details['pair_missing_causes']=[pair_causes.get((int(r.firm_id),int(r.stack_id)),'') for r in details.itertuples()]
save(details,'all_2052_loss_reason_links_private.csv')
pending=raw.loc[raw.reason.eq('missing_annual_market_value_after_listing')].copy()
weekdb=Path('/Users/macpro/Documents/New project/huang_granularity_fixed_20261030_work/cache/weekly_cache.sqlite')
conn=sqlite3.connect('file:'+str(weekdb)+'?mode=ro',uri=True)
weekcounts=[]
for r in pending.itertuples():
    q=conn.execute('SELECT count(*),min(week_key),max(week_key) FROM weekly WHERE firm_int=? AND week_key BETWEEN ? AND ?',
                  (int(r.firm_id),int(r.fiscal_year)*100+1,int(r.fiscal_year)*100+53)).fetchone()
    weekcounts.append({'firm_id':r.firm_id,'firm_code':r.firm_code,'fiscal_year':r.fiscal_year,'eligible_weekly_return_rows_calendar_year':q[0],
                       'min_week':q[1],'max_week':q[2],'interpretation':'no eligible trading rows; annual market value remains genuinely unavailable in local sources' if q[0]==0 else 'annual source missing; requires original source clarification'})
conn.close()
save(pd.DataFrame(weekcounts),'post_listing_market_value_gap_checks.csv')
after=[]
for r in manifest:
    q=Path(r['path']);after.append({'path':str(q),'sha256_before':r['sha256'],'sha256_after':sha(q),'unchanged':sha(q)==r['sha256']})
save(pd.DataFrame(after),'financial_source_integrity_after.csv')
assert all(r['unchanged'] for r in after)
result={'financial_target_firm_years':len(raw),'source_rows_streamed':sum(r['rows_streamed'] for r in manifest),
        'proposed_missing_raw_field_fills':len(patch),'complete_G1_control_firm_years_recoverable':int(new.G1_controls_complete_after_source_check.sum()),
        'structural_reason_counts':raw.reason.value_counts().to_dict(),
        'post_listing_missing_market_firm_years':len(pending),'Python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
(O/'financial_trace_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
print(summary.to_string(index=False),flush=True)
