version 18.0
clear all
set more off
set varabbrev off

local out "/Users/macpro/Documents/New project/gao_exact_replication_work/outputs/official_table3_rebuild"
use "`out'/official_table3_stack_analysis.dta", clear

tempname h
tempfile results
postfile `h' int cohort long N clusters treated_firms double coefficient SE t p CI_low CI_high using `results', replace
foreach c in 2013 2015 2016 2017 {
    quietly reghdfe SYN_CSRC_FAMILY_w_exact TreatPost if cohort_report_year==`c', ///
        absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local tv=`b'/`se'
    local pv=2*ttail(e(df_r),abs(`tv'))
    local crit=invttail(e(df_r),.025)
    tempvar es tag
    gen byte `es'=e(sample)
    egen byte `tag'=tag(firm_id) if `es' & treated_in_stack==1
    quietly count if `tag'==1
    local nt=r(N)
    post `h' (`c') (e(N)) (e(N_clust)) (`nt') (`b') (`se') (`tv') (`pv') ///
        (`b'-`crit'*`se') (`b'+`crit'*`se')
    drop `es' `tag'
}
postclose `h'
use `results', clear
export delimited using "`out'/official_table3_cohort_diagnostics.csv", replace
exit, clear
