version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
log using "outputs/drdid_fixed.log", text append
which drdid
which drdid_predict
program define onepair
    syntax, Label(string) Outcome(string)
    capture confirm file "outputs/`label'_done.txt"
    if !_rc {
        display "ALREADY_COMPLETE_SKIP `label'"
        exit
    }
    capture confirm file "outputs/`label'.ster"
    if !_rc {
        display as error "Stored estimate exists without completion marker: export-only recovery required. No refit."
        exit 459
    }
    use "outputs/dr_analysis_wide.dta", clear
    isid firm_id
    assert inlist(Treat,0,1)
    local x "X_Size X_Age X_Lev X_Cent X_Top10 X_Dual X_Board X_Big4"
    foreach v of local x {
        assert !missing(`v')
    }
    drop if missing(y_pre,`outcome')
    local firms=_N
    count if Treat==1
    local nt=r(N)
    assert `nt'>8 & (`firms'-`nt')>8
    gen double Y1=`outcome'
    gen double Y0=y_pre
    keep firm_id Treat `x' Y0 Y1
    reshape long Y, i(firm_id) j(period)
    gen byte time=period+1
    isid firm_id time
    bysort firm_id (time): assert _N==2 & Treat[1]==Treat[2]
    display as result "FIXED_PAIR_START `label'"
    drdid Y `x', ivar(firm_id) time(time) tr(Treat) drimp ///
        cluster(firm_id) pscoretrim(1) stub(r_)
    estimates save "outputs/`label'.ster"
    assert e(N)==2*`firms'
    assert e(N_clust)==`firms'
    assert e(sample)==1
    matrix bb=e(b)
    matrix vv=e(V)
    scalar att=bb[1,1]
    scalar se=sqrt(vv[1,1])
    tempname hh
    tempfile rr
    postfile `hh' str24 model long firms treated controls panel_rows clusters ///
        double ATT SE z p CI_low CI_high using `rr', replace
    post `hh' ("`label'") (`firms') (`nt') (`firms'-`nt') (e(N)) (e(N_clust)) ///
        (att) (se) (att/se) (2*normal(-abs(att/se))) ///
        (att-invnormal(.975)*se) (att+invnormal(.975)*se)
    postclose `hh'
    matrix iptb=e(iptb)
    matrix score double score=iptb
    gen double pscore=invlogit(score)
    gen double att_weight=cond(Treat==1,1,exp(score))
    keep if period==0
    assert !missing(r_att,pscore,att_weight)
    assert pscore>0 & pscore<1
    assert att_weight>0 & att_weight<.
    gen str24 model="`label'"
    rename r_att recentered_IF
    keep firm_id Treat `x' model recentered_IF pscore att_weight
    export delimited using "outputs/`label'_influence_private.csv", replace
    preserve
        use `rr', clear
        export delimited using "outputs/`label'_result.csv", replace
    restore
    tempname ff
    file open `ff' using "outputs/`label'_done.txt", write
    file write `ff' "FIXED_PAIR_COMPLETE `label'" _n
    file close `ff'
    display as result "FIXED_PAIR_COMPLETE `label'"
end

onepair, label(main_static) outcome(y_meanpost)
foreach y in 2009 2010 2011 2012 2015 2016 2017 2018 2019 2020 2021 {
    onepair, label(year_`y') outcome(y_`y')
}
display as result "ALL_FIXED_DRDID_COMPLETE"
log close
