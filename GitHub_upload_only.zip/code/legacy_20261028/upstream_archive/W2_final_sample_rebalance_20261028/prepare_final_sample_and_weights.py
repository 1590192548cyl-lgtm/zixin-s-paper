from __future__ import annotations

import ast
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

WORK=Path('/Users/macpro/Documents/New project/w2_final_sample_rebalance_20261028_work')
OUT=WORK/'outputs'
OUT.mkdir(parents=True,exist_ok=True)
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
PREV=P/'static_model_correction_20261028'
SOURCE=PREV/'static_eligible_stack.dta'
LEGACY=Path('/Users/macpro/Documents/New project/pretrend_balance_weighting_work/build_entropy_weights.py')
X='Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w'.split()
Z='Size_w Lev_w MB_w Age_w Turnover_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w'.split()
KEY=['firm_id','stack_id','syn_year']
GK=['firm_id','stack_id']


def sha(f):
    h=hashlib.sha256()
    with Path(f).open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def save(df,name): df.to_csv(OUT/name,index=False,encoding='utf-8-sig')


sources={'eligible_stack':SOURCE,'prior_model_results':PREV/'static_original_vs_corrected.csv',
         'prior_estimation_samples':PREV/'estimation_sample_audit.csv','prior_policy_exclusions':PREV/'excluded_observation_list.csv',
         'original_entropy_code':LEGACY,'frozen_plan':WORK/'PRE_ANALYSIS_PLAN.md'}
manifest=[{'role':k,'path':str(f),'bytes':f.stat().st_size,'sha256_before':sha(f)} for k,f in sources.items()]
save(pd.DataFrame(manifest),'input_manifest.csv')

d=pd.read_stata(SOURCE,convert_categoricals=False)
assert len(d)==33658
assert not d.duplicated(KEY).any()
assert d.objective_keep.eq(1).all()
assert d.control_fiscal_year.eq(d.syn_year-1).all()
assert d.TreatPost.eq(d.treated_in_stack.eq(1)&d.event_time.ge(0)).all()
assert d.event_time.between(-3,2).all()
assert sorted(d.cohort_report_year.unique().tolist())==[2015,2016,2017,2018,2019]
assert d.groupby('firm_id').firm_cluster_id.nunique().eq(1).all()
assert d.groupby('firm_cluster_id').firm_id.nunique().eq(1).all()

complete=np.isfinite(d[['SYN_w_Gao','TreatPost']+X]).all(axis=1)
current=complete.copy()
reasons=pd.Series('',index=d.index,dtype=object)
reasons.loc[~complete]='W2_annual_variable_missing'
flow=[]


def flow_row(stage,mask,iteration=0):
    for co in [None,2015,2016,2017,2018,2019]:
        a=d.loc[mask if co is None else mask&d.cohort_report_year.eq(co)]
        flow.append({'stage':stage,'iteration':iteration,'cohort':'all' if co is None else co,'N':len(a),
                     'firms':a.firm_id.nunique(),'firm_stacks':len(a[GK].drop_duplicates()),
                     'treated_firms':a.loc[a.treated_in_stack.eq(1),'firm_id'].nunique(),
                     'control_firms':a.loc[a.treated_in_stack.eq(0),'firm_id'].nunique()})


flow_row('objective_eligible_stack',pd.Series(True,index=d.index))
flow_row('W2_annual_complete',current)
iteration=0
while True:
    iteration+=1
    previous=current.copy()
    bases=d.loc[current&d.event_time.eq(-1),GK]
    base_index=pd.MultiIndex.from_frame(bases)
    available_base=pd.MultiIndex.from_frame(d[GK]).isin(base_index)
    no_base=current&~available_base
    reasons.loc[no_base]='firm_stack_no_complete_minus1'
    current&=available_base
    flow_row('require_complete_minus1',current,iteration)
    a=d.loc[current]
    singleton=a.groupby('firm_stack_id').firm_stack_id.transform('size').le(1)|a.groupby('cohort_year_id').cohort_year_id.transform('size').le(1)
    ids=singleton.index[singleton]
    reasons.loc[ids]='FE_singleton_before_weight_estimation'
    current.loc[ids]=False
    flow_row('remove_FE_singletons',current,iteration)
    if current.equals(previous): break
    assert iteration<20,'Unexpected selection closure; do not change rules.'

assert sorted(d.loc[current,'cohort_report_year'].unique().tolist())==[2015,2016,2017,2018,2019]
final=d.loc[current].copy()
baseline=final.loc[final.event_time.eq(-1)].copy()
assert not baseline.duplicated(GK).any()
assert len(baseline)==len(final[GK].drop_duplicates())
assert baseline[Z].notna().all().all()

old_es=pd.read_csv(PREV/'estimation_sample_audit.csv',dtype={'firm_id':str})
old_ids=set(old_es.loc[old_es.es_corrected_W2.eq(1),'audit_row_id'])
d['was_prior_W2_sample']=d.audit_row_id.isin(old_ids)
d['final_sample']=current.astype(np.int8)
d['selection_reason']=reasons
assert set(final.audit_row_id).issubset(old_ids)
selection_cols=['audit_row_id']+KEY+['cohort_report_year','event_time','treated_in_stack','was_prior_W2_sample','final_sample','selection_reason']
save(d[selection_cols],'sample_selection_audit.csv')
save(d.loc[~current,selection_cols],'new_sample_exclusions.csv')
save(d.loc[~current&d.was_prior_W2_sample,selection_cols],'excluded_from_prior_W2.csv')
save(pd.DataFrame(flow),'sample_attrition.csv')
final_keys=final[['audit_row_id']+KEY+['cohort_report_year','event_time','treated_in_stack']].sort_values(KEY)
save(final_keys,'final_sample_keys_frozen_before_weights.csv')
key_hash=sha(OUT/'final_sample_keys_frozen_before_weights.csv')

# Extract only the original function definitions. Never import/execute the legacy top-level ETL.
source=LEGACY.read_text()
tree=ast.parse(source)
names={'entropy_weights','weighted_sd','smd'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in nodes}==names
original_z=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BALANCE_VARS' for t in n.targets))
assert original_z==Z
namespace={'np':np,'math':math}
module=ast.Module(body=nodes,type_ignores=[])
exec(compile(module,str(LEGACY),'exec'),namespace)
entropy_weights=namespace['entropy_weights']
weighted_sd=namespace['weighted_sd']
smd=namespace['smd']
functions=[]
for n in nodes:
    text_source=ast.get_source_segment(source,n)
    functions.append({'function':n.name,'source_path':str(LEGACY),'source_start_line':n.lineno,'source_end_line':n.end_lineno,
                      'exact_function_sha256':hashlib.sha256(text_source.encode()).hexdigest(),'algorithm_modified':False})
save(pd.DataFrame(functions),'entropy_algorithm_provenance.csv')

weights=[]
balances=[]
diagnostics=[]
for co,g in baseline.groupby('cohort_report_year',sort=True):
    t=g.loc[g.treated_in_stack.eq(1)].sort_values('firm_id')
    c=g.loc[g.treated_in_stack.eq(0)].sort_values('firm_id')
    assert len(t)>1 and len(c)>1
    assert t.ebal_weight.eq(1).all()
    target=t[Z].mean().to_numpy(dtype=float)
    probabilities,status=entropy_weights(c[Z].to_numpy(dtype=float),target)
    wc=probabilities*len(t)
    assert np.isfinite(wc).all() and (wc>0).all()
    assert abs(wc.sum()-len(t))<1e-8
    for _,r in t.iterrows(): weights.append({'firm_id':r.firm_id,'stack_id':int(r.stack_id),'cohort_report_year':int(co),'treated':1,'old_weight':r.ebal_weight,'new_weight':1.0})
    for i,(_,r) in enumerate(c.iterrows()): weights.append({'firm_id':r.firm_id,'stack_id':int(r.stack_id),'cohort_report_year':int(co),'treated':0,'old_weight':r.ebal_weight,'new_weight':float(wc[i])})
    for v in Z:
        xt=t[v].to_numpy(dtype=float); xc=c[v].to_numpy(dtype=float)
        for label,wt,ww in [('unweighted',np.ones(len(t)),np.ones(len(c))),('old_weights',t.ebal_weight.to_numpy(),c.ebal_weight.to_numpy()),('new_weights',np.ones(len(t)),wc)]:
            mt=float(np.average(xt,weights=wt)); mc=float(np.average(xc,weights=ww))
            sd_t=weighted_sd(xt,wt); sd_c=weighted_sd(xc,ww)
            val=smd(mt,mc,sd_t,sd_c)
            balances.append({'cohort':int(co),'weighting':label,'variable':v,'treated_N':len(t),'control_N':len(c),
                             'treated_mean':mt,'control_mean':mc,'treated_sd':sd_t,'control_sd':sd_c,
                             'SMD':val,'abs_SMD':abs(val),'mean_difference':mt-mc})
    for label,w in [('old_weights',c.ebal_weight.to_numpy()),('new_weights',wc)]:
        ess=w.sum()**2/(w@w)
        diagnostics.append({'cohort':int(co),'weighting':label,'treated_N':len(t),'control_N':len(c),
                            'control_sum':w.sum(),'treated_sum':float(len(t)),'control_ESS':ess,'ESS_over_control_N':ess/len(c),
                            'min_control_weight':w.min(),'median_control_weight':np.median(w),'max_control_weight':w.max(),
                            'p95_control_weight':np.quantile(w,.95),'p99_control_weight':np.quantile(w,.99),
                            'max_control_weight_share':w.max()/w.sum(),'original_warning_rule_triggered':int(w.max()>20 or ess/len(c)<.30),
                            **(status if label=='new_weights' else {})})

w=pd.DataFrame(weights)
assert not w.duplicated(GK).any()
bal=pd.DataFrame(balances)
assert bal.loc[bal.weighting.eq('new_weights'),'abs_SMD'].max()<1e-5
save(w,'entropy_weights_final_sample.csv')
w.to_stata(OUT/'entropy_weights_final_sample.dta',write_index=False,version=118)
save(bal,'baseline_balance_by_variable.csv')
save(pd.DataFrame(diagnostics),'weight_diagnostics.csv')
save(bal.groupby(['cohort','weighting']).agg(max_abs_SMD=('abs_SMD','max'),mean_abs_SMD=('abs_SMD','mean'),variables_over_010=('abs_SMD',lambda s:int(s.gt(.1).sum()))).reset_index(),'baseline_balance_summary.csv')

final=final.merge(w[['firm_id','stack_id','new_weight']],on=GK,how='left',validate='many_to_one')
assert final.new_weight.notna().all()
assert final.groupby(GK).new_weight.nunique().eq(1).all()
assert final.ebal_weight.notna().all()
assert len(final)==int(current.sum())
final.to_stata(OUT/'W2_final_sample_rebalanced.dta',write_index=False,version=118)
save(baseline[GK+['cohort_report_year','syn_year','control_fiscal_year','treated_in_stack']+Z],'baseline_covariates_used_for_weights.csv')
summary={'source_eligible_rows':len(d),'annual_W2_complete_rows':int(complete.sum()),'final_rows':len(final),
         'prior_W2_N':len(old_ids),'lost_prior_W2_rows':int((~current&d.was_prior_W2_sample).sum()),
         'final_firms':int(final.firm_id.nunique()),'final_treated_firms':int(final.loc[final.treated_in_stack.eq(1),'firm_id'].nunique()),
         'firm_stacks':len(baseline),'cohorts':sorted(int(x) for x in final.cohort_report_year.unique()),
         'singleton_and_baseline_closure_iterations':iteration,'sample_key_sha256_before_weights':key_hash,
         'new_weight_max_abs_SMD':float(bal.loc[bal.weighting.eq('new_weights'),'abs_SMD'].max()),
         'legacy_entropy_source_sha256':sha(LEGACY),'all_new_optimizers_success':bool(pd.DataFrame(diagnostics).query("weighting=='new_weights'").optimizer_success.eq(1).all())}
(OUT/'pre_regression_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(pd.DataFrame(diagnostics).loc[lambda x:x.weighting.eq('new_weights'),['cohort','treated_N','control_N','control_ESS','ESS_over_control_N','max_control_weight','optimizer_success']].to_string(index=False))
