version 18
clear all
set more off
capture log close _all
log using "outputs/export_only.log", text replace
tempname h
tempfile r
postfile `h' str24 model double ATT double SE double z double p double CI_low double CI_high ///
    long panel_rows long clusters using `r', replace
foreach m in main_static year_2009 year_2010 year_2011 year_2012 year_2015 year_2016 year_2017 year_2018 year_2019 year_2020 year_2021 {
    estimates use "outputs/`m'.ster"
    matrix b=e(b)
    matrix V=e(V)
    scalar att=b[1,1]
    scalar se=sqrt(V[1,1])
    post `h' ("`m'") (att) (se) (att/se) (2*normal(-abs(att/se))) ///
        (att-invnormal(.975)*se) (att+invnormal(.975)*se) (e(N)) (e(N_clust))
}
postclose `h'
use `r', clear
export delimited using "outputs/drdid_results_full_precision.csv", replace
display "EXPORT_ONLY_COMPLETE_NO_REFITS"
log close
