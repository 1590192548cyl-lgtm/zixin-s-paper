from pathlib import Path
import hashlib
import json
import resource
import pandas as pd

OUT = Path(__file__).resolve().parent
SOURCE = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_full_controls/gao_controls_firm_year_2009_2025.dta')
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

before = sha(SOURCE)
cols = ['firm_id','fiscal_year','total_assets','total_assets_lag','total_liabilities',
        'equity_total','equity_parent','market_value','ROA','Big4']
a = pd.read_stata(SOURCE, columns=cols, convert_categoricals=False)
b = a[a.fiscal_year.between(2009, 2021)]
stats = {}
for v in cols[2:]:
    stats[v] = {'n_nonmissing': int(b[v].count()), 'missing_rate': float(b[v].isna().mean()),
                'mean': float(b[v].mean()), 'std': float(b[v].std()),
                'min': float(b[v].min()), 'max': float(b[v].max())}
result = {
    'scope': 'Existing Gao source panel only; NOT Huang selected sample',
    'source': str(SOURCE), 'sha256_before': before, 'sha256_after': sha(SOURCE),
    'rows': len(a), 'firms': int(a.firm_id.nunique()),
    'min_year': int(a.fiscal_year.min()), 'max_year': int(a.fiscal_year.max()),
    'duplicate_firm_year': int(a.duplicated(['firm_id','fiscal_year']).sum()),
    'rows_2009_2021': len(b), 'firms_2009_2021': int(b.firm_id.nunique()),
    'variables_2009_2021': stats, 'regressions_run': 0,
    'peak_memory_mib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024**2,
}
assert result['sha256_before'] == result['sha256_after']
(OUT/'source_panel_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
skills = {
    'stata-replication': 'skills/64-tmonk-mcp-stata/skills/stata-replication',
    'stata-data-audit': 'skills/64-tmonk-mcp-stata/skills/stata-data-audit',
    'aer-replication': 'skills/50-brycewang-aer-skills/skills/aer-replication',
}
manifest = {'repository':'https://github.com/brycewang-stanford/Auto-Empirical-Research-Skills',
            'commit':'bfa0a6e5a843babbf45a1ef1663fd5dc4f07c0ba', 'skills':[]}
for name, upstream in skills.items():
    directory = Path('/Users/macpro/.codex/skills')/name
    assert (directory/'SKILL.md').is_file()
    files = [{'relative_path':str(p.relative_to(directory)),'size':p.stat().st_size,'sha256':sha(p)}
             for p in sorted(directory.rglob('*')) if p.is_file()]
    manifest['skills'].append({'name':name,'installed_path':str(directory),'upstream_path':upstream,'files':files})
(OUT/'installed_skills_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'source_unchanged':True,'installed_skills':list(skills),'regressions':0,'peak_memory_mib':result['peak_memory_mib']}))
