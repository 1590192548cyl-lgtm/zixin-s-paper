version 18
clear all
set more off
set processors 1
capture log close _all
log using "outputs/stored_estimates_read_only.log", text replace
tempname ch mh
tempfile coeff meta
postfile `ch' str24 model str20 matrix_name str64 term double coefficient double SE using `coeff', replace
postfile `mh' str24 model double N double clusters str30 weight_type str80 weight_expression ///
    str120 absorbed str50 cluster_variable str32 method using `meta', replace
local H "/Users/macpro/Documents/New project/huang_transition_static_H8_20261104/outputs"
local D "/Users/macpro/Documents/New project/huang_DR_DID_2008_complete_20261109/outputs"
foreach m in H8_static H8_event DR_static DR_2010 {
    local f "`H'/H8_transition_static.ster"
    if "`m'"=="H8_event" local f "`H'/H8_transition_event.ster"
    if "`m'"=="DR_static" local f "`D'/main_static.ster"
    if "`m'"=="DR_2010" local f "`D'/year_2010.ster"
    estimates use "`f'"
    post `mh' ("`m'") (e(N)) (e(N_clust)) ("`e(wtype)'") ("`e(wexp)'") ///
        ("`e(absvars)'") ("`e(clustvar)'") ("`e(method)'")
    matrix b=e(b)
    matrix V=e(V)
    local names: colfullnames b
    local j=0
    foreach term of local names {
        local ++j
        post `ch' ("`m'") ("e(b)") ("`term'") (b[1,`j']) (sqrt(V[`j',`j']))
    }
    if substr("`m'",1,2)=="DR" {
        foreach mat in iptb regb {
            matrix a=e(`mat')
            local names: colfullnames a
            local j=0
            foreach term of local names {
                local ++j
                post `ch' ("`m'") ("e(`mat')") ("`term'") (a[1,`j']) (.)
            }
        }
    }
}
postclose `ch'
postclose `mh'
use `coeff', clear
export delimited using "outputs/stored_coefficients.csv", replace
use `meta', clear
export delimited using "outputs/stored_model_metadata.csv", replace
display "READ_EXISTING_ESTIMATES_COMPLETE_ZERO_FITS"
log close
