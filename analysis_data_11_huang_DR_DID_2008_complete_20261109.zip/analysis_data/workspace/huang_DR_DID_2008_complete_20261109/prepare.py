from pathlib import Path
import sys,json,hashlib,sqlite3,re,unicodedata,time,resource
from collections import defaultdict
import pandas as pd
import numpy as np

W=Path(__file__).resolve().parent; B=W.parent; O=W/'outputs'; O.mkdir(exist_ok=True)
ROOT=Path('/Users/macpro/Desktop/毕业论文'); start=time.monotonic()
sys.path.insert(0,str(B/'huang_replication_data_audit_20261103'))
from audit_sources import xml_rows,norm
COV=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4']
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(n,x): (O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(n,x): pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def records(p):
    heads={}
    for sh,rn,v in xml_rows(p):
        if rn==1:heads[sh]=v
        if rn>=4:yield {n:v.get(c,'') for c,n in heads[sh].items()}
def num(x):
    try:v=float(x);return v if np.isfinite(v) else np.nan
    except (ValueError,TypeError):return np.nan

assert not (O/'prepared.json').exists(),'Existing prepared sample must not be overwritten.'
manifest=json.loads((B/'duality_2008_remaining11_followup_20261109/protected_after.json').read_text())
assert all(sha(r['path'])==r['sha256'] for r in manifest),'Prior protected files changed.'
sources={r['source']:r for r in json.loads((B/'huang_replication_data_audit_20261103/source_audit.json').read_text())}
src=B/'huang_week_calendar_repair_20261103/fixed_rerun/outputs/fixed_analysis.dta'
ipo_path=ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta'
cache=B/'gao_full_controls_work/gao_controls_staging.sqlite'
newinv=pd.read_csv(B/'controls_2008_supplement_audit_20261109/file_inventory.csv')
sharerow=newinv[newinv.filename.eq('CG_Sharehold.xlsx')].iloc[0]
sharepath=Path(sharerow.path); assert sha(sharepath)==sharerow.sha256
ledgerpath=B/'duality_2008_remaining11_followup_20261109/18家公司核验台账_第二版.csv'
mapping=ROOT/'堆叠DID重跑/gao_full_controls/big4_name_mapping.csv'
extra=[src,ipo_path,cache,sharepath,ledgerpath,mapping,W/'PLAN.md',W/'prepare.py']
extra += [Path(sources[s]['path']) for s in ['balance','duality','board','auditor']]
extra += list((B/'huang_transition_static_H8_20261104/outputs').glob('*.ster'))
extra += [B/'huang_transition_static_H8_20261104/outputs'/n for n in ['static_results.csv','event_results.csv','joint_tests.csv','transition_H8_report.md']]
extra += [Path('/Users/macpro/Library/Application Support/Stata/ado/plus/d')/n for n in ['drdid.ado','drdid.sthlp','drdid_predict.ado']]
known={r['path'] for r in manifest}
for p in extra:
    if str(p) not in known:manifest.append(dict(path=str(p),sha256=sha(p)));known.add(str(p))
dump('protected_before.json',manifest)
for s in ['balance','duality','board','auditor']:assert sha(sources[s]['path'])==sources[s]['sha256']

d=pd.read_stata(src,convert_categoricals=False)
assert not d.duplicated(['firm_id','year']).any()
univ=d[d.old_H8_sample.eq(1)][['firm_id','Treat']].drop_duplicates().set_index('firm_id').sort_index()
assert len(univ)==648 and univ.index.is_unique and set(univ.Treat)=={0,1}
ids=set(univ.index); X=pd.DataFrame(index=univ.index,columns=COV,dtype=float)
ipo=pd.read_stata(ipo_path,columns=['Stkcd','Listdt'],convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd')
ipo['firm_id']=ipo.Stkcd.astype(int); dates=ipo.set_index('firm_id').Listdt.reindex(X.index)
listed=dates.notna() & dates.le('2008-12-31'); assert listed.sum()==526
con=sqlite3.connect('file:'+str(cache)+'?mode=ro',uri=True)
sig=con.execute('SELECT signature FROM source_done WHERE source_id="balance"').fetchone()[0]
st=Path(sources['balance']['path']).stat();assert sig==f'{st.st_size}:{st.st_mtime_ns}'
fin=pd.read_sql_query("SELECT firm_id,variable,value FROM num_values WHERE variable IN ('total_assets','total_liabilities') AND year=2008 AND conflict=0",con);con.close()
fin.firm_id=fin.firm_id.astype(int)
fin=fin[fin.firm_id.isin(ids)].pivot(index='firm_id',columns='variable',values='value').reindex(X.index)
a=fin.total_assets; l=fin.total_liabilities
X['Size']=np.log(a.where(a.gt(0)));X['Lev']=l/a.where(a.gt(0))
X['Age']=np.log((2008-dates.str[:4].astype(float)+1).where(listed))
for sid,field,vname in [('duality','ConcurrentPosition','Dual'),('board','DirectorNumber','Board')]:
    seen=set()
    for r in records(sources[sid]['path']):
        code=norm(r.get('Symbol',''))
        if r.get('Enddate')!='2008-12-31' or not code.isdigit() or int(code) not in ids:continue
        if sid=='board' and norm(r.get('StatisticalCaliber',''))!='1':continue
        f=int(code);assert f not in seen;seen.add(f);v=num(r.get(field))
        if vname=='Dual' and v in [0,1]:X.at[f,vname]=v
        if vname=='Board' and v>0:X.at[f,vname]=np.log(v)
    print('Read baseline source',sid,flush=True)
aud=defaultdict(list); bignames=set(pd.read_csv(mapping).normalized_name)
for r in records(sources['auditor']['path']):
    code=norm(r.get('Symbol',''))
    if r.get('EndDate')!='2008-12-31' or not code.isdigit() or int(code) not in ids:continue
    if norm(r.get('Source',''))!='0' or norm(r.get('TerritoryForeignIdentity',''))!='1':continue
    name=re.sub(r'\s+','',unicodedata.normalize('NFKC',r.get('AccountingFirmName','')).strip())
    if name:aud[int(code)].append(name)
for f,names in aud.items():X.at[f,'Big4']=int(any(n in bignames for n in names))
holders={}; seen=set()
for r in records(sharepath):
    code=norm(r.get('Stkcd',''))
    if r.get('Reptdt')!='2008-12-31' or not code.isdigit() or int(code) not in ids:continue
    f=int(code);rank=num(r.get('S0501b'));v=num(r.get('S0301b'))
    if np.isfinite(rank) and int(rank)==rank and 1<=rank<=10:
        k=(f,int(rank));assert k not in seen;seen.add(k)
        h=holders.setdefault(f,np.full(10,np.nan));h[int(rank)-1]=v if 0<=v<=100 else np.nan
for f,h in holders.items():
    if np.isfinite(h[:5]).all() and h[0]>0:X.at[f,'Cent']=h[1:5].sum()/h[0]
    if np.isfinite(h).all():X.at[f,'Top10']=h.sum()/100
assert X.loc[listed,['Cent','Top10']].notna().all().all()
ledger=pd.read_csv(ledgerpath); confirmed=ledger[ledger['最新严格结论'].str.startswith('确认不兼任')]
assert set(confirmed['股票代码'])=={600156,600171,600415,600452,600509,600761,600841,600029,601008}
provenance=[]
for _,r in confirmed.iterrows():
    f=int(r['股票代码']);assert pd.isna(X.at[f,'Dual'])
    X.at[f,'Dual']=0
    provenance.append(dict(firm_id=f,variable='Dual',value=0,source=str(ledgerpath),decision=r['最新严格结论'],chair=r['董事长或代理'],manager=r['经营负责人或安排'],is_imputation=False))
save('verified_duality_evidence.csv',provenance)

legal=d.old_H0_sample.eq(1)&d.n_weeks.ge(30)&d.R2.gt(0)&d.R2.lt(1)&np.isfinite(d.SYN)&np.isfinite(d.SYN_w)
assert np.array_equal(legal,d.old_H0_sample.eq(1))
assert np.allclose(d.loc[legal,'SYN_w'],d.loc[legal,'SYN'].clip(-2.6623991805823506,1.555292310918417),rtol=0,atol=1e-12)
ys=d[legal&d.firm_id.isin(ids)].pivot(index='firm_id',columns='year',values='SYN_w').reindex(X.index)
ys=ys.reindex(columns=range(2009,2022)); post=ys[list(range(2015,2022))]
audit=univ.copy();audit['IPODate']=dates;audit['listed_2008']=listed
audit['deferred_601607']=audit.index==601607
audit['missing_baseline']=X.isna().apply(lambda r:';'.join(r.index[r]),axis=1)
audit['complete_baseline']=X.notna().all(axis=1);audit['legal_pre2013']=ys[2013].notna()
audit['post_year_count']=post.notna().sum(axis=1);audit['legal_post']=audit.post_year_count.gt(0)
audit['observed_post_years']=post.notna().apply(lambda r:';'.join(map(str,r.index[r])),axis=1)
conditions=[('not_listed_by_2008',listed),('deferred_601607',~audit.deferred_601607),('incomplete_2008_baseline',audit.complete_baseline),('no_legal_2013_SYN',audit.legal_pre2013),('no_legal_post_SYN',audit.legal_post)]
audit['included']=True; flow=[]
for name,cond in conditions:
    before=audit.included.copy();audit['included'] &= cond
    for t in [0,1]:flow.append(dict(step=name,Treat=t,before=int((before&audit.Treat.eq(t)).sum()),excluded=int((before&~cond&audit.Treat.eq(t)).sum()),remaining=int((audit.included&audit.Treat.eq(t)).sum())))
audit['all_exclusion_reasons']=[';'.join(name for name,c in conditions if not c.loc[f]) for f in audit.index]
audit['primary_exclusion_reason']=['included' if x=='' else x.split(';')[0] for x in audit.all_exclusion_reasons]
save('company_sample_audit_private.csv',audit.reset_index());save('excluded_firms_private.csv',audit[~audit.included].reset_index());save('sample_attrition.csv',flow)
save('baseline_2008_private.csv',X.join(audit[['Treat','IPODate','included']]).reset_index())
dd=d[['firm_id','year','Treat','old_H0_sample','old_H8_sample','n_weeks']].copy();dd['legal_outcome']=legal
dd['eligible_company']=dd.firm_id.map(audit.included);dd['in_static_outcome']=dd.legal_outcome&dd.eligible_company&(dd.year.eq(2013)|dd.year.between(2015,2021))
save('outcome_row_audit_private.csv',dd)
s=X.loc[audit.included].copy();s['Treat']=univ.Treat;s['y_pre']=ys[2013];s['y_meanpost']=post.mean(axis=1);s['n_post']=post.notna().sum(axis=1)
scale=[]
for v in COV:
    mean=s[v].mean();sd=s[v].std(ddof=0)
    if v in ['Dual','Big4']:mean,sd=0.,1.
    assert sd>0
    s['X_'+v]=(s[v]-mean)/sd;scale.append(dict(variable=v,mean=mean,sd=sd,rule='linear_rescaling_only'))
for y in list(range(2009,2013))+list(range(2015,2022)):s[f'y_{y}']=ys[y]
s=s.reset_index();s.firm_id=s.firm_id.astype('int32');s.Treat=s.Treat.astype('int8')
s.to_stata(O/'dr_analysis_wide.dta',write_index=False,version=118)
save('baseline_scaling.csv',scale)
availability=[]
for y in range(2009,2022):
    for t in [0,1]:
        group=audit.included&audit.Treat.eq(t);availability.append(dict(year=y,Treat=t,eligible_firms=int(group.sum()),legal_outcomes=int(ys.loc[group,y].notna().sum()),used_as='transition_excluded' if y==2014 else 'pre_reference' if y==2013 else 'pre_placebo' if y<2013 else 'post'))
save('outcome_coverage_by_year.csv',availability)
meta=dict(status='PREPARED_NO_EFFECTS_ESTIMATED',initial_firms=len(audit),listed_2008=int(listed.sum()),included_firms=len(s),treated_firms=int(s.Treat.sum()),controls=int(s.Treat.eq(0).sum()),excluded_firms=int((~audit.included).sum()),observed_post_counts=s.groupby('Treat').n_post.agg(['min','max','mean']).to_dict(),actual_prepost_source_rows=int(dd.in_static_outcome.sum()),main_pair_rows=2*len(s),manual_real_dual_zero_records=len(provenance),missing_values_imputed=0,SYN_recomputed=False,winsor_points_recomputed=False,elapsed_seconds=time.monotonic()-start,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,plan_sha256=sha(W/'PLAN.md'))
dump('prepared.json',meta);print(json.dumps(meta,ensure_ascii=False,indent=2),flush=True)
