from pathlib import Path
import sys,json,hashlib,resource,time
import pandas as pd
import numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent
sys.path.insert(0,str(B/'huang_replication_data_audit_20261103'))
from audit_sources import xml_rows,norm
def save(n,x):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def table(d):
    d=d.copy()
    for c in d.columns:
        if pd.api.types.is_float_dtype(d[c]):d[c]=d[c].map(lambda v:f'{v:.6f}' if np.isfinite(v) else 'NA')
    return '| '+' | '.join(map(str,d.columns))+' |\n|'+'|'.join(['---']*len(d.columns))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in d.itertuples(index=False,name=None))
m=json.loads((O/'audit_metrics.json').read_text());assert m['regressions_run']==0
D=B/'huang_DR_DID_2008_complete_20261109/outputs';H=B/'huang_transition_static_H8_20261104/outputs'
review=pd.read_csv(O/'industry_backcast_review_private.csv').set_index('firm_id');names=review.groupby('code2014').name2014.agg(lambda x:';'.join(sorted(set(x.dropna()))))
allind=pd.read_csv(O/'industry_2010_2013_contributions.csv')
allind['industry_name_2014']=allind.industry2014.map(names);save('industry_2010_2013_contributions.csv',allind)
isum=allind[allind.population.eq('DR_2010_frozen_IPT')].groupby('industry2014').agg(Treat=('Treat','first'),firms=('firms','sum'),contribution_2010=('contribution_2010','sum'),contribution_minus2013=('contribution_minus2013','sum'),contribution_total=('contribution_total','sum')).reset_index()
isum['industry_name_2014']=isum.industry2014.map(names);isum=isum.iloc[isum.contribution_total.abs().sort_values(ascending=False).index].reset_index(drop=True)
save('DR2010_industry_contribution_order.csv',isum)

# Supplement the classification-change file separately; ImplementDate is not EndDate.
eventpath=Path('/Users/macpro/Desktop/毕业论文/控制变量/2207-2008行业分类/STK_INDUSTRYCLASS.xlsx')
head={};events=[]
for sh,rn,v in xml_rows(eventpath):
    if rn==1:head[sh]=v
    if rn>=4:
        r={field:v.get(col,'') for col,field in head[sh].items()};r['firm_id']=int(norm(r['Symbol']));events.append(r)
ev=pd.DataFrame(events);cov=pd.read_csv(O/'additional_classification_year_coverage.csv');cov=cov[cov.path.ne(str(eventpath))].copy()
cov['date_field']='EndDate';cov['coverage_kind']='annual_snapshot'
e08=ev[ev.IndustryClassificationID.eq('P0207')].copy()
e08['in_H8']=e08.firm_id.isin(review.index);e08['in_DR']=e08.firm_id.isin(review.index[review.in_DR])
e08['source2010_P0201']=e08.firm_id.map(review.code2010);e08['frozen2012_P0207']=e08.firm_id.map(review.code2012);e08['frozen2014_P0207']=e08.firm_id.map(review.code2014)
e08['exact_code_matches_2012']=e08.IndustryCode.eq(e08.frozen2012_P0207)
e08['does_not_certify_2010_yearend_without_full_change_history']=True
save('early_P0207_implementation_records_private.csv',e08)
erows=[]
for (sid,y),g in ev.assign(year=ev.ImplementDate.str[:4].astype(int)).groupby(['IndustryClassificationID','year']):
    erows.append(dict(path=str(eventpath),standard=sid,year=y,rows=len(g),mapped_firms=g.firm_id.nunique(),DR513_firms=g[g.firm_id.isin(review.index[review.in_DR])].firm_id.nunique(),standard_ID_field_present=True,date_field='ImplementDate',coverage_kind='implementation_event_not_annual_snapshot'))
cov=pd.concat([cov,pd.DataFrame(erows)],ignore_index=True);save('additional_classification_year_coverage.csv',cov)
assert len(cov[cov.coverage_kind.eq('annual_snapshot')&cov.standard.eq('P0207')&cov.year.lt(2012)])==0
eventsumm=ev.groupby('IndustryClassificationID').agg(classification_name=('IndustryClassificationName',lambda x:';'.join(sorted(set(x)))),rows=('Symbol','size'),firms=('firm_id','nunique'),earliest_implementation=('ImplementDate','min'),latest_implementation=('ImplementDate','max')).reset_index()
save('implementation_date_source_summary.csv',eventsumm)
m.update(early_P0207_implementation_records=len(e08),early_P0207_implementation_unique_firms=e08.firm_id.nunique(),early_P0207_implementation_H8_firms=e08[e08.in_H8].firm_id.nunique(),early_P0207_implementation_DR_firms=e08[e08.in_DR].firm_id.nunique(),early_P0207_implementation_is_not_full_yearend_coverage=True)

bridge=pd.read_csv(O/'descriptive_2010_2013_bridge.csv');cc=pd.read_csv(O/'DR_2010_frozen_IPT_company_contribution_order_private.csv');st=pd.read_csv(O/'ST_observed_source_records_private.csv').fillna('')
screen=pd.read_csv(O/'existing_postpolicy_ST_screened_company_list_private.csv');screen_ids=set(screen.firm_id)
realpost=st[st.firm_id.isin(screen_ids)&st.FirstSTDate.between('2015-01-01','2021-12-31')].copy()
save('documented_postpolicy_ST_screened_private.csv',realpost);m['proxy_first_ST_2015_2021_screened_companies']=len(screen);m['documented_actual_first_ST_2015_2021_screened_companies']=realpost.firm_id.nunique()

samplebridge=[dict(step='original_H8',rows=7609,change=np.nan,note='648 firms; original annual complete sample'),dict(step='same_DR_513_companies_keep_H8_rows',rows=6379,change=-1230,note='Remove rows of 135 firms, audit only'),dict(step='restrict_to_2013_and_2015_2021',rows=3872,change=-2507,note='Remove other pre years and transition year, audit only'),dict(step='include_legal_outcomes_missing_current_H8_controls',rows=4054,change=182,note='DR needs fixed baseline X, not annual H8 control completeness'),dict(step='collapse_post_to_company_observed_mean',rows=1026,change=-3028,note='Aggregation, not deletion; 513 firms times two synthetic periods')]
save('sample_row_count_bridge.csv',samplebridge)
tw=pd.read_csv(O/'DR_static_time_group_weights.csv');rawsum=tw.groupby(['part','Treat']).outcome_contribution.sum()
means=pd.DataFrame([dict(period='2013',treated_mean=-rawsum['pre',1],control_mean=rawsum['pre',0]),dict(period='observed_post_average',treated_mean=rawsum['post',1],control_mean=-rawsum['post',0])])
means['treated_minus_control']=means.treated_mean-means.control_mean
save('DR_static_frozen_weight_group_means.csv',means)
history_need=[]
for _,r in pd.read_csv(O/'ST_still_missing_DR_companies_private.csv').iterrows():
    history_need.append(dict(firm_id=int(r.firm_id),Treat=int(r.Treat),industry2014=review.at[r.firm_id,'industry2014'],need='公司基本信息行 + 完整ST/*ST/PT状态变更日期/起止区间',listing_date_filter='不得设为2009年以后；公司已于2008年末前上市',history_window='覆盖2009年初初始状态至2021年底；首次ST日期可保留更早历史',required_fields='股票代码;状态类别;状态开始/生效日期;状态结束或下一次变更日期;首次ST日期;上市日期;退市日期',deferred_601607=False))
save('ST_download_target_DR513_private.csv',history_need)
original_candidate=pd.read_csv(B/'huang_industry_ST_audit_20261103/outputs/ST_proxy_vs_FirstSTDate_private.csv')
original_candidate['in_DR']=original_candidate.firm_id.isin(review.index[review.in_DR]);original_candidate['deferred_601607']=original_candidate.firm_id.eq(601607)
original_candidate['download_fields']='股票代码;上市日期;退市日期;首次ST日期;ST/*ST/PT/正常状态类别;状态生效/开始日期;结束或下一次变更日期'
original_candidate['scope_reason']='核验已保留公司的漏筛及已排除公司的误筛/政策后选择；不改变原资格'
save('ST_original_candidate_scope_private.csv',original_candidate)
targets=original_candidate[~original_candidate.deferred_601607];assert len(targets)==922
save('ST_download_target_candidates922_private.csv',targets)
m['ST_candidate_download_target_count']=len(targets)
needs=[dict(item='ST历史完整审计',status='尚未解决',minimum_download='原923家ST筛选前候选的公司基本信息及完整状态变更；601607暂缓，实际清单922家；不要限制上市日期为2009以后',why='同时核验保留公司的漏筛和排除公司的误筛；仅补DR513家不能评估被排除公司的资格',target_file='ST_download_target_candidates922_private.csv'),dict(item='ST历史最低覆盖',status='尚未解决，仅解决保留组覆盖',minimum_download='若先补最小范围，则513家DR公司的完整ST状态及公司基本信息',why='现首次ST表513家全部无公司行；这不是完整候选池筛选风险的解决方案',target_file='ST_download_target_DR513_private.csv'),dict(item='行业历史',status='尚未解决，有实施日期表线索',minimum_download='优先核对现有STK_INDUSTRYCLASS的完整变更历史与回溯说明；如不完整，再补同口径变更记录/官方对应表',why='年度P0207仅2012起；238条早期P0207实施记录不是完整2010年末快照，不直接替换或外推',target_file='early_P0207_implementation_records_private.csv'),dict(item='财务/治理控制',status='本轮无新增下载要求',minimum_download='不要求重下全库，也不要求重扫年报',why='基线补齐和IPT已未消除2010/2013差异；应先修识别证据',target_file='')]
save('remaining_evidence_checklist.csv',needs)

# Check the historical source code still uses 2012 rows for early SYN; read only.
build=(B/'huang_basic_reconstruction_20261103/build.py').read_text()
assert "early=ind[ind.year.eq(2012)]" in build
repair=(B/'huang_week_calendar_repair_20261103/repair.py').read_text()
assert "early=ind[ind.year.eq(2012)]" in repair and 'for y in range(2008,2012)' in repair
assert review.industry2014.eq(review.code2014).all()
oldstcode=(B/'huang_industry_ST_audit_20261103/audit.py').read_text()
assert "y.between(2009,2021)" not in oldstcode or 'firstproxy' in oldstcode
protected=json.loads((O/'protected_before.json').read_text());after=[]
for r in protected:
    h=sha(r['path']);after.append(dict(path=r['path'],sha256=h,unchanged=h==r['sha256']))
dump('protected_after.json',after);assert all(r['unchanged'] for r in after)
codehash=[dict(path=str(p),sha256=sha(p)) for p in [W/'PLAN.md',W/'audit.py',W/'extract_existing.do',W/'complete_report.py']]
dump('audit_code_hashes.json',codehash)
m['reporting_peak_RSS_MiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2
m['protected_files']=len(after);m['all_originals_unchanged']=True
dump('audit_metrics.json',m)

displaybridge=bridge[['stage','firms','gap2010','gap2013','difference_2010_minus2013']].copy()
displaybridge['stage']=displaybridge.stage.replace({'H8_original_annual_available':'H8逐年原可用记录','H8_fixed_pair':'H8两年共同公司','H8_DR_common_pair':'H8与DR共同配对公司','DR_2010_pair_equal_weights':'DR配对公司未加权','DR_2010_frozen_IPT':'DR配对公司冻结IPT权重'})
topind=isum.head(10)[['industry2014','industry_name_2014','Treat','firms','contribution_2010','contribution_minus2013','contribution_total']]
topco=cc.head(10)[['firm_id','Treat','industry2014','contribution_2010','contribution_minus2013','contribution_total']]
stable=pd.read_csv(O/'industry_stability_contribution_audit.csv');drstable=stable[stable.population.eq('DR_2010_frozen_IPT')].set_index('stable_2012_2013_2014')
report=f'''# H8与DR-DID估计差异、2010—2013前趋势来源审计

2026-11-09。本轮仅审计：**新增回归0、辅助回归0、新p值0、SYN重算0、插补0、删样本0、正式数据改写0**。只恢复已有估计存档导出系数和元数据，所有描述性分组均非新的估计样本。

## 一、结论与边界

1. H8与DR不是同样本同基准的算法替换。原H8是648家公司、7,609公司年度；DR是513家公司、4,054个真实结果年度压缩为1,026个两期行。样本、控制时点/缩尾和前后期比较均不同。不能把p从0.0363到0.5200只归因于加权或数据补齐。
2. 在预定描述桥接中，2010减2013的两组差异保持在约+0.17至+0.18。DR512个配对公司未加权+0.182811，冻结IPT权重后+0.183543，仅改变+0.000732。这不支持年度进出、135家公司的范围变化或这套基线权重单独解释该前期差异。
3. 冻结DR配对权重下，2010处理减对照为+0.174598，2013为-0.008945，前者减后者+0.183543。相对差异主要表现为2010两组差距较大，不能据此认定2010数据错误、2013正常或差异全部是经济冲击。
4. 行业贡献正负并存；2012—2014代码稳定的491家DR配对公司在原权重下仍贡献+0.163007，变动21家贡献+0.020536。“少数2012—2014行业变更公司产生全部前趋势”的解释不成立，但稳定性不能证明2010回溯归组正确。
5. **行业回溯尚未验证，ST覆盖缺口尚未解决。** 当前首次ST表覆盖原H8的123/648家公司，却覆盖DR的0/513家。不能把其余无公司行解释为从未ST。
6. 尚不能精确分配H8静态系数到DR静态ATT的变化比例或p值变化来源。H8缺少已保存的残差化TreatPost，禁止新辅助回归，因此没有伪造其精确FWL隐含权重。DR的点估计可用冻结权重作已验证恒等分解，但这不是对H8的精确分解。

## 二、样本键与行数桥接

{table(pd.DataFrame(samplebridge)[['step','rows','change']])}

H8原样本限制到DR513家公司后为6,379行；再限制2013及2015—2021，仅3,872行与DR实际结果行重合。DR另有182行因当前年度H8控制不完整而不在原H8中，但其SYN合法、2008固定基线完整，因此按既定DR规则保留。两期聚合使4,054变成1,026，不是又丢了3,028条原始记录。

135家公司排除原因沿用前轮：122家2008末未上市，9家真实基线缺失，601607暂缓，3家无合法2013基准。没有更改处理身份或重新定义控制组。冻结文件还保留600661的2021一行，但原H0/H8标志均为0，既不属于原648家公司也不属于DR；已单列记录，不是本轮新排除。

## 三、基准、控制和权重核对

原H8静态：2009—2013作为纯前期参与全期TWFE比较，2014单列TreatTransition，2015—2021为政策后。原事件模型已归一化至2013，2014独立展示，不是本轮再换基准。八控制为年度Size_w、Age_w、Lev_w、Cent_w、Top10_w、Dual、Board_w、Big4；公司/年份FE，firm_id聚类。存档weight_type和weight_expression为空，即无显式加权输入。**这不等于静态系数按公司或事件年简单等权。**

DR静态：只用2013基准；2014不进入前后比较；后期为每家公司2015—2021已观察合法结果均值。8项原始2008基线，仅线性标准化，无重新缩尾。公司等权定义处理组目标，控制组使用冻结IPT ATT权重；按firm_id聚类。既有诊断中对照ESS145.95/155，15家处理公司得分超出对照观察范围，权重均值平衡不能认证条件平行趋势。

冻结DR权重下的组别均值：

{table(means)}

后期组差减2013组差等于已有静态ATT -0.0491535905。因每家公司后期有5—7年，不同年度合计时间权重略不同，详见DR_static_time_group_weights.csv；这不是固定每年1/7的完全平衡估计目标。未重估倾向模型或结果模型。

## 四、2010与2013的描述桥接

{table(displaybridge)}

首行使用各年H8可用记录，后四行使用固定成对公司。原H8事件模型2010系数为+0.196652，**不是首行或第二行的原始均值差**：它还包含原控制和全期FE估计信息。不得用上表声称已将该回归系数精确分解。

DR2010冻结IPT权重使8项线性基线均值平衡，因此加权原始前后差分与已保存改进型DR ATT数值相同，误差{m['DR2010_point_identity_error']:.2e}；主静态ATT的对应恒等误差{m['DR_static_point_identity_error']:.2e}。这仅核对已有估计的点恒等关系，不产生新的标准误或p值，也不证明识别成立。

## 五、行业与公司贡献

固定定义：对每家配对公司，处理组q=正归一化权重，对照组q=负归一化权重；各组绝对权重和为1。贡献2010=q×(SYN2010−全配对均值2010)，贡献减2013=−q×(SYN2013−全配对均值2013)。两项相加再求和，严格等于两组差之差。居中用于移除任意共同水平，其行业归因并非唯一；不能称为各行业因果效应。标签是被冻结的2014行业，不伪称2010真实历史行业。

DR配对按绝对贡献排序前10个行业（完整表全部保留）：

{table(topind)}

例如医药制造业C27合计+0.068358、非金属矿物制品业C30合计+0.044635；电力热力D44合计-0.022265，对冲正差异。C32与C38的贡献较多来自2013一端，说明行业内不能把2013完全忽略，不能只核查2010。

DR配对公司前10项绝对贡献：

{table(topco)}

前10家公司贡献绝对值占全部绝对贡献10.15%，但这**不是净差异或因果效应的10.15%**。其带符号贡献合计{cc.head(10).contribution_total.sum():.6f}，全部正贡献约{cc[cc.contribution_total.gt(0)].contribution_total.sum():.6f}、负贡献约{cc[cc.contribution_total.lt(0)].contribution_total.sum():.6f}，存在显著抵消。最大的600258贡献为负，不能因为其数值大就删掉。冻结权重下贡献表不是实际删除这些公司后的ATT；没有删一重估或影响p值实验。

另存全部公司DR影响函数，其与点贡献不是同一对象，影响函数只表示局部估计敏感性，不代表该公司的政策因果效应。

代码稳定性按2012/2013/2014三年完全相同检查：

{table(stable)}

原权重未对稳定或变动子组重新归一化，上表是完整样本贡献的分组和，不是子组回归或候选样本。H8固定配对526家公司中，504家稳定者贡献+0.161307；相同结论不依赖DR单独的21家变动公司。

## 六、行业回溯是否解决：未解决，但发现需单独核验的实施日期线索

1. 当前原行业DTA与4份年度分类来源仍没有2010年的P0207年度快照，P0207年度数据从2012起。补充2007—2008年度表为P0201，不能直接补上同口径P0207。现有SYN早期代码仍按原构造读取公司2012 P0207回溯，未修改或重算。
2. 在H8现有公司中，2010 P0201的50个旧代码有28个对应多个2012新代码、24个对应多个新SYN行业组。这是版本跨越/拆分风险，不等于已证实28个代码错误。不能多数映射或按p值选映射。
3. 另有STK_INDUSTRYCLASS.xlsx **实施日期表**，实际1,688条，其中P0207有238条，ImplementDate为2007-01-09至2008-12-31。这不能被写成“完全没有早期P0207记录”。其中涉及H8 {m['early_P0207_implementation_H8_firms']}家、DR {m['early_P0207_implementation_DR_firms']}家，已另列完整记录与2012代码对照。
4. 该表不是EndDate年度表，而是ImplementDate记录，且还含P0221等后来版本对应的2007—2008日期。字段说明只给出日期格式，没有解释历史回溯规则。没有2009—2010完整后续变更和初始覆盖，不能仅靠这238条有限记录向前/向后填补全体公司的2010年末分类。它是值得核实的证据线索，不直接丢弃，也不直接替换。
5. InstitutionID不能跨年份直接等同于股票代码：当前源中有跨证券/年份的多重键。审计链接使用机构+年份，并仅在原H8公司键唯一时识别目标公司；歧义全保留，未选择冲突来源构造新行业。

优先行动是查明实施日期表是否可提供完整变更历史与回溯说明，再对歧义记录定点核验。继续重下相同P0201年度表并不能自动解决这个问题。无需重扫全部年报。

## 七、ST与政策后选择是否解决：未解决

当前可用FirstSTDate表仍为3173家公司，ListedDate范围2009-07-10—2021-12-31。已逐个检查候选公司基本信息来源，EVA_Co等不含可替代的完整FirstSTDate历史。原H8覆盖123家，525家无公司行；DR513家全部无公司行，不能记为ST=0或从未ST。

原候选923家中，简称代理曾排除231家；其中106家的首次**被本地简称观察为ST**年份为2015—2021，不能把106家都表述为真实首次ST。现有限的真实日期表能核对其中{m['documented_actual_first_ST_2015_2021_screened_companies']}家确实首次ST在2015—2021，却被整公司追溯排除前期记录。该事实支持政策后选择风险存在，但未识别其偏误方向/大小，不能据此自动放回。

下一份数据应优先补公司覆盖，不限制上市日期为2009年以后。**完整筛选审计应覆盖原923家ST筛选前候选，601607暂缓后实际下载清单922家。** 这能同时核验保留公司的漏筛与被排除公司的误筛/政策后选择。只补513家DR公司属于最低覆盖步骤，不能解决原候选池被排除公司的资格核验。

需要公司基本信息及ST/*ST/PT状态起止或变更日期，包含2009年初初始状态、至2021末全部区间。仅首次ST日期不足以完整识别反复ST/撤销或窗口前首次ST的状态区间。922家与513家两份清单均已保存，601607仍暂缓，不在下载目标中。没有要求重下财务整库。

## 八、现在能解释和不能解释的内容

**已支持：**2010/2013差异对样本共同化与冻结基线IPT较稳定；不只是少数年度进出或2012—2014行业变动公司；8项基线均值平衡不能消除前期相对变化；原H8与DR估计目标明显不同；行业历史与ST筛选两项证据缺口仍存在。

**未支持：**“DR算法造成不显著”“2010原始数据一定有错”“2013必须换掉”“某行业贡献大就应删除”“已确定ST筛选是前趋势的唯一原因”“修复后必然三星”。本轮没有估计任何修正口径，不能给出这类肯定判断。

**建议下步顺序：**先补齐真实ST历史与实施日期表的完整历史/口径说明，客观确认行业和样本资格；如查实错误，再提出唯一修正清单供用户确认。本轮不改模型或删样本，不进入SDID等新估计。若证据齐备后仍有行业前趋势，才另行论证可比对照或政策前结果轨迹调整，并保留静态平均效应研究目标，不保证显著。

## 九、保护、资源与文件

原H8、DR、G1及原始来源共{m['protected_files']}份保护文件SHA256全部一致。无新DTA、无原数据改写、无新回归或检验；存档恢复日志中没有估计命令。源文件600661未进入任何估计或贡献分解集合。峰值内存约{m['peak_RSS_MiB']:.1f}MiB，Stata只读存档峰值约{m['Stata_peak_RSS_MiB']:.1f}MiB。未扫描年报。

主要文件：sample_row_count_bridge.csv；sample_membership_by_year.csv；descriptive_2010_2013_bridge.csv；industry_2010_2013_contributions.csv；company_2010_2013_contributions_private.csv；DR2010_influence_diagnostic_private.csv；DR_static_frozen_outcome_weights_private.csv；industry_backcast_review_private.csv；early_P0207_implementation_records_private.csv；ST_risk_summary.csv；ST_download_target_DR513_private.csv；remaining_evidence_checklist.csv；stored_estimates_read_only.log；protected_before/after.json。

private表、影响函数/估计权重和公司级来源均含CSMAR衍生资料，不自动公开GitHub。完整代码与来源清单已留存；本轮完成停止。
'''
(O/'H8_DR估计差异与前趋势来源审计报告.md').write_text(report,encoding='utf-8')
dump('completed.json',dict(status='COMPLETE_AUDIT_ONLY',regressions_run=0,new_p_values=0,originals_unchanged=True,protected_files=len(after),report=str(O/'H8_DR估计差异与前趋势来源审计报告.md'),ST_missing_DR_firms=513,industry_risk_resolved=False,ST_risk_resolved=False,early_P0207_event_records=238))
print(json.dumps(m,ensure_ascii=False,indent=2))
