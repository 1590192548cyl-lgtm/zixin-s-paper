# 四批次G1估计目标审计

先阅读G1_estimand_weight_audit_report.md。

本轮未更换控制、未删批次、未实施新权重。逐观测审计CSV含CSMAR衍生数据，请勿上传公开GitHub。
