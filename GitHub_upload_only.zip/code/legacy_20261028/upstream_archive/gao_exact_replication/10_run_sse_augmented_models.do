version 18.0
clear all
set more off
set varabbrev off
set maxvar 20000

local work "/private/tmp/gao_exact_replication_work"
local out "`work'/outputs"
capture log close _all
log using "`out'/gao_sse_augmented_replication.log", text replace

use "`out'/gao_sse_augmented_exact_available_analysis.dta", clear
isid stack_id firm_id annual_report_year
assert inrange(event_time,-3,2)
assert annual_report_year==syn_year-1
assert TreatPost==treated_in_stack*Post
assert inlist(cohort_report_year,2012,2015,2016,2017)

local G1 "Size_w_exact MB_parent_w_exact Lev_w_exact"
local FULL "Size_w_exact MB_parent_w_exact Lev_w_exact Stdroa_w_exact abs_dEPS_w_exact abs_Accruals_w_exact Loss Length_MDA_w_exact Length_AR_w_exact Stdret_w_exact FundCorr_w_exact d_Instihold_w_exact Instihold_w_exact Analyst_exact_w_exact Indsize_broad_w_exact Subs_exact_w_exact Big4 Tophold_w_exact Tophold2_w_exact"

tempname mh ah
tempfile models attrition
postfile `mh' str40 model str24 sample long N_before N clusters treated_firms cohorts ///
    double TreatPost SE t p CI_low CI_high using `models', replace
postfile `ah' str40 model long N_before N_after dropped_by_reghdfe using `attrition', replace
global AUG_MODEL_POST "`mh'"
global AUG_ATTR_POST "`ah'"

capture program drop runmodel
program define runmodel
    version 18.0
    syntax, Model(string) Sample(name) [Controls(string)]
    quietly count if `sample'==1
    local nb=r(N)
    quietly reghdfe SYN_CSRC_FAMILY_w_exact TreatPost `controls' if `sample'==1, ///
        absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    local n=e(N)
    local nc=e(N_clust)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local tv=`b'/`se'
    local pv=2*ttail(e(df_r),abs(`tv'))
    local crit=invttail(e(df_r),.025)
    local lo=`b'-`crit'*`se'
    local hi=`b'+`crit'*`se'
    tempvar es tagt tagc
    gen byte `es'=e(sample)
    egen byte `tagt'=tag(firm_id) if `es' & treated_in_stack==1
    quietly count if `tagt'==1
    local nt=r(N)
    egen byte `tagc'=tag(cohort_report_year) if `es'
    quietly count if `tagc'==1
    local ng=r(N)
    post $AUG_MODEL_POST ("`model'") ("`sample'") (`nb') (`n') (`nc') (`nt') (`ng') ///
        (`b') (`se') (`tv') (`pv') (`lo') (`hi')
    post $AUG_ATTR_POST ("`model'") (`nb') (`n') (`=`nb'-`n'')
    drop `es' `tagt' `tagc'
end

runmodel, model(augmented_formula_base_no_controls) sample(sample_formula_base)
runmodel, model(augmented_G1) sample(sample_g1) controls("`G1'")
runmodel, model(augmented_full_sample_no_controls) sample(sample_full)
runmodel, model(augmented_full_controls) sample(sample_full) controls("`FULL'")

postclose `mh'
postclose `ah'
preserve
use `models', clear
export delimited using "`out'/gao_sse_augmented_replication_models.csv", replace
restore
preserve
use `attrition', clear
export delimited using "`out'/gao_sse_augmented_reghdfe_attrition.csv", replace
restore

log close
exit, clear
