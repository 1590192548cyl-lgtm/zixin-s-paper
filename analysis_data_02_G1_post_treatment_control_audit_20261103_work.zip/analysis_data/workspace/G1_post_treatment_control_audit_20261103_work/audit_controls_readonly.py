"""Read-only timing/availability audit. No estimates, analytical data, or replacements."""
from pathlib import Path
import hashlib
import json
import resource
import pandas as pd

ROOT = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
OUT = Path(__file__).resolve().parent
paths = {
    'frozen_G1': ROOT / 'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta',
    'controls': ROOT / 'gao_full_controls/gao_controls_firm_year_2009_2025.dta',
    'policy_lookup_only': ROOT / 'gao_treatment_eligibility_strict_recheck/official_table3_stack_analysis.dta',
    'existing_static_result': ROOT / 'four_cohort_G1_final_fixed_rerun_20261103/final_G1_static.csv',
    'Gao_extracted_text': ROOT / 'data_work/reference_text/gao2024.txt',
}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


before = {k: digest(v) for k, v in paths.items()}
a = pd.read_stata(paths['frozen_G1'], convert_categoricals=False)
s = a.loc[a.sample_g1.eq(1)].copy()
assert len(a) == 26711 and len(s) == 24659
assert not a.duplicated(['firm_id', 'stack_id', 'syn_year']).any()
assert s.annual_report_year.eq(s.syn_year - 1).all()
assert s.event_time.eq(s.annual_report_year - s.cohort_report_year).all()
assert set(s.cohort_report_year.unique()) == {2013, 2015, 2016, 2017}

timing = s.groupby(['cohort_report_year', 'event_time', 'treated_in_stack']).size().rename('N').reset_index()
timing['control_fiscal_year'] = timing.cohort_report_year + timing.event_time
timing['control_measurement_asof'] = timing.control_fiscal_year.astype(str) + '-12-31'
timing['syn_year'] = timing.control_fiscal_year + 1
timing['syn_window_start'] = timing.syn_year.astype(str) + '-05-01'
timing['syn_window_end'] = (timing.syn_year + 1).astype(str) + '-04-30'
timing['timing_status'] = timing.event_time.map({
    -3: 'before_first_applicable_report_year_not_announcement_certification',
    -2: 'before_first_applicable_report_year_not_announcement_certification',
    -1: 'before_first_applicable_report_year_not_announcement_certification',
    0: 'first_applicable_report_year_check_actual_announcement',
    1: 'subsequent_policy_year_not_strictly_pre_policy',
    2: 'subsequent_policy_year_not_strictly_pre_policy',
})
timing.to_csv(OUT / 'control_timing_counts.csv', index=False, encoding='utf-8-sig')

# Identity attachment is audit-only. Never overwrite the slim/frozen analysis data.
lookup = pd.read_stata(paths['policy_lookup_only'], columns=[
    'firm_id', 'stack_id', 'annual_report_year', 'primary_iidg_id'
], convert_categoricals=False)
z = s.merge(lookup, on=['firm_id', 'stack_id', 'annual_report_year'], how='left', validate='one_to_one', indicator=True)
assert z._merge.eq('both').all()
# Only this event version was date-verified against the official notice in this audit.
verified_four = z.cohort_report_year.eq(2015) & z.primary_iidg_id.isin(['SSE-04', 'SSE-05', 'SSE-06', 'SSE-07'])
z['date_verification'] = 'exact_event_version_not_fully_verified_in_this_audit'
z.loc[verified_four, 'date_verification'] = 'official_notice_2015_09_11_effective_2015_10_01'
policy_summary = z[z.treated_in_stack.eq(1)].groupby([
    'cohort_report_year', 'primary_iidg_id', 'date_verification'
]).agg(stack_rows=('firm_id', 'size'), firms=('firm_id', 'nunique')).reset_index()
policy_summary.to_csv(OUT / 'policy_version_verification_scope.csv', index=False, encoding='utf-8-sig')

# Availability only: no candidate baseline variable is saved or used in an estimator.
c = pd.read_stata(paths['controls'], columns=['firm_id', 'fiscal_year', 'Size', 'MB_parent', 'Lev'], convert_categoricals=False)
key = s[['firm_id', 'stack_id', 'cohort_report_year', 'treated_in_stack']].copy()
for frame in (key, c):
    frame['firm_id'] = frame.firm_id.astype(str).str.replace(r'\.0$', '', regex=True).str.zfill(6)
key['candidate_baseline_year'] = key.cohort_report_year - 1
c = c.rename(columns={'fiscal_year': 'candidate_baseline_year'})
b = key.merge(c, on=['firm_id', 'candidate_baseline_year'], how='left', validate='many_to_one')
b['all_three_available'] = b[['Size', 'MB_parent', 'Lev']].notna().all(axis=1)
b['Size_missing'] = b.Size.isna()
b['MB_missing'] = b.MB_parent.isna()
b['Lev_missing'] = b.Lev.isna()
base = b.groupby('cohort_report_year').agg(
    current_rows=('firm_id', 'size'), rows_with_three_available=('all_three_available', 'sum'),
    Size_missing_rows=('Size_missing', 'sum'), MB_missing_rows=('MB_missing', 'sum'),
    Lev_missing_rows=('Lev_missing', 'sum')
)
u = b.drop_duplicates(['firm_id', 'stack_id'])
base = base.join(u.groupby('cohort_report_year').agg(
    current_firm_stacks=('firm_id', 'size'), firm_stacks_with_three_available=('all_three_available', 'sum')
))
base['candidate_baseline_year'] = base.index - 1
base['announcement_status'] = 'candidate_only_not_certified_pre_announcement_for_all_policies'
base.to_csv(OUT / 'candidate_baseline_availability.csv', encoding='utf-8-sig')

after = {k: digest(v) for k, v in paths.items()}
assert before == after
pd.DataFrame([{'input': k, 'path': str(paths[k]), 'sha256_before': before[k],
               'sha256_after': after[k], 'unchanged': before[k] == after[k]} for k in paths]).to_csv(
    OUT / 'input_integrity.csv', index=False, encoding='utf-8-sig')
t = s.loc[s.treated_in_stack.eq(1)]
summary = {
    'status': 'READ_ONLY_AUDIT_COMPLETED_NO_REGRESSION',
    'regression_runs_this_audit': 0, 'variables_replaced': 0, 'rows_deleted': 0,
    'raw_stack_rows': len(a), 'unchanged_G1_sample_rows': len(s),
    'treated_stack_rows': len(t), 'treated_event0_rows': int(t.event_time.eq(0).sum()),
    'treated_later_policy_year_rows': int(t.event_time.gt(0).sum()),
    'candidate_baseline_missing_rows': int((~b.all_three_available).sum()),
    'candidate_baseline_missing_firm_stacks': int((~u.all_three_available).sum()),
    'officially_date_checked_policy_families': 4,
    'date_checked_treated_rows': int((verified_four & z.treated_in_stack.eq(1)).sum()),
    'date_checked_treated_firms': int(z.loc[verified_four & z.treated_in_stack.eq(1), 'firm_id'].nunique()),
    'all_inputs_unchanged': True,
    'python_peak_memory_mib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 ** 2,
}
(OUT / 'audit_status.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
