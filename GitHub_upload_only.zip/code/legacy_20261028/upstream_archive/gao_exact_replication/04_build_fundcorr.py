from pathlib import Path
import gc
import json
import math
import time

import numpy as np
import pandas as pd
from openpyxl import load_workbook


ROOT = Path("/Users/macpro/Desktop")
WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"
INCOME = ROOT / "控制变量/营业利润净利润/FS_Comins.xlsx"
BALANCE = ROOT / "控制变量/资产合计负债合计所有者权益合计/FS_Combas.xlsx"
INDUSTRY = ROOT / "毕业论文/堆叠DID重跑/data_work/industry_new_standardized.dta"
WEEK_FILES = [
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week.dta",
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week1.dta",
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week2.dta",
]

YEAR_MIN = 2007
YEAR_MAX = 2019
CSRC_RULE = {
    **{y: "P0201" for y in range(2008, 2012)},
    **{y: "P0207" for y in range(2012, 2020)},
}


def stream_xlsx(path, value_col):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    # CSMAR files have an incorrect A-only dimension; reset it before streaming.
    ws.reset_dimensions()
    rows = ws.iter_rows(values_only=True)
    header = next(rows)
    names = {v: i for i, v in enumerate(header)}
    required = ["Stkcd", "Accper", "Typrep", value_col]
    missing = [x for x in required if x not in names]
    if missing:
        raise KeyError(f"{path}: missing {missing}")
    next(rows, None)
    next(rows, None)
    out = []
    for row in rows:
        try:
            if str(row[names["Typrep"]]).strip() != "A":
                continue
            fid = int(float(str(row[names["Stkcd"]]).strip()))
            dt = pd.Timestamp(row[names["Accper"]])
            value = float(row[names[value_col]])
        except (TypeError, ValueError, OverflowError):
            continue
        if not YEAR_MIN <= dt.year <= YEAR_MAX or dt.month not in (3, 6, 9, 12):
            continue
        out.append((fid, dt, value))
    wb.close()
    return pd.DataFrame(out, columns=["firm_id", "date", value_col])


def weekly_quarter_end_cap():
    frames = []
    for p in WEEK_FILES:
        for ch in pd.read_stata(
            p,
            columns=["Stkcd", "Trdwnt", "Wsmvosd"],
            convert_categoricals=False,
            chunksize=250_000,
        ):
            fid = pd.to_numeric(ch["Stkcd"], errors="coerce")
            key = pd.to_numeric(
                ch["Trdwnt"].astype(str).str.replace("-", "", regex=False),
                errors="coerce",
            )
            cap = pd.to_numeric(ch["Wsmvosd"], errors="coerce")
            good = fid.notna() & key.notna() & cap.gt(0)
            y = (key[good] // 100).astype(int)
            w = (key[good] % 100).astype(int)
            date = pd.to_datetime(
                y.astype(str) + "-" + w.astype(str).str.zfill(2) + "-1",
                format="%Y-%W-%w",
                errors="coerce",
            )
            z = pd.DataFrame(
                {
                    "firm_id": fid[good].astype(np.int32),
                    "date": date,
                    "week_key": key[good].astype(np.int32),
                    "market_cap": cap[good].astype(np.float64),
                }
            ).dropna(subset=["date"])
            z = z[z.date.dt.year.between(YEAR_MIN, YEAR_MAX)]
            z["year"] = z.date.dt.year.astype(np.int16)
            z["quarter"] = z.date.dt.quarter.astype(np.int8)
            frames.append(z)
    d = pd.concat(frames, ignore_index=True)
    d.sort_values(["firm_id", "year", "quarter", "week_key"], inplace=True)
    return d.drop_duplicates(["firm_id", "year", "quarter"], keep="last")[
        ["firm_id", "year", "quarter", "market_cap"]
    ]


def industry_map():
    cols = ["EndDate", "IndustryClassificationID", "Symbol", "IndustryCode2", "IndustryName2"]
    d = pd.read_stata(INDUSTRY, columns=cols, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.Symbol, errors="coerce").astype("Int64")
    d["year"] = pd.to_datetime(d.EndDate, errors="coerce").dt.year.astype("Int64")
    rows = []
    for y, std in CSRC_RULE.items():
        rows.append(d[(d.year.eq(y)) & (d.IndustryClassificationID.eq(std))].copy())
    m = pd.concat(rows, ignore_index=True)
    m = m.sort_values(["firm_id", "year", "EndDate"]).drop_duplicates(
        ["firm_id", "year"], keep="last"
    )
    return m[["firm_id", "year", "IndustryClassificationID", "IndustryCode2", "IndustryName2"]]


def main():
    start = time.time()
    inc = stream_xlsx(INCOME, "B001300000")
    bal = stream_xlsx(BALANCE, "A001000000")
    q = inc.merge(bal, on=["firm_id", "date"], how="inner", validate="one_to_one")
    q["year"] = q.date.dt.year.astype(np.int16)
    q["quarter"] = q.date.dt.quarter.astype(np.int8)
    q.sort_values(["firm_id", "year", "quarter"], inplace=True)

    # CSMAR quarterly income statement fields are year-to-date. Convert to
    # single-quarter operating income only when the prior quarter exists.
    q["q_operating_income"] = q["B001300000"]
    prior_cum = q.groupby(["firm_id", "year"], sort=False)["B001300000"].shift(1)
    prior_quarter = q.groupby(["firm_id", "year"], sort=False)["quarter"].shift(1)
    later = q.quarter.gt(1)
    consecutive = prior_quarter.eq(q.quarter - 1)
    q.loc[later & consecutive, "q_operating_income"] = (
        q.loc[later & consecutive, "B001300000"] - prior_cum[later & consecutive]
    )
    q.loc[later & ~consecutive, "q_operating_income"] = np.nan
    q["quarterly_roa"] = q["q_operating_income"] / q["A001000000"]
    q.loc[~np.isfinite(q.quarterly_roa), "quarterly_roa"] = np.nan

    cap = weekly_quarter_end_cap()
    ind = industry_map()
    q = q.merge(cap, on=["firm_id", "year", "quarter"], how="left", validate="one_to_one")
    q = q.merge(ind, on=["firm_id", "year"], how="left", validate="many_to_one")
    q["industry_key"] = (
        q["IndustryClassificationID"].astype(str) + "|" + q["IndustryCode2"].astype(str)
    )
    valid = q.quarterly_roa.notna() & q.market_cap.gt(0) & q.IndustryCode2.notna()
    v = q[valid].copy()
    v["weighted_roa"] = v.quarterly_roa * v.market_cap
    agg = (
        v.groupby(["year", "quarter", "industry_key"], sort=False)
        .agg(sum_weighted_roa=("weighted_roa", "sum"), sum_cap=("market_cap", "sum"), n_firms=("firm_id", "nunique"))
        .reset_index()
    )
    q = q.merge(agg, on=["year", "quarter", "industry_key"], how="left", validate="many_to_one")
    den = q.sum_cap - q.market_cap
    q["industry_vw_roa_ex_firm"] = np.where(
        (den > 0) & q.n_firms.gt(1),
        (q.sum_weighted_roa - q.quarterly_roa * q.market_cap) / den,
        np.nan,
    )
    q["quarter_index"] = q.year.astype(int) * 4 + q.quarter.astype(int)
    q.sort_values(["firm_id", "quarter_index"], inplace=True)

    out = []
    for fid, g in q.groupby("firm_id", sort=True):
        g = g.set_index("quarter_index", drop=False)
        for year in range(2009, 2020):
            end = year * 4 + 4
            idx = np.arange(end - 11, end + 1)
            if not np.isin(idx, g.index).all():
                continue
            z = g.loc[idx, ["quarterly_roa", "industry_vw_roa_ex_firm"]].dropna()
            if len(z) != 12:
                continue
            yy = z.quarterly_roa.to_numpy(float)
            xx = np.column_stack([np.ones(12), z.industry_vw_roa_ex_firm.to_numpy(float)])
            beta, _, rank, _ = np.linalg.lstsq(xx, yy, rcond=None)
            resid = yy - xx @ beta
            sst = float(((yy - yy.mean()) ** 2).sum())
            r2 = np.nan if sst <= 0 else 1 - float(resid @ resid) / sst
            fc = math.log(r2 / (1 - r2)) if np.isfinite(r2) and 0 < r2 < 1 else np.nan
            out.append(
                {
                    "firm_id": int(fid),
                    "fiscal_year": year,
                    "FundCorr": fc,
                    "FundCorr_R2": r2,
                    "FundCorr_quarters": 12,
                    "FundCorr_weight": "quarter-end weekly market capitalization",
                }
            )
    res = pd.DataFrame(out)
    s = res.FundCorr.dropna()
    p1, p99 = float(s.quantile(0.01)), float(s.quantile(0.99))
    res["FundCorr_w"] = res.FundCorr.clip(p1, p99)
    res.to_csv(OUT / "fundcorr_firm_year_2009_2019.csv", index=False)
    res.to_stata(OUT / "fundcorr_firm_year_2009_2019.dta", write_index=False, version=118)
    by_year = res.groupby("fiscal_year").FundCorr.agg(["count", "mean", "std", "median", "min", "max"]).reset_index()
    by_year.to_csv(OUT / "fundcorr_coverage_by_year.csv", index=False)
    # The compact firm-year result and the construction audit are the durable
    # replication outputs. The several-hundred-thousand-row quarterly working
    # frame is intentionally not persisted, keeping disk and memory use low.
    meta = {
        "income_quarter_rows": len(inc),
        "balance_quarter_rows": len(bal),
        "merged_quarter_rows": len(q),
        "fundcorr_firm_years": len(res),
        "fundcorr_unique_firms": int(res.firm_id.nunique()),
        "fundcorr_mean": float(s.mean()),
        "fundcorr_median": float(s.median()),
        "fundcorr_sd": float(s.std()),
        "paper_mean": -2.676,
        "paper_median": -2.112,
        "paper_sd": 2.007,
        "winsor_p1": p1,
        "winsor_p99": p99,
        "industry_weight": "quarter-end market capitalization from the last observed weekly record in each calendar quarter",
        "quarterly_income_conversion": "CSMAR cumulative operating income converted to single-quarter flow by within-firm-year differencing",
        "elapsed_seconds": time.time() - start,
    }
    (OUT / "fundcorr_build_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2), flush=True)
    print(by_year.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
