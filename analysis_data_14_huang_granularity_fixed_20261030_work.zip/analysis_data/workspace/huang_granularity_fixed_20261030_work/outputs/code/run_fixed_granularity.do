version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/huang_granularity_fixed_20261030_work/outputs"
log using "`out'/fixed_granularity_stata.log", text replace
which reghdfe
tempname mh eh jh
tempfile main events joint
postfile `mh' str24 model long N clusters treated_firms control_firms cohorts double TreatPost SE t p CI_low CI_high df_r using `main', replace
postfile `eh' str24 model int event_time long N clusters double coefficient SE t p CI_low CI_high using `events', replace
postfile `jh' str24 model str12 test long N clusters double F df_num df_den p using `joint', replace
foreach version in old new {
    use "`out'/analysis_granularity_compare.dta", clear
    local y "SYN_CSRC_FAMILY_w_exact"
    if "`version'"=="new" local y "SYN_huang_grain_w"
    isid firm_id stack_id annual_report_year
    assert annual_report_year==syn_year-1
    assert event_time==annual_report_year-cohort_report_year
    assert inrange(event_time,-3,2)
    assert TreatPost==treated_in_stack*Post
    assert inlist(treated_in_stack,0,1)
    assert !missing(`y',Size_w_exact,MB_parent_w_exact,Lev_w_exact,TreatPost) if common_sample==1
    quietly count if common_sample==1
    local expected=r(N)
    reghdfe `y' TreatPost Size_w_exact MB_parent_w_exact Lev_w_exact if common_sample==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    assert e(N)==`expected'
    gen byte static_es=e(sample)
    assert static_es==common_sample
    local n=e(N)
    local nc=e(N_clust)
    local df=e(df_r)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local t=`b'/`se'
    local p=2*ttail(`df',abs(`t'))
    local crit=invttail(`df',.025)
    egen byte ft=tag(firm_id) if static_es&treated_in_stack==1
    egen byte fc=tag(firm_id) if static_es&treated_in_stack==0
    egen byte fg=tag(cohort_report_year) if static_es
    quietly count if ft==1
    local nt=r(N)
    quietly count if fc==1
    local n0=r(N)
    quietly count if fg==1
    local ng=r(N)
    assert `ng'==4
    post `mh' ("`version'_common_G1") (`n') (`nc') (`nt') (`n0') (`ng') (`b') (`se') (`t') (`p') (`b'-`crit'*`se') (`b'+`crit'*`se') (`df')
    estimates save "`out'/`version'_common_static.ster", replace
    preserve
    keep firm_id stack_id annual_report_year syn_year event_time treated_in_stack static_es common_sample
    export delimited using "`out'/`version'_static_sample.csv", replace
    restore
    gen byte D_m2=treated_in_stack==1 & event_time==-2
    gen byte D_m1=treated_in_stack==1 & event_time==-1
    gen byte D_0=treated_in_stack==1 & event_time==0
    gen byte D_p1=treated_in_stack==1 & event_time==1
    gen byte D_p2=treated_in_stack==1 & event_time==2
    foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
        assert inlist(`term',0,1)
        assert `term'==0 if treated_in_stack==0 | event_time==-3
    }
    reghdfe `y' D_m2 D_m1 D_0 D_p1 D_p2 Size_w_exact MB_parent_w_exact Lev_w_exact if common_sample==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    assert e(N)==`expected'
    gen byte event_es=e(sample)
    assert event_es==static_es
    local crit=invttail(e(df_r),.025)
    foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
        local et=-2
        if "`term'"=="D_m1" local et=-1
        if "`term'"=="D_0" local et=0
        if "`term'"=="D_p1" local et=1
        if "`term'"=="D_p2" local et=2
        local b=_b[`term']
        local se=_se[`term']
        assert `se'>0 & !missing(`se')
        local t=`b'/`se'
        local p=2*ttail(e(df_r),abs(`t'))
        post `eh' ("`version'_common_G1") (`et') (e(N)) (e(N_clust)) (`b') (`se') (`t') (`p') (`b'-`crit'*`se') (`b'+`crit'*`se')
    }
    test D_m2 D_m1
    post `jh' ("`version'_common_G1") ("pre_joint") (e(N)) (e(N_clust)) (r(F)) (r(df)) (r(df_r)) (r(p))
    test D_0 D_p1 D_p2
    post `jh' ("`version'_common_G1") ("post_joint") (e(N)) (e(N_clust)) (r(F)) (r(df)) (r(df_r)) (r(p))
    estimates save "`out'/`version'_common_event.ster", replace
    preserve
    keep firm_id stack_id annual_report_year event_time treated_in_stack event_es common_sample
    export delimited using "`out'/`version'_event_sample.csv", replace
    restore
}
postclose `mh'
postclose `eh'
postclose `jh'
use `main', clear
export delimited using "`out'/static_common_comparison.csv", replace
use `joint', clear
export delimited using "`out'/event_joint_tests.csv", replace
use `events', clear
sort model event_time
export delimited using "`out'/event_study_comparison.csv", replace
set obs `=_N+2'
local last=_N
local penultimate=_N-1
replace model="old_common_G1" in `last'
replace model="new_common_G1" in `penultimate'
replace event_time=-3 if missing(event_time)
replace coefficient=0 if event_time==-3
sort model event_time
twoway (rcap CI_low CI_high event_time if model=="old_common_G1",lcolor(gs10)) (connected coefficient event_time if model=="old_common_G1",lcolor(gs8) mcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if model=="new_common_G1",lcolor(navy)) (connected coefficient event_time if model=="new_common_G1",lcolor(navy) mcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-3 reference)") ytitle("SYN coefficient") legend(order(2 "Original granularity: common sample" 4 "Non-manufacturing level 1: common sample") position(6) rows(2) size(small) region(lstyle(none))) title("Fixed G1: industry-granularity comparison",size(medium)) note("95% firm-clustered CI; same sample, controls, FE and four cohorts",size(small)) graphregion(color(white)) xsize(8) ysize(5)
graph export "`out'/industry_granularity_event_plot.png", width(2200) replace
display as result "FIXED_GRANULARITY_COMPLETE"
log close
exit, clear
