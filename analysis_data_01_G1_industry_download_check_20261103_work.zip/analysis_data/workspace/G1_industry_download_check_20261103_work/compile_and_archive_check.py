from pathlib import Path
import hashlib,json,shutil,sys
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
PREV=P/'G1_true_data_repair_20261103'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def md(d):
    return '\n'.join(['|'+'|'.join(map(str,d.columns))+'|','|'+'|'.join(['---']*len(d.columns))+'|']+
                     ['|'+'|'.join(map(str,row))+'|' for row in d.itertuples(index=False,name=None)])

if len(sys.argv)>1 and sys.argv[1]=='archive':
    target=P/'G1_industry_download_check_20261103'
    assert not target.exists(),'Do not overwrite historical audit'
    shutil.copytree(O,target);(target/'code').mkdir()
    for f in ['check_new_industry.py','compile_and_archive_check.py']:shutil.copy2(W/f,target/'code'/f)
    entries=[]
    for f in O.iterdir():
        if f.is_file():
            assert sha(f)==sha(target/f.name)
            entries.append({'file':f.name,'bytes':f.stat().st_size,'sha256':sha(target/f.name)})
    (target/'archive_manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'archive':str(target),'verified_output_files':len(entries),'output_bytes':sum(x['bytes'] for x in entries)},ensure_ascii=False))
    raise SystemExit

s=json.loads((O/'new_download_check_summary.json').read_text())
coverage=pd.read_csv(O/'new_P0201_year_coverage.csv').rename(columns={'industry_year':'年份','firms':'公司数','rows':'观测数','level1_missing':'一级码缺失','level2_missing':'二级码缺失'})
oldmanifest=pd.read_csv(PREV/'financial_source_manifest_before.csv')
financial=[]
for r in oldmanifest.itertuples():
    financial.append({'file':r.path,'previous_sha256':r.sha256,'current_sha256':sha(Path(r.path)),
                       'changed_since_financial_audit':sha(Path(r.path))!=r.sha256})
fm=pd.DataFrame(financial);fm.to_csv(O/'financial_sources_change_check.csv',index=False,encoding='utf-8-sig')
assert not fm.changed_since_financial_audit.any(),'New financial source changes require separate review'
stack=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
before=pd.read_csv(PREV/'primary_input_manifest_before.csv')
assert sha(stack)==before.loc[before.path.eq(str(stack)),'sha256'].iloc[0]
assert s['required_industry_source_ready'] and s['fixed_old_pool_partition_equivalent']
text=f'''# 新下载行业分类是否补齐：增量核验

## Material Passport

- 日期：2026-11-03；来源技能：academic-research-suite / experiment-agent与表格只读审计。
- 状态：ANALYZED，已完整读取新表实际数据行并与旧源/缺口清单核对；不是回归复现认证。
- 本次用户请求仅检查是否补齐；没有合并或修改正式分析数据、没有重算SYN、没有运行回归。

## 结论

**必需的早期行业来源已补齐，可以解除上一轮的行业分类来源等待。**
新文件是：{s['source_file']}。

- 实际1个sheet，{s['actual_data_rows']:,}条数据、10个真实非空字段；不含说明行和空行。
- P0201的2009—2011年记录{s['P0201_rows_2009_2011']:,}条，与旧源6,057个公司年度键完全一致；无漏键、无多键、无重复冲突。
- 股票代码、InstitutionID、EndDate、IndustryClassificationID、一级/二级代码及行业名称均已提供。
- 新表未单独导出IndustryClassification名称列，但CSMAR字段说明明确P0201为证监会行业分类2001年版；旧同键源的实际分类名称亦已核对。无需为这个冗余名称列再次下载。

## 按年实际覆盖

{md(coverage)}

一级码全部非缺失。二级码缺失仍然存在，但新表真实一级码表明这些记录均为M、综合类，不是应当随意填出的普通二级码。

## 此前缺口是否解决

- 先前170条占位二级码记录：170/170有同期一级/完整行业代码支持。
- 当前G1直接涉及的2011年30条：30/30均有同期真实记录，全部一级M、综合类。
- 原先20家缺同期直接证据的公司：20/20已找到，不再需要补年报文本。
- 新表对旧有效二级码的更改：0；固定原成员集合后，旧行业组未被拆分或合并。

## 对SYN和正式回归意味着什么

旧的P0201|None组与新来源确认的P0201|M组成员集合完全相同；其他二级组也不变。
因此，在原收益池、原二级分组原则和原算法不变的条件下，这属于组标签与真实证据核实，不是行业收益分组的实质改变。
本次没有数值重算SYN，不能把新表当作“修复后系数更显著”的证据，也不能把旧None组继续描述成已查实的跨行业混编错误。
若接下来只是按证据把标签记为M，原行业收益和SYN在数学上不应因重命名而发生实质变化。

这与此前“所有非制造业聚合到一级”的黄文式敏感性口径不同，本次没有采用该口径。

## 财务缺口是否也补齐

本次新增的是行业分类表。此前检查的7份财务/市值来源指纹均未改变，没有发现新增年末市值来源。
因此，原2,052条损失的解释不变，本次不能宣称恢复了这些观测：

- 上市前控制年度及其连带支持不足：1,879条。
- 非正母公司权益及其连带支持不足：135条。
- 10个上市后年末市值缺口及其连带支持不足：38条。

10个年度市值仅是可选定点核验；若CSMAR确实无原始值，保持缺失，不必为了它们重新下载财务全库。

## 保护、资源和下一步

- 新表、旧源及缺口清单的输入指纹运行前后一致；原正式DTA指纹也与上轮一致。
- Python峰值RSS约{s['Python_peak_RSS_MiB']:.1f}MiB；只检查小表及必要旧字段，没有加载年报或周收益。
- 本轮只做核验，不改三控制，不重建stack，不删批次，不重新缩尾，不消耗既定的一次回归。
- 若继续原计划，应先保存分类证据已补齐的说明；因分组成员未变、财务也未新增，不应预期只靠这次补下载使N或显著性改变。可以做原设定的最终固定复核，但不能将相同数据重复运行称作新的实证改进。

## 关键检查文件

- new_P0201_year_coverage.csv：按年覆盖。
- current_G1_30_evidence_check_private.csv：30条逐条来源行号与行业代码。
- all_170_prior_placeholder_evidence_private.csv：完整占位码缺口核实。
- industry_partition_equivalence.csv：分组成员等价核对。
- input_integrity.csv及financial_sources_change_check.csv：输入及旧财务来源指纹。

private文件含CSMAR衍生数据，不应上传公开GitHub。
'''
(O/'industry_download_check_report.md').write_text(text,encoding='utf-8')
status={'stage':'INDUSTRY_SOURCE_READY_PARTITION_UNCHANGED','previous_required_industry_download_resolved':True,
        'current_G1_30_records_resolved':30,'previous20_unverified_resolved':20,
        'industry_partition_changed':False,'new_financial_sources_found':False,
        'formal_data_modified':False,'SYN_recomputed':False,'regressions_run':0,
        'previous_status_file_retained_without_overwrite':str(PREV/'continuation_status.json')}
(O/'continuation_addendum.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'READ_FIRST.md').write_text('# 新行业来源已经补齐，未启动回归\n\n先看industry_download_check_report.md。\n\n170条分类缺口全部核清；30条当前观测及此前20家均为综合类M；旧行业分组成员未改变，不能预期仅重命名就提高显著性。\n\n上轮审计报告和等待状态保留为历史；当前以continuation_addendum.json为新状态说明。\n',encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2))
