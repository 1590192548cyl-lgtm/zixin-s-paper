version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/four_cohort_G1_latest_recheck_20261028_work/outputs"
global G1OUT "`out'"
log using "`out'/four_cohort_G1_rerun.log", text replace
which reghdfe
local x "Size_w_exact MB_parent_w_exact Lev_w_exact"
tempname mh eh jh
tempfile main events joint
postfile `mh' str24 model str24 sample long complete_N N clusters treated_firms control_firms cohorts double TreatPost SE t p CI_low CI_high df_r using `main', replace
postfile `eh' str24 model int event_time long N clusters double coefficient SE t p CI_low CI_high using `events', replace
postfile `jh' str24 model str12 test long N clusters double F df_num df_den p using `joint', replace
global G1MH "`mh'"
global G1EH "`eh'"
global G1JH "`jh'"

program define runstatic
    syntax, Model(string) Sample(name)
    isid firm_id stack_id annual_report_year
    assert inrange(event_time,-3,2)
    assert annual_report_year==syn_year-1
    assert TreatPost==treated_in_stack*Post
    quietly count if `sample'==1
    local rawN=r(N)
    reghdfe SYN_CSRC_FAMILY_w_exact TreatPost Size_w_exact MB_parent_w_exact Lev_w_exact if `sample'==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    assert e(N)==`rawN'
    assert _se[TreatPost]>0 & !missing(_se[TreatPost])
    local n=e(N)
    local nc=e(N_clust)
    local df=e(df_r)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local tv=`b'/`se'
    local pv=2*ttail(`df',abs(`tv'))
    local crit=invttail(`df',.025)
    gen byte actual_es=e(sample)
    assert actual_es==(`sample'==1)
    tempvar ft fc fg
    egen byte `ft'=tag(firm_id) if e(sample)&treated_in_stack==1
    egen byte `fc'=tag(firm_id) if e(sample)&treated_in_stack==0
    egen byte `fg'=tag(cohort_report_year) if e(sample)
    quietly count if `ft'==1
    local nt=r(N)
    quietly count if `fc'==1
    local n0=r(N)
    quietly count if `fg'==1
    local ng=r(N)
    assert `ng'==4
    post $G1MH ("`model'") ("`sample'") (`rawN') (`n') (`nc') (`nt') (`n0') (`ng') (`b') (`se') (`tv') (`pv') (`b'-`crit'*`se') (`b'+`crit'*`se') (`df')
    estimates save "$G1OUT/`model'.ster", replace
    preserve
    keep firm_id stack_id annual_report_year syn_year cohort_report_year event_time treated_in_stack TreatPost actual_es
    export delimited using "$G1OUT/`model'_estimation_sample.csv", replace
    restore
    drop actual_es `ft' `fc' `fg'
end

foreach version in old strict latest {
    use "`out'/`version'_G1_analysis.dta", clear
    runstatic, model("`version'_G1") sample(sample_g1)
}
foreach version in old latest {
    use "`out'/`version'_G1_analysis.dta", clear
    runstatic, model("`version'_G1_common") sample(common_G1_sample)
}
postclose `mh'
use `main', clear
export delimited using "`out'/G1_static_rerun_results.csv", replace

foreach version in old latest {
    use "`out'/`version'_G1_analysis.dta", clear
    gen byte D_m2=treated_in_stack==1 & event_time==-2
    gen byte D_m1=treated_in_stack==1 & event_time==-1
    gen byte D_0=treated_in_stack==1 & event_time==0
    gen byte D_p1=treated_in_stack==1 & event_time==1
    gen byte D_p2=treated_in_stack==1 & event_time==2
    foreach var in D_m2 D_m1 D_0 D_p1 D_p2 {
        assert inlist(`var',0,1)
        assert `var'==0 if treated_in_stack==0 | event_time==-3
    }
    assert D_m2+D_m1+D_0+D_p1+D_p2==1 if treated_in_stack==1 & event_time!=-3
    reghdfe SYN_CSRC_FAMILY_w_exact D_m2 D_m1 D_0 D_p1 D_p2 Size_w_exact MB_parent_w_exact Lev_w_exact if sample_g1==1, absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    local n=e(N)
    local nc=e(N_clust)
    local crit=invttail(e(df_r),.025)
    gen byte event_es=e(sample)
    assert event_es==sample_g1
    foreach term in D_m2 D_m1 D_0 D_p1 D_p2 {
        local et=-2
        if "`term'"=="D_m1" local et=-1
        if "`term'"=="D_0" local et=0
        if "`term'"=="D_p1" local et=1
        if "`term'"=="D_p2" local et=2
        local b=_b[`term']
        local se=_se[`term']
        assert `se'>0 & !missing(`se')
        local tv=`b'/`se'
        local pv=2*ttail(e(df_r),abs(`tv'))
        post $G1EH ("`version'_G1") (`et') (`n') (`nc') (`b') (`se') (`tv') (`pv') (`b'-`crit'*`se') (`b'+`crit'*`se')
    }
    test D_m2 D_m1
    post $G1JH ("`version'_G1") ("pre_joint") (`n') (`nc') (r(F)) (r(df)) (r(df_r)) (r(p))
    test D_0 D_p1 D_p2
    post $G1JH ("`version'_G1") ("post_joint") (`n') (`nc') (r(F)) (r(df)) (r(df_r)) (r(p))
    estimates save "`out'/`version'_G1_event.ster", replace
    preserve
    keep firm_id stack_id annual_report_year syn_year cohort_report_year event_time treated_in_stack event_es
    export delimited using "`out'/`version'_G1_event_sample.csv", replace
    restore
}
postclose `eh'
postclose `jh'
use `joint', clear
export delimited using "`out'/G1_event_joint_tests.csv", replace
use `events', clear
sort model event_time
export delimited using "`out'/G1_event_results.csv", replace
set obs `=_N+2'
local last=_N
local penultimate=_N-1
replace model="old_G1" in `last'
replace model="latest_G1" in `penultimate'
replace event_time=-3 if missing(event_time)
replace coefficient=0 if event_time==-3
sort model event_time
twoway (rcap CI_low CI_high event_time if model=="old_G1",lcolor(gs10)) (connected coefficient event_time if model=="old_G1",lcolor(gs8) mcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if model=="latest_G1",lcolor(navy)) (connected coefficient event_time if model=="latest_G1",lcolor(navy) mcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-3 reference)") ytitle("SYN coefficient") legend(order(2 "Historical G1" 4 "Latest verified G1") position(6) rows(1) size(small) region(lstyle(none))) title("Four-cohort G1: verified-list update",size(medium)) note("95% firm-clustered CI; original Size, MB and Lev; four cohorts retained",size(small)) graphregion(color(white)) xsize(8) ysize(5)
graph export "`out'/G1_event_old_vs_latest.png", width(2200) replace
display as result "FOUR_COHORT_G1_FIXED_RECHECK_COMPLETE"
log close
exit, clear
