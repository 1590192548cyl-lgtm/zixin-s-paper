from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/macpro/Documents/New project/pretrend_balance_weighting_work")
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)
STACK = Path("/Users/macpro/Desktop/毕业论文/堆叠DID重跑/own_controls_systematic_test/stacked_did_own_controls.dta")

BALANCE_VARS = [
    "Size_w", "Lev_w", "MB_w", "Age_w", "Turnover_w", "ROA_w",
    "Growth_w", "CFO_w", "Loss", "Tophold_w", "Instihold_w",
]
CORE_VARS = ["Size_w", "Lev_w", "MB_w", "Age_w", "Turnover_w", "ROA_w"]
ID_VARS = ["firm_id", "stack_id", "cohort_report_year", "event_time", "treated_in_stack"]


def weighted_sd(x: np.ndarray, w: np.ndarray) -> float:
    total = float(w.sum())
    if total <= 0:
        return math.nan
    mean = float(np.dot(w, x) / total)
    denom = total - float(np.dot(w, w) / total)
    if denom <= 0:
        return math.nan
    return float(np.sqrt(np.dot(w, (x - mean) ** 2) / denom))


def smd(mean_t: float, mean_c: float, sd_t: float, sd_c: float) -> float:
    pooled = math.sqrt((sd_t * sd_t + sd_c * sd_c) / 2.0)
    if pooled == 0:
        return 0.0 if mean_t == mean_c else math.copysign(math.inf, mean_t - mean_c)
    return (mean_t - mean_c) / pooled


def entropy_weights(control: np.ndarray, treated_mean: np.ndarray) -> tuple[np.ndarray, dict]:
    center = control.mean(axis=0)
    scale = control.std(axis=0, ddof=1)
    if np.any(~np.isfinite(scale)) or np.any(scale <= 0):
        raise ValueError("one or more control covariates have zero/invalid variance")
    z = (control - center) / scale
    target = (treated_mean - center) / scale

    def state(lam: np.ndarray) -> tuple[float, np.ndarray, np.ndarray, np.ndarray]:
        eta = z @ lam
        eta_max = float(eta.max())
        exp_eta = np.exp(eta - eta_max)
        sum_exp = float(exp_eta.sum())
        p = exp_eta / sum_exp
        mean_z = p @ z
        grad = mean_z - target
        centered = z - mean_z
        hessian = centered.T @ (centered * p[:, None])
        obj = eta_max + math.log(sum_exp) - math.log(len(eta)) - float(np.dot(target, lam))
        return obj, grad, hessian, p

    lam = np.zeros(z.shape[1])
    inverse_hessian = np.eye(z.shape[1])
    success = False
    message = "maximum iterations reached"
    max_iter = 5000
    for iteration in range(max_iter):
        obj, grad, _, _ = state(lam)
        if float(np.max(np.abs(grad))) < 1e-7:
            success = True
            message = "converged by gradient tolerance"
            break
        direction = -(inverse_hessian @ grad)
        directional_derivative = float(np.dot(grad, direction))
        if not np.isfinite(directional_derivative) or directional_derivative >= 0:
            inverse_hessian = np.eye(z.shape[1])
            direction = -grad
            directional_derivative = -float(np.dot(grad, grad))
        step = 1.0
        accepted = False
        for _ in range(60):
            candidate = lam + step * direction
            candidate_obj, candidate_grad, _, _ = state(candidate)
            if np.isfinite(candidate_obj) and candidate_obj <= obj + 1e-4 * step * directional_derivative:
                accepted = True
                break
            step *= 0.5
        if not accepted:
            message = "line search failed"
            break
        s = candidate - lam
        y = candidate_grad - grad
        ys = float(np.dot(y, s))
        lam = candidate
        if ys > 1e-12:
            rho = 1.0 / ys
            identity = np.eye(z.shape[1])
            left = identity - rho * np.outer(s, y)
            right = identity - rho * np.outer(y, s)
            inverse_hessian = left @ inverse_hessian @ right + rho * np.outer(s, s)
        else:
            inverse_hessian = np.eye(z.shape[1])
    else:
        iteration = max_iter - 1

    final_obj, final_grad, _, p = state(lam)
    eta = z @ lam
    eta -= eta.max()
    p = np.exp(eta)
    p /= p.sum()
    weights = p  # rescaled below to the treated count
    max_mean_error = float(np.max(np.abs(weights @ control - treated_mean)))
    max_gradient = float(np.max(np.abs(final_grad)))
    status = {
        "optimizer_success": int(success),
        "optimizer_status": 0 if success else 1,
        "optimizer_message": message,
        "iterations": int(iteration + 1),
        "objective": float(final_obj),
        "max_gradient": max_gradient,
        "max_unscaled_mean_error": max_mean_error,
    }
    if not success and max_gradient > 1e-6:
        raise RuntimeError(f"entropy balancing did not converge: {status}")
    return weights, status


df = pd.read_stata(STACK, columns=ID_VARS + BALANCE_VARS, convert_categoricals=False)
pre = df.loc[df["event_time"].eq(-1)].copy()
if pre.duplicated(["firm_id", "stack_id"]).any():
    raise RuntimeError("duplicate firm_id + stack_id at event_time=-1")

sample_rows: list[dict] = []
missing_rows: list[dict] = []
for cohort, g in pre.groupby("cohort_report_year", sort=True):
    full_ok = g[BALANCE_VARS].notna().all(axis=1)
    core_ok = g[CORE_VARS].notna().all(axis=1)
    for treat in [0, 1]:
        sg = g.loc[g["treated_in_stack"].eq(treat)]
        f_ok = full_ok.loc[sg.index]
        c_ok = core_ok.loc[sg.index]
        sample_rows.append({
            "cohort": int(cohort),
            "group": "treated" if treat == 1 else "control",
            "firms_total": int(len(sg)),
            "firms_complete_full11": int(f_ok.sum()),
            "firms_lost_full11": int((~f_ok).sum()),
            "loss_share_full11": float((~f_ok).mean()) if len(sg) else math.nan,
            "firms_complete_core6": int(c_ok.sum()),
            "firms_lost_core6": int((~c_ok).sum()),
            "loss_share_core6": float((~c_ok).mean()) if len(sg) else math.nan,
        })
        for variable in BALANCE_VARS:
            missing_count = int(sg[variable].isna().sum())
            missing_rows.append({
                "cohort": int(cohort),
                "group": "treated" if treat == 1 else "control",
                "variable": variable,
                "firms_total": int(len(sg)),
                "missing_firms": missing_count,
                "missing_share": missing_count / len(sg) if len(sg) else math.nan,
            })

sample_audit = pd.DataFrame(sample_rows)
treated_full_loss = (
    sample_audit.loc[sample_audit["group"].eq("treated"), "firms_lost_full11"].sum()
    / sample_audit.loc[sample_audit["group"].eq("treated"), "firms_total"].sum()
)
chosen_vars = BALANCE_VARS if treated_full_loss <= 0.20 else CORE_VARS
chosen_name = "full11" if chosen_vars == BALANCE_VARS else "core6"
sample_audit["selected_balance_set"] = chosen_name
sample_audit.to_csv(OUT / "balance_sample_audit.csv", index=False)
pd.DataFrame(missing_rows).to_csv(OUT / "balance_missingness_by_variable.csv", index=False)

before_rows: list[dict] = []
after_rows: list[dict] = []
weight_rows: list[dict] = []
diagnostic_rows: list[dict] = []

for cohort, g0 in pre.groupby("cohort_report_year", sort=True):
    complete = g0[chosen_vars].notna().all(axis=1)
    g = g0.loc[complete].copy()
    treated = g.loc[g["treated_in_stack"].eq(1)].copy()
    control = g.loc[g["treated_in_stack"].eq(0)].copy()
    if treated.empty or control.empty:
        raise RuntimeError(f"cohort {cohort}: empty treated/control after complete-case restriction")

    treated_mean_vector = treated[chosen_vars].mean().to_numpy(dtype=float)
    base_weights, status = entropy_weights(
        control[chosen_vars].to_numpy(dtype=float), treated_mean_vector
    )
    control_weights = base_weights * len(treated)

    for _, row in treated.iterrows():
        weight_rows.append({
            "firm_id": str(row["firm_id"]),
            "stack_id": int(row["stack_id"]),
            "cohort": int(cohort),
            "ebal_weight": 1.0,
        })
    for idx, (_, row) in enumerate(control.iterrows()):
        weight_rows.append({
            "firm_id": str(row["firm_id"]),
            "stack_id": int(row["stack_id"]),
            "cohort": int(cohort),
            "ebal_weight": float(control_weights[idx]),
        })

    for variable in chosen_vars:
        xt = treated[variable].to_numpy(dtype=float)
        xc = control[variable].to_numpy(dtype=float)
        mt = float(xt.mean())
        mc = float(xc.mean())
        st = float(xt.std(ddof=1))
        sc = float(xc.std(ddof=1))
        before_smd = smd(mt, mc, st, sc)
        before_rows.append({
            "cohort": int(cohort), "variable": variable,
            "treated_n": int(len(xt)), "control_n": int(len(xc)),
            "treated_mean": mt, "control_mean": mc,
            "treated_sd": st, "control_sd": sc,
            "smd": before_smd,
            "variance_ratio": (st * st) / (sc * sc) if sc > 0 else math.nan,
            "abs_smd_gt_0_10": int(abs(before_smd) > 0.10),
            "abs_smd_gt_0_20": int(abs(before_smd) > 0.20),
        })

        mcw = float(np.average(xc, weights=control_weights))
        scw = weighted_sd(xc, control_weights)
        after_smd = smd(mt, mcw, st, scw)
        after_rows.append({
            "cohort": int(cohort), "variable": variable,
            "treated_n": int(len(xt)), "control_n": int(len(xc)),
            "treated_mean": mt, "weighted_control_mean": mcw,
            "treated_sd": st, "weighted_control_sd": scw,
            "smd": after_smd,
            "variance_ratio": (st * st) / (scw * scw) if scw > 0 else math.nan,
            "abs_smd_gt_0_10": int(abs(after_smd) > 0.10),
            "abs_smd_gt_0_20": int(abs(after_smd) > 0.20),
        })

    sum_w = float(control_weights.sum())
    ess = sum_w * sum_w / float(np.dot(control_weights, control_weights))
    max_weight = float(control_weights.max())
    ess_ratio = ess / len(control)
    diagnostic_rows.append({
        "cohort": int(cohort),
        "balance_set": chosen_name,
        "balance_variable_count": len(chosen_vars),
        "treated_firms": int(len(treated)),
        "control_firms": int(len(control)),
        "control_weight_mean": float(control_weights.mean()),
        "control_weight_median": float(np.median(control_weights)),
        "control_weight_sd": float(control_weights.std(ddof=1)),
        "control_weight_min": float(control_weights.min()),
        "control_weight_max": max_weight,
        "control_weight_p95": float(np.quantile(control_weights, 0.95)),
        "control_weight_p99": float(np.quantile(control_weights, 0.99)),
        "control_weight_sum": sum_w,
        "control_ess": ess,
        "ess_over_control_n": ess_ratio,
        "extreme_weight_warning": int(max_weight > 20 or ess_ratio < 0.30),
        **status,
    })

before = pd.DataFrame(before_rows)
after = pd.DataFrame(after_rows)
weights = pd.DataFrame(weight_rows).sort_values(["cohort", "firm_id"]).reset_index(drop=True)
diagnostics = pd.DataFrame(diagnostic_rows)

before.to_csv(OUT / "balance_before_weighting.csv", index=False)
after.to_csv(OUT / "balance_after_weighting.csv", index=False)
weights.to_csv(OUT / "entropy_weights.csv", index=False)
diagnostics.to_csv(OUT / "weight_diagnostics.csv", index=False)

# Stata merge helper; retained locally and copied for reproducibility.
weights_stata = weights.rename(columns={"cohort": "cohort_report_year"})
weights_stata.to_stata(OUT / "entropy_weights.dta", write_index=False, version=118)

summary = (
    before.assign(abs_smd=before["smd"].abs())
    .groupby("cohort")
    .agg(before_max_abs_smd=("abs_smd", "max"), before_gt_010=("abs_smd_gt_0_10", "sum"), before_gt_020=("abs_smd_gt_0_20", "sum"))
    .reset_index()
    .merge(
        after.assign(abs_smd=after["smd"].abs())
        .groupby("cohort")
        .agg(after_max_abs_smd=("abs_smd", "max"), after_gt_010=("abs_smd_gt_0_10", "sum"), after_gt_020=("abs_smd_gt_0_20", "sum"))
        .reset_index(),
        on="cohort", how="inner", validate="one_to_one",
    )
)
summary.to_csv(OUT / "balance_summary_by_cohort.csv", index=False)

print(f"selected_balance_set={chosen_name}; treated_full11_loss={treated_full_loss:.6f}")
print(summary.to_string(index=False))
print(diagnostics[["cohort", "control_weight_max", "control_ess", "ess_over_control_n", "extreme_weight_warning", "max_gradient"]].to_string(index=False))
