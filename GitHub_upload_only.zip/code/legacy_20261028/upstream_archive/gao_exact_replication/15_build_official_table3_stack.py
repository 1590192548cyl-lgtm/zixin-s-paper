#!/usr/bin/env python3
"""Rebuild Gao's four stacked-DID cohorts from official Appendix Table III.

This is a fixed, source-driven correction.  It does not use regression results,
p-values, or Appendix Table III target counts to add or remove firms.  Direct
industry guidelines use the adoption-year P0207 industry snapshot and formal
exchange/board scope.  Business-scope guidelines use only previously confirmed
firm-IIDG mappings whose evidence is no later than the official cohort year.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = ROOT / "outputs/official_table3_rebuild"
OUT.mkdir(parents=True, exist_ok=True)

DESKTOP = Path("/Users/macpro/Desktop/毕业论文")
PROJECT = DESKTOP / "堆叠DID重跑"

SYN = ROOT / "outputs/syn_csrc_family_2010_2020.dta"
MAPPING = ROOT / "outputs/targeted_supplement/gao_firm_iidg_mapping_supplemented.csv"
FIRST = ROOT / "outputs/targeted_supplement/gao_firm_first_treat_supplemented.csv"
CONTROLS = (
    ROOT
    / "outputs/targeted_supplement/control_coverage_repair/fundcorr_weekyear_corrected/"
    "gao_controls_firm_year_true_data_repaired_with_fundcorr.dta"
)
CUTS = (
    ROOT
    / "outputs/targeted_supplement/cohort_2012/fixed_models/"
    "cohort_2012_fixed_winsor_cutoffs.csv"
)
MDA_FILES = [
    ROOT / "outputs/length_mda_exact_stack_firm_year.csv",
    ROOT / "outputs/length_mda_sse_augmented_firm_year.csv",
    PROJECT / "gao_replication_refinement/length_mda_firm_year_2009_2025.csv",
]
INDUSTRY = DESKTOP / "原始数据/行业分类_新下载.dta"
BASIC_XLSX = DESKTOP / "原始数据/公司基本信息/EVA_Co.xlsx"
BASIC_DTA = DESKTOP / "原始数据/公司基本信息/IPO_Cobasic.dta"
DELIST = PROJECT / "gao_replication_refinement/official_delisting_dates_combined.csv"

COHORTS = [2013, 2015, 2016, 2017]

# Official Appendix Table III: one row per IIDG industry and its treated
# firm-year observations.  Counts are validation targets only.
POLICIES = [
    (2013, "SSE-02", "Real estate (SH)", 485, "direct", "上交所", ("主板",), ("K70",)),
    (2013, "SSE-03", "Coal (SH)", 156, "direct", "上交所", ("主板",), ("B06",)),
    (2013, "SSE-08", "Petroleum and natural gas exploitation (SH)", 32, "direct", "上交所", ("主板",), ("B07",)),
    (2015, "SSE-11", "Photovoltaic (SH)", 85, "business", "上交所", ("主板",), ()),
    (2015, "SSE-07", "Pharmaceutical manufacturing (SH)", 309, "direct", "上交所", ("主板",), ("C27",)),
    (2015, "SSE-10", "Architecture (SH)", 160, "direct", "上交所", ("主板",), ("E47", "E48", "E49", "E50")),
    (2015, "SSE-13", "Press and publications (SH)", 79, "direct", "上交所", ("主板",), ("R85",)),
    (2015, "SSE-12", "Clothing (SH)", 79, "direct", "上交所", ("主板",), ("C18",)),
    (2015, "SSE-06", "Automobile manufacturing (SH)", 150, "direct", "上交所", ("主板",), ("C36",)),
    (2015, "SSE-04", "Electrical energy (SH)", 244, "direct", "上交所", ("主板",), ("D44",)),
    (2015, "SSE-09", "Steel (SH)", 82, "direct", "上交所", ("主板",), ("C31",)),
    (2015, "SSE-05", "Retail (SH)", 229, "direct", "上交所", ("主板",), ("F52",)),
    (2015, "SZ-C-05", "Internet games (SZ-C)", 11, "business", "深交所", ("创业板",), ()),
    (2015, "SZ-C-06", "Internet video (SZ-C)", 4, "business", "深交所", ("创业板",), ()),
    (2015, "SZ-C-03", "Industry chain for photovoltaics (SZ-C)", 7, "business", "深交所", ("创业板",), ()),
    (2015, "SZ-02", "Solid mineral resources (SZ)", 164, "business", "深交所", ("主板", "中小板"), ()),
    (2015, "SZ-03", "Real estate (SZ)", 333, "direct", "深交所", ("主板", "中小板"), ("K70",)),
    (2015, "SZ-01", "Livestock and poultry, aquaculture (SZ)", 76, "direct", "深交所", ("主板", "中小板"), ("A03", "A04")),
    (2016, "SSE-20", "Agriculture, forestry, livestock, and fishery (SH)", 86, "direct", "上交所", ("主板",), ("A01", "A02", "A03", "A04", "A05")),
    (2016, "SSE-18", "Chemical (SH)", 366, "direct", "上交所", ("主板",), ("C26",)),
    (2016, "SSE-15", "Service for broadcasting and television transmission (SH)", 22, "business", "上交所", ("主板",), ()),
    (2016, "SSE-17", "Water generation and distribution (SH)", 34, "direct", "上交所", ("主板",), ("D46",)),
    (2016, "SSE-16", "Environmental services (SH)", 47, "business", "上交所", ("主板",), ()),
    (2016, "SSE-19", "Transportation by air (SH)", 50, "direct", "上交所", ("主板",), ("G56",)),
    (2016, "SSE-14", "Wine manufacturing (SH)", 94, "direct", "上交所", ("主板",), ("C15",)),
    (2016, "SZ-C-08", "Internet marketing (SZ-C)", 4, "business", "深交所", ("创业板",), ()),
    (2016, "SZ-05", "Engineering machinery (SZ)", 49, "business", "深交所", ("主板", "中小板"), ()),
    (2016, "SZ-04", "Planting and seeding (SZ)", 20, "business", "深交所", ("主板", "中小板"), ()),
    (2016, "SZ-06", "Decoration (SZ)", 55, "direct", "深交所", ("主板", "中小板"), ("E50",)),
    (2017, "SZ-C-09", "LED chain (SZ-C)", 32, "business", "深交所", ("创业板",), ()),
    (2017, "SZ-C-10", "Medical instruments and equipment (SZ-C)", 33, "business", "深交所", ("创业板",), ()),
    (2017, "SZ-07", "Construction (SZ)", 116, "direct", "深交所", ("主板", "中小板"), ("E48",)),
    (2017, "SZ-09", "Express (SZ)", 16, "business", "深交所", ("主板", "中小板"), ()),
    (2017, "SZ-08", "Retail (SZ)", 129, "direct", "深交所", ("主板", "中小板"), ("F52",)),
]

PAPER_CELLS = {
    2013: {(0, 0): 2952, (0, 1): 2778, (1, 0): 326, (1, 1): 347},
    2015: {(0, 0): 2886, (0, 1): 2806, (1, 0): 1017, (1, 1): 995},
    2016: {(0, 0): 3115, (0, 1): 2841, (1, 0): 419, (1, 1): 408},
    2017: {(0, 0): 3343, (0, 1): 2959, (1, 0): 164, (1, 1): 162},
}

FULL_RAW = [
    "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
    "Length_MDA", "Length_AR", "Stdret", "FundCorr", "d_Instihold", "Instihold",
    "Analyst_exact", "Indsize_broad", "Subs_exact", "Big4", "Tophold", "Tophold2",
]


def norm_id(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype("Int64")


def impose_prepost(frame: pd.DataFrame, raw: str, target: str) -> None:
    frame[target] = np.int8(0)
    q = frame.loc[frame[raw].eq(1), ["stack_id", "firm_id", "Post"]]
    ok = q.groupby(["stack_id", "firm_id"], sort=False).Post.transform(
        lambda x: x.eq(0).any() and x.eq(1).any()
    )
    frame.loc[q.index[ok], target] = np.int8(1)


def load_company_master() -> pd.DataFrame:
    basic = pd.read_excel(
        BASIC_XLSX, sheet_name="sheet1", header=0, skiprows=[1, 2], dtype=str
    )
    ipo = pd.read_stata(BASIC_DTA, convert_categoricals=False)
    basic["firm_id"] = norm_id(basic["Symbol"])
    basic["listing_date"] = pd.to_datetime(basic["IPODate"], errors="coerce")
    basic["delisted_date"] = pd.to_datetime(basic["DelistedDate"], errors="coerce")
    ipo["firm_id"] = norm_id(ipo["Stkcd"])
    ipo["Listdt_sort"] = pd.to_datetime(ipo["Listdt"], errors="coerce")
    ipo = ipo.sort_values(["firm_id", "Listdt_sort"]).drop_duplicates("firm_id", keep="last")
    basic = basic.merge(ipo[["firm_id", "Listexg", "Conme"]], on="firm_id", how="left")
    basic["exchange"] = basic["Listexg"].astype(str).map({"1": "上交所", "2": "深交所"})
    basic = basic.sort_values(["firm_id", "listing_date"]).drop_duplicates("firm_id", keep="last")
    return basic[["firm_id", "StkShortName", "Conme", "Board", "exchange", "listing_date", "delisted_date"]]


def build_candidate_mapping(master: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    policy = pd.DataFrame(
        POLICIES,
        columns=["cohort_year", "iidg_id", "iidg_name_official", "gao_table3_obs", "scope_type", "exchange", "boards", "industry_codes"],
    )
    policy.assign(
        boards=policy.boards.map(lambda x: "|".join(x)),
        industry_codes=policy.industry_codes.map(lambda x: "|".join(x)),
    ).to_csv(OUT / "official_table3_policy_crosswalk.csv", index=False)

    industry = pd.read_stata(INDUSTRY, convert_categoricals=False)
    industry = industry[industry["IndustryClassificationID"].eq("P0207")].copy()
    industry["firm_id"] = norm_id(industry["Symbol"])
    industry["industry_year"] = pd.to_datetime(industry["EndDate"], errors="coerce").dt.year
    industry = (
        industry.sort_values(["firm_id", "industry_year", "EndDate"])
        .drop_duplicates(["firm_id", "industry_year"], keep="last")
    )

    direct_rows = []
    for row in policy.loc[policy.scope_type.eq("direct")].itertuples(index=False):
        q = industry[
            industry.industry_year.eq(row.cohort_year)
            & industry.IndustryCode2.isin(row.industry_codes)
        ][["firm_id", "IndustryCode2", "IndustryName2"]].copy()
        q = q.merge(master, on="firm_id", how="inner", validate="many_to_one")
        cutoff = pd.Timestamp(row.cohort_year, 12, 31)
        q = q[
            q.exchange.eq(row.exchange)
            & q.Board.isin(row.boards)
            & q.listing_date.le(cutoff)
            & (q.delisted_date.isna() | q.delisted_date.gt(cutoff))
        ].copy()
        q["cohort_year"] = row.cohort_year
        q["iidg_id"] = row.iidg_id
        q["iidg_name_official"] = row.iidg_name_official
        q["candidate_source"] = "direct_P0207_adoption_year"
        q["evidence_year"] = row.cohort_year
        q["evidence_status"] = "structured_direct_scope"
        q.rename(columns={"IndustryCode2": "industry_code_at_adoption", "IndustryName2": "industry_name_at_adoption"}, inplace=True)
        direct_rows.append(q)
    direct = pd.concat(direct_rows, ignore_index=True)

    mapping = pd.read_csv(MAPPING, low_memory=False)
    mapping["firm_id"] = norm_id(mapping["firm_id"])
    for col in ["evidence_report_year", "business_confirmed_year", "treat_year_core"]:
        mapping[col] = pd.to_numeric(mapping[col], errors="coerce")
    mapping["evidence_year"] = mapping[
        ["evidence_report_year", "business_confirmed_year", "treat_year_core"]
    ].min(axis=1, skipna=True)
    business_policy = policy[policy.scope_type.eq("business")][
        ["cohort_year", "iidg_id", "iidg_name_official", "exchange", "boards"]
    ]
    business = mapping.merge(business_policy, on="iidg_id", how="inner")
    business = business.merge(
        master[["firm_id", "StkShortName", "Conme", "Board", "exchange", "listing_date", "delisted_date"]],
        on="firm_id",
        how="left",
        suffixes=("_mapping", "_master"),
        validate="many_to_one",
    )
    cutoff = pd.to_datetime(business.cohort_year.astype(str) + "-12-31")
    business["exchange_check"] = business["exchange_master"].eq(business["exchange_mapping"])
    business["board_check"] = [b in boards for b, boards in zip(business.Board, business.boards)]
    business["adoption_evidence_check"] = business.evidence_year.le(business.cohort_year)
    business["active_check"] = business.listing_date.le(cutoff) & (
        business.delisted_date.isna() | business.delisted_date.gt(cutoff)
    )
    rejected = business[
        ~(business.exchange_check & business.board_check & business.adoption_evidence_check & business.active_check)
    ].copy()
    rejected.to_csv(OUT / "business_scope_candidates_rejected_from_backdating.csv", index=False)
    business = business[
        business.exchange_check & business.board_check & business.adoption_evidence_check & business.active_check
    ].copy()
    business["candidate_source"] = "confirmed_business_mapping_by_adoption_year"
    business["industry_code_at_adoption"] = business.get("industry_code", "")
    business["industry_name_at_adoption"] = business.get("industry_name", "")
    business["exchange"] = business["exchange_master"]
    keep = [
        "firm_id", "StkShortName", "Conme", "Board", "exchange", "listing_date", "delisted_date",
        "cohort_year", "iidg_id", "iidg_name_official", "candidate_source", "evidence_year",
        "evidence_status", "industry_code_at_adoption", "industry_name_at_adoption",
    ]
    candidates = pd.concat([direct[keep], business[keep]], ignore_index=True)
    candidates.drop_duplicates(["firm_id", "cohort_year", "iidg_id"], inplace=True)

    # Deterministic primary category for Appendix Table III audit.  It never
    # changes treatment status: direct adoption-year industry scope takes
    # precedence, followed by the strongest already-confirmed text evidence.
    candidates["source_priority"] = candidates.candidate_source.map(
        {"direct_P0207_adoption_year": 0, "confirmed_business_mapping_by_adoption_year": 1}
    )
    status = candidates.evidence_status.fillna("")
    candidates["evidence_priority"] = np.select(
        [status.str.contains("strict_confirmed_explicit"), status.str.contains("earlier_treatment_confirmed"), status.str.contains("mda_confirmed_business")],
        [0, 1, 2],
        default=3,
    )
    candidates.sort_values(
        ["firm_id", "cohort_year", "source_priority", "evidence_priority", "iidg_id"], inplace=True
    )
    candidates["primary_policy"] = (
        ~candidates.duplicated(["firm_id", "cohort_year"], keep="first")
    ).astype(np.int8)
    candidates.to_csv(OUT / "official_table3_candidate_mapping.csv", index=False)
    return candidates, policy


def main() -> None:
    master = load_company_master()
    candidates, policy = build_candidate_mapping(master)

    first = pd.read_csv(FIRST, low_memory=False)
    first["firm_id"] = norm_id(first["firm_id"])
    first["first_treat_year_supplemented"] = pd.to_numeric(
        first["first_treat_year_supplemented"], errors="coerce"
    )
    first["eligible_as_clean_control_supplemented"] = pd.to_numeric(
        first["eligible_as_clean_control_supplemented"], errors="coerce"
    ).fillna(0).astype(np.int8)

    candidate_first = candidates.groupby("firm_id").cohort_year.min()
    first = first.merge(candidate_first.rename("first_table3_candidate_year"), on="firm_id", how="outer")
    first["first_treat_year_official_corrected"] = first[
        ["first_treat_year_supplemented", "first_table3_candidate_year"]
    ].min(axis=1, skipna=True)
    first.to_csv(OUT / "official_table3_corrected_first_treat.csv", index=False)
    corrected_first = first.set_index("firm_id")["first_treat_year_official_corrected"].to_dict()

    candidates["first_treat_year_official_corrected"] = candidates.firm_id.map(corrected_first)
    candidates["eligible_treated_in_cohort"] = candidates.cohort_year.eq(
        candidates.first_treat_year_official_corrected
    ).astype(np.int8)
    candidates.to_csv(OUT / "official_table3_candidate_mapping.csv", index=False)

    syn = pd.read_stata(SYN, convert_categoricals=False)
    syn["firm_id"] = norm_id(syn["firm_int"])
    syn = syn[["firm_id", "syn_year", "SYN_CSRC_FAMILY", "R2_CSRC_FAMILY", "n_weeks_CSRC_FAMILY"]]

    controls = pd.read_stata(CONTROLS, convert_categoricals=False)
    controls["firm_id"] = norm_id(controls["firm_id"])
    controls["fiscal_year"] = pd.to_numeric(controls.fiscal_year, errors="coerce").astype("Int64")

    delist = pd.read_csv(DELIST, low_memory=False)
    delist["firm_id"] = norm_id(delist["firm_id"])
    delist["delisting_date"] = pd.to_datetime(delist.delisting_date, errors="coerce")
    excluded_delist = set(
        delist.loc[delist.delisting_date.between("2009-01-01", "2019-12-31"), "firm_id"]
        .dropna().astype(int)
    )

    first_lookup = first.dropna(subset=["firm_id"]).copy()
    rows = []
    selection = []
    for stack_id, cohort in enumerate(COHORTS, 1):
        treated_ids = set(
            candidates.loc[
                candidates.cohort_year.eq(cohort) & candidates.eligible_treated_in_cohort.eq(1),
                "firm_id",
            ].dropna().astype(int)
        )
        future_clean = first_lookup.first_treat_year_official_corrected.ge(cohort + 3)
        never_clean = (
            first_lookup.first_treat_year_official_corrected.isna()
            & first_lookup.eligible_as_clean_control_supplemented.eq(1)
        )
        control_ids = set(first_lookup.loc[future_clean | never_clean, "firm_id"].dropna().astype(int))
        control_ids -= treated_ids

        q = syn[
            syn.syn_year.between(cohort - 2, cohort + 3)
            & syn.firm_id.isin(treated_ids | control_ids)
            & ~syn.firm_id.isin(excluded_delist)
        ].copy()
        q["annual_report_year"] = q.syn_year - 1
        q["cohort_report_year"] = cohort
        q["gao_cohort_label"] = cohort
        q["event_time"] = q.annual_report_year - cohort
        q["treated_in_stack"] = q.firm_id.isin(treated_ids).astype(np.int8)
        q["Post"] = q.annual_report_year.ge(cohort).astype(np.int8)
        q["TreatPost"] = (q.treated_in_stack * q.Post).astype(np.int8)
        q["stack_id"] = stack_id
        q = q.merge(
            controls,
            left_on=["firm_id", "annual_report_year"],
            right_on=["firm_id", "fiscal_year"],
            how="left",
            validate="many_to_one",
        )
        q = q[~q.industry_name.fillna("").str.contains(r"银行|证券|保险|金融|信托", regex=True)].copy()
        g = q.groupby("firm_id")
        q = q[
            g.Post.transform(lambda x: x.eq(0).any())
            & g.Post.transform(lambda x: x.eq(1).any())
        ].copy()
        rows.append(q)
        selection.append({
            "cohort_year": cohort,
            "treated_candidate_firms": len(treated_ids),
            "control_candidate_firms": len(control_ids),
            "stack_rows": len(q),
            "treated_firms": int(q.loc[q.treated_in_stack.eq(1), "firm_id"].nunique()),
            "control_firms": int(q.loc[q.treated_in_stack.eq(0), "firm_id"].nunique()),
            "treated_observations": int(q.treated_in_stack.sum()),
        })

    stack = pd.concat(rows, ignore_index=True)
    stack["firm_stack_id"] = pd.factorize(
        stack.stack_id.astype(str) + "_" + stack.firm_id.astype(str), sort=True
    )[0] + 1
    stack["cohort_year_id"] = pd.factorize(
        stack.stack_id.astype(str) + "_" + stack.annual_report_year.astype(str), sort=True
    )[0] + 1
    if stack.duplicated(["firm_id", "stack_id", "annual_report_year"]).any():
        raise ValueError("Duplicate firm-stack-year rows")
    if not stack.event_time.between(-3, 2).all():
        raise ValueError("Event window differs from [-3,+2]")
    if not stack.annual_report_year.eq(stack.syn_year - 1).all():
        raise ValueError("Syn_spec(t+1) alignment failed")

    # Attach one audit category per treated firm without changing Treat.
    primary = candidates[
        candidates.primary_policy.eq(1) & candidates.eligible_treated_in_cohort.eq(1)
    ][["firm_id", "cohort_year", "iidg_id", "iidg_name_official"]].rename(
        columns={"cohort_year": "cohort_report_year", "iidg_id": "primary_iidg_id", "iidg_name_official": "primary_iidg_name"}
    )
    stack = stack.merge(primary, on=["firm_id", "cohort_report_year"], how="left", validate="many_to_one")

    # MDA length is reused from the already extracted genuine reports; no text
    # is rescanned and no missing value is imputed.
    mda_parts = []
    for source_priority, path in enumerate(MDA_FILES):
        q = pd.read_csv(path, low_memory=False)
        q["firm_id"] = norm_id(q.firm_id)
        q["report_year"] = pd.to_numeric(q.report_year, errors="coerce").astype("Int64")
        q["source_priority"] = source_priority
        mda_parts.append(q[["firm_id", "report_year", "Length_MDA", "extraction_status", "source_priority"]])
    mda = pd.concat(mda_parts, ignore_index=True)
    # Prefer a genuine nonmissing extraction; among duplicates prefer the most
    # recent broad file.  No missing value is imputed.
    mda["has_length"] = mda.Length_MDA.notna().astype(int)
    mda = (
        mda.sort_values(["firm_id", "report_year", "has_length", "source_priority"])
        .drop_duplicates(["firm_id", "report_year"], keep="last")
        .drop(columns=["source_priority", "has_length"])
    )
    stack = stack.merge(
        mda,
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "report_year"],
        how="left",
        validate="many_to_one",
    )
    stack["Length_AR"] = np.log(pd.to_numeric(stack.Length_AR_chars, errors="coerce").where(lambda x: x > 0))
    stack["Analyst_exact"] = stack.Analyst.fillna(0)
    stack["Subs_exact"] = stack.Subs.fillna(0)
    stack["industry_broad"] = stack.industry_code.astype("string").str.slice(0, 1)
    stack["Indsize_broad_count"] = stack.groupby(
        ["stack_id", "annual_report_year", "industry_broad"], dropna=False
    ).firm_id.transform("nunique")
    stack["Indsize_broad"] = np.log(
        stack.Indsize_broad_count.where(stack.industry_broad.notna() & stack.Indsize_broad_count.gt(0))
    )

    stack["sample_formula_base"] = np.int8(1)
    stack["sample_g1_raw"] = stack[
        ["SYN_CSRC_FAMILY", "TreatPost", "Size", "MB_parent", "Lev"]
    ].notna().all(axis=1).astype(np.int8)
    stack["sample_full_raw"] = stack[
        ["SYN_CSRC_FAMILY", "TreatPost"] + FULL_RAW
    ].notna().all(axis=1).astype(np.int8)
    impose_prepost(stack, "sample_g1_raw", "sample_g1")
    impose_prepost(stack, "sample_full_raw", "sample_full")

    # Freeze all previously estimated cutoffs so this round isolates the
    # treatment/cohort correction.
    cuts = pd.read_csv(CUTS).set_index("variable")
    for variable, row in cuts.iterrows():
        if variable not in stack.columns:
            raise KeyError(f"Frozen winsor variable missing: {variable}")
        stack[variable + "_w_exact"] = pd.to_numeric(stack[variable], errors="coerce").clip(
            float(row.p1), float(row.p99)
        )

    # Table 1 cells.
    cells = stack.groupby(["cohort_report_year", "treated_in_stack", "Post"]).size().rename("project_rows").reset_index()
    paper = []
    for cohort, entries in PAPER_CELLS.items():
        for (treated, post), n in entries.items():
            paper.append({"cohort_report_year": cohort, "treated_in_stack": treated, "Post": post, "gao_rows": n})
    cells = cells.merge(pd.DataFrame(paper), on=["cohort_report_year", "treated_in_stack", "Post"], how="outer")
    cells["gap_project_minus_gao"] = cells.project_rows - cells.gao_rows
    cells.to_csv(OUT / "official_table3_stack_vs_gao_table1.csv", index=False)

    # Appendix Table III policy counts on the rebuilt stack.
    pc = (
        stack.loc[stack.treated_in_stack.eq(1)]
        .groupby(["cohort_report_year", "primary_iidg_id", "primary_iidg_name"], dropna=False)
        .size().rename("project_treated_obs").reset_index()
    )
    target = policy[["cohort_year", "iidg_id", "iidg_name_official", "gao_table3_obs"]].rename(
        columns={"cohort_year": "cohort_report_year", "iidg_id": "primary_iidg_id", "iidg_name_official": "primary_iidg_name"}
    )
    pc = target.merge(pc, on=["cohort_report_year", "primary_iidg_id", "primary_iidg_name"], how="left")
    pc["project_treated_obs"] = pc.project_treated_obs.fillna(0).astype(int)
    pc["gap_project_minus_gao"] = pc.project_treated_obs - pc.gao_table3_obs
    pc.to_csv(OUT / "official_table3_policy_count_comparison.csv", index=False)

    samples = []
    for sample in ["sample_formula_base", "sample_g1", "sample_full"]:
        z = stack[stack[sample].eq(1)]
        samples.append({
            "sample": sample,
            "rows": len(z),
            "clusters": int(z.firm_id.nunique()),
            "treated_firms": int(z.loc[z.treated_in_stack.eq(1), "firm_id"].nunique()),
            "cohorts": int(z.cohort_report_year.nunique()),
            "treated_pre_rows": int(((z.treated_in_stack == 1) & (z.Post == 0)).sum()),
            "treated_post_rows": int(((z.treated_in_stack == 1) & (z.Post == 1)).sum()),
        })
    pd.DataFrame(selection).to_csv(OUT / "official_table3_stack_selection_audit.csv", index=False)
    pd.DataFrame(samples).to_csv(OUT / "official_table3_sample_audit.csv", index=False)

    stack.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    stack["firm_id"] = pd.to_numeric(stack.firm_id, errors="raise").astype(np.int32)
    stack.to_csv(OUT / "official_table3_stack_analysis.csv", index=False)
    stack.to_stata(OUT / "official_table3_stack_analysis.dta", write_index=False, version=118)
    meta = {
        "source": "Gao official Online Appendix Tables I and III",
        "cohorts": COHORTS,
        "stack_rows": int(len(stack)),
        "unique_firms": int(stack.firm_id.nunique()),
        "treated_firms": int(stack.loc[stack.treated_in_stack.eq(1), "firm_id"].nunique()),
        "sample_g1": int(stack.sample_g1.sum()),
        "sample_full": int(stack.sample_full.sum()),
        "duplicate_firm_stack_year": 0,
        "winsor_cutoffs": str(CUTS),
        "annual_reports_rescanned": False,
        "target_counts_used_for_selection": False,
        "important_limit": "Appendix Table III supplies industry-level observation counts, not the unpublished firm list.",
    }
    (OUT / "official_table3_build_audit.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2), flush=True)
    print(pd.DataFrame(selection).to_string(index=False), flush=True)
    print(cells.to_string(index=False), flush=True)
    print(pc.to_string(index=False), flush=True)
    print(pd.DataFrame(samples).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
