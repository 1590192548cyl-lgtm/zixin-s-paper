from pathlib import Path
import hashlib,json,shutil

W=Path(__file__).resolve().parent;O=W/'outputs'
D=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_final_fixed_rerun_20261103')
assert not D.exists(),'Refuse to overwrite an archive'
s=json.loads((O/'final_run_summary.json').read_text())
assert s['formal_static_runs']==1 and s['formal_event_runs']==1 and s['old_new_estimates_b_and_V_exactly_equal']
shutil.copytree(O,D);(D/'code').mkdir()
for name in ['FIXED_RERUN_PLAN.md','prepare_fixed_rerun.py','run_once.do','launch_once.py','compile_final_report.py','archive_final.py']:
    shutil.copy2(W/name,D/'code'/name)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
rows=[]
for p in O.rglob('*'):
    if p.is_file():
        rel=p.relative_to(O);q=D/rel
        assert sha(p)==sha(q),str(rel)
        rows.append({'file':str(rel),'bytes':p.stat().st_size,'sha256':sha(q)})
(D/'archive_manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'archive':str(D),'verified_output_files':len(rows),'bytes':sum(x['bytes'] for x in rows),
                  'static_runs':1,'event_runs':1},ensure_ascii=False))
