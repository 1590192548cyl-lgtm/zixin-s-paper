version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/static_model_correction_20261028_work/outputs"
log using "`out'/static_correction_stata.log", text replace
which reghdfe
which eventstudyinteract
use "`out'/static_corrected_analysis.dta", clear
isid firm_id stack_id syn_year
assert inrange(event_time,-3,2)
assert control_fiscal_year==syn_year-1
assert TreatPost==(treated_in_stack==1 & event_time>=0)
local x "Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w"

tempname mh
tempfile mres
postfile `mh' str24 model str12 weighting str16 sample_status long complete_N N clusters treated_firms control_firms cohorts singleton_N double coefficient SE t p CI_low CI_high df_r using `mres', replace

foreach stage in original corrected {
    local restriction "model_complete==1"
    if "`stage'"=="corrected" local restriction "model_complete==1 & objective_keep==1"
    foreach mode in W2 UW2 {
        local opt ""
        local wt "unweighted"
        if "`mode'"=="W2" {
            local opt "[pw=ebal_weight]"
            local wt "weighted"
        }
        quietly count if `restriction'
        local rawN=r(N)
        noisily reghdfe SYN_w_Gao TreatPost `x' if `restriction' `opt', absorb(firm_stack_id cohort_year_id) vce(cluster firm_cluster_id)
        assert _se[TreatPost]>0 & !missing(_se[TreatPost])
        local n=e(N)
        local nc=e(N_clust)
        local b=_b[TreatPost]
        local se=_se[TreatPost]
        local tv=`b'/`se'
        local pv=2*ttail(e(df_r),abs(`tv'))
        local crit=invttail(e(df_r),.025)
        local lo=`b'-`crit'*`se'
        local hi=`b'+`crit'*`se'
        local df=e(df_r)
        local sn=`rawN'-`n'
        gen byte es_`stage'_`mode'=e(sample)
        tempvar ft fc fg
        egen byte `ft'=tag(firm_id) if e(sample)&treated_in_stack==1
        egen byte `fc'=tag(firm_id) if e(sample)&treated_in_stack==0
        egen byte `fg'=tag(cohort_report_year) if e(sample)
        quietly count if `ft'==1
        local nt=r(N)
        quietly count if `fc'==1
        local n0=r(N)
        quietly count if `fg'==1
        local ng=r(N)
        assert `ng'==5
        post `mh' ("`stage'_`mode'") ("`wt'") ("`stage'") (`rawN') (`n') (`nc') (`nt') (`n0') (`ng') (`sn') (`b') (`se') (`tv') (`pv') (`lo') (`hi') (`df')
        estimates save "`out'/`stage'_`mode'.ster", replace
        drop `ft' `fc' `fg'
    }
}
postclose `mh'
preserve
use `mres', clear
export delimited using "`out'/fixed_static_model_results.csv", replace
restore

foreach pair in m3 m2 0 p1 p2 {
    local et=-3
    if "`pair'"=="m2" local et=-2
    if "`pair'"=="0" local et=0
    if "`pair'"=="p1" local et=1
    if "`pair'"=="p2" local et=2
    gen byte D_`pair'=(treated_in_stack==1 & event_time==`et')
    assert D_`pair'==0 if treated_in_stack==0 | event_time==-1
}
assert D_m3+D_m2+D_0+D_p1+D_p2==1 if treated_in_stack==1 & event_time!=-1

tempname eh jh
tempfile eres jres
postfile `eh' str24 model str12 term int event_time double coefficient SE t p CI_low CI_high long N clusters using `eres', replace
postfile `jh' str24 model str12 test double F df_num df_den p long N clusters using `jres', replace
foreach stage in original corrected {
    local restriction "model_complete==1"
    if "`stage'"=="corrected" local restriction "model_complete==1 & objective_keep==1"
    noisily reghdfe SYN_w_Gao D_m3 D_m2 D_0 D_p1 D_p2 `x' if `restriction' [pw=ebal_weight], absorb(firm_stack_id cohort_year_id) vce(cluster firm_cluster_id)
    gen byte es_`stage'_event=e(sample)
    assert es_`stage'_event==es_`stage'_W2
    local n=e(N)
    local nc=e(N_clust)
    foreach pair in m3 m2 0 p1 p2 {
        local et=-3
        if "`pair'"=="m2" local et=-2
        if "`pair'"=="0" local et=0
        if "`pair'"=="p1" local et=1
        if "`pair'"=="p2" local et=2
        local b=_b[D_`pair']
        local se=_se[D_`pair']
        assert `se'>0 & !missing(`se')
        local tv=`b'/`se'
        local pv=2*ttail(e(df_r),abs(`tv'))
        local crit=invttail(e(df_r),.025)
        post `eh' ("`stage'_W2") ("D_`pair'") (`et') (`b') (`se') (`tv') (`pv') (`b'-`crit'*`se') (`b'+`crit'*`se') (`n') (`nc')
    }
    test D_m3 D_m2
    post `jh' ("`stage'_W2") ("pre_joint") (r(F)) (r(df)) (r(df_r)) (r(p)) (`n') (`nc')
    test D_0 D_p1 D_p2
    post `jh' ("`stage'_W2") ("post_joint") (r(F)) (r(df)) (r(df_r)) (r(p)) (`n') (`nc')
    estimates save "`out'/`stage'_W2_event.ster", replace
}
postclose `eh'
postclose `jh'
preserve
use `eres', clear
export delimited using "`out'/fixed_W2_event_results.csv", replace
restore
preserve
use `jres', clear
export delimited using "`out'/fixed_W2_joint_tests.csv", replace
restore

preserve
keep audit_row_id firm_id stack_id syn_year cohort_report_year event_time treated_in_stack objective_keep model_complete es_*
save "`out'/estimation_sample_audit.dta", replace
export delimited using "`out'/estimation_sample_audit.csv", replace
restore

* A factual plot of original and corrected W2 estimates; no estimates are adjusted.
preserve
use `eres', clear
set obs `=_N+2'
local lastrow=_N
local beforelast=_N-1
replace model="original_W2" in `lastrow'
replace model="corrected_W2" in `beforelast'
replace event_time=-1 if missing(event_time)
replace coefficient=0 if event_time==-1
sort model event_time
twoway (rcap CI_low CI_high event_time if model=="original_W2", lcolor(gs10)) (connected coefficient event_time if model=="original_W2", mcolor(gs8) lcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if model=="corrected_W2", lcolor(navy)) (connected coefficient event_time if model=="corrected_W2", mcolor(navy) lcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-1 reference)") ytitle("SYN coefficient") legend(order(2 "Original W2" 4 "Corrected W2") rows(1)) graphregion(color(white)) title("Fixed weighted stacked DID: sample correction") note("95% firm-clustered confidence intervals; original weights retained")
graph export "`out'/static_W2_event_comparison.png", width(2200) replace
restore
display as result "FIXED_STATIC_AND_W2_EVENT_COMPLETE"

* Correct the earlier full-panel SA coding error; this remains a code diagnostic only.
use "`out'/sa_full_event_indicators.dta", clear
isid firm_id syn_year
unab allterms: A_*
assert A_m3==E_m3 & A_m2==E_m2 & A_p0==E_0 & A_p1==E_p1 & A_p2==E_p2
egen byte sum_events=rowtotal(`allterms')
assert sum_events==1 if g>0 & event_time!=-1 & core_complete==1
assert sum_events==0 if g==0 | event_time==-1
noisily eventstudyinteract SYN_MARKET_ONLY_w `allterms', cohort(g_sa) control_cohort(never_treated) absorb(firm_id syn_year) covariates(Size_w Lev_w MB_w Age_w) vce(cluster firm_id)
estimates save "`out'/sa_full_event_corrected.ster", replace
gen byte sa_corrected_es=e(sample)
local nn=e(N)
tempvar saft satt sagg
egen byte `saft'=tag(firm_id) if e(sample)
egen byte `satt'=tag(firm_id) if e(sample)&g>0
egen byte `sagg'=tag(g) if e(sample)&g>0
quietly count if `saft'==1
local nf=r(N)
quietly count if `satt'==1
local nt=r(N)
quietly count if `sagg'==1
local ng=r(N)
matrix BB=e(b_iw)
matrix VV=e(V_iw)
matrix FF=e(ff_w)
matrix BI=e(b_interact)
local j1=colnumb(BB,"A_m3")
local j2=colnumb(BB,"A_m2")
local j3=colnumb(BB,"A_p0")
local j4=colnumb(BB,"A_p1")
local j5=colnumb(BB,"A_p2")
matrix PB=(BB[1,`j1'],BB[1,`j2'])
matrix PV=(VV[`j1',`j1'],VV[`j1',`j2'] \ VV[`j2',`j1'],VV[`j2',`j2'])
matrix PW=PB*syminv(PV)*PB'
local prep=chi2tail(2,PW[1,1])
matrix AB=(BB[1,`j3'],BB[1,`j4'],BB[1,`j5'])
matrix AV=(VV[`j3',`j3'],VV[`j3',`j4'],VV[`j3',`j5'] \ VV[`j4',`j3'],VV[`j4',`j4'],VV[`j4',`j5'] \ VV[`j5',`j3'],VV[`j5',`j4'],VV[`j5',`j5'])
matrix AW=AB*syminv(AV)*AB'
local postp=chi2tail(3,AW[1,1])
tempname sah sh
tempfile sares share_res
postfile `sah' str12 term int event_time double coefficient SE p CI_low CI_high pre_joint_p post_joint_p long N clusters treated_firms cohorts byte displayed using `sares', replace
postfile `sh' int effective_cohort str12 term double share cohort_coefficient using `share_res', replace
foreach term of local allterms {
    local et=real(substr("`term'",4,.))
    if substr("`term'",3,1)=="m" local et=-`et'
    local j=colnumb(BB,"`term'")
    local b=BB[1,`j']
    local se=sqrt(VV[`j',`j'])
    local pv=2*normal(-abs(`b'/`se'))
    local shown=inlist(`et',-3,-2,0,1,2)
    if `shown' assert `se'>0 & !missing(`se')
    post `sah' ("`term'") (`et') (`b') (`se') (`pv') (`b'-1.9599639845*`se') (`b'+1.9599639845*`se') (`prep') (`postp') (`nn') (`nf') (`nt') (`ng') (`shown')
    local rows: rownames FF
    local rownum=0
    foreach row of local rows {
        local ++rownum
        post `sh' (real("`row'")) ("`term'") (FF[`rownum',`j']) (BI[`rownum',`j'])
    }
}
postclose `sah'
postclose `sh'
preserve
keep firm_id firm_code syn_year g event_time sa_corrected_es
export delimited using "`out'/sa_corrected_estimation_sample.csv", replace
restore
use `share_res', clear
export delimited using "`out'/sa_cohort_shares_and_coefficients.csv", replace
use `sares', clear
sort event_time
export delimited using "`out'/sa_full_event_corrected_results.csv", replace
keep if displayed
set obs `=_N+1'
replace event_time=-1 in L
replace coefficient=0 in L
sort event_time
twoway (rcap CI_low CI_high event_time, lcolor(navy)) (connected coefficient event_time, mcolor(navy) lcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-1 reference)") ytitle("Market-model SYN coefficient") legend(off) graphregion(color(white)) title("Sun-Abraham diagnostic: omitted-period correction") note("All supported event times modeled; only [-3,+2] displayed; 95% pointwise CI")
graph export "`out'/sa_corrected_event_plot.png", width(2200) replace
display as result "ALL_FIXED_CORRECTION_MODELS_COMPLETE"
log close
exit, clear
