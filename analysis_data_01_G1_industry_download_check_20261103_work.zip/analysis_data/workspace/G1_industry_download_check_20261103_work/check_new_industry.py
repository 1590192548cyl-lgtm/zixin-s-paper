"""Incremental read-only audit; no analysis-data merge, SYN, or regression."""
from pathlib import Path
import hashlib,json,re,resource
import pandas as pd
from openpyxl import load_workbook

W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True)
R=Path('/Users/macpro/Desktop/毕业论文');P=R/'堆叠DID重跑'
NEW=R/'控制变量/上市公司行业分类年度表142024727(仅供vip使用)/STK_IndustryClassAnl.xlsx'
DES=NEW.with_name('STK_IndustryClassAnl[DES][xlsx].txt')
OLD=P/'data_work/industry_new_standardized.dta'
PREV=P/'G1_true_data_repair_20261103'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(x,n):x.to_csv(O/n,index=False,encoding='utf-8-sig')
def textval(v):
    s='' if v is None else str(v).strip()
    return '' if s.lower() in ['none','nan','nat','<na>','.'] else s
def code(v):
    s=textval(v).removesuffix('.0')
    return s.zfill(6) if s.isdigit() and len(s)<=6 else ''
inputs=[NEW,DES,OLD,PREV/'industry_30_evidence_status.csv',PREV/'industry_placeholder_targets_2009_2011.csv']
fingerprints={str(p):sha(p) for p in inputs}
book=load_workbook(NEW,read_only=True,data_only=True)
parts=[];sheets=[]
for sheet in book.worksheets:
    sheet.reset_dimensions()
    header=None;rows=[];last=width=0
    for rownum,values in enumerate(sheet.iter_rows(values_only=True),1):
        if not any(v is not None for v in values):continue
        last=rownum
        width=max(width,max(j+1 for j,v in enumerate(values) if v is not None))
        if rownum==1:header=[textval(v) for v in values];continue
        if rownum<4:continue
        r={k:textval(values[j]) if j<len(values) else '' for j,k in enumerate(header) if k}
        r.update(source_sheet=sheet.title,source_row=rownum)
        rows.append(r)
    sheets.append({'sheet':sheet.title,'actual_data_rows':len(rows),'actual_nonempty_columns':width,'last_nonempty_row':last,'fields':'|'.join(header)})
    parts.extend(rows)
book.close()
data=pd.DataFrame(parts)
required=['InstitutionID','EndDate','IndustryClassificationID','Symbol','IndustryCode1','IndustryName1','IndustryCode2','IndustryName2']
assert set(required).issubset(data.columns),f'Missing fields: {set(required)-set(data.columns)}'
data['firm_code']=data.Symbol.map(code)
data['industry_year']=pd.to_datetime(data.EndDate,errors='coerce').dt.year.astype('Int64')
data['year_end']=data.EndDate.str.match(r'^\d{4}-12-31')
save(pd.DataFrame(sheets),'new_file_actual_sheets.csv')
standards=data.groupby('IndustryClassificationID').agg(rows=('Symbol','size'),firms=('firm_code','nunique'),first_year=('industry_year','min'),last_year=('industry_year','max')).reset_index()
save(standards,'new_file_standards.csv')
q=data.loc[data.IndustryClassificationID.eq('P0201')&data.industry_year.between(2009,2011)].copy()
assert q.firm_code.ne('').all() and q.year_end.all()
keys=['firm_code','industry_year']
dups=q.loc[q.duplicated(keys,keep=False)]
save(dups,'new_P0201_duplicate_records_private.csv')
conflicts=[]
for key,g in dups.groupby(keys):
    if len(g[['IndustryCode1','IndustryName1','IndustryCode2','IndustryName2']].drop_duplicates())>1:conflicts.append(key)
assert not conflicts,f'Conflicting firm-years: {conflicts[:5]}'
q=q.sort_values(['firm_code','industry_year','source_row']).drop_duplicates(keys,keep='last')
assert q.IndustryCode1.ne('').all() and q.IndustryName1.ne('').all()
q['code2_missing']=q.IndustryCode2.eq('')
q['resolved_code_original_granularity']=q.IndustryCode2.where(~q.code2_missing,q.IndustryCode1)
save(q,'new_P0201_audited_source_private.csv')
byyear=q.groupby('industry_year').agg(firms=('firm_code','nunique'),rows=('Symbol','size'),
                                     level1_missing=('IndustryCode1',lambda s:int(s.eq('').sum())),
                                     level2_missing=('code2_missing','sum')).reset_index()
save(byyear,'new_P0201_year_coverage.csv')

oldparts=[]
cols=['EndDate','IndustryClassificationID','Symbol','IndustryClassification','IndustryCode2','IndustryName2']
with pd.read_stata(OLD,columns=cols,chunksize=20000,convert_categoricals=False) as reader:
    for ch in reader:
        yy=pd.to_datetime(ch.EndDate,errors='coerce').dt.year
        good=ch.IndustryClassificationID.eq('P0201')&yy.between(2009,2011)
        z=ch.loc[good].copy();z['industry_year']=yy[good].astype(int);oldparts.append(z)
old=pd.concat(oldparts,ignore_index=True)
old['firm_code']=old.Symbol.map(code)
old=old.sort_values(['firm_code','industry_year','EndDate']).drop_duplicates(keys,keep='last')
old['old_code2_normalized']=old.IndustryCode2.map(textval)
old['old_group_label']=old.old_code2_normalized.where(old.old_code2_normalized.ne(''),'__old_None_pool__')
oldlook=old.set_index(keys);newlook=q.set_index(keys)
oldset=set(oldlook.index);newset=set(newlook.index)
missing=oldset-newset;extra=newset-oldset
save(pd.DataFrame(sorted(missing),columns=keys),'old_pool_firm_years_missing_from_new.csv')
save(pd.DataFrame(sorted(extra),columns=keys),'new_extra_firm_years_not_added_to_pool.csv')
comparison=[]
for k in sorted(oldset&newset):
    a=oldlook.loc[k];b=newlook.loc[k]
    comparison.append({'firm_code':k[0],'industry_year':int(k[1]),'old_group_label':a.old_group_label,
                       'old_code2':a.old_code2_normalized,'old_industry_name2':textval(a.IndustryName2),
                       'new_code1':b.IndustryCode1,'new_name1':b.IndustryName1,'new_code2':b.IndustryCode2,
                       'new_name2':b.IndustryName2,'new_group_label':b.resolved_code_original_granularity,
                       'valid_old_code2_changed':int(a.old_code2_normalized!='' and a.old_code2_normalized!=b.IndustryCode2),
                       'new_source_row':int(b.source_row)})
cmp=pd.DataFrame(comparison)
save(cmp,'old_new_classification_comparison_private.csv')
partitions=[]
for y,g in cmp.groupby('industry_year'):
    old_to_new=g.groupby('old_group_label').new_group_label.nunique()
    new_to_old=g.groupby('new_group_label').old_group_label.nunique()
    partitions.append({'industry_year':int(y),'old_pool_firms':int(old.industry_year.eq(y).sum()),
                       'matched_firms':len(g),'old_groups':g.old_group_label.nunique(),'new_groups':g.new_group_label.nunique(),
                       'old_group_splits':int(old_to_new.gt(1).sum()),'new_group_merges':int(new_to_old.gt(1).sum()),
                       'partition_equivalent_for_matched_old_members':bool(old_to_new.max()==1 and new_to_old.max()==1),
                       'old_valid_code2_changes':int(g.valid_old_code2_changed.sum())})
part=pd.DataFrame(partitions);save(part,'industry_partition_equivalence.csv')

prior=pd.read_csv(PREV/'industry_placeholder_targets_2009_2011.csv',dtype={'firm_code':str})
resolved=[]
for r in prior.itertuples():
    k=(r.firm_code,int(r.industry_year));present=k in newset
    b=newlook.loc[k] if present else None
    resolved.append({'firm_code':k[0],'industry_year':k[1],'new_source_present':int(present),
                     'new_code1':b.IndustryCode1 if present else '', 'new_name1':b.IndustryName1 if present else '',
                     'new_code2':b.IndustryCode2 if present else '',
                     'resolved_with_contemporaneous_real_code':int(present and b.resolved_code_original_granularity!=''),
                     'new_source_row':int(b.source_row) if present else None})
res=pd.DataFrame(resolved);save(res,'all_170_prior_placeholder_evidence_private.csv')
target30=pd.read_csv(PREV/'industry_30_evidence_status.csv',dtype={'firm_code':str})
results30=[]
for r in target30.itertuples():
    k=(r.firm_code,int(r.industry_year));present=k in newset;b=newlook.loc[k] if present else None
    results30.append({'firm_code':k[0],'industry_year':k[1],
                      'previous_direct_historical_record_available':int(r.direct_historical_record_available),
                      'new_contemporaneous_record_present':int(present),
                      'IndustryCode1':b.IndustryCode1 if present else '', 'IndustryName1':b.IndustryName1 if present else '',
                      'IndustryCode2':b.IndustryCode2 if present else '', 'IndustryName2':b.IndustryName2 if present else '',
                      'source_sheet':b.source_sheet if present else '', 'source_row':int(b.source_row) if present else None})
t30=pd.DataFrame(results30);save(t30,'current_G1_30_evidence_check_private.csv')
name_map={k:'|'.join(sorted(g.IndustryName1.unique())) for k,g in q.loc[q.code2_missing].groupby('IndustryCode1')}
integrity=pd.DataFrame([{'path':p,'sha256_before':v,'sha256_after':sha(Path(p)),'unchanged':v==sha(Path(p))} for p,v in fingerprints.items()])
assert integrity.unchanged.all();save(integrity,'input_integrity.csv')
ready=(len(missing)==0 and len(conflicts)==0 and res.resolved_with_contemporaneous_real_code.eq(1).all()
       and t30.new_contemporaneous_record_present.eq(1).all())
summary={'source_file':str(NEW),'actual_sheets':sheets,'actual_data_rows':len(data),'P0201_rows_2009_2011':len(q),
         'P0201_years':sorted(q.industry_year.astype(int).unique().tolist()),'P0201_duplicate_rows':len(dups),
         'conflicting_firm_years':len(conflicts),'missing_old_pool_keys':len(missing),'new_extra_keys':len(extra),
         'prior_170_placeholder_records_resolved':int(res.resolved_with_contemporaneous_real_code.sum()),
         'current30_contemporaneous_records_found':int(t30.new_contemporaneous_record_present.sum()),
         'previous20_unverified_now_found':int(t30.loc[t30.previous_direct_historical_record_available.eq(0),'new_contemporaneous_record_present'].sum()),
         'missing_code2_level1_groups':name_map,'valid_old_code2_changes':int(cmp.valid_old_code2_changed.sum()),
         'fixed_old_pool_partition_equivalent':bool(part.partition_equivalent_for_matched_old_members.all()),
         'required_industry_source_ready':bool(ready),'optional_market_value_source_newly_supplied':False,
         'formal_analysis_data_modified':False,'SYN_recomputed':False,'regressions_run':0,
         'Python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
(O/'new_download_check_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
print(byyear.to_string(index=False),flush=True)
print(part.to_string(index=False),flush=True)
print(t30.groupby(['IndustryCode1','IndustryName1']).size().to_string(),flush=True)
