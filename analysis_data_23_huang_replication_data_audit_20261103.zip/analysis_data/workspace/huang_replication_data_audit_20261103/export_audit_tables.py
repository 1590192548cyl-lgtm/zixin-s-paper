#!/usr/bin/env python3
"""Export the reviewed report tables, and reproducibly retain multirecord evidence.

No empirical variables or regression samples are created.
"""
from collections import defaultdict
import audit_sources as a

def report_tables():
 text=(a.OUT/'README.md').read_text(encoding='utf-8')
 sections=[('control_definition_audit.csv','|变量|'),('download_checklist.csv','|优先级|'),('industry_mapping_audit.csv','|重点行业名称|')]
 for filename,marker in sections:
  segment=text[text.index(marker):].split('\n\n',1)[0]
  lines=segment.splitlines()
  header=[s.strip() for s in lines[0].strip('|').split('|')]
  records=[dict(zip(header,[s.strip() for s in line.strip('|').split('|')])) for line in lines[2:] if line.startswith('|')]
  a.write_csv(filename,records)

def multirecord_evidence():
 rows=[]
 for sid in ['controller','auditor']:
  spec=next(x for x in a.SOURCES if x[0]==sid);_,path,stock,date,fields,filters=spec
  headers={};groups=defaultdict(list);before=a.sha(path)
  for sheet,rn,vs in a.xml_rows(path):
   if rn==1:headers[sheet]=vs
   if rn<4:continue
   rec={code:vs.get(col,'') for col,code in headers[sheet].items()}
   d=rec.get(date,'')
   if not ('2009-12-31'<=d<='2021-12-31' and d.endswith('-12-31')):continue
   if any(a.norm(rec.get(k,''))!=v for k,v in filters.items()):continue
   groups[rec.get(stock,''),d].append((rn,rec))
  for (firm,date),records in groups.items():
   values={a.norm(rec.get(fields[0],'')) for _,rec in records}-{''}
   if len(values)<=1:continue
   for rn,rec in records:
    rows.append(dict(source=sid,firm_id=firm,date=date,source_row=rn,field=fields[0],value=rec.get(fields[0],''),judgment_standard=rec.get('S0701a',''),direct_controller=rec.get('S0702a',''),ultimate_controller=rec.get('S0701b',''),note='同年不同原始记录；未经裁定；不是自动删除依据'))
  assert a.sha(path)==before
 a.write_csv('multi_record_review_private.csv',rows)

if __name__=='__main__':
 import sys
 report_tables()
 if '--recheck-multirecords' in sys.argv:multirecord_evidence()
