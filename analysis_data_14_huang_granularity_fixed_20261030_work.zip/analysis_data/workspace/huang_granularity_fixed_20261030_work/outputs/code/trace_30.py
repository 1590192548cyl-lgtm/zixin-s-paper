from pathlib import Path
import csv,json,re
from openpyxl import load_workbook

O=Path(__file__).resolve().parent
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
review=json.loads((P/'huang_industry_review_20261030/source_inspection.json').read_text())
ids={r['firm_id'] for r in review['invalid_source_code_audit']['affected_current_keys']}
events=json.loads((O/'old_industry_candidate_rows.json').read_text())
history=[]
for r in events:
    if r['IndustryClassificationID']=='P0201':
        history.append({'firm_id':r['Symbol'],'date':r['ImplementDate'],'code':r['IndustryCode'],'name':r['IndustryName'],'source':'原始数据/行业分类.xlsx'})
f=Path('/Users/macpro/Desktop/毕业论文/控制变量/2207-2008行业分类/STK_INDUSTRYCLASS.xlsx')
wb=load_workbook(f,read_only=True,data_only=True)
ws=wb.worksheets[0];ws.reset_dimensions()
for row in ws.iter_rows(min_row=4,values_only=True):
    if len(row)>=6 and str(row[0]).zfill(6) in ids and row[1]=='P0201':
        history.append({'firm_id':str(row[0]).zfill(6),'date':str(row[3]),'code':row[4],'name':row[5],'source':str(f)})
wb.close()
available=[]
with (P/'年报指引识别/output/annual_report_inventory.csv').open(encoding='utf-8-sig',newline='') as stream:
    for r in csv.DictReader(stream):
        if r['stock_code'] in ids and r['report_year']=='2011' and r['preferred_version']=='1' and r['is_full_annual_report']=='1':
            source=Path(r['source_path'])
            z={'firm_id':r['stock_code'],'source':str(source),'exists':source.is_file(),'evidence':[]}
            if source.is_file():
                text=source.read_text(encoding=r['encoding'] or 'utf-8',errors='replace')
                # Only the explicitly selected 2011 reports, never a corpus scan.
                for m in re.finditer('综合类|所属行业|行业分类',text):
                    z['evidence'].append(text[max(0,m.start()-80):m.end()+100])
                    if len(z['evidence'])>=12:break
            available.append(z)
out={'target_firms':len(ids),'historical_classification_events':history,'targeted_2011_annual_reports':available,
     'no_automatic_classification_assignment':True}
(O/'trace_30_evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'target_firms':len(ids),'event_evidence_firms':len({r['firm_id'] for r in history}),
                  'reports_in_inventory':len(available),'reports_still_present':sum(r['exists'] for r in available)},ensure_ascii=False),flush=True)
