from pathlib import Path
import json

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"

SYN = OUT / "syn_csrc_family_2010_2020.dta"
FIRST = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/年报指引识别/"
    "final_mapping/gao_firm_first_treat_core.csv"
)
CONTROLS = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_full_controls/"
    "gao_controls_firm_year_2009_2025.dta"
)
DELIST = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_replication_refinement/"
    "official_delisting_dates_combined.csv"
)

COHORTS = [2012, 2015, 2016, 2017]
PAPER_LABEL = {2012: 2013, 2015: 2015, 2016: 2016, 2017: 2017}
PAPER_COUNTS = {
    2012: {(0, 0): 2952, (0, 1): 2778, (1, 0): 326, (1, 1): 347},
    2015: {(0, 0): 2886, (0, 1): 2806, (1, 0): 1017, (1, 1): 995},
    2016: {(0, 0): 3115, (0, 1): 2841, (1, 0): 419, (1, 1): 408},
    2017: {(0, 0): 3343, (0, 1): 2959, (1, 0): 164, (1, 1): 162},
}

# The existing verified mapping already contains SSE-11, SSE-15, SSE-16 and
# all locally collected SZ/SZ-C guidelines.  The following rows add only the
# omitted Shanghai guidelines whose official scope maps directly to CSRC
# industry classifications.  Cross-industry/threshold cases are not guessed.
SSE_DIRECT_SCOPE = [
    # 2015 reporting cohort (SSE guidelines 2-13, excluding already-mapped 11)
    (2015, "SSE-02", "房地产", {"K70"}),
    (2015, "SSE-03", "煤炭", {"B06"}),
    (2015, "SSE-04", "电力", {"D44"}),
    (2015, "SSE-05", "零售", {"F52"}),
    (2015, "SSE-06", "汽车制造", {"C36"}),
    (2015, "SSE-07", "医药制造", {"C27"}),
    (2015, "SSE-08", "石油和天然气开采", {"B07"}),
    (2015, "SSE-09", "钢铁", {"C31"}),
    (2015, "SSE-10", "建筑", {"E47", "E48", "E49", "E50"}),
    (2015, "SSE-12", "服装", {"C18"}),
    (2015, "SSE-13", "新闻出版", {"R85"}),
    # 2016 reporting cohort (SSE guidelines 14-20, excluding mapped 15/16)
    (2016, "SSE-14", "酒制造", {"C15"}),
    (2016, "SSE-17", "水的生产与供应", {"D46"}),
    (2016, "SSE-18", "化工", {"C25", "C26", "C28", "C29"}),
    (2016, "SSE-19", "航空运输", {"G56"}),
    (2016, "SSE-20", "农林牧渔", {"A01", "A02", "A03", "A04", "A05"}),
]


def norm_id(s):
    return pd.to_numeric(s, errors="coerce").astype("Int64")


def main():
    syn = pd.read_stata(SYN, convert_categoricals=False)
    syn["firm_id"] = norm_id(syn["firm_int"])
    syn = syn[["firm_id", "syn_year", "SYN_CSRC_FAMILY", "R2_CSRC_FAMILY", "n_weeks_CSRC_FAMILY"]]

    first = pd.read_csv(FIRST, low_memory=False)
    first["firm_id"] = norm_id(first["firm_id"])
    first["first_treat_year_core"] = pd.to_numeric(first["first_treat_year_core"], errors="coerce")
    first["eligible_as_clean_control"] = pd.to_numeric(
        first["eligible_as_clean_control"], errors="coerce"
    ).fillna(0).astype(int)

    ctrl = pd.read_stata(CONTROLS, convert_categoricals=False)
    ctrl["firm_id"] = norm_id(ctrl["firm_id"])
    ctrl["fiscal_year"] = pd.to_numeric(ctrl["fiscal_year"], errors="coerce").astype("Int64")

    # Build source-defined additions only for Shanghai main-board firms.  No
    # regression result is used to choose a policy, industry, firm, or year.
    scope_rows = []
    additions = []
    for year, iidg_id, iidg_name, codes in SSE_DIRECT_SCOPE:
        q = ctrl[
            ctrl["fiscal_year"].eq(year)
            & ctrl["firm_id"].between(600000, 687999)
            & ctrl["industry_code"].isin(codes)
        ][["firm_id", "industry_standard_id", "industry_code", "industry_name"]].drop_duplicates("firm_id")
        q["official_first_applicable_year"] = year
        q["iidg_id"] = iidg_id
        q["iidg_name"] = iidg_name
        q["mapping_basis"] = "official SSE direct industry scope + CSRC industry at adoption year"
        additions.append(q)
        scope_rows.append(
            {
                "official_first_applicable_year": year,
                "iidg_id": iidg_id,
                "iidg_name": iidg_name,
                "industry_codes": "|".join(sorted(codes)),
                "added_firms_before_first-treatment_dedup": int(q.firm_id.nunique()),
            }
        )
    add = pd.concat(additions, ignore_index=True)
    add.to_csv(OUT / "official_sse_direct_scope_firm_mapping.csv", index=False)
    pd.DataFrame(scope_rows).to_csv(OUT / "official_sse_direct_scope_policy_audit.csv", index=False)

    add_first = (
        add.groupby("firm_id", as_index=False)
        .official_first_applicable_year.min()
        .rename(columns={"official_first_applicable_year": "sse_direct_first_year"})
    )
    first = first.merge(add_first, on="firm_id", how="left", validate="one_to_one")
    first["first_treat_year_augmented"] = first[["first_treat_year_core", "sse_direct_first_year"]].min(axis=1, skipna=True)
    first["added_by_sse_direct_scope"] = (
        first["sse_direct_first_year"].notna()
        & (first["first_treat_year_core"].isna() | first["sse_direct_first_year"].lt(first["first_treat_year_core"]))
    ).astype(int)
    first.to_csv(OUT / "gao_firm_first_treat_sse_augmented.csv", index=False)

    keep_ctrl = [
        "firm_id", "fiscal_year", "industry_standard_id", "industry_code", "industry_name",
        "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
        "Length_AR_chars", "Stdret", "d_Instihold", "Instihold", "Analyst",
        "Indsize_candidate", "Subs", "Big4", "Tophold", "Tophold2",
    ]
    ctrl = ctrl[keep_ctrl].copy()

    de = pd.read_csv(DELIST, low_memory=False)
    de["firm_id"] = norm_id(de["firm_id"])
    de["delisting_date"] = pd.to_datetime(de["delisting_date"], errors="coerce")
    excluded_delist = set(
        de.loc[de["delisting_date"].between("2009-01-01", "2019-12-31"), "firm_id"]
        .dropna().astype(int).tolist()
    )

    rows = []
    selection = []
    for c in COHORTS:
        treated_ids = set(
            first.loc[first["first_treat_year_augmented"].eq(c), "firm_id"].dropna().astype(int)
        )
        future_clean = first["first_treat_year_augmented"].ge(c + 3)
        never_clean = first["first_treat_year_augmented"].isna() & first["eligible_as_clean_control"].eq(1)
        control_ids = set(first.loc[future_clean | never_clean, "firm_id"].dropna().astype(int))
        control_ids -= treated_ids

        q = syn[
            syn["syn_year"].between(c - 2, c + 3)
            & syn["firm_id"].isin(treated_ids | control_ids)
            & ~syn["firm_id"].isin(excluded_delist)
        ].copy()
        q["annual_report_year"] = q["syn_year"] - 1
        q["cohort_report_year"] = c
        q["gao_cohort_label"] = PAPER_LABEL[c]
        q["event_time"] = q["annual_report_year"] - c
        q["treated_in_stack"] = q["firm_id"].isin(treated_ids).astype(np.int8)
        q["Post"] = q["annual_report_year"].ge(c).astype(np.int8)
        q["TreatPost"] = (q["treated_in_stack"] * q["Post"]).astype(np.int8)
        q = q.merge(
            ctrl,
            left_on=["firm_id", "annual_report_year"],
            right_on=["firm_id", "fiscal_year"],
            how="left",
            validate="many_to_one",
        )
        q = q[~q["industry_name"].fillna("").str.contains(r"银行|证券|保险|金融|信托", regex=True)].copy()
        g = q.groupby("firm_id")
        has_pre = g["Post"].transform(lambda x: x.eq(0).any())
        has_post = g["Post"].transform(lambda x: x.eq(1).any())
        q = q[has_pre & has_post].copy()
        q["stack_id"] = COHORTS.index(c) + 1
        rows.append(q)

        selection.append(
            {
                "cohort_report_year": c,
                "gao_cohort_label": PAPER_LABEL[c],
                "augmented_treated_ids_before_data": len(treated_ids),
                "clean_control_ids_before_data": len(control_ids),
                "stack_rows": len(q),
                "treated_firms": int(q.loc[q.treated_in_stack.eq(1), "firm_id"].nunique()),
                "control_firms": int(q.loc[q.treated_in_stack.eq(0), "firm_id"].nunique()),
            }
        )

    stack = pd.concat(rows, ignore_index=True)
    stack["firm_stack_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["firm_id"].astype(str), sort=True
    )[0] + 1
    stack["cohort_year_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["annual_report_year"].astype(str), sort=True
    )[0] + 1
    if stack.duplicated(["firm_id", "stack_id", "annual_report_year"]).any():
        raise AssertionError("duplicate firm-stack-year rows")

    counts = stack.groupby(["cohort_report_year", "treated_in_stack", "Post"]).size().rename("project_rows").reset_index()
    paper_rows = []
    for c, z in PAPER_COUNTS.items():
        for key, value in z.items():
            paper_rows.append(
                {"cohort_report_year": c, "treated_in_stack": key[0], "Post": key[1], "gao_paper_rows": value}
            )
    counts = counts.merge(pd.DataFrame(paper_rows), on=["cohort_report_year", "treated_in_stack", "Post"], how="outer")
    counts["row_gap_project_minus_paper"] = counts["project_rows"] - counts["gao_paper_rows"]

    stack.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    stack["firm_id"] = stack["firm_id"].astype(np.int32)
    stack.to_stata(OUT / "gao_official_sse_augmented_stack.dta", write_index=False, version=118)
    stack.to_csv(OUT / "gao_official_sse_augmented_stack.csv", index=False)
    counts.to_csv(OUT / "official_sse_augmented_stack_vs_gao_table1.csv", index=False)
    pd.DataFrame(selection).to_csv(OUT / "official_sse_augmented_stack_selection_audit.csv", index=False)

    meta = {
        "rows": int(len(stack)),
        "unique_firms": int(stack.firm_id.nunique()),
        "treated_firms": int(stack.loc[stack.treated_in_stack.eq(1), "firm_id"].nunique()),
        "added_direct_scope_policy_count": len(SSE_DIRECT_SCOPE),
        "added_direct_scope_firm_policy_rows": int(len(add)),
        "newly_or_earlier_treated_firms": int(first.added_by_sse_direct_scope.sum()),
        "cohorts": COHORTS,
        "no_p_value_selection": True,
        "status": "source-defined SSE-augmented reconstruction; not claimed identical to authors' unpublished manual mapping",
    }
    (OUT / "official_sse_augmented_stack_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print(pd.DataFrame(selection).to_string(index=False))
    print(counts.to_string(index=False))


if __name__ == "__main__":
    main()
