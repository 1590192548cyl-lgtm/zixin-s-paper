from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';OLD=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(d,n):pd.DataFrame(d).to_csv(O/n,index=False,encoding='utf-8-sig')
def md(df,cols=None):
 if cols:df=df[cols]
 def fmt(x):
  if pd.isna(x):return '—'
  if isinstance(x,(float,np.floating)):return f'{x:.6f}'
  return str(x)
 return '|'+ '|'.join(df.columns)+'|\n|'+'|'.join(['---']*len(df.columns))+'|\n'+'\n'.join('|'+ '|'.join(fmt(x) for x in r)+'|' for r in df.itertuples(index=False,name=None))
log=(O/'transition_H8.log').read_text();assert 'H8_TRANSITION_TWO_AUTHORIZED_FITS_COMPLETE' in log
assert log.count('HDFE Linear regression')==2
for marker in ['AUTHORIZED_STATIC_FIT_START','AUTHORIZED_STATIC_FIT_COMPLETE','AUTHORIZED_EVENT_FIT_START','AUTHORIZED_EVENT_FIT_COMPLETE']:
 assert sum(line.strip()==marker for line in log.splitlines())==1,marker
assert 'STORED_ESTIMATES_EXPORT_AND_PLOT_COMPLETE_NO_FITS' in (O/'stored_estimates_export.log').read_text()
new=pd.read_csv(O/'static_results.csv');old=pd.read_csv(OLD/'static_results.csv').query('model=="H8"');ev=pd.read_csv(O/'event_results.csv');orig=pd.read_csv(OLD/'event_results.csv').query('model=="H8"');reb=pd.read_csv(O/'old_event_rebased2013.csv');j=pd.read_csv(O/'joint_tests.csv');oj=pd.read_csv(OLD/'joint_tests.csv').query('model=="H8"')
rows=[]
for name,z in [('old_H8',old.iloc[0]),('H8_transition',new[new.term.eq('TreatPost')].iloc[0])]:
 rows.append(dict(model=name,N=int(z.N),clusters=int(z.clusters),treated_firms=int(z.treated_firms),TreatPost=z.coefficient,SE=z.SE,t=z.t,p=z.p,CI_low=z.CI_low,CI_high=z.CI_high,transition_term_added=name=='H8_transition'))
comp=pd.DataFrame(rows);save(comp,'static_model_comparison.csv')
aligned=ev.merge(reb,on='event_time',suffixes=('_new','_old_rebased'));errors={v:float((aligned[v+'_new']-aligned[v+'_old_rebased']).abs().max()) for v in ['coefficient','SE','p','CI_low','CI_high']};assert max(errors.values())<1e-10
evcmp=orig.merge(ev,on='event_time',how='outer',suffixes=('_old2014base','_new2013base')).merge(reb[['event_time','coefficient','SE','p','CI_low','CI_high']].rename(columns={k:k+'_old_rebased2013' for k in ['coefficient','SE','p','CI_low','CI_high']}),on='event_time',how='outer').sort_values('event_time');save(evcmp,'event_model_comparison.csv')
for test in ['pre_2009_2012','post_2015_2021']:
 a=j[(j.model=='old_H8_rebased2013')&j.test.eq(test)].iloc[0];b=j[(j.model=='H8_transition')&j.test.eq(test)].iloc[0];assert abs(a.p-b.p)<1e-12
actual=pd.read_csv(O/'actual_sample_keys_private.csv');expect=pd.read_csv(O/'expected_sample_keys_private.csv');sel=actual[actual.static_sample.eq(1)]
assert len(sel)==7609 and sel.firm_id.nunique()==648 and sel[sel.Treat.eq(1)].firm_id.nunique()==439
assert actual.static_sample.equals(actual.event_sample) and actual.static_sample.equals(actual.old_H8_sample)
assert set(map(tuple,sel[['firm_id','year']].to_numpy()))==set(map(tuple,expect[['firm_id','year']].to_numpy()))
assert actual.TreatPost.eq(actual.Treat*actual.Post).all() and actual.Post.eq(actual.year.ge(2015)).all() and actual.event_time.eq(actual.year-2015).all()
assert actual.TreatTransition.eq(actual.Treat.eq(1)&actual.year.eq(2014)).all()
assert len(pd.read_csv(O/'automatic_exclusions_private.csv'))==0
fit=pd.read_csv(O/'event_fit_invariance.csv').iloc[0];assert abs(fit.new_rss-fit.old_rss)<1e-8
manifest=json.loads((O/'protected_before.json').read_text());after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after)
(O/'protected_after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),encoding='utf-8')
metadata=dict(status='complete',static_fits=1,event_fits=1,additional_regression_specs=0,N=7609,clusters=648,treated_firms=439,automatic_exclusions=0,actual_keys_equal_original_H8=True,static_and_event_samples_identical=True,all_five_requested_horizon_terms_estimable=True,all_twelve_dynamic_terms_estimable=True,baseline_year=2013,transition_year=2014,event_reparameterization_max_abs_errors=errors,event_fitted_RSS_unchanged=True,protected_files=len(manifest),originals_unchanged=True,original_G1_unchanged=True,SYN_recomputed=False,winsor_recomputed=False,stata_threads=1,stata_peak_RSS='not measured',initial_launch_failed_before_do_file=True,subsequent_export_and_plot_calls_refit_models=False)
(O/'run_completed.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
pre=float(j[(j.model=='H8_transition')&j.test.eq('pre_2009_2012')].p.iloc[0]);post=float(j[(j.model=='H8_transition')&j.test.eq('post_2015_2021')].p.iloc[0]);tr=new[new.term.eq('TreatTransition')].iloc[0]
report=f'''# H8保留2014过渡期的一次固定修正

2026-11-04。已完成用户授权的1次静态、1次事件研究，不继续试规格。未经作者确认的重建研究，非原G1，也不称为黄文完整13控制数值复现。

## 结论

静态TreatPost={comp.iloc[1].TreatPost:.6f}，聚类SE={comp.iloc[1].SE:.6f}，p={comp.iloc[1].p:.6f}，95%CI=[{comp.iloc[1].CI_low:.6f}, {comp.iloc[1].CI_high:.6f}]。达到5%和10%，未达到1%。

2013为事件基准，2014单列过渡期。2009—2012政策前四项联合p={pre:.9f}，拒绝联合为0；不能声称平行趋势通过。2015—2021政策后七项联合p={post:.6f}，未达到10%。不因结果未达目标追加规格。

## 固定设置及实际样本

唯一输入为周历修复后的fixed_analysis.dta，限定原old_H8_sample==1。静态增加TreatTransition=Treat×1(year==2014)，原TreatPost、Post不变。

控制始终为Size_w、Age_w、Lev_w、Cent_w、Top10_w、Dual、Board_w、Big4。公司与年份FE，公司firm_id聚类。连续变量缩尾值及SYN_w直接读取冻结文件，未重算。原Treat及event_time=year-2015完全保留。

静态和事件实际样本均7609条、648家公司、439家处理公司，实际公司年键恰等于原H8。2014全部578条H8记录保留；自动删除0条，空剔除表保留。无firm-year重复、交互项只在处理组对应时期为1。未加载周收益全库或年报。

## 静态与原结果并列

{md(comp)}

新减旧：系数变化{comp.iloc[1].TreatPost-comp.iloc[0].TreatPost:+.6f}，标准误变化{comp.iloc[1].SE-comp.iloc[0].SE:+.6f}。负向点估计绝对值减小、标准误增加，p由约0.0132变为0.0363；原与新均只达到5%，均未达到1%。这是本次固定修正的结果，不是新一轮筛选的起点。

静态过渡期系数δ={tr.coefficient:.6f}，SE={tr.SE:.6f}，p={tr.p:.6f}，95%CI=[{tr.CI_low:.6f}, {tr.CI_high:.6f}]。不显著不证明2014没有政策暴露；暴露由日期与周数据确认，δ是模型中的相对差异参数。δ也不应强制等于β乘17/52。

主β仍是该线性静态模型的完整政策后时期相对差异，不是2015年1月即时效应，不是所有沪市公司的监管总效应；前趋势风险尚在，不能直接将其当成因果效应已确认。

## 完整动态结果

事件0仍为2015，2013=-2省略，2014=-1单列。2013图示置0但不估计SE/CI，不把它编号改成-1；其余12项全部可估计。

{md(ev[['event_time','coefficient','SE','p','CI_low','CI_high']])}

2014过渡期的动态系数与静态δ不是同一个模型参数，不能要求两者相等。0、+1、+2分别约+0.0143、-0.0363、-0.0122，p分别约0.8611、0.6897、0.8873；+1和+2均负但均未达到10%。2021单期负向达到5%，不据此筛年份，亦未作多重检验校正。

## 联合检验、基准变换与原事件研究比较

{md(j)}

原事件研究以2014为基准，原全部事前检验覆盖2009—2013五项，p={float(oj[oj.test.eq('pre_all')].p.iloc[0]):.9f}；原全部事后检验p={float(oj[oj.test.eq('post_all')].p.iloc[0]):.6f}。新检验覆盖2009—2012四项，相对2013，不含有暴露的2014，原假设已经不同，不能直接将p值升降解释为识别改善。

为避免混淆，仅恢复原H8_event.ster及其协方差，用线性组合将旧系数表达为2013基准，没有重估旧回归。新完整事件模型与旧模型只是重参数化：以旧2014基准系数记b，新的非2013年份系数为b_k−b_2013，2014新系数为−b_2013。

同基准旧值与新值的系数/SE/p/CI最大绝对差均小于1e-10；残差平方和均约{fit.new_rss:.9f}。政策前联合F和p在统一假设下也完全一致。因此更换基准没有改变动态模型的拟合信息，也没有修复原有趋势差异。

2011单项p相对2013变为约0.2932，但2010单项p约0.0111，政策前联合仍拒绝。不能挑某个前置系数不显著就宣称平行趋势通过。政策后联合p约0.117同样依赖明确的参照假设，不是政策后效应被程序删除。

## 一次拟合、技术处理和保护

模型日志恰含2次HDFE回归及静态/事件各1次完成标记；未运行H0、其他控制组合、加权或稳健模型。旧事件重表达、完整精度导出与画图只恢复估计存档，不执行回归。

最初启动因路径空格在读取do文件之前退出r(601)，拟合次数为0；保留launch_path_failure.log后改用相对文件名启动。成功运行的模型各1次。后续仅从.ster重新导出double精度数值，未重新拟合。

Stata设为单线程，小面板读取，不读取原周库或年报；未测量Stata进程峰值RSS，不虚报。{len(manifest)}份保护文件前后SHA256一致，含原G1、全期/短窗口数据及估计结果、源分类和缓存、事先固定的PLAN及模型do文件。

事件图已经检查。图中2014橙色标记为过渡期，2013空心点为归一化基准；未将2014/2015之间的竖线误标为真实1月政策日。区间与系数直接来自存档，未为了视觉效果修改。

## 文件与停止

主要输出：static_model_comparison.csv、static_results.csv、event_results.csv、event_model_comparison.csv、old_event_rebased2013.csv、joint_tests.csv、event_fit_invariance.csv、transition_event_study.png、两份新.ster、transition_H8.log、actual_sample_keys_private.csv、空automatic_exclusions_private.csv、run_completed.json及保护清单。原始/分析数据与估计存档含CSMAR许可信息，不自动公开GitHub。

本轮完成后停止。结果没有达到“静态三星且平行趋势不拒绝”的目标，但未因此换样本、控制变量或继续试模型。
'''
(O/'transition_H8_report.md').write_text(report,encoding='utf-8')
print(comp.to_string(index=False));print('PRE',pre,'POST',post);print('All original hashes unchanged; two authorized fits verified.')
