"""Archive new audit artifacts only; refuse any existing destination."""
from pathlib import Path
import hashlib
import json
import shutil

work=Path(__file__).resolve().parent
dest=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_estimand_audit_20261103')
assert not dest.exists(), f'Archive target already exists: {dest}'
assert (work/'outputs/G1_estimand_weight_audit_report.md').is_file()
checks=json.loads((work/'outputs/audit_summary.json').read_text(encoding='utf-8'))
assert checks['algebra_checks']==31 and checks['source_hash_checks']==10
shutil.copytree(work/'outputs',dest)
(dest/'code').mkdir()
for name in ['AUDIT_PLAN.md','audit_fixed_G1.do','audit_G1.py','archive_audit.py']:
    shutil.copy2(work/name,dest/'code'/name)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for p in sorted((work/'outputs').iterdir()):
    if p.is_file():
        target=dest/p.name
        assert sha(p)==sha(target),p.name
        files.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(target)})
for name in ['AUDIT_PLAN.md','audit_fixed_G1.do','audit_G1.py','archive_audit.py']:
    assert sha(work/name)==sha(dest/'code'/name)
(dest/'archive_manifest.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'archive':str(dest),'verified_output_files':len(files),
                  'output_bytes':sum(p['bytes'] for p in files),'code_files':4},ensure_ascii=False))
