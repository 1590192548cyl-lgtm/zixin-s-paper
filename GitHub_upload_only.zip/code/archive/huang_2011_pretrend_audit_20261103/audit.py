"""Read-only diagnostics, no alternate DID/SYN estimation or source writes."""
from pathlib import Path
import sqlite3,hashlib,json,resource,time
from datetime import date
import numpy as np,pandas as pd
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True)
B=Path('/Users/macpro/Documents/New project/huang_basic_reconstruction_20261103');P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑');R=P.parent
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig')
files=list((B/'outputs').glob('*.csv'))+list((B/'outputs').glob('*.ster'))+[B/'outputs/final_analysis.dta',P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta']
before={str(f):sha(f) for f in files};start=time.time()
d=pd.read_stata(B/'outputs/final_analysis.dta',convert_categoricals=False);syn=pd.read_csv(B/'outputs/syn_all_SSE_private.csv');mapping=pd.read_csv(B/'outputs/policy_mapping_private.csv').set_index('firm_id')
assert not d.duplicated(['firm_id','year']).any()
profiles=[];pairs=[];industries=[]
for model in ['H0','H8']:
 s=pd.read_csv(B/f'outputs/{model}_sample_private.csv');keys=pd.MultiIndex.from_frame(s.loc[s.static_sample.eq(1),['firm_id','year']]);q=d.set_index(['firm_id','year']).loc[keys].reset_index()
 for (year,treat),g in q.groupby(['year','Treat']):
  profiles.append(dict(model=model,year=year,Treat=treat,N=len(g),SYN_mean=g.SYN.mean(),SYN_w_mean=g.SYN_w.mean(),R2_mean=g.R2.mean(),n_weeks_mean=g.n_weeks.mean(),n_weeks_min=g.n_weeks.min(),n_30_34=int(g.n_weeks.lt(35).sum()),lower_clips=int(g.SYN.lt(g.SYN_w).sum()),upper_clips=int(g.SYN.gt(g.SYN_w).sum())))
 for year in range(2009,2014):
  both=set(q.loc[q.year.eq(year),'firm_id'])&set(q.loc[q.year.eq(2014),'firm_id'])
  full=q[q.year.isin([year,2014])];paired=full[full.firm_id.isin(both)]
  for label,frame in [('full_available',full),('same_firms_both_years',paired)]:
   a=frame.groupby(['year','Treat']).SYN_w.mean();gap0=a.loc[year,1]-a.loc[year,0];gap1=a.loc[2014,1]-a.loc[2014,0]
   pairs.append(dict(model=model,year=year,comparison=label,N_firms=frame.firm_id.nunique(),T_firms=frame.loc[frame.Treat.eq(1),'firm_id'].nunique(),gap_year=gap0,gap2014=gap1,gap_minus_2014=gap0-gap1,note='descriptive not adjusted DID; no regression'))
 if model=='H8':
  f=q[q.year.isin([2011,2014])].copy();f['industry2014']=f.firm_id.map(mapping.industry2014)
  paired=set(f.loc[f.year.eq(2011),'firm_id'])&set(f.loc[f.year.eq(2014),'firm_id']);f=f[f.firm_id.isin(paired)]
  for (code,treat),g in f.groupby(['industry2014','Treat']):
   a=g.groupby('year').SYN_w.mean()
   if len(a)==2:industries.append(dict(industry2014=code,Treat=treat,firms=g.firm_id.nunique(),SYN2011=a[2011],SYN2014=a[2014],change_2014_minus2011=a[2014]-a[2011]))
save(pd.DataFrame(profiles),'annual_group_profiles.csv');save(pd.DataFrame(pairs),'same_firm_descriptive_decomposition.csv');save(pd.DataFrame(industries),'industry_descriptive_changes.csv')
# Raw SYN coverage/distribution: independent of original filters/controls.
save(syn.groupby('year').agg(N=('firm_id','size'),SYN_mean=('SYN','mean'),SYN_sd=('SYN','std'),SYN_median=('SYN','median'),R2_mean=('R2','mean'),n_weeks_mean=('n_weeks','mean'),n_weeks_min=('n_weeks','min'),n_weeks_max=('n_weeks','max')).reset_index(),'raw_SYN_annual_profile.csv')
c=sqlite3.connect('file:'+str(B/'cache/weekly.sqlite')+'?mode=ro',uri=True)
w=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',c);wktext=w.week.astype(str).str[:4]+'-'+w.week.astype(str).str[4:]+'-1';w['ISO_anchor']=pd.to_datetime(wktext,format='%G-%V-%u',errors='coerce');iso=w.ISO_anchor.dt.isocalendar();w['ISO_roundtrip_code']=iso.year*100+iso.week;w['roundtrip_mismatch']=w.week.ne(w.ISO_roundtrip_code);w['anchor_gap_days']=w.ISO_anchor.diff().dt.days;w['same_ISO_anchor']=w.ISO_anchor.duplicated(False)
save(w,'weekly_calendar_roundtrip_audit.csv');save(w[w.roundtrip_mismatch|w.same_ISO_anchor],'week_encoding_conflicts.csv')
save(pd.read_sql_query('SELECT year,COUNT(*) AS firm_week_rows,COUNT(DISTINCT firm_id) AS firms,COUNT(DISTINCT week) AS source_weeks,AVG(ret) AS mean_return,AVG(cap) AS mean_cap,MIN(ret) AS min_return,MAX(ret) AS max_return FROM weekly GROUP BY year',c),'weekly_pool_annual_profile.csv')
save(pd.read_sql_query('SELECT week,COUNT(*) AS firm_weeks,COUNT(DISTINCT firm_id) AS firms,AVG(ret) AS mean_return,MIN(ret) AS min_return,MAX(ret) AS max_return,SUM(ret*cap)/SUM(cap) AS weighted_market_return FROM weekly WHERE year BETWEEN 2010 AND 2014 GROUP BY week ORDER BY week',c),'weekly_market_2010_2014.csv');c.close()
# Compare the 2011 legacy classification with 2012 backcast, not a replacement.
parts=[];firstst={};poolst={}
for ch in pd.read_stata(R/'原始数据/行业分类_新下载.dta',chunksize=40000,convert_categoricals=False):
 yy=ch.EndDate.str[:4].astype(int);fid=ch.Symbol.astype(int)
 mask=yy.between(2009,2021)&ch.ShortName.str.upper().str.match(r'^(?:\*?ST|S\*?ST|PT)',na=False)
 for a,b in zip(fid[mask],yy[mask]):firstst[a]=min(firstst.get(a,9999),b)
 mask=(ch.IndustryClassificationID.eq('P0201')&yy.eq(2011))|(ch.IndustryClassificationID.eq('P0207')&yy.isin([2012,2013,2014]))
 z=ch.loc[mask,['IndustryClassificationID','IndustryCode2','IndustryName2']].copy();z['year']=yy[mask];z['firm_id']=fid[mask];parts.append(z)
ind=pd.concat(parts,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any()
pivot=ind.pivot(index='firm_id',columns='year',values='IndustryCode2');a=pivot.loc[pivot[2011].notna()&pivot[2012].notna()].copy();a['Treat2014']=a.index.map(mapping.Treat);a['in_H8_2011']=a.index.isin(d.loc[d.year.eq(2011)&d.sample8.eq(1),'firm_id'])
save(a.reset_index(),'legacy2011_backcast2012_2014_codes_private.csv')
trans=ind[ind.year.eq(2011)][['firm_id','IndustryCode2','IndustryName2']].rename(columns={'IndustryCode2':'code2011','IndustryName2':'name2011'}).merge(ind[ind.year.eq(2012)][['firm_id','IndustryCode2','IndustryName2']].rename(columns={'IndustryCode2':'code2012','IndustryName2':'name2012'}),on='firm_id',validate='one_to_one')
save(trans.groupby(['code2011','name2011','code2012','name2012'],dropna=False).size().rename('firms').reset_index(),'legacy_backcast_crosswalk_audit.csv')
# Show future-status exclusions transparently; no new model or revised sample.
ipo=pd.read_stata(R/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ids=set(ipo.loc[ipo.Listexg.eq('1')&ipo.Listdt.lt('2015-01-01')&ipo.Stkcd.str.startswith('6'),'firm_id'])
f=syn[syn.firm_id.isin(ids)&syn.year.isin([2011,2014])].copy();f['Treat']=f.firm_id.map(mapping.Treat);f['eligible']=f.firm_id.map(mapping.eligible);f['first_observed_ST_year']=f.firm_id.map(firstst);f['status']='not_flagged_ST_in_source';f.loc[f.first_observed_ST_year.le(2014),'status']='first_ST_observed_by2014';f.loc[f.first_observed_ST_year.ge(2015),'status']='first_ST_observed2015_2021'
save(f.groupby(['year','Treat','status','eligible'],dropna=False).agg(N=('firm_id','size'),SYN_mean=('SYN','mean')).reset_index(),'sample_selection_descriptive_profile.csv')
save(pd.DataFrame([dict(variable=v,missing2011=int(d.loc[d.year.eq(2011),v].isna().sum()),missing2014=int(d.loc[d.year.eq(2014),v].isna().sum())) for v in ['Size','Age','Lev','Cent','Top10','Dual','Board','Big4']]),'control_missingness_2011_2014.csv')
meta=dict(regressions_run=0,SYN_reestimated=False,originals_unchanged=all(sha(f)==h for f,h in before.items()),protected_files=len(before),ISO_roundtrip_mismatched_keys=int(w.roundtrip_mismatch.sum()),duplicate_ISO_anchor_keys=int(w.same_ISO_anchor.sum()),legacy_crosswalk_groups=int(trans.groupby('code2011').code2012.nunique().gt(1).sum()),seconds=time.time()-start,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
assert meta['originals_unchanged'];(O/'audit_execution.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');print(meta);print(pd.DataFrame(pairs).query('year==2011').to_string(index=False));print(pd.DataFrame(profiles).query('year>=2009 and year<=2014').to_string(index=False))
