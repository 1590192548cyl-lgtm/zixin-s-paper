"""Read-only industry/sample/SYN lineage audit. No fitting or SYN reconstruction."""
from pathlib import Path
import json,hashlib,sqlite3,time,resource,sys
import pandas as pd,numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);BASE=W.parent
ROOT=Path('/Users/macpro/Desktop/毕业论文');B=BASE/'huang_basic_reconstruction_20261103';R=BASE/'huang_week_calendar_repair_20261103';F=R/'fixed_rerun/outputs';start=time.time()
sys.path.insert(0,str(BASE/'huang_replication_data_audit_20261103'));from audit_sources import xml_rows
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(d,n):pd.DataFrame(d).to_csv(O/n,index=False,encoding='utf-8-sig')
def js(d,n):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
protected=[Path(x['path']) for x in json.loads((BASE/'huang_identification_descriptive_audit_20261103/outputs/protected_before.json').read_text())]
protected += [B/'build.py',R/'repair.py',R/'cache/weekly_corrected.sqlite',B/'cache/weekly.sqlite',ROOT/'原始数据/行业分类_新下载.dta']+list((R/'cache').glob('syn_*.csv'))
protected=list(dict.fromkeys(protected));manifest=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in protected];js(manifest,'protected_before.json')
d=pd.read_stata(F/'fixed_analysis.dta',convert_categoricals=False);mapping=pd.read_csv(B/'outputs/policy_mapping_private.csv').set_index('firm_id');s=d[d.old_H8_sample.eq(1)];ids=set(d.loc[d.old_H0_sample.eq(1),'firm_id']);all14=mapping.industry2014
def treat(code):return bool(code in ['K70','C26','C27','F52']+[f'C{x}' for x in range(34,41)] or str(code)[:1] in 'ABDG IJ'.replace(' ',''))
assert all(treat(c)==bool(t) for c,t in zip(all14,mapping.Treat))
names=pd.read_csv(BASE/'huang_replication_data_audit_20261103/observed_2014_P0207_codebook.csv').set_index('code').industry_name.to_dict()
boundaries=[('房地产','K70','较直接；不等于作者代码已确认'),('设备制造','C34—C40','七类全纳入未经作者确认；C36汽车、C39电子等边界需核实'),('医药','C27','较直接'),('化工','C26','未纳C25/C28/C29；名称宽于单一代码时需作者解释'),('交通运输','G全部','包含仓储/邮政等；不是只按运输子类'),('采矿业','B全部','门类全纳入解释'),('金融','J全部','Treat映射为1，但正式样本排除金融'),('商业零售','F52','未纳批发F51；同组联动监管不等于重点身份'),('信息通信','I全部','包含I63/I64/I65；不是仅电信'),('农林','A全部','实际纳入畜牧、渔业与辅助服务，名称边界待核实'),('公用事业','D全部','电热燃气水全部纳入；未纳N77/N78环保服务')]
def category(c):
 if c=='K70':return '房地产'
 if c in [f'C{x}' for x in range(34,41)]:return '设备制造'
 if c=='C27':return '医药'
 if c=='C26':return '化工'
 if c=='F52':return '商业零售'
 return {'G':'交通运输','B':'采矿业','J':'金融','I':'信息通信','A':'农林','D':'公用事业'}.get(str(c)[:1],'非重点重建组')
rows=[]
for title,codes,note in boundaries:
 g=s[s.firm_id.map(all14).map(category).eq(title)]
 rows.append(dict(official_industry_name=title,current_code_rule=codes,H8_firms=g.firm_id.nunique(),H8_rows=len(g),official_code_list_obtained=False,author_fixed_year_confirmed=False,boundary_note=note))
save(rows,'eleven_industry_boundary_audit.csv')
rows=[]
for c,g in s.assign(code=s.firm_id.map(all14)).groupby('code'):
 rows.append(dict(code=c,source_name=names.get(c,''),category=category(c),Treat=int(g.Treat.iloc[0]),firms=g.firm_id.nunique(),rows=len(g)))
save(rows,'current_code_composition.csv')
# Only source classification fields, streaming; no annual reports/weekly raw scan.
parts=[]
for ch in pd.read_stata(ROOT/'原始数据/行业分类_新下载.dta',columns=['Symbol','EndDate','IndustryClassificationID','IndustryCode2'],chunksize=40000,convert_categoricals=False):
 y=ch.EndDate.str[:4].astype(int);q=ch.loc[ch.IndustryClassificationID.eq('P0207')&y.between(2012,2021)].copy();q['firm_id']=q.Symbol.astype(int);q['year']=q.EndDate.str[:4].astype(int);parts.append(q[['firm_id','year','IndustryCode2']])
ind=pd.concat(parts,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any();index=ind.set_index(['firm_id','year']).IndustryCode2
src14=ind[ind.year.eq(2014)].set_index('firm_id').IndustryCode2;assert mapping.loc[src14.index,'industry2014'].equals(src14.rename('industry2014'))
changes=[];details=[]
for y,g in ind[ind.firm_id.isin(ids)].groupby('year'):
 z=g.copy();z['frozen2014']=z.firm_id.map(all14);z['current_year_rule_flag']=z.IndustryCode2.map(treat).astype(int);z['frozen_flag']=z.firm_id.map(mapping.Treat);z['code_changed']=z.IndustryCode2.ne(z.frozen2014);z['membership_changed']=z.current_year_rule_flag.ne(z.frozen_flag)
 changes.append(dict(year=y,source_companies=len(z),code_differs_from2014=int(z.code_changed.sum()),rule_membership_differs_from2014=int(z.membership_changed.sum()),note='audit flags only, not replacement Treat'))
 details.extend(z[z.code_changed].to_dict('records'))
save(changes,'fixed2014_vs_source_year.csv');save(details,'industry_change_review_private.csv')
# Reconcile eligibility in a set-equivalent audit order (not changing actual filters).
ipo=pd.read_stata(ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo=ipo.set_index('firm_id');pre=set(ipo.index[ipo.Listexg.eq('1')&ipo.Stkcd.str.startswith('6')&ipo.Listdt.lt('2015-01-01')])
heads={};dead=set()
for sh,rn,vs in xml_rows(ROOT/'原始数据/公司基本信息/EVA_Co.xlsx'):
 if rn==1:heads[sh]=vs
 if rn>=4:
  r={name:vs.get(k,'') for k,name in heads[sh].items()};dt=r.get('DelistedDate','')
  if dt and dt<='2021-12-31':dead.add(int(r['Symbol']))
detail=pd.read_csv(BASE/'huang_industry_ST_audit_20261103/outputs/ST_proxy_vs_FirstSTDate_private.csv').set_index('firm_id')
st_ex=set(detail.index[~detail.old_retained]);candidate=(pre-dead)&set(all14.index[~all14.str.startswith('J')]);assert candidate==set(detail.index);eligible=candidate-st_ex;assert eligible==set(mapping.index[mapping.eligible.eq(1)])
flow=[]
for label,fs in [('pre2015_SSE_A',pre),('exclude_delisted_by2021',pre-dead),('require_2014_classification_exclude_J',candidate),('exclude_observed_ST_proxy',eligible),('current_H0_firms',set(d.loc[d.old_H0_sample.eq(1),'firm_id'])),('current_H8_firms',set(s.firm_id))]:
 known=fs&set(mapping.index);t=int(mapping.loc[sorted(known)].Treat.sum());flow.append(dict(stage=label,firms=len(fs),classification_known=len(known),treated_firms_known=t,control_firms_known=len(known)-t,unknown_classification=len(fs-known),note='audit order has industry before ST; set-equivalent final eligibility, not reselecting'))
save(flow,'selection_stage_group_counts.csv')
review=[]
for f in sorted(pre):
 reason='eligible_before_SYN'
 if f in dead:reason='delisted_by2021'
 elif f not in all14.index:reason='missing_2014_classification'
 elif all14[f].startswith('J'):reason='financial_J'
 elif f in st_ex:reason='observed_ST_proxy_2009_2021'
 elif f not in set(d.loc[d.old_H0_sample.eq(1),'firm_id']):reason='eligible_but_no_current_H0_record'
 review.append(dict(firm_id=f,IPODate=ipo.at[f,'Listdt'],code2014=all14.get(f,''),Treat2014=mapping.Treat.get(f,np.nan),audit_exclusive_reason=reason,current_H0=f in set(d.loc[d.old_H0_sample.eq(1),'firm_id']),current_H8=f in set(s.firm_id)))
save(review,'company_selection_review_private.csv')
# Existing SYN caches/descriptives only, no least squares/correlations or alternative SYN.
syn=pd.read_csv(R/'outputs/corrected_SYN_private.csv');summary=[]
for label,z in [('all_cached_valid_SSE',syn[syn.SYN.notna()]),('current_H0',d[d.old_H0_sample.eq(1)]),('current_H8',s)]:
 for y,g in [('all',z)]+list(z.groupby('year')):
  vals=g.SYN;summary.append(dict(population=label,year=y,N=len(g),firms=g.firm_id.nunique(),SYN_mean=vals.mean(),SYN_sd=vals.std(),SYN_median=vals.median(),R2_mean=g.R2.mean(),R2_median=g.R2.median(),n_weeks_mean=g.n_weeks.mean(),SYN_w_mean=g.SYN_w.mean() if 'SYN_w'in g else np.nan))
save(summary,'existing_SYN_distribution.csv')
cut=pd.read_csv(B/'outputs/final_frozen_winsor_cutoffs.csv').set_index('variable').loc['SYN'];err=(np.exp(s.SYN)-s.R2/(1-s.R2)).abs().max();assert err<1e-10
keys=pd.MultiIndex.from_frame(d[['firm_id','year']]);ss=syn.set_index(['firm_id','year']);assert not ss.index.duplicated().any();linked=ss.reindex(keys)
assert np.allclose(d.SYN,linked.SYN,equal_nan=True) and np.allclose(d.R2,linked.R2,equal_nan=True)
js(dict(SYN_matches_corrected_cache=True,R2_matches_corrected_cache=True,stored_logit_identity_max_error=float(err),frozen_p1=float(cut.p1),frozen_p99=float(cut.p99),SYN_raw_mean=float(s.SYN.mean()),SYN_w_mean=float(s.SYN_w.mean()),winsor_mean_change=float(s.SYN_w.mean()-s.SYN.mean()),same_current_H8_before_calendar_SYN_w_mean=float(s.SYN_w_before.mean()),calendar_mean_change_on_same_current_H8=float(s.SYN_w.mean()-s.SYN_w_before.mean())),'SYN_lineage_checks.json')
# Read corrected weekly cache in yearly slices; counts/concentration only, no return reconstruction.
db=sqlite3.connect('file:'+str(R/'cache/weekly_corrected.sqlite')+'?mode=ro',uri=True);pools=[]
for y in range(2009,2022):
 q=pd.read_sql_query('SELECT firm_id,week,cap FROM weekly WHERE year=?',db,params=[y]);srcy=max(y,2012);q['industry']=pd.MultiIndex.from_arrays([q.firm_id,np.full(len(q),srcy)]).map(index);q['group']=np.where(q.industry.str.startswith('C',na=False),q.industry,q.industry.str[0]);z=q.dropna(subset=['group']);n=z.groupby(['week','group']).firm_id.transform('size');total=z.groupby(['week','group']).cap.transform('sum');pools.append(dict(year=y,firm_weeks=len(q),firms=q.firm_id.nunique(),weeks=q.week.nunique(),unclassified_rows=int(q.group.isna().sum()),unclassified_cap_share=float(q.loc[q.group.isna(),'cap'].sum()/q.cap.sum()),industry_groups=z.group.nunique(),rows_in_singleton_group=int(n.eq(1).sum()),rows_in_2to5_group=int(n.between(2,5).sum()),rows_with_own_cap_gt_half_group=int((z.cap/total>.5).sum()),note='own-cap fraction diagnostic only; return pool not recomputed'))
db.close();save(pools,'cached_weekly_pool_structure.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(x['unchanged'] for x in after);js(after,'protected_after.json');js(dict(regressions_run=0,SYN_recomputed=False,new_analysis_DTA=0,formal_Treat_changed=False,sample_changed=False,protected_files=len(manifest),source_industry_stream_chunk=40000,weekly_raw_scanned=False,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'execution_audit.json')
print(pd.DataFrame(flow).to_string(index=False));print(pd.DataFrame(changes).to_string(index=False));print((O/'SYN_lineage_checks.json').read_text());print(pd.DataFrame(summary).query('year=="all"').to_string(index=False))
