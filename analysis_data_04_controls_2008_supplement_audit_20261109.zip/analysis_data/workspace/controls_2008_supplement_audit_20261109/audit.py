"""Read-only source coverage checks. No model, merge or variable construction."""
import csv
import hashlib
import json
import re
import resource
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, '/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows, norm

ROOT = Path('/Users/macpro/Desktop/2008年控制变量下载清单_20261104')
OUT = Path(__file__).resolve().parent

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def dump(name, obj):
    (OUT/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def writecsv(name, rows):
    if not rows: return
    with (OUT/name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)

def readcsv(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

target_rows = readcsv(ROOT/'2008_下载公司总清单_526家.csv')
targets = {r['股票代码'] for r in target_rows}
dual_targets = {r['股票代码'] for r in readcsv(ROOT/'2008_两职合一缺口_19家.csv')}
assert len(targets) == 526 and len(dual_targets) == 19

protected = json.loads(Path('/Users/macpro/Documents/New project/huang_two_firm_gap_audit_20261104/outputs/protected_before.json').read_text())
before_protected = [{'path':r['path'], 'sha256':digest(Path(r['path']))} for r in protected]
dump('protected_before.json', before_protected)
inventory=[]; workbooks=[]; yearrows=[]; records={}
for p in sorted(ROOT.rglob('*')):
    if not p.is_file(): continue
    st=p.stat(); inv=dict(path=str(p),filename=p.name,type=p.suffix,size_bytes=st.st_size,
        modified_local=datetime.fromtimestamp(st.st_mtime).isoformat(),sha256=digest(p))
    inventory.append(inv)
    if p.suffix.lower()!='.xlsx': continue
    with ZipFile(p) as z:
        ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        sheets=[dict(s.attrib) for s in wb.findall('s:sheets/s:sheet',ns)]
    headers={}; desc={}; units={}; counts=Counter(); cols=defaultdict(set); first=[]
    data=[]; years=Counter(); firms=defaultdict(set); dates=Counter()
    for sh,rn,vals in xml_rows(p):
        counts[sh]+=1; cols[sh].update(c for c,v in vals.items() if v!='')
        if len(first)<5: first.append(dict(sheet=sh,row=rn,cells=vals))
        if rn==1: headers[sh]=vals; continue
        if rn==2: desc[sh]=vals; continue
        if rn==3: units[sh]=vals; continue
        rec={field:vals.get(col,'') for col,field in headers[sh].items()}
        data.append(rec)
        code=norm(rec.get('Stkcd',rec.get('Symbol',rec.get('StockCode','')))).zfill(6)
        date=rec.get('Reptdt',rec.get('Enddate',rec.get('ApprsReptAnoDt','')))
        dates[date]+=1
        if re.match(r'^\d{4}',date):
            year=int(date[:4]); years[year]+=1; firms[year].add(code)
    records[p.name]=data
    detail=dict(path=str(p),sheets=sheets,actual_nonempty_rows=dict(counts),actual_nonempty_columns={k:len(v) for k,v in cols.items()},
        data_rows=len(data),headers=headers,descriptions=desc,units=units,first_five_rows=first,
        earliest_year=min(years) if years else None,latest_year=max(years) if years else None,dates=dict(dates))
    workbooks.append(detail)
    for y in sorted(years): yearrows.append(dict(file=p.name,year=y,observations=years[y],firms=len(firms[y])))
    print(p.name,len(data),detail['earliest_year'],detail['latest_year'],flush=True)

share=defaultdict(list)
for r in records['CG_Sharehold.xlsx']:
    if r['Reptdt']=='2008-12-31': share[norm(r['Stkcd']).zfill(6)].append(r)
coverage=[]; issues=[]; share_summary=Counter()
for code in sorted(targets):
    rr=share[code]; ranks=defaultdict(list)
    for r in rr:
        rank=norm(r['S0501b']); ranks[rank].append(r)
    valid={}; conflicts=[]; duplicates=[]
    for rank,rows in ranks.items():
        # Duplicate identical export rows are observable; never choose among conflicts.
        pairs={(r['S0101b'],norm(r['S0301b'])) for r in rows}
        if len(rows)>1: duplicates.append(rank)
        if len(pairs)>1: conflicts.append(rank)
        if len(pairs)==1:
            v=next(iter(pairs))[1]
            try:
                x=float(v)
                if 0<=x<=100: valid[rank]=x
            except ValueError: pass
    cent_components=all(str(k) in valid for k in range(1,6)) and valid.get('1',0)>0
    top10_components=all(str(k) in valid for k in range(1,11))
    item=dict(firm_id=code,date='2008-12-31',source_rows=len(rr),distinct_ranks=len(ranks),
        ranks=';'.join(sorted(ranks,key=lambda x:float(x) if x else -1)),
        valid_rank_1to5_components=cent_components,valid_rank_1to10_components=top10_components,
        duplicate_ranks=';'.join(duplicates),conflicting_ranks=';'.join(conflicts),
        extra_rank_rows=sum(len(v) for k,v in ranks.items() if k not in {str(j) for j in range(1,11)}))
    coverage.append(item)
    share_summary['company_with_rows']+=bool(rr)
    share_summary['Cent_components_complete']+=cent_components
    share_summary['Top10_components_complete']+=top10_components
    share_summary['duplicate_rank_companies']+=bool(duplicates)
    share_summary['conflicting_rank_companies']+=bool(conflicts)
    share_summary['extra_rank_companies']+=item['extra_rank_rows']>0
    share_summary['extra_rank_rows']+=item['extra_rank_rows']
    if not cent_components or not top10_components or duplicates or conflicts or item['extra_rank_rows']: issues.append(item)

dual=defaultdict(list)
for r in records['BDT_ManaGovAbil.xlsx']:
    if r['Enddate']=='2008-12-31': dual[norm(r['Symbol']).zfill(6)].append(norm(r['ConcurrentPosition']))
dualcoverage=[]
for code in sorted(dual_targets):
    vv=dual[code]; values=set(v for v in vv if v in ('0','1'))
    dualcoverage.append(dict(firm_id=code,date='2008-12-31',source_rows=len(vv),raw_values=';'.join(vv),
        usable_nonconflicting=len(values)==1 and len(set(vv))==1))

board2008=[r for r in records['CG_ManagerShareSalary.xlsx'] if r['Enddate']=='2008-12-31' and norm(r['StatisticalCaliber'])=='1']
audits2008=[r for r in records['CHN_AA_Overall.xlsx'] if r['ApprsReptAnoDt'].startswith('2008')]
missing_dual=[r['firm_id'] for r in dualcoverage if not r['usable_nonconflicting']]
summary=dict(target_firms=len(targets),new_xlsx_files=len(workbooks),total_folder_files=len(inventory),
    share_2008=share_summary,share_2008_outside_target=sorted(set(share)-targets),
    dual_target_firms=len(dual_targets),dual_2008_nonconflicting=sum(r['usable_nonconflicting'] for r in dualcoverage),
    dual_2008_missing_or_ambiguous=missing_dual,
    board_2008_yearend_inservice_rows=board2008,
    asset_appraisal_2008_announcement_rows=audits2008,
    annual_auditor_source_present=False,
    warning='Asset-appraisal auditor is not an annual financial statement auditor; no automatic substitution.',
    no_merges=True,no_formal_variables=True,no_SYN_recomputation=True,no_regression=True)

writecsv('file_inventory.csv',inventory); dump('workbook_details.json',workbooks)
writecsv('source_year_coverage.csv',yearrows)
writecsv('shareholder_2008_526_coverage.csv',coverage)
writecsv('shareholder_2008_issues.csv',issues)
writecsv('duality_2008_19_coverage.csv',dualcoverage)
dump('audit_summary.json',summary)
after_protected=[{'path':r['path'],'sha256':digest(Path(r['path']))} for r in protected]
dump('protected_after.json',after_protected)
changed=[r['path'] for r,s in zip(before_protected,after_protected) if r!=s]
source_changed=[r['path'] for r in inventory if digest(Path(r['path']))!=r['sha256']]
dump('execution_audit.json',dict(protected_files=len(protected),protected_changed=changed,
    original_inputs_changed=source_changed,peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,
    no_original_file_writes=True,no_DTA_created=True,no_merges=True,no_regressions=True))
assert not changed and not source_changed
print(json.dumps(summary,ensure_ascii=False,indent=2))
