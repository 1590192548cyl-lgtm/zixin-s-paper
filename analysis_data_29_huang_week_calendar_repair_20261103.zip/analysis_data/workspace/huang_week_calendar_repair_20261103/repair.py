from pathlib import Path
from datetime import date,timedelta
import pandas as pd,numpy as np,sqlite3,hashlib,json,gc,resource,time
W=Path(__file__).resolve().parent;O=W/'outputs';C=W/'cache';C.mkdir(exist_ok=True);B=W.parent/'huang_basic_reconstruction_20261103';R=Path('/Users/macpro/Desktop/毕业论文');start=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig')
def js(a,n):(O/n).write_text(json.dumps(a,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def log(s):print(time.strftime('%H:%M:%S'),s,flush=True)
v=pd.read_csv(O/'calendar_rule_validation.csv').set_index('rule');assert v.loc['Sunday_Jan1_week1','matches']==v.loc['Sunday_Jan1_week1','N']==1125
protected=list((B/'outputs').glob('*.ster'))+list((B/'outputs').glob('*results.csv'))+[B/'outputs/final_analysis.dta',R/'堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta',W/'REPAIR_PLAN.md']
manifest=[dict(file=str(p),sha256=sha(p)) for p in protected];js(manifest,'protected_input_manifest.json')
calendar=[]
for y in range(2009,2026):
 jan=date(y,1,1);origin=jan-timedelta(days=(jan.weekday()+1)%7)
 for k in range(1,54):
  sun=origin+timedelta(days=7*(k-1));a=max(sun,jan);z=min(sun+timedelta(days=6),date(y,12,31))
  if a>z:continue
  mon=sun+timedelta(days=1);calendar.append(dict(week=y*100+k,start=a.isoformat(),end=z.isoformat(),Monday_anchor=mon.isoformat(),year=mon.year if mon.month>=5 else mon.year-1))
cal=pd.DataFrame(calendar).set_index('week');assert not cal[['start','end']].duplicated().any()
ipo=pd.read_stata(R/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False);pool=set(ipo.loc[ipo.Listexg.eq('1')&ipo.Stkcd.str.startswith('6'),'Stkcd'].astype(int))
db=sqlite3.connect(C/'weekly_corrected.sqlite');db.execute('PRAGMA cache_size=-12000');db.execute('PRAGMA temp_store=FILE')
if not (C/'complete.json').exists():
 db.execute('CREATE TABLE weekly(firm_id INTEGER,week INTEGER,year INTEGER,ret REAL,cap REAL,PRIMARY KEY(firm_id,week))');reads=[]
 for path in sorted((R/'原始数据/周度数据重下').glob('*.dta')):
  n=kept=0
  for ch in pd.read_stata(path,chunksize=40000,convert_categoricals=False,columns=['Stkcd','Trdwnt','Wsmvosd','Wretwd']):
   n+=len(ch);fid=ch.Stkcd.astype(int);wk=ch.Trdwnt.str.replace('-','',regex=False).astype(int);yr=wk.map(cal.year);mask=fid.isin(pool)&yr.between(2008,2021)&ch.Wretwd.notna()&ch.Wsmvosd.gt(0)
   z=pd.DataFrame(dict(firm_id=fid[mask],week=wk[mask],year=yr[mask].astype(int),ret=ch.Wretwd[mask],cap=ch.Wsmvosd[mask]));db.executemany('INSERT INTO weekly VALUES(?,?,?,?,?)',z.itertuples(index=False,name=None));kept+=len(z)
  db.commit();reads.append(dict(file=str(path),read=n,kept=kept,sha256=sha(path)));log(f'{path.name} kept {kept}')
 db.execute('CREATE INDEX yr ON weekly(year)');db.commit();js(reads,'source_reads.json');(C/'complete.json').write_text('{}')
weeks=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',db);wk=weeks.week.to_numpy();prev=pd.Series(np.r_[np.nan,wk[:-1]],index=wk);yr=weeks.set_index('week').year;save(cal.loc[wk].reset_index(),'confirmed_week_calendar.csv')
old=sqlite3.connect('file:'+str(B/'cache/weekly.sqlite')+'?mode=ro',uri=True);oldweeks=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',old);old.close();check=oldweeks.merge(weeks,on='week',how='outer',suffixes=('_old','_corrected'),indicator=True);save(check,'week_research_year_comparison.csv')
oldprev=pd.Series(np.r_[np.nan,oldweeks.week.to_numpy()[:-1]],index=oldweeks.week)
affected=set()
for y in range(2009,2022):
 newkeys=set(weeks.loc[weeks.year.eq(y),'week']);oldkeys=set(oldweeks.loc[oldweeks.year.eq(y),'week']);allkeys=newkeys|oldkeys
 if newkeys!=oldkeys or any(oldprev.get(k,-1)!=prev.get(k,-2) for k in allkeys):affected.add(y)
 if any(check.loc[check.week.isin(allkeys),'year_old'].ne(check.loc[check.week.isin(allkeys),'year_corrected'])):affected.add(y)
# Industry year of a lag period can change even if current membership is stable.
for y in range(2009,2022):
 for k in weeks.loc[weeks.year.eq(y),'week']:
  pr=prev.get(k)
  if pd.notna(pr) and oldweeks.set_index('week').year.get(pr,-999)!=yr.get(pr,-998):affected.add(y);break
parts=[]
for ch in pd.read_stata(R/'原始数据/行业分类_新下载.dta',chunksize=40000,columns=['Symbol','EndDate','IndustryClassificationID','IndustryCode2'],convert_categoricals=False):
 mask=ch.IndustryClassificationID.eq('P0207')&ch.EndDate.str[:4].astype(int).between(2012,2021);q=ch.loc[mask].copy();q['firm_id']=q.Symbol.astype(int);q['year']=q.EndDate.str[:4].astype(int);parts.append(q)
ind=pd.concat(parts,ignore_index=True);ind['group']=np.where(ind.IndustryCode2.str.startswith('C'),ind.IndustryCode2,ind.IndustryCode2.str[0]);early=ind[ind.year.eq(2012)];parts=[ind]
for y in range(2008,2012):q=early.copy();q['year']=y;parts.append(q)
im=pd.concat(parts).set_index(['firm_id','year']).group;assert not im.index.duplicated().any();statuses=[]
for y in range(2009,2022):
 path=C/f'syn_{y}.csv'
 if y not in affected:
  original=pd.read_csv(B/f'cache/syn_{y}.csv');original.to_csv(path,index=False);statuses.append(dict(year=y,recomputed=False,reason='same weekly membership and lag industry year'));continue
 if path.exists():continue
 first=weeks.loc[weeks.year.eq(y),'week'].min();pr=prev.loc[first];d=pd.read_sql_query('SELECT * FROM weekly WHERE year=? OR week=? ORDER BY firm_id,week',db,params=[y,int(pr)])
 d['group']=pd.MultiIndex.from_frame(d[['firm_id','year']]).map(im);d['num']=d.ret*d.cap;d['prev_week']=d.week.map(prev);m=d.groupby('week').agg(num=('num','sum'),cap=('cap','sum'));d['market']=d.week.map(m.num/m.cap);d['market_lag']=d.prev_week.map(m.num/m.cap)
 it=d.dropna(subset=['group']).groupby(['week','group']).agg(num=('num','sum'),cap=('cap','sum'));ix=pd.MultiIndex.from_frame(d[['week','group']]);cap=ix.map(it.cap).to_numpy(dtype=float);num=ix.map(it.num).to_numpy(dtype=float)
 with np.errstate(divide='ignore',invalid='ignore'):d['industry']=np.where(cap>d.cap,(num-d.num)/(cap-d.cap),np.nan)
 lg=pd.MultiIndex.from_arrays([d.firm_id,d.prev_week.map(yr)]).map(im);ix=pd.MultiIndex.from_arrays([d.prev_week,lg]);lc=ix.map(it.cap).to_numpy(dtype=float);ln=ix.map(it.num).to_numpy(dtype=float);own=d.set_index(['firm_id','week']);ix=pd.MultiIndex.from_arrays([d.firm_id,d.prev_week]);oc=ix.map(own.cap).to_numpy(dtype=float);on=ix.map(own.num).to_numpy(dtype=float);og=ix.map(own.group);same=np.asarray(og==lg)&np.isfinite(oc);oc=np.where(same,oc,0);on=np.where(same,on,0)
 with np.errstate(divide='ignore',invalid='ignore'):d['industry_lag']=np.where(lc>oc,(ln-on)/(lc-oc),np.nan)
 rows=[]
 for fid,g in d[d.year.eq(y)].dropna(subset=['ret','market','market_lag','industry','industry_lag']).groupby('firm_id'):
  n=len(g);r2=sv=np.nan;rank=0
  if n>=30:
   a=g.ret.to_numpy();x=np.column_stack([np.ones(n),g[['market','market_lag','industry','industry_lag']].to_numpy()]);b,_,rank,_=np.linalg.lstsq(x,a,rcond=None);ss=((a-a.mean())**2).sum();r2=1-((a-x@b)**2).sum()/ss if ss>0 else np.nan
   if rank==5 and 0<r2<1:sv=float(np.log(r2/(1-r2)))
  rows.append(dict(firm_id=int(fid),year=y,SYN=sv,R2=r2,n_weeks=n,rank=int(rank)))
 q=pd.DataFrame(rows);q.to_csv(path,index=False);statuses.append(dict(year=y,recomputed=True,reason='calendar membership/lag-year affected'));log(f'SYN {y}: valid {q.SYN.notna().sum()}');del d;gc.collect()
db.close();save(pd.DataFrame(statuses),'SYN_year_recompute_status.csv')
syn=pd.concat([pd.read_csv(C/f'syn_{y}.csv') for y in range(2009,2022)],ignore_index=True);save(syn,'corrected_SYN_private.csv');orig=pd.read_stata(B/'outputs/final_analysis.dta',convert_categoricals=False);result=orig.rename(columns={'SYN':'SYN_before','SYN_w':'SYN_w_before','R2':'R2_before','n_weeks':'n_weeks_before'}).merge(syn[['firm_id','year','SYN','R2','n_weeks']],on=['firm_id','year'],how='left',validate='one_to_one')
for model in ['H0','H8']:
 mask=pd.read_csv(B/f'outputs/{model}_sample_private.csv');result=result.merge(mask[['firm_id','year','static_sample']].rename(columns={'static_sample':f'old_{model}_sample'}),on=['firm_id','year'],validate='one_to_one')
cut=pd.read_csv(B/'outputs/final_frozen_winsor_cutoffs.csv').set_index('variable').loc['SYN'];result['SYN_w']=result.SYN.clip(cut.p1,cut.p99)
missing=result[result.old_H0_sample.eq(1)&result.SYN.isna()].copy();save(missing,'mechanically_unavailable_fixed_sample_private.csv');save(result[['firm_id','year','SYN_before','SYN','SYN_w_before','SYN_w','n_weeks_before','n_weeks','old_H0_sample','old_H8_sample']],'SYN_fixed_sample_comparison_private.csv')
for v in orig.columns:
 if v not in ['SYN','SYN_w','R2','n_weeks']:assert result[v].equals(orig[v]),v
result.to_stata(O/'corrected_analysis.dta',write_index=False,version=118)
after=[dict(**r,unchanged=sha(r['file'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);js(after,'input_integrity_after.json');meta=dict(affected_years=sorted(affected),missing_fixed_sample_N=len(missing),old_H0_N=int(result.old_H0_sample.sum()),old_H8_N=int(result.old_H8_sample.sum()),new_regressions=0,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start,may_run_fixed_models=len(missing)==0);js(meta,'repair_audit.json');log(str(meta))
