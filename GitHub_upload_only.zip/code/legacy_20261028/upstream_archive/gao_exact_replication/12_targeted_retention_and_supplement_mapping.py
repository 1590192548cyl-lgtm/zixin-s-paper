from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs" / "targeted_supplement"
OUT.mkdir(parents=True, exist_ok=True)

PROJECT = Path("/Users/macpro/Desktop/毕业论文/堆叠DID重跑")
AR = PROJECT / "年报指引识别"

CANDIDATES = PROJECT / "output/iidg_all_candidates_v2.csv"
CORE_MAPPING = AR / "final_mapping/gao_firm_iidg_mapping_core.csv"
CORE_FIRST = AR / "final_mapping/gao_firm_first_treat_core.csv"
ALL_EVIDENCE = AR / "final_mapping/gao_firm_iidg_evidence_all.csv"
INVENTORY = AR / "output/annual_report_inventory.csv"

COHORTS = {2012, 2015, 2016, 2017}
TARGET_EXCHANGE = "上交所"

POLICY_KEYWORDS = {
    "SSE-02": ["房地产", "商品房", "物业销售"],
    "SSE-03": ["煤炭", "煤矿", "原煤"],
    "SSE-04": ["电力", "发电", "上网电量"],
    "SSE-05": ["零售", "门店", "直营网点"],
    "SSE-06": ["汽车制造", "整车", "汽车零部件"],
    "SSE-07": ["医药制造", "药品", "制药"],
    "SSE-08": ["石油", "天然气", "油气开采"],
    "SSE-09": ["钢铁", "钢材", "粗钢"],
    "SSE-10": ["建筑", "施工", "工程承包"],
    "SSE-12": ["服装", "成衣", "服饰"],
    "SSE-13": ["新闻出版", "出版", "发行"],
    "SSE-14": ["酒制造", "白酒", "啤酒", "葡萄酒"],
    "SSE-17": ["供水", "自来水", "水的生产"],
    "SSE-18": ["化工", "化学原料", "化学制品"],
    "SSE-19": ["航空运输", "客运量", "货邮运输"],
    "SSE-20": ["农业", "林业", "畜牧", "渔业", "养殖", "种植"],
    "SZ-01": ["畜禽", "水产养殖", "养殖"],
    "SZ-03": ["房地产", "商品房", "物业销售"],
    "SZ-06": ["装修装饰", "装饰工程", "装修工程"],
    "SZ-07": ["土木工程", "建筑施工", "工程承包"],
    "SZ-08": ["零售", "门店", "直营网点"],
}

CHINESE_NUMERALS = {
    1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "七", 8: "八", 9: "九",
    10: "十", 11: "十一", 12: "十二", 13: "十三", 14: "十四", 15: "十五", 16: "十六",
    17: "十七", 18: "十八", 19: "十九", 20: "二十", 21: "二十一", 22: "二十二",
    23: "二十三", 24: "二十四", 25: "二十五", 26: "二十六", 27: "二十七", 28: "二十八",
}

# P0207 classifications can lag a shell-company restructuring or be broader
# than the IIDG business scope. These exclusions are supported by the cited
# adoption-year annual-report business descriptions, not by regression output.
VERIFIED_EXCLUSIONS = {
    (600421, "SSE-07"): "2015年报主营业务为内燃机配件制造和销售，不属于医药制造。",
    (600556, "SSE-07"): "2015年报主营业务为智慧城市业务和物业管理，不属于医药制造。",
    (600962, "SSE-14"): "2016年报主营业务为浓缩果汁和蔬菜汁，不属于酒制造。",
}


def norm_firm(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype("Int64")


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            block = fh.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def read_text(path: Path, encoding_hint: str | None) -> str:
    encodings = []
    if encoding_hint and str(encoding_hint).lower() not in {"nan", "none", ""}:
        encodings.append(str(encoding_hint))
    encodings.extend(["utf-8-sig", "utf-8", "gb18030"])
    seen = set()
    for enc in encodings:
        if enc in seen:
            continue
        seen.add(enc)
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def compact_text(text: str) -> str:
    return re.sub(r"\s+", "", text.replace("—", "-").replace("－", "-"))


def policy_number(iidg_id: str) -> int | None:
    m = re.search(r"(\d+)$", iidg_id)
    return int(m.group(1)) if m else None


def contexts_for_policy(text: str, iidg_id: str, iidg_name: str) -> tuple[list[str], list[str]]:
    number = policy_number(iidg_id)
    industry_term = re.sub(r"^.*?[—-]", "", iidg_name).replace("相关业务", "").replace("业务", "")
    patterns = []
    if number:
        cn = CHINESE_NUMERALS.get(number, str(number))
        patterns.extend([
            rf"行业信息披露指引第0*{number}号.{{0,24}}{re.escape(industry_term)}",
            rf"行业信息披露指引第{cn}号.{{0,24}}{re.escape(industry_term)}",
            rf"{re.escape(industry_term)}.{{0,24}}行业信息披露指引第0*{number}号",
            rf"{re.escape(industry_term)}.{{0,24}}行业信息披露指引第{cn}号",
        ])
    if industry_term:
        patterns.append(re.escape(industry_term) + r".{0,16}行业信息披露指引")
        patterns.append(r"行业信息披露指引.{0,16}" + re.escape(industry_term))

    exact_contexts = []
    for pattern in patterns:
        for match in re.finditer(pattern, text):
            lo = max(0, match.start() - 220)
            hi = min(len(text), match.end() + 320)
            exact_contexts.append(text[lo:hi])
            if len(exact_contexts) >= 5:
                break
        if len(exact_contexts) >= 5:
            break

    business_contexts = []
    for keyword in POLICY_KEYWORDS.get(iidg_id, [industry_term] if industry_term else []):
        if not keyword:
            continue
        for match in re.finditer(re.escape(keyword), text):
            lo = max(0, match.start() - 160)
            hi = min(len(text), match.end() + 240)
            context = text[lo:hi]
            if context not in business_contexts:
                business_contexts.append(context)
            if len(business_contexts) >= 5:
                break
        if len(business_contexts) >= 5:
            break
    return exact_contexts, business_contexts


def classify_context(exact_contexts: list[str], business_contexts: list[str]) -> str:
    exact = "｜".join(exact_contexts)
    if exact_contexts and re.search(r"不适用|无需适用|不属于|未达到.{0,20}适用|豁免", exact):
        return "explicit_negative_or_exemption"
    if exact_contexts and re.search(r"适用|按照|根据|遵循|执行|要求披露", exact):
        return "explicit_positive"
    if exact_contexts:
        return "policy_title_mentioned"
    if business_contexts:
        return "business_signal_only"
    return "no_text_signal"


def prepare_inventory() -> pd.DataFrame:
    usecols = [
        "source_path", "file_name", "file_size", "sha256", "encoding", "decode_status",
        "stock_code", "company_name", "report_year", "is_full_annual_report",
        "is_annual_report_summary", "preferred_version", "duplicate_exact",
    ]
    inv = pd.read_csv(INVENTORY, usecols=usecols, low_memory=False)
    inv["firm_id"] = norm_firm(inv["stock_code"])
    inv["report_year"] = pd.to_numeric(inv["report_year"], errors="coerce").astype("Int64")
    for col in ["is_full_annual_report", "is_annual_report_summary", "preferred_version", "duplicate_exact"]:
        inv[col] = pd.to_numeric(inv[col], errors="coerce").fillna(0).astype(int)
    inv["inventory_priority"] = (
        100 * inv["preferred_version"]
        + 20 * inv["is_full_annual_report"]
        - 10 * inv["is_annual_report_summary"]
        - inv["duplicate_exact"]
    )
    preferred = (
        inv.sort_values(["firm_id", "report_year", "inventory_priority", "file_size"], ascending=[True, True, False, False])
        .drop_duplicates(["firm_id", "report_year"], keep="first")
    )
    return inv, preferred


def main() -> None:
    candidates = pd.read_csv(CANDIDATES, low_memory=False)
    candidates["firm_id"] = norm_firm(candidates["Stkcd"])
    candidates["candidate_first_report_year"] = pd.to_numeric(
        candidates["candidate_first_report_year"], errors="coerce"
    ).astype("Int64")
    selected = candidates[
        candidates["candidate_first_report_year"].isin(COHORTS)
        & candidates["mapping_type"].eq("A")
        & candidates["exchange"].eq(TARGET_EXCHANGE)
    ].copy()
    selected.sort_values(["candidate_first_report_year", "iidg_id", "firm_id"], inplace=True)
    selected.drop_duplicates(["firm_id", "iidg_id"], inplace=True)

    core = pd.read_csv(CORE_MAPPING, low_memory=False)
    core["firm_id"] = norm_firm(core["firm_id"])
    core_pairs = set(zip(core["firm_id"].astype(int), core["iidg_id"]))
    selected["already_in_core_mapping"] = [
        int((int(fid), iidg) in core_pairs) for fid, iidg in zip(selected["firm_id"], selected["iidg_id"])
    ]
    additions = selected[selected["already_in_core_mapping"].eq(0)].copy()

    inv, preferred = prepare_inventory()
    report_cols = [
        "firm_id", "report_year", "source_path", "file_name", "file_size", "sha256",
        "encoding", "decode_status", "is_full_annual_report", "preferred_version",
    ]
    additions = additions.merge(
        preferred[report_cols],
        left_on=["firm_id", "candidate_first_report_year"],
        right_on=["firm_id", "report_year"],
        how="left",
        validate="many_to_one",
    )

    # Read one report at a time. Multiple policies for a firm-year reuse the
    # same in-memory string and release it before the next report.
    extraction_rows = []
    for (firm_id, report_year), group in additions.groupby(["firm_id", "candidate_first_report_year"], sort=True):
        source_value = group["source_path"].dropna()
        source_path = Path(str(source_value.iloc[0])) if not source_value.empty else None
        encoding_value = group["encoding"].dropna()
        encoding = str(encoding_value.iloc[0]) if not encoding_value.empty else None
        if source_path is None or not source_path.exists():
            for row in group.itertuples(index=False):
                extraction_rows.append({
                    "firm_id": int(row.firm_id),
                    "company_name": row.公司名称,
                    "iidg_id": row.iidg_id,
                    "iidg_name": row.iidg_name,
                    "report_year": int(row.candidate_first_report_year),
                    "industry_code": row.industry_code,
                    "industry_name": row.industry_name,
                    "source_path": str(source_path) if source_path else "",
                    "source_sha256": "",
                    "text_evidence_status": "missing_report",
                    "exact_policy_contexts": "",
                    "business_contexts": "",
                    "text_chars": np.nan,
                })
            continue

        raw = read_text(source_path, encoding)
        text = compact_text(raw)
        actual_hash = file_sha256(source_path)
        for row in group.itertuples(index=False):
            exact_contexts, business_contexts = contexts_for_policy(text, row.iidg_id, row.iidg_name)
            extraction_rows.append({
                "firm_id": int(row.firm_id),
                "company_name": row.公司名称,
                "iidg_id": row.iidg_id,
                "iidg_name": row.iidg_name,
                "report_year": int(row.candidate_first_report_year),
                "industry_code": row.industry_code,
                "industry_name": row.industry_name,
                "source_path": str(source_path),
                "source_sha256": actual_hash,
                "text_evidence_status": classify_context(exact_contexts, business_contexts),
                "exact_policy_contexts": "｜".join(exact_contexts),
                "business_contexts": "｜".join(business_contexts),
                "text_chars": len(raw),
            })
        del raw, text

    extracted = pd.DataFrame(extraction_rows)
    extracted.to_csv(OUT / "targeted_annual_report_evidence.csv", index=False)
    additions = additions.merge(
        extracted[
            ["firm_id", "iidg_id", "report_year", "source_path", "source_sha256", "text_evidence_status",
             "exact_policy_contexts", "business_contexts"]
        ].rename(columns={"report_year": "evidence_report_year"}),
        left_on=["firm_id", "iidg_id", "candidate_first_report_year"],
        right_on=["firm_id", "iidg_id", "evidence_report_year"],
        how="left",
        suffixes=("_inventory", ""),
        validate="one_to_one",
    )

    additions["supplement_decision"] = np.where(
        additions["text_evidence_status"].isin(
            ["business_signal_only", "explicit_positive", "policy_title_mentioned"]
        ),
        "accept_structured_scope_plus_business_signal",
        "pending_targeted_manual_review",
    )
    additions["verified_exclusion_reason"] = ""
    for idx, row in additions.iterrows():
        key = (int(row["firm_id"]), row["iidg_id"])
        if key in VERIFIED_EXCLUSIONS:
            additions.at[idx, "supplement_decision"] = "exclude_verified_nonapplicable"
            additions.at[idx, "verified_exclusion_reason"] = VERIFIED_EXCLUSIONS[key]
    accepted = additions[
        additions["supplement_decision"].eq("accept_structured_scope_plus_business_signal")
    ].copy()
    excluded = additions[
        additions["supplement_decision"].eq("exclude_verified_nonapplicable")
    ].copy()
    pending = additions[
        additions["supplement_decision"].eq("pending_targeted_manual_review")
    ].copy()
    excluded.to_csv(OUT / "targeted_verified_exclusions.csv", index=False)
    pending.to_csv(OUT / "targeted_manual_review_queue.csv", index=False)

    # Add the pre-specified direct-scope A candidates without using regression
    # results. A direct P0207 match is triangulated against the firm's annual-
    # report business description. Missing or contradictory business evidence
    # is retained for manual review instead of being silently treated.
    new_rows = pd.DataFrame({
        "firm_id": accepted["firm_id"].astype("Int64"),
        "company_name": accepted["公司名称"].fillna(accepted.get("Conme", "")),
        "iidg_id": accepted["iidg_id"],
        "iidg_name": accepted["iidg_name"],
        "official_first_applicable_year": accepted["candidate_first_report_year"],
        "evidence_report_year": accepted["candidate_first_report_year"],
        "listing_year": pd.to_datetime(accepted["listing_date"], errors="coerce").dt.year,
        "business_confirmed_year": np.nan,
        "treat_year_core": accepted["candidate_first_report_year"],
        "treat_year_expanded": accepted["candidate_first_report_year"],
        "late_entry_uncertain": 0,
        "evidence_status": "structured_direct_scope_plus_business_signal",
        "evidence_source": "pre-specified exchange+board+P0207 industry rule + targeted annual-report business signal",
        "confidence": "high_triangulated",
        "evidence_text": accepted["exact_policy_contexts"].where(
            accepted["exact_policy_contexts"].fillna("").ne(""),
            accepted["business_contexts"],
        ),
        "source_path": accepted["source_path"].fillna(""),
        "decision_reason": (
            "补入原候选构造中预先定义的上交所A类直接行业范围，并由首次适用年度年报主营业务信号交叉确认；未使用回归结果或p值。"
        ),
    })
    new_rows["text_evidence_status"] = accepted["text_evidence_status"].values
    new_rows["industry_code"] = accepted["industry_code"].values
    new_rows["industry_name"] = accepted["industry_name"].values
    new_rows["policy_source_url"] = accepted["policy_source_url"].values

    for col in new_rows.columns:
        if col not in core.columns:
            core[col] = np.nan
    for col in core.columns:
        if col not in new_rows.columns:
            new_rows[col] = np.nan
    supplemented = pd.concat([core, new_rows[core.columns]], ignore_index=True)
    supplemented.sort_values(["firm_id", "official_first_applicable_year", "iidg_id"], inplace=True)
    if supplemented.duplicated(["firm_id", "iidg_id"]).any():
        raise AssertionError("Duplicate firm-IIDG rows in supplemented mapping")
    supplemented.to_csv(OUT / "gao_firm_iidg_mapping_supplemented.csv", index=False)

    core_first = pd.read_csv(CORE_FIRST, low_memory=False)
    core_first["firm_id"] = norm_firm(core_first["firm_id"])
    first_new = (
        new_rows.sort_values(["firm_id", "official_first_applicable_year", "iidg_id"])
        .drop_duplicates("firm_id", keep="first")
        [["firm_id", "official_first_applicable_year", "iidg_id", "iidg_name"]]
        .rename(columns={
            "official_first_applicable_year": "first_structured_scope_year",
            "iidg_id": "first_structured_scope_iidg_id",
            "iidg_name": "first_structured_scope_iidg_name",
        })
    )
    first = core_first.merge(first_new, on="firm_id", how="left", validate="one_to_one")
    first["first_treat_year_supplemented"] = first[
        ["first_treat_year_core", "first_structured_scope_year"]
    ].min(axis=1, skipna=True)
    first["added_or_earlier_by_structured_scope"] = (
        first["first_structured_scope_year"].notna()
        & (
            first["first_treat_year_core"].isna()
            | first["first_structured_scope_year"].lt(first["first_treat_year_core"])
        )
    ).astype(int)
    first["eligible_as_clean_control_supplemented"] = np.where(
        first["first_treat_year_supplemented"].notna(), 0, first["eligible_as_clean_control"]
    ).astype(int)
    first.to_csv(OUT / "gao_firm_first_treat_supplemented.csv", index=False)

    # Policy audit.
    policy = (
        selected.groupby(["candidate_first_report_year", "iidg_id", "iidg_name", "mapping_type"], dropna=False)
        .agg(structured_candidates=("firm_id", "nunique"), already_in_core=("already_in_core_mapping", "sum"))
        .reset_index()
    )
    ext_counts = (
        extracted.groupby(["report_year", "iidg_id", "text_evidence_status"])
        .size().unstack(fill_value=0).reset_index()
        .rename(columns={"report_year": "candidate_first_report_year"})
    )
    policy = policy.merge(ext_counts, on=["candidate_first_report_year", "iidg_id"], how="left")
    accepted_counts = (
        accepted.groupby(["candidate_first_report_year", "iidg_id"]).size()
        .rename("newly_added").reset_index()
    )
    pending_counts = (
        pending.groupby(["candidate_first_report_year", "iidg_id"]).size()
        .rename("pending_manual_review").reset_index()
    )
    excluded_counts = (
        excluded.groupby(["candidate_first_report_year", "iidg_id"]).size()
        .rename("verified_excluded").reset_index()
    )
    policy = policy.merge(accepted_counts, on=["candidate_first_report_year", "iidg_id"], how="left")
    policy = policy.merge(pending_counts, on=["candidate_first_report_year", "iidg_id"], how="left")
    policy = policy.merge(excluded_counts, on=["candidate_first_report_year", "iidg_id"], how="left")
    policy[["newly_added", "pending_manual_review", "verified_excluded"]] = policy[
        ["newly_added", "pending_manual_review", "verified_excluded"]
    ].fillna(0).astype(int)
    policy.to_csv(OUT / "supplemented_policy_coverage_audit.csv", index=False)

    # Retention manifest. Keep all files supporting the four-cohort mapping,
    # including unresolved evidence rows, plus every newly scanned A report.
    reasons: dict[str, set[str]] = defaultdict(set)
    for row in extracted.itertuples(index=False):
        if row.source_path:
            reasons[str(row.source_path)].add("new_structured_scope_target")
    evidence = pd.read_csv(ALL_EVIDENCE, low_memory=False)
    evidence["official_first_applicable_year"] = pd.to_numeric(
        evidence["official_first_applicable_year"], errors="coerce"
    )
    evidence = evidence[evidence["official_first_applicable_year"].isin(COHORTS)]
    for row in evidence.itertuples(index=False):
        if isinstance(row.source_path, str) and row.source_path:
            if int(row.is_core) == 1:
                reasons[row.source_path].add("existing_core_evidence")
            elif int(row.is_expanded) == 1:
                reasons[row.source_path].add("existing_expanded_evidence")
            else:
                reasons[row.source_path].add("unresolved_or_negative_evidence")

    inv_by_path = inv.drop_duplicates("source_path").set_index("source_path", drop=False)
    keep_rows = []
    for source_path, reason_set in sorted(reasons.items()):
        path = Path(source_path)
        if source_path in inv_by_path.index:
            row = inv_by_path.loc[source_path]
            if isinstance(row, pd.DataFrame):
                row = row.iloc[0]
            keep_rows.append({
                "source_path": source_path,
                "file_name": row["file_name"],
                "firm_id": row["firm_id"],
                "report_year": row["report_year"],
                "file_size": row["file_size"],
                "inventory_sha256": row["sha256"],
                "keep_reason": "|".join(sorted(reason_set)),
                "file_exists": int(path.exists()),
            })
        else:
            keep_rows.append({
                "source_path": source_path,
                "file_name": path.name,
                "firm_id": np.nan,
                "report_year": np.nan,
                "file_size": path.stat().st_size if path.exists() else np.nan,
                "inventory_sha256": "",
                "keep_reason": "|".join(sorted(reason_set)),
                "file_exists": int(path.exists()),
            })
    keep = pd.DataFrame(keep_rows)
    keep.to_csv(OUT / "annual_report_keep_manifest.csv", index=False)

    keep_paths = set(keep["source_path"])
    not_required = inv[~inv["source_path"].isin(keep_paths)].copy()
    not_required["current_task_status"] = "not_required_after_targeted_extraction"
    not_required["deletion_note"] = "当前四批次IIDG映射不再需要；为可复现性优先转移或压缩归档，删除仍需用户单独确认。"
    not_required[[
        "source_path", "file_name", "file_size", "sha256", "firm_id", "report_year",
        "current_task_status", "deletion_note",
    ]].to_csv(OUT / "annual_reports_not_required_for_current_iidg.csv", index=False)

    cohort_summary = (
        first[first["first_treat_year_supplemented"].isin(COHORTS)]
        .groupby("first_treat_year_supplemented")
        .agg(
            supplemented_treated_firms=("firm_id", "nunique"),
            newly_or_earlier=("added_or_earlier_by_structured_scope", "sum"),
        )
        .reset_index()
    )
    cohort_summary.to_csv(OUT / "supplemented_first_treat_by_cohort.csv", index=False)

    keep_bytes = int(pd.to_numeric(keep["file_size"], errors="coerce").fillna(0).sum())
    removable_bytes = int(pd.to_numeric(not_required["file_size"], errors="coerce").fillna(0).sum())
    status_counts = extracted["text_evidence_status"].value_counts(dropna=False).to_dict()
    meta = {
        "candidate_A_pairs_in_four_cohorts": int(len(selected)),
        "already_in_core_pairs": int(selected["already_in_core_mapping"].sum()),
        "new_structured_scope_pairs_added": int(len(new_rows)),
        "pending_targeted_manual_review_pairs": int(len(pending)),
        "verified_nonapplicable_exclusions": int(len(excluded)),
        "new_or_earlier_treated_firms": int(first["added_or_earlier_by_structured_scope"].sum()),
        "supplemented_mapping_pairs": int(len(supplemented)),
        "reports_scanned_one_at_a_time": int(extracted[["firm_id", "report_year"]].drop_duplicates().shape[0]),
        "text_evidence_status_counts": {str(k): int(v) for k, v in status_counts.items()},
        "keep_manifest_files": int(len(keep)),
        "keep_manifest_bytes": keep_bytes,
        "not_required_files": int(len(not_required)),
        "not_required_bytes": removable_bytes,
        "raw_files_deleted": 0,
        "selection_uses_regression_results": False,
        "mapping_rule": "pre-specified SSE A-class exchange+board+P0207 industry rule from iidg_all_candidates_v2",
    }
    (OUT / "targeted_supplement_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    report = [
        "# IIDG遗漏补充与原始年报保留审计",
        "",
        "## 结论",
        "",
        f"原候选构造中Gao四批次涉及的上交所A类直接行业公司—IIDG候选共有{len(selected):,}个，其中{int(selected['already_in_core_mapping'].sum()):,}个已进入核心映射，{len(new_rows):,}个此前没有进入。",
        f"本轮先按预先固定的交易所、板块和P0207行业规则定位遗漏，再用首次适用年度年报主营业务信号交叉确认，最终补入{len(new_rows):,}个公司—IIDG组合，影响{int(first['added_or_earlier_by_structured_scope'].sum()):,}家公司的首次处理年度。{len(excluded):,}条行业代码边界记录经年报主营业务核对后排除，仍待人工核验{len(pending):,}条。没有使用回归结果或p值筛选。",
        "",
        "文本扫描只作为审计证据，不作为A类候选的选择条件；未出现指引名称不能解释为不适用。所有目标年报逐份读取并立即释放，未批量载入全文。",
        "",
        "## 文本证据状态",
        "",
    ]
    for key, value in sorted(status_counts.items()):
        report.append(f"- {key}: {int(value):,}")
    report.extend([
        "",
        "## 原始年报保留",
        "",
        f"- 当前四批次映射建议保留：{len(keep):,}份，约{keep_bytes / 1024**3:.2f} GiB。",
        f"- 当前任务不再需要：{len(not_required):,}份，约{removable_bytes / 1024**3:.2f} GiB。",
        "- 本轮未删除任何文件。`annual_reports_not_required_for_current_iidg.csv`仅说明当前任务不再需要；为保证可复现性，优先移动到外置硬盘或压缩归档。",
        "",
        "## 限制",
        "",
        "本轮只补上交所A类直接行业范围。上交所/深交所较宽的B类业务及深交所A类记录均维持既有文本/人工核验，不自动放宽。补充映射不是作者未公开人工名单的替代品，后续回归必须同时报告这一重建口径。",
    ])
    (OUT / "targeted_supplement_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print("\nCohort summary")
    print(cohort_summary.to_string(index=False))
    print("\nPolicy audit")
    print(policy.to_string(index=False))


if __name__ == "__main__":
    main()
