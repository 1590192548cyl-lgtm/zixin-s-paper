from pathlib import Path
import hashlib,json,resource,shutil
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
SRC=P/'four_cohort_G1_latest_recheck_20261028'
DATA=SRC/'latest_G1_analysis.dta'
CHECK=P/'G1_industry_download_check_20261103'
REPAIR=P/'G1_true_data_repair_20261103'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig')
assert not O.exists(),'Refuse to overwrite a previous final run'
O.mkdir()
state=json.loads((CHECK/'continuation_addendum.json').read_text())
assert state['previous_required_industry_download_resolved'] and not state['industry_partition_changed']
assert state['regressions_run']==0 and not state['formal_data_modified']
for name in ['input_integrity.csv','financial_sources_change_check.csv']:
    table=pd.read_csv(CHECK/name)
    if name=='input_integrity.csv':
        for r in table.itertuples():assert sha(r.path)==r.sha256_after,r.path
    else:
        for r in table.itertuples():assert sha(r.file)==r.current_sha256,r.file
before=pd.read_csv(REPAIR/'primary_input_manifest_before.csv')
assert sha(DATA)==before.loc[before.path.eq(str(DATA)),'sha256'].iloc[0]
snap=O/'input_snapshot';snap.mkdir()
shutil.copy2(DATA,snap/'latest_G1_analysis_original.dta')
assert sha(DATA)==sha(snap/'latest_G1_analysis_original.dta')
files=[DATA,CHECK/'continuation_addendum.json',CHECK/'industry_partition_equivalence.csv',
       CHECK/'current_G1_30_evidence_check_private.csv',CHECK/'all_170_prior_placeholder_evidence_private.csv',
       REPAIR/'continuation_status.json',REPAIR/'frozen_winsor_cutoffs.csv',REPAIR/'applied_repair_ledger.csv']
files += [SRC/n for n in ['G1_static_rerun_results.csv','G1_event_results.csv','G1_event_joint_tests.csv',
                          'latest_G1_estimation_sample.csv','latest_G1_event_sample.csv','latest_G1.ster','latest_G1_event.ster']]
save(pd.DataFrame([{'path':str(p),'bytes':p.stat().st_size,'sha256_before':sha(p)} for p in files]),'input_manifest_before.csv')
evidence=O/'audit_evidence';evidence.mkdir()
for origin,name in [(CHECK,'industry_download_check'),(REPAIR,'data_loss_audit')]:
    dest=evidence/name;dest.mkdir()
    for p in origin.iterdir():
        if p.is_file() and p.suffix in ['.csv','.json','.md']:
            shutil.copy2(p,dest/p.name)
            assert sha(p)==sha(dest/p.name)
d=pd.read_stata(DATA,convert_categoricals=False)
checks=[]
def check(name,value,passed):checks.append({'check':name,'value':value,'passed':bool(passed)})
check('all_original_rows_preserved',len(d),len(d)==26711)
check('unique_firm_stack_year',int(d.duplicated(['firm_id','stack_id','annual_report_year']).sum()),not d.duplicated(['firm_id','stack_id','annual_report_year']).any())
check('frozen_G1_sample_N',int(d.sample_g1.sum()),int(d.sample_g1.sum())==24659)
check('TreatPost_identity',int((d.TreatPost!=d.treated_in_stack*d.Post).sum()),(d.TreatPost==d.treated_in_stack*d.Post).all())
check('Post_identity',int((d.Post!=(d.event_time>=0)).sum()),(d.Post==(d.event_time>=0)).all())
check('control_year_alignment',int((d.annual_report_year!=d.syn_year-1).sum()),(d.annual_report_year==d.syn_year-1).all())
check('event_time_identity',int((d.event_time!=d.annual_report_year-d.cohort_report_year).sum()),(d.event_time==d.annual_report_year-d.cohort_report_year).all())
check('event_window','[-3,+2]',d.event_time.between(-3,2).all())
check('cohorts',str(sorted(d.cohort_report_year.unique())),sorted(d.cohort_report_year.unique())==[2013,2015,2016,2017])
s=d.loc[d.sample_g1.eq(1)]
check('complete_original_values',int(s[['SYN_CSRC_FAMILY_w_exact','TreatPost','Size_w_exact','MB_parent_w_exact','Lev_w_exact']].isna().sum().sum()),not s[['SYN_CSRC_FAMILY_w_exact','TreatPost','Size_w_exact','MB_parent_w_exact','Lev_w_exact']].isna().any().any())
check('original_firm_clusters',s.firm_id.nunique(),s.firm_id.nunique()==1770)
check('treated_firms',s.loc[s.treated_in_stack.eq(1),'firm_id'].nunique(),s.loc[s.treated_in_stack.eq(1),'firm_id'].nunique()==636)
support=s.groupby(['cohort_report_year','event_time','treated_in_stack']).size().reset_index(name='N')
check('cohort_event_role_support',len(support),len(support)==48 and support.N.min()>0)
check('original_30plus_week_rule',int(s.n_weeks_CSRC_FAMILY.lt(30).sum()),s.n_weeks_CSRC_FAMILY.ge(30).all())
cuts=pd.read_csv(REPAIR/'frozen_winsor_cutoffs.csv').set_index('variable')
for v in ['SYN_CSRC_FAMILY','Size','MB_parent','Lev']:
    ok=np.allclose(d[v].clip(cuts.loc[v,'p1'],cuts.loc[v,'p99']),d[v+'_w_exact'],atol=1e-12,rtol=0,equal_nan=True)
    check('unchanged_frozen_winsor_'+v,0 if ok else 1,ok)
save(pd.DataFrame(checks),'pre_run_design_checks.csv');save(support,'cohort_event_support.csv')
assert all(r['passed'] for r in checks)
shutil.copy2(W/'FIXED_RERUN_PLAN.md',O/'FIXED_RERUN_PLAN.md')
(O/'preparation_status.json').write_text(json.dumps({'stage':'READY_FOR_ONE_STATIC_AND_ONE_EVENT_RUN','regressions_run':0,
    'checks_passed':len(checks),'stack_N':26711,'G1_N':24659,'new_control_values':0,'industry_membership_changes':0,
    'Python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2},ensure_ascii=False,indent=2),encoding='utf-8')
print('PREPARED: 18 design checks; immutable snapshot; one static and one dynamic run authorized.',flush=True)
