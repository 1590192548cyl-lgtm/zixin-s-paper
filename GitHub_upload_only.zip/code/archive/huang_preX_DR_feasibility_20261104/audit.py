from pathlib import Path
from zipfile import ZipFile
import json,hashlib,sqlite3,tempfile,shutil,resource,time,sys,re,unicodedata
from collections import defaultdict
import pandas as pd,numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);BASE=W.parent;ROOT=Path('/Users/macpro/Desktop/毕业论文');RAW=ROOT/'控制变量';start=time.time();anchors=[2008,2010,2012];covs=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4']
sys.path.insert(0,str(BASE/'huang_replication_data_audit_20261103'));from audit_sources import xml_rows,norm
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def js(x,n):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(x,n):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def records(p):
 heads={}
 for sh,rn,v in xml_rows(p):
  if rn==1:heads[sh]=v
  if rn>=4:yield {n:v.get(c,'') for c,n in heads[sh].items()}
def num(x):
 try:f=float(x);return f if np.isfinite(f) else np.nan
 except:return np.nan
manifest=json.loads((BASE/'huang_transition_static_H8_20261104/outputs/protected_before.json').read_text());assert all(sha(r['path'])==r['sha256'] for r in manifest)
extras=list((BASE/'huang_transition_static_H8_20261104/outputs').glob('*.ster'))+[BASE/'huang_transition_static_H8_20261104/outputs'/x for x in ['static_results.csv','event_results.csv','joint_tests.csv','transition_H8_report.md']]
prior=json.loads((BASE/'huang_replication_data_audit_20261103/source_audit.json').read_text());sources={r['source']:Path(r['path']) for r in prior};integrity=[]
for sid in ['balance','duality','board','auditor']:
 r=next(r for r in prior if r['source']==sid);h=sha(r['path']);assert h==r['sha256'];integrity.append(dict(source=sid,path=r['path'],sha256=h,same_as_previous_full_source_audit=True));extras.append(Path(r['path']))
zp=next((RAW/'黄文复现补充').glob('十大*.zip'));cache=BASE/'gao_full_controls_work/gao_controls_staging.sqlite';extras += [zp,cache,W/'PLAN.md']
known={r['path'] for r in manifest};manifest += [dict(path=str(p),sha256=sha(p)) for p in extras if str(p) not in known];js(manifest,'protected_before.json');save(integrity,'source_integrity.csv')
src=BASE/'huang_week_calendar_repair_20261103/fixed_rerun/outputs/fixed_analysis.dta'
keys=pd.read_stata(src,columns=['firm_id','year','Treat','old_H8_sample'],convert_categoricals=False);univ=keys[keys.old_H8_sample.eq(1)][['firm_id','Treat']].drop_duplicates().set_index('firm_id');assert len(univ)==648;ids=set(univ.index)
# No post-period outcome values are used: discard outside <=2013 immediately on each chunk.
pieces=[]
for ch in pd.read_stata(src,columns=['firm_id','year','SYN','SYN_w','old_H8_sample'],chunksize=1000,convert_categoricals=False):pieces.append(ch[ch.year.le(2013)&ch.old_H8_sample.eq(1)].copy())
pre=pd.concat(pieces,ignore_index=True);assert pre.year.max()==2013
ipo=pd.read_stata(ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta',columns=['Stkcd','Listdt'],convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo=ipo.set_index('firm_id').Listdt;listing_year=ipo.str[:4].astype(int)
X={b:pd.DataFrame(index=pd.Index(sorted(ids),name='firm_id'),columns=covs,dtype=float) for b in anchors};sourcekeys=defaultdict(set)
con=sqlite3.connect('file:'+str(cache)+'?mode=ro',uri=True);sig=con.execute('SELECT signature FROM source_done WHERE source_id="balance"').fetchone()[0];st=sources['balance'].stat();assert sig==f'{st.st_size}:{st.st_mtime_ns}'
fin=pd.read_sql_query("SELECT firm_id,year,variable,value FROM num_values WHERE variable IN ('total_assets','total_liabilities') AND year IN (2008,2010,2012) AND conflict=0",con);con.close();fin.firm_id=fin.firm_id.astype(int);fin=fin[fin.firm_id.isin(ids)].pivot(index=['firm_id','year'],columns='variable',values='value')
for b,x in X.items():
 for f in ids:
  k=(f,b)
  if k in fin.index:
   a=fin.at[k,'total_assets'];l=fin.at[k,'total_liabilities']
   if np.isfinite(a) and a>0:x.at[f,'Size']=np.log(a)
   if np.isfinite(a) and a>0 and np.isfinite(l):x.at[f,'Lev']=l/a
  if ipo.get(f,'9999')<=f'{b}-12-31':x.at[f,'Age']=np.log(b-listing_year[f]+1)
for sid,field in [('duality','ConcurrentPosition'),('board','DirectorNumber')]:
 seen=set()
 for r in records(sources[sid]):
  dt=r.get('Enddate','');code=norm(r.get('Symbol',''))
  if not code.isdigit() or not dt.endswith('-12-31') or int(dt[:4]) not in anchors or int(code) not in ids:continue
  if sid=='board' and norm(r.get('StatisticalCaliber',''))!='1':continue
  f,b=int(code),int(dt[:4]);assert (f,b) not in seen;seen.add((f,b));v=num(r.get(field,''));sourcekeys[sid,b].add(f)
  if sid=='duality' and v in [0,1]:X[b].at[f,'Dual']=v
  if sid=='board' and v>0:X[b].at[f,'Board']=np.log(v)
 print('Read source',sid,flush=True)
# Original exact-name mapping, no new SOE/other controls.
bm=pd.read_csv(ROOT/'堆叠DID重跑/gao_full_controls/big4_name_mapping.csv');bignames=set(bm.normalized_name);aud=defaultdict(list)
for r in records(sources['auditor']):
 dt=r.get('EndDate','');code=norm(r.get('Symbol',''))
 if not code.isdigit() or not dt.endswith('-12-31') or int(dt[:4]) not in anchors or int(code) not in ids:continue
 if norm(r.get('Source',''))!='0' or norm(r.get('TerritoryForeignIdentity',''))!='1':continue
 name=re.sub(r'\s+','',unicodedata.normalize('NFKC',r.get('AccountingFirmName','')).strip())
 if name:aud[int(code),int(dt[:4])].append(name)
for (f,b),names in aud.items():X[b].at[f,'Big4']=int(any(n in bignames for n in names));sourcekeys['auditor',b].add(f)
print('Read source auditor',flush=True)
holders={};seenr=set();rawyears=set()
with ZipFile(zp) as z:
 for name in sorted(z.namelist()):
  if not name.endswith('.xlsx'):continue
  with tempfile.TemporaryFile(suffix='.xlsx') as tmp:
   with z.open(name) as stream:shutil.copyfileobj(stream,tmp,1048576)
   tmp.seek(0)
   for r in records(tmp):
    dt=r.get('Reptdt','');code=norm(r.get('Stkcd',''))
    if len(dt)>=4 and dt[:4].isdigit():rawyears.add(int(dt[:4]))
    if not code.isdigit() or not dt.endswith('-12-31') or int(dt[:4]) not in anchors or int(code) not in ids:continue
    f,b=int(code),int(dt[:4]);rank=num(r.get('S0306a',''));v=num(r.get('S0304a',''))
    if np.isfinite(rank) and int(rank)==rank and 1<=rank<=10:
     k=(f,b,int(rank));assert k not in seenr;seenr.add(k);a=holders.setdefault((f,b),np.full(10,np.nan));a[int(rank)-1]=v if 0<=v<=100 else np.nan
  print('Read shareholder fragment',name,flush=True)
for (f,b),a in holders.items():
 if np.isfinite(a[:5]).all() and a[0]>0:X[b].at[f,'Cent']=a[1:5].sum()/a[0]
 if np.isfinite(a).all():X[b].at[f,'Top10']=a.sum()/100
js(dict(shareholder_source_min_year=min(rawyears),shareholder_source_max_year=max(rawyears),anchor_years=anchors,baseline_derivation_is_audit_only=True,no_new_winsorization=True),'baseline_source_notes.json')
# Audit measurements only; no new analytical panel or weights are exported.
coverage=[];overlap=[];missing=[];joint=[];nn=[]
for b,x in X.items():
 listed=ipo.reindex(x.index).le(f'{b}-12-31');complete=x.notna().all(axis=1)
 for t in [0,1]:
  fs=univ.index[univ.Treat.eq(t)];joint.append(dict(anchor_year=b,Treat=t,universe_firms=len(fs),listed_by_anchor=int(listed.reindex(fs).sum()),not_yet_listed=int((~listed.reindex(fs)).sum()),all_eight_available=int(complete.reindex(fs).sum()),all_eight_available_and_listed=int((complete&listed).reindex(fs).sum())))
  for v in covs:
   good=x[v].notna().reindex(fs);coverage.append(dict(anchor_year=b,Treat=t,variable=v,universe=len(fs),nonmissing=int(good.sum()),missing=int((~good).sum()),missing_already_listed=int((~good&listed.reindex(fs)).sum()),missing_not_yet_listed=int((~good&~listed.reindex(fs)).sum())))
   for f in fs[~good]:missing.append(dict(anchor_year=b,firm_id=f,Treat=t,variable=v,listed_by_anchor=bool(listed[f]),IPODate=ipo[f],reason='not_yet_listed_at_anchor' if not listed[f] else 'missing_true_baseline_source_or_field',downloadable_gap=bool(listed[f])))
 for v in covs:
  a=x.loc[univ[univ.Treat.eq(1)].index,v].dropna();c=x.loc[univ[univ.Treat.eq(0)].index,v].dropna()
  if len(a)==0 or len(c)==0:overlap.append(dict(anchor_year=b,variable=v,n_treat=len(a),n_control=len(c),SMD=np.nan,note='insufficient source coverage; not replaced with a smaller control set'));continue
  sd=np.sqrt((a.var()+c.var())/2);lo=max(a.min(),c.min());hi=min(a.max(),c.max());overlap.append(dict(anchor_year=b,variable=v,n_treat=len(a),n_control=len(c),mean_treat=a.mean(),mean_control=c.mean(),SMD=(a.mean()-c.mean())/sd if sd>0 else np.nan,treat_p05=a.quantile(.05),treat_p50=a.median(),treat_p95=a.quantile(.95),control_p05=c.quantile(.05),control_p50=c.median(),control_p95=c.quantile(.95),shared_minmax_low=lo,shared_minmax_high=hi,treated_outside_control_range=((a<c.min())|(a>c.max())).mean(),treated_outside_control_p05_p95=((a<c.quantile(.05))|(a>c.quantile(.95))).mean(),note='available observations only; not proof of joint overlap'))
 # Descriptive cross-group proximity, never a matching assignment or weight.
 z=x[complete&listed];info=univ.reindex(z.index).Treat
 if len(z)>1 and info.nunique()==2:
  sd=z.std().replace(0,1);a=((z-z.mean())/sd).to_numpy();dist=np.sqrt(((a[:,None,:]-a[None,:,:])**2).sum(axis=2)/len(covs));np.fill_diagonal(dist,np.inf);t=info.to_numpy()
  for tv in [0,1]:
   cross=dist[t==tv][:,t!=tv].min(axis=1);within=dist[t==tv][:,t==tv].min(axis=1);nn.append(dict(anchor_year=b,Treat=tv,complete_listed_firms=int((t==tv).sum()),cross_group_nearest_p50=float(np.median(cross)),cross_group_nearest_p90=float(np.quantile(cross,.9)),within_group_nearest_p50=float(np.median(within)),note='standardized RMS distance over all eight; no match, weights or trimming'))
 else:nn.append(dict(anchor_year=b,Treat='both',complete_listed_firms=len(z),note='joint eight-variable diagnosis unavailable; no PS estimated on partial controls'))
save(coverage,'baseline_coverage_by_variable.csv');save(joint,'baseline_joint_coverage.csv');save(overlap,'baseline_distribution_overlap.csv');save(nn,'joint_covariate_proximity.csv');save(missing,'missing_baseline_keys_private.csv')
# Associations with PRE outcomes only. No p-values, post outcomes, fitting or model selection.
pivot=pre.pivot(index='firm_id',columns='year',values='SYN_w');rawpivot=pre.pivot(index='firm_id',columns='year',values='SYN');corr=[];strata=[]
for b,pairs in [(2008,[(2009,2010),(2010,2011),(2011,2012),(2012,2013),(2009,2013)]),(2010,[(2011,2012),(2012,2013),(2011,2013)])]:
 for y0,y1 in pairs:
  delta=(pivot[y1]-pivot[y0]).dropna();rawdelta=(rawpivot[y1]-rawpivot[y0]).reindex(delta.index)
  for v in covs:
   g=pd.DataFrame({'X':X[b][v],'change':delta,'raw_change':rawdelta,'Treat':univ.Treat}).dropna(subset=['X','change']);g=g[ipo.reindex(g.index).le(f'{b}-12-31')]
   for label,z in [('all',g),('treated',g[g.Treat.eq(1)]),('control',g[g.Treat.eq(0)])]:
    varying=len(z)>2 and z.X.nunique()>1 and z.change.nunique()>1
    corr.append(dict(anchor_year=b,start_SYN_year=y0,end_SYN_year=y1,variable=v,group=label,N=len(z),pearson=z.X.corr(z.change) if varying else np.nan,spearman=z.X.rank().corr(z.change.rank()) if varying else np.nan,raw_SYN_pearson=z.X.corr(z.raw_change) if varying else np.nan,note='descriptive association only; variable-specific availability, not an estimation sample'))
   if len(g)>0 and g.X.nunique()>1:
    if g.X.nunique()<=6:g['stratum']=g.X.map(lambda x:f'value={x:.8g}')
    else:g['stratum']=pd.qcut(g.X,3,duplicates='drop').astype(str)
    for band,z in g.groupby('stratum'):
     a=z[z.Treat.eq(1)].change;c=z[z.Treat.eq(0)].change;strata.append(dict(anchor_year=b,start_SYN_year=y0,end_SYN_year=y1,variable=v,stratum=band,n_treat=len(a),n_control=len(c),mean_change_treat=a.mean(),mean_change_control=c.mean(),unadjusted_gap=a.mean()-c.mean() if len(a) and len(c) else np.nan,note='pre-only descriptive bins; not weighted DID, no p-values'))
save(corr,'pre_SYN_change_associations.csv');save(strata,'pre_SYN_change_descriptive_strata.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);js(after,'protected_after.json');js(dict(main_regressions=0,post_policy_effects_estimated=0,post2013_SYN_used=False,PS_models=0,weights_computed=0,DRDID_models=0,new_analysis_DTA=0,formal_sample_changed=False,formal_controls_changed=False,universe_firms=648,pre_outcome_min=int(pre.year.min()),pre_outcome_max=int(pre.year.max()),protected_files=len(manifest),peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'execution_audit.json')
print(pd.DataFrame(joint).to_string(index=False));print(pd.DataFrame(coverage).query('anchor_year==2008').to_string(index=False));print((O/'execution_audit.json').read_text())
