"""Separate audit ledgers only; no import of analytical data, no recoding or regression."""
import csv,hashlib,json,resource
from collections import Counter
from pathlib import Path
O=Path(__file__).resolve().parent
P=Path('/Users/macpro/Documents/New project/duality_2008_name_verification_20261109')
old=json.loads((P/'decisions.json').read_text())
new=json.loads((O/'followup_decisions.json').read_text())
assert len(new)==11 and all(r['firm_id']!='601607' for r in new)
assert {r['firm_id'] for r in new}=={r['firm_id'] for r in old if r['decision']=='待核验'}
notices=json.loads((O/'selected_notice_retrieval.json').read_text())
byid={r['id']:r for r in notices};assert len(notices)==44 and all(r['status']=='retrieved' for r in notices)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def csvout(name,rows):
 with (O/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
ledger=[]
for r in new:
 sources=[byid[x] for x in r['source_ids']]
 assert all(s['firm_id']==r['firm_id'] for s in sources)
 ledger.append(dict(股票代码=r['firm_id'],公司简称=r['company'],截止日期='2008-12-31',
  原结论='待核验',本轮类别=r['category'],本轮结论=r['decision'],
  董事长或代理董事长=r['chairman'],总经理或经营履职安排=r['manager'],
  核验事实=r['finding'],证据页码=r['pages'],
  公告原文链接=';'.join(s['url'] for s in sources),
  原文文件路径=';'.join(s['pdf_path'] for s in sources),
  尚需证据或口径事项=r['remaining'],正式变量回填=False))
csvout('剩余11家任免代理续核.csv',ledger)
csvout('新增2家确认不兼任.csv',[r for r in ledger if r['本轮类别']=='新增确认不兼任'])
csvout('9家仍待核验及具体缺口.csv',[r for r in ledger if r['本轮类别']!='新增确认不兼任'])
newby={r['股票代码']:r for r in ledger}
allrows=[]
for r in old:
 x=newby.get(r['firm_id'])
 allrows.append(dict(股票代码=r['firm_id'],公司简称=r['company'],截止日期='2008-12-31',
  前轮结论=r['decision'],最新严格结论=x['本轮结论'] if x else r['decision'],
  本轮证据状态=x['本轮类别'] if x else '沿用前轮已确认结论，不重算',
  董事长或代理=x['董事长或代理董事长'] if x else r['chairman_at_cutoff'],
  经营负责人或安排=x['总经理或经营履职安排'] if x else r['manager_at_cutoff'],
  正式分析数据未修改=True))
csvout('18家公司核验台账_第二版.csv',allrows)
count=Counter(r['本轮类别'] for r in ledger)
manifest=[]
for r in notices:
 p=Path(r['pdf_path']); h=sha(p); assert h==r['sha256']
 manifest.append(dict(firm_id=r['firm_id'],notice_id=r['id'],title=r['title'],url=r['url'],pdf_path=str(p),bytes=p.stat().st_size,sha256=h))
csvout('44份定点公告来源及校验.csv',manifest)
before=json.loads((O/'protected_before.json').read_text())
after=[dict(path=r['path'],sha256=sha(r['path'])) for r in before]
assert before==after,'Protected source or prior audit changed'
(O/'protected_after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2))
summary=json.loads((O/'query_summary.json').read_text());assert len(summary)==11 and all(r['complete'] for r in summary)
evidence_total=sum(r['records'] for r in summary)
audit=dict(firms_reviewed=11,notice_files_reviewed=44,new_confirmed_not_dual=2,
 new_confirmed_dual=0,remaining_not_binary_adjudicated=9,
 prior_confirmed_not_dual_preserved=7,cumulative_confirmed_not_dual=9,cumulative_unresolved=9,
 categories=dict(count),metadata_company_announcement_keys=evidence_total,date_windows_complete_for_requested_ranges=True,
 metadata_pagination_issue='Detected repeated pages; switched to bounded date intervals and deduplicated announcement IDs. Legacy paginated files not used to infer absence.',
 protected_paths=len(before),protected_changes=[],original_sources_unchanged=True,prior_results_unchanged=True,
 deferred_601607=True,no_formal_Dual_variable_created=True,no_imputation=True,no_merge=True,
 no_new_DTA=True,no_SYN_recalculation=True,no_regressions=True,no_sample_changes=True,
 evidence_scope='Targeted historical notices only, not all annual reports. Lack of an appointment in this search is not proof no appointment exists.',
 save_process_peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,
 notice_process_peak_memory_MB=json.loads((O/'notice_runtime.json').read_text())['peak_memory_MB'])
(O/'execution_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False,indent=2))
