from pathlib import Path
import datetime,json,resource,subprocess,time

W=Path(__file__).resolve().parent;O=W/'outputs'
status=O/'execution_once_status.json'
with status.open('x',encoding='utf-8') as f:
    json.dump({'stage':'STARTING','formal_run_authorized':'one static and one event model','launch_attempts':1,
               'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()},f,ensure_ascii=False,indent=2)
start=time.monotonic()
cmd=['/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp','-b','do','run_once.do']
p=subprocess.Popen(cmd,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
print(json.dumps({'stage':'RUNNING','pid':p.pid,'single_core':True},ensure_ascii=False),flush=True)
while p.poll() is None:
    if time.monotonic()-start>600:
        print('Hard timeout: notifying and stopping the audit process; no retry.',flush=True)
        p.terminate();break
    time.sleep(.25)
stdout,stderr=p.communicate(timeout=30)
log=O/'final_fixed_rerun.log'
body=log.read_text(encoding='utf-8',errors='replace') if log.exists() else ''
complete='\nFINAL_FIXED_RERUN_COMPLETE\n' in body
record={'stage':'COMPLETED' if p.returncode==0 and complete else 'FAILED_NO_AUTOMATIC_RETRY',
        'exit_code':p.returncode,'launch_attempts':1,'elapsed_seconds':time.monotonic()-start,
        'static_completion_markers':body.count('\nSTATIC_ONE_DONE\n'),
        'event_completion_markers':body.count('\nEVENT_ONE_DONE\n'),
        'Stata_child_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss/1024**2,
        'stdout':stdout[-2000:],'stderr':stderr[-2000:]}
status.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2),flush=True)
assert record['stage']=='COMPLETED', 'Do not rerun: inspect the existing log and completed model markers.'
