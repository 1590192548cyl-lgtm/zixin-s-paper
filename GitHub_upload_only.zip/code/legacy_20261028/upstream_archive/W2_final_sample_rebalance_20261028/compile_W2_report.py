from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

WORK=Path('/Users/macpro/Documents/New project/w2_final_sample_rebalance_20261028_work')
O=WORK/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
PREV=P/'static_model_correction_20261028'


def sha(f):
    h=hashlib.sha256()
    with Path(f).open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(f,**kwargs):return pd.read_csv(O/f,**kwargs)
def save(d,f):d.to_csv(O/f,index=False,encoding='utf-8-sig')
def md(d,formats=None):
    formats=formats or {}
    lines=['|'+'|'.join(d.columns)+'|','|'+'|'.join(['---']*len(d.columns))+'|']
    for _,r in d.iterrows():lines.append('|'+'|'.join(formats[c](r[c]) if c in formats else str(r[c]) for c in d.columns)+'|')
    return '\n'.join(lines)


log=(O/'W2_final_rebalance.log').read_text()
assert 'FINAL_SAMPLE_W2_REBALANCE_COMPLETE' in log
assert not any(x.startswith('r(') for x in log.splitlines())
summary=json.loads((O/'pre_regression_summary.json').read_text())
new=read('W2_fixed_new_runs.csv')
keys=read('final_sample_keys_frozen_before_weights.csv',dtype={'firm_id':str})
actual=read('actual_estimation_sample.csv',dtype={'firm_id':str})
z=keys.merge(actual,on=['audit_row_id','firm_id','stack_id','syn_year','cohort_report_year','event_time','treated_in_stack'],how='outer',validate='one_to_one',indicator=True)
assert z._merge.eq('both').all() and z.es_old.eq(1).all() and z.es_new.eq(1).all()
assert len(z)==summary['final_rows'] and new.N.eq(len(z)).all()
assert new.singleton_N.eq(0).all()
assert sha(O/'final_sample_keys_frozen_before_weights.csv')==summary['sample_key_sha256_before_weights']

original=pd.read_csv(PREV/'static_original_vs_corrected.csv')
comparison=[]
for model,label in [('original_W2','原始W2（归档）'),('corrected_W2','上轮客观纠错、旧权重')]:
    r=original.loc[original.model.eq(model)].iloc[0]
    comparison.append({'model':model,'label':label,'result_source':'archived_prior_verified_run','TreatPost':r.coefficient,'SE':r.SE,'t':r.t,'p':r.p,
                       'CI_low':r.CI_low,'CI_high':r.CI_high,'N':int(r.N),'clusters':int(r.clusters),'treated_firms':int(r.treated_firms),'control_firms':int(r.control_firms),'cohorts':int(r.cohorts)})
for _,r in new.iterrows():
    label='最终样本、原权重' if 'old_weights' in r.model else '最终样本、重算权重（本轮W2）'
    comparison.append({'model':r.model,'label':label,'result_source':'current_fixed_run','TreatPost':r.TreatPost,'SE':r.SE,'t':r.t,'p':r.p,
                       'CI_low':r.CI_low,'CI_high':r.CI_high,'N':int(r.N),'clusters':int(r.clusters),'treated_firms':int(r.treated_firms),'control_firms':int(r.control_firms),'cohorts':int(r.cohorts)})
c=pd.DataFrame(comparison)
save(c,'W2_original_vs_final_rebalanced.csv')
prior=c.loc[c.model.eq('corrected_W2')].iloc[0]
old=c.loc[c.model.eq('W2_final_sample_old_weights')].iloc[0]
main=c.loc[c.model.eq('W2_final_sample_rebalanced')].iloc[0]
deltas=[]
for label,left,right in [('sample_change_only',prior,old),('weight_change_same_sample',old,main),('total_vs_previous_corrected',prior,main)]:
    row={'comparison':label}
    for v in ['TreatPost','SE','p','N','clusters','treated_firms']:
        row['from_'+v]=left[v];row['to_'+v]=right[v];row['delta_'+v]=right[v]-left[v]
    deltas.append(row)
save(pd.DataFrame(deltas),'W2_sample_vs_weight_decomposition.csv')

final=pd.read_stata(O/'W2_final_sample_rebalanced.dta',convert_categoricals=False)
source=pd.read_stata(PREV/'static_eligible_stack.dta',convert_categoricals=False)
check=final.merge(source,on=['audit_row_id','firm_id','stack_id','syn_year'],how='left',validate='one_to_one',suffixes=('','_source'),indicator=True)
assert check._merge.eq('both').all()
frozen=['SYN','SYN_w_Gao','TreatPost','treated_in_stack','event_time','cohort_report_year','cohort_effective_syn_year','control_fiscal_year',
        'firm_stack_id','cohort_year_id','firm_cluster_id','ebal_weight']+'Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w'.split()
value_checks=[]
for v in frozen:
    changed=~np.isclose(check[v],check[v+'_source'],atol=0,rtol=0,equal_nan=True)
    assert not changed.any(),v
    value_checks.append({'check':'frozen_column_'+v,'checked_rows':len(check),'disagreements':int(changed.sum())})
value_checks += [
    {'check':'final_keys_match_actual_e_sample_both_runs','checked_rows':len(z),'disagreements':int(z._merge.ne('both').sum())},
    {'check':'final_key_file_unchanged_after_weighting','checked_rows':len(keys),'disagreements':0},
    {'check':'all_five_cohorts_retained','checked_rows':5,'disagreements':int(new.cohorts.ne(5).sum())}]

weights=read('entropy_weights_final_sample.csv',dtype={'firm_id':str})
bal=read('baseline_balance_by_variable.csv')
diag=read('weight_diagnostics.csv')
pre=final.loc[final.event_time.eq(-1)].copy()
assert len(pre)==summary['firm_stacks']
assert not pre.duplicated(['firm_id','stack_id']).any()
assert len(pre[['firm_id','stack_id']].merge(weights[['firm_id','stack_id']],on=['firm_id','stack_id'],how='outer',indicator=True).query("_merge!='both'"))==0
assert (bal.query("weighting=='new_weights'").abs_SMD<1e-5).all()
assert diag.query("weighting=='new_weights'").optimizer_success.eq(1).all()
value_checks.append({'check':'11_baseline_covariates_balanced_actual_e_sample','checked_rows':55,'disagreements':int(bal.query("weighting=='new_weights'").abs_SMD.ge(1e-5).sum())})
save(pd.DataFrame(value_checks),'final_sample_and_value_verification.csv')

manifest=read('input_manifest.csv')
manifest['sha256_after']=[sha(f) for f in manifest.path]
manifest['unchanged']=manifest.sha256_before.eq(manifest.sha256_after)
assert manifest.unchanged.all()
save(manifest,'input_integrity_after_run.csv')

flow=read('sample_attrition.csv')
sel=read('sample_selection_audit.csv',dtype={'firm_id':str})
excluded=sel.loc[sel.final_sample.eq(0)]
reasons=excluded.groupby('selection_reason').agg(rows=('audit_row_id','size'),firms=('firm_id','nunique'),prior_W2_rows=('was_prior_W2_sample','sum')).reset_index()
save(reasons,'sample_exclusion_summary.csv')
group_counts=pre.groupby(['cohort_report_year','treated_in_stack']).size().unstack(fill_value=0).reset_index()
group_counts.columns=['cohort','control_firm_stacks','treated_firm_stacks']
save(group_counts,'final_baseline_firm_counts.csv')

# Observe Stdret balance without adding it to the eleven entropy constraints.
stdret=[]
for co,g in pre.groupby('cohort_report_year'):
    t=g.loc[g.treated_in_stack.eq(1)]; cc=g.loc[g.treated_in_stack.eq(0)]
    for mode,weight in [('old_weights','ebal_weight'),('new_weights','new_weight')]:
        x=t.Stdret_w.to_numpy(); y=cc.Stdret_w.to_numpy(); wt=t[weight].to_numpy(); wc=cc[weight].to_numpy()
        def sd(a,w):return np.sqrt(np.dot(w,(a-np.average(a,weights=w))**2)/(w.sum()-(w@w)/w.sum()))
        mt=np.average(x,weights=wt); mc=np.average(y,weights=wc)
        stdret.append({'cohort':int(co),'weighting':mode,'variable':'Stdret_w','included_in_entropy_constraints':False,'SMD':(mt-mc)/np.sqrt((sd(x,wt)**2+sd(y,wc)**2)/2)})
save(pd.DataFrame(stdret),'Stdret_unconstrained_balance.csv')

provenance=read('entropy_algorithm_provenance.csv')
legacy=Path(provenance.source_path.iloc[0]).read_text()
tree=ast.parse(legacy)
snippets=[]
for n in tree.body:
    if isinstance(n,ast.FunctionDef) and n.name in {'entropy_weights','weighted_sd','smd'}:
        txt=ast.get_source_segment(legacy,n)
        assert hashlib.sha256(txt.encode()).hexdigest()==provenance.loc[provenance.function.eq(n.name),'exact_function_sha256'].iloc[0]
        snippets.append(txt)
(O/'entropy_algorithm_exact_reference.txt').write_text('\n\n'.join(snippets)+'\n',encoding='utf-8')

four=lambda x:f'{float(x):.4f}'
integer=lambda x:f'{int(x):,}'
ct=c[['label','TreatPost','SE','p','N','clusters','treated_firms','cohorts']].copy()
ct.columns=['模型','TreatPost','SE','p','N','公司簇','处理公司','批次']
table=md(ct,{'TreatPost':four,'SE':four,'p':four,'N':integer,'公司簇':integer,'处理公司':integer,'批次':integer})
bs=read('baseline_balance_summary.csv')
bt=bs.loc[bs.weighting.isin(['old_weights','new_weights'])].pivot(index='cohort',columns='weighting',values='max_abs_SMD').reset_index()
nd=diag.query("weighting=='new_weights'")
bt=bt.merge(nd[['cohort','treated_N','control_N','control_ESS','ESS_over_control_N','max_control_weight','original_warning_rule_triggered']],on='cohort')
save(bt,'balance_and_weight_summary.csv')
bdisplay=bt[['cohort','treated_N','control_N','old_weights','new_weights','control_ESS','ESS_over_control_N']].copy()
bdisplay.columns=['批次','处理','控制','原权重最大绝对SMD','新权重最大绝对SMD','控制ESS','ESS比例']
btable=md(bdisplay,{'批次':lambda x:str(int(x)),'处理':integer,'控制':integer,'原权重最大绝对SMD':four,'新权重最大绝对SMD':lambda x:f'{float(x):.2e}','控制ESS':lambda x:f'{float(x):.2f}','ESS比例':lambda x:f'{100*float(x):.2f}%'})
report=f'''# W2最终样本先行与原算法熵平衡修正报告

## Material Passport

- 日期：2026-10-28。
- 执行状态：固定样本构造、原函数求解和两次静态W2均已实际运行；估计样本与冻结清单完全一致。
- 原则：原始及历史结果只读；未新增控制、删除cohort或改变Treat、政策时点、SYN、缩尾、FE及公司聚类。
- 方案在求新权重和回归前保存为PRE_ANALYSIS_PLAN.md；这是既有研究的公开纠错，不是历史预注册。
- 本轮仅新估计“同一最终样本+原权重”和“同一最终样本+重算权重”两次W2；未运行事件研究或其他规格。

## 一、核心结果

{table}

本轮W2：TreatPost={main.TreatPost:.7f}，聚类SE={main.SE:.7f}，t={main.t:.7f}，p={main.p:.7f}；95%CI=[{main.CI_low:.7f}, {main.CI_high:.7f}]。N={int(main.N):,}，公司簇={int(main.clusters):,}，处理公司={int(main.treated_firms)}，控制公司={int(main.control_firms):,}，五批次均保留。未达到10%、5%或1%显著。

在完全相同观测上，重新配重使系数变化{main.TreatPost-old.TreatPost:+.7f}（更接近0），SE变化{main.SE-old.SE:+.7f}。相对上轮纠错结果，总系数变化{main.TreatPost-prior.TreatPost:+.7f}，其中最终样本变化贡献{old.TreatPost-prior.TreatPost:+.7f}，同样本权重变化贡献{main.TreatPost-old.TreatPost:+.7f}。这是固定对照分解，不是根据p值择优。

纠正配重顺序恢复了已指定11项基期协变量的均值平衡，没有恢复显著的静态平均效应。置信区间仍同时包含负效应和0附近或小幅正效应，不能据此证明政策必然无效。

## 二、先确定最终样本

继承上一轮客观合格stack的33,658行，不重做政策资格筛选。

1. 要求SYN_w_Gao、TreatPost和全部12项W2控制有限且非缺失，保留27,953行；这一阶段未使用原权重匹配状态决定是否可用。
2. 公司—stack必须在上述可用记录中有完整event_time=-1基期。缺少完整基期的公司—stack不进入本次权重及回归，剩23,671行。该规则不是要求六期完全平衡，也不按SYN大小排除。
3. 提前机械处理两组FE的singleton并闭合基期要求，移除1条singleton；最终冻结23,670行。Stata最终没有再删除任何观测。

相对上轮实际W2样本25,553行，少1,883行；处理公司由409变为341。样本对象因此收窄至“有完整基期和年度W2数据”的公司，不能将新旧全样本系数差全部称为权重效应。

最终有4,215个公司—stack，341家不同处理公司、1,262家不同公司；同一家公司可在不同stack承担不同角色，因此处理/控制公司数不直接相加。

逐行保留sample_selection_audit.csv、新排除清单new_sample_exclusions.csv和相对上轮的excluded_from_prior_W2.csv；没有删除任何原始文件。最终键清单在求权重前冻结，SHA256={summary['sample_key_sha256_before_weights']}。

## 三、原算法与约束保持一致

W2控制：Size_w、Lev_w、MB_w、Age_w、Turnover_w、Stdret_w、ROA_w、Growth_w、CFO_w、Loss、Tophold_w、Instihold_w。配重约束仍是其中不含Stdret_w的原11项，顺序与原代码一致。

在每个cohort内部，使用最终样本-1期的11项协变量，以处理组均值为目标；处理公司权重1，控制权重和等于该cohort处理公司数，权重在公司—stack内固定。Stdret_w只作为原W2回归控制，没有被临时加入配重约束。

从原build_entropy_weights.py仅提取entropy_weights、weighted_sd、smd函数的原始AST，不执行原文件顶层ETL。原BFGS、零初始值、梯度阈值1e-7、最多5,000次迭代和原线搜索均不变；函数文本SHA256另存，精确原文保存为entropy_algorithm_exact_reference.txt。未启用原脚本的六变量后备分支，未改矩数、截尾或优化器。

五个cohort全部成功收敛；权重全部正且有限；新权重的基期处理/控制权重和相等。权重求解只接收11项政策前协变量与处理身份，不接收SYN数值、政策后协变量或回归结果。样本非缺失筛选本身仍会改变研究对象，不将其解释为完全消除选择问题。

## 四、实际回归基期的平衡及权重质量

{btable}

55项cohort×协变量的一阶矩约束全部满足数值精度；最大|SMD|={summary['new_weight_max_abs_SMD']:.9g}。这次平衡核验用的-1期记录确实全部进入最终e(sample)，没有再次以Stdret缺失筛掉配重目标样本。

2017批次控制ESS比例为28.95%，略低于原30%预警线；已报告但未删批次或调整权重。最大控制权重约1.636，未触发原最大权重20的警告。ESS不是原始公司簇数，不能混写。

均值平衡只针对指定11项，不能宣称所有分布、高阶矩、Stdret_w或未观测因素都已平衡；Stdret单独的观察性平衡表存于Stdret_unconstrained_balance.csv，没有据此追加约束。

## 五、固定模型与核验

模型仍为reghdfe SYN_w_Gao TreatPost + 原12控制，absorb(firm_stack_id cohort_year_id)，vce(cluster firm_cluster_id)，按新权重进行pweight估计。财务年度保持syn_year-1，Loss保持原二元值。

两次实际e(sample)与配重前冻结的23,670行完全相等，singleton追加删除为0；公司聚类与原始股票代码一一对应。SYN、全部控制、TreatPost、事件时间、批次、固定效应、原权重等25个冻结字段逐值保持不变。原始输入文件运行前后指纹全部一致。

原始W2和上轮W2直接读取此前已经复现验证的归档结果，没有重新计算旧回归。两次本轮估计和全部控制系数均保存Stata日志、ster和CSV。

## 六、解释边界与停止点

本轮修正的是“先配重、后因完整控制筛样本”的顺序问题。修正后的权重实现了指定目标，但平均TreatPost仍不显著，说明不能继续把原先不显著主要归因于这一配重顺序。

没有加入任何2021有效年度新批次，仍为2015—2019五个报告年度批次。新样本与新权重不同于此前事件研究，本轮没有重跑动态模型，因此不能沿用旧政策前联合p值或旧+2期显著性为这次新W2背书。

仍存在可观测变量之外的识别限制、缺失样本选择及stacked聚合目标问题。本轮不自动改权重方法、控制组合或政策窗；没有按p值排除cohort或公司。固定静态比较完成，到此停止。

## 七、统计解释核验（11/11检查）

|检查|结论或范围|
|---|---|
|辛普森悖论|不新估计批次异质性，不用分组符号删批次|
|生态谬误|结果限定公司面板，不推断个别投资者机制|
|选择偏误|基期和年度完整样本规则及损失已披露，不能代表全部上市公司|
|碰撞变量|保留固定控制，不声称重新验证其全部因果角色|
|基率忽略|非分类问题，不适用|
|均值回归|未按SYN大小或回归残差筛选|
|幸存者偏误|不要求六期完整，不新增ST、退市或IPO剔除|
|多重检验|仅两次新静态W2且全部报告，名义p不替代整项历史探索校正|
|分析路径选择|样本规则先于配重和系数，五批次不变，无结果导向调参|
|相关与因果|均值平衡和不显著系数均不能证明因果识别成立|
|反向因果|政策时序保持，适用资格及同期冲击风险仍需制度证据|

## 八、主要交付

- W2_original_vs_final_rebalanced.csv：原始、上轮、同最终样本旧权重、新权重四行对照。
- W2_sample_vs_weight_decomposition.csv：样本变化与同样本权重变化。
- balance_and_weight_summary.csv、baseline_balance_by_variable.csv、weight_diagnostics.csv：55项约束与ESS。
- final_sample_keys_frozen_before_weights.csv、sample_selection_audit.csv、new_sample_exclusions.csv：样本与逐行原因。
- W2_final_sample_rebalanced.dta、entropy_weights_final_sample.csv/dta：新分析数据及新权重。
- W2_final_rebalance.log、actual_estimation_sample.csv、final_sample_and_value_verification.csv：命令和实际样本核验。
- input_integrity_after_run.csv、entropy_algorithm_provenance.csv、code/：原文件保护及算法溯源。
'''
(O/'W2_final_sample_rebalance_report.md').write_text(report,encoding='utf-8')
print(c[['label','TreatPost','SE','p','N','clusters']].to_string(index=False))
print('All frozen fields unchanged:',all(r['disagreements']==0 for r in value_checks))
print('All source hashes unchanged:',manifest.unchanged.all())
print('Final sample exact:',len(z),'baseline firm-stacks:',len(pre))
print(reasons.to_string(index=False))
