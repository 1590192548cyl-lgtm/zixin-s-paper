version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/w2_final_sample_rebalance_20261028_work/outputs"
log using "`out'/W2_final_rebalance.log", text replace
use "`out'/W2_final_sample_rebalanced.dta", clear
isid firm_id stack_id syn_year
assert inrange(event_time,-3,2)
assert control_fiscal_year==syn_year-1
assert TreatPost==(treated_in_stack==1 & event_time>=0)
assert new_weight>0 & !missing(new_weight)
bysort firm_id stack_id: assert new_weight==new_weight[1]
local x "Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w"
local fixedN=_N
local groups "2015 2016 2017 2018 2019"
levelsof cohort_report_year, local(actualgroups)
assert "`actualgroups'"=="`groups'"
egen byte missing_model=rowmiss(SYN_w_Gao TreatPost `x')
assert missing_model==0

tempname mh ch
tempfile mres cres
postfile `mh' str30 model str20 weight_source long N clusters treated_firms control_firms cohorts singleton_N double TreatPost SE t p CI_low CI_high df_r using `mres', replace
postfile `ch' str30 model str24 term double coefficient SE t p CI_low CI_high using `cres', replace
foreach kind in old new {
    local weight "ebal_weight"
    local model "W2_final_sample_old_weights"
    if "`kind'"=="new" {
        local weight "new_weight"
        local model "W2_final_sample_rebalanced"
    }
    reghdfe SYN_w_Gao TreatPost `x' [pw=`weight'], absorb(firm_stack_id cohort_year_id) vce(cluster firm_cluster_id)
    assert e(N)==`fixedN'
    assert _se[TreatPost]>0 & !missing(_se[TreatPost])
    gen byte es_`kind'=e(sample)
    assert es_`kind'==1
    local n=e(N)
    local nc=e(N_clust)
    local df=e(df_r)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local tv=`b'/`se'
    local pv=2*ttail(`df',abs(`tv'))
    local crit=invttail(`df',.025)
    tempvar ft fc fg
    egen byte `ft'=tag(firm_id) if e(sample)&treated_in_stack==1
    egen byte `fc'=tag(firm_id) if e(sample)&treated_in_stack==0
    egen byte `fg'=tag(cohort_report_year) if e(sample)
    quietly count if `ft'==1
    local nt=r(N)
    quietly count if `fc'==1
    local n0=r(N)
    quietly count if `fg'==1
    local ng=r(N)
    assert `ng'==5
    post `mh' ("`model'") ("`weight'") (`n') (`nc') (`nt') (`n0') (`ng') (`fixedN'-`n') (`b') (`se') (`tv') (`pv') (`b'-`crit'*`se') (`b'+`crit'*`se') (`df')
    foreach term in TreatPost `x' {
        local b=_b[`term']
        local se=_se[`term']
        local tv=`b'/`se'
        local pv=2*ttail(`df',abs(`tv'))
        post `ch' ("`model'") ("`term'") (`b') (`se') (`tv') (`pv') (`b'-`crit'*`se') (`b'+`crit'*`se')
    }
    estimates save "`out'/`model'.ster", replace
    drop `ft' `fc' `fg'
}
assert es_old==es_new
postclose `mh'
postclose `ch'
preserve
keep audit_row_id firm_id stack_id syn_year cohort_report_year event_time treated_in_stack es_old es_new
export delimited using "`out'/actual_estimation_sample.csv", replace
restore
use `mres', clear
export delimited using "`out'/W2_fixed_new_runs.csv", replace
use `cres', clear
export delimited using "`out'/W2_all_coefficients.csv", replace
display as result "FINAL_SAMPLE_W2_REBALANCE_COMPLETE"
log close
exit, clear
