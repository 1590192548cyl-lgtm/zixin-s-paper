from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path('/Users/macpro/Desktop/毕业论文');W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True)
ipo=pd.read_stata(R/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo['date']=pd.to_datetime(ipo.Listdt,errors='coerce');ipo=ipo[ipo.Listexg.eq('1')&ipo.date.between('2010-01-01','2021-12-31')].copy();ids=set(ipo.firm_id);first={}
for p in sorted((R/'原始数据/周度数据重下').glob('*.dta')):
 for ch in pd.read_stata(p,chunksize=40000,columns=['Stkcd','Trdwnt'],convert_categoricals=False):
  f=ch.Stkcd.astype(int);z=ch[f.isin(ids)].copy();z['firm_id']=z.Stkcd.astype(int);z['week']=z.Trdwnt.str.replace('-','',regex=False).astype(int)
  for fid,wk in z.groupby('firm_id').week.min().items():first[fid]=min(first.get(fid,999999),wk)
ipo['first_source_week']=ipo.firm_id.map(first);ipo=ipo[ipo.first_source_week.notna()];jan=pd.to_datetime(ipo.date.dt.year.astype(str)+'-01-01');day=ipo.date.dt.dayofyear
ipo['Sunday_Jan1_week1']=ipo.date.dt.year*100+((day-1+(jan.dt.dayofweek+1)%7)//7+1)
ipo['Monday_Jan1_week1']=ipo.date.dt.year*100+((day-1+jan.dt.dayofweek)//7+1)
i=ipo.date.dt.isocalendar();ipo['ISO']=i.year*100+i.week
rows=[]
for v in ['Sunday_Jan1_week1','Monday_Jan1_week1','ISO']:rows.append(dict(rule=v,N=len(ipo),matches=int(ipo.first_source_week.eq(ipo[v]).sum())))
ipo[['Stkcd','Listdt','first_source_week','Sunday_Jan1_week1','Monday_Jan1_week1','ISO']].to_csv(O/'IPO_first_week_calendar_validation_private.csv',index=False,encoding='utf-8-sig');pd.DataFrame(rows).to_csv(O/'calendar_rule_validation.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False));print(ipo.loc[ipo.first_source_week.ne(ipo.Sunday_Jan1_week1),['Stkcd','Listdt','first_source_week','Sunday_Jan1_week1']].head(15).to_string(index=False))
if not ipo.first_source_week.eq(ipo.Sunday_Jan1_week1).all():raise RuntimeError('Unresolved calendar disagreement: do not repair or regress')
