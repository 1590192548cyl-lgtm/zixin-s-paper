#!/usr/bin/env python3
"""Rebuild FundCorr with newly downloaded 2007-2009 market data.

This is a parallel repair build.  It never overwrites the original controls,
treatment stack, or prior FundCorr output, and it does not run regressions.
"""

from __future__ import annotations

import gc
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook


ROOT = Path("/Users/macpro/Desktop")
WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs/targeted_supplement/control_coverage_repair/fundcorr_weekyear_corrected"
INCOME = ROOT / "控制变量/营业利润净利润/FS_Comins.xlsx"
BALANCE = ROOT / "控制变量/资产合计负债合计所有者权益合计/FS_Combas.xlsx"
NEW_WEEK = ROOT / "控制变量/2007-2009周个股回报率/TRD_Week.xlsx"
NEW_INDUSTRY = ROOT / "控制变量/07-08年度行业分类表/STK_IndustryClassAnl.xlsx"
OLD_INDUSTRY = ROOT / "毕业论文/堆叠DID重跑/data_work/industry_new_standardized.dta"
OLD_WEEK = [
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week.dta",
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week1.dta",
    ROOT / "毕业论文/原始数据/周度数据重下/TRD_Week2.dta",
]
OLD_FUNDCORR = WORK / "outputs/fundcorr_firm_year_2009_2019.dta"
REPAIRED_CONTROLS = WORK / "outputs/targeted_supplement/control_coverage_repair/gao_controls_firm_year_true_data_repaired.dta"
FIXED_STACK = WORK / "outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_analysis.dta"

YEAR_MIN = 2007
YEAR_MAX = 2019
CSRC_RULE = {
    **{y: "P0201" for y in range(2007, 2012)},
    **{y: "P0207" for y in range(2012, 2020)},
}


def stream_xlsx(path: Path, value_col: str) -> pd.DataFrame:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    ws.reset_dimensions()
    rows = ws.iter_rows(values_only=True)
    header = next(rows)
    pos = {v: i for i, v in enumerate(header)}
    required = ["Stkcd", "Accper", "Typrep", value_col]
    missing = [x for x in required if x not in pos]
    if missing:
        raise KeyError(f"{path}: missing fields {missing}")
    next(rows, None)
    next(rows, None)
    out = []
    for row in rows:
        try:
            if str(row[pos["Typrep"]]).strip() != "A":
                continue
            fid = int(float(str(row[pos["Stkcd"]]).strip()))
            dt = pd.Timestamp(row[pos["Accper"]])
            value = float(row[pos[value_col]])
        except (TypeError, ValueError, OverflowError):
            continue
        if YEAR_MIN <= dt.year <= YEAR_MAX and dt.month in (3, 6, 9, 12):
            out.append((fid, dt, value))
    wb.close()
    return pd.DataFrame(out, columns=["firm_id", "date", value_col])


def quarter_end(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.dropna(subset=["date", "market_cap"]).copy()
    frame = frame[frame.market_cap.gt(0)]
    frame["year"] = frame.date.dt.year.astype(np.int16)
    frame["quarter"] = frame.date.dt.quarter.astype(np.int8)
    frame.sort_values(["firm_id", "year", "quarter", "date"], inplace=True)
    return frame.drop_duplicates(["firm_id", "year", "quarter"], keep="last")[
        ["firm_id", "year", "quarter", "date", "market_cap"]
    ]


def corrected_week_anchor(year: int, week: int) -> pd.Timestamp:
    """Preserve the CSMAR YYYY label when a cross-year week spills in parsing."""
    dt = pd.to_datetime(f"{year}-{week:02d}-1", format="%Y-%W-%w", errors="coerce")
    if pd.isna(dt):
        return pd.NaT
    if dt.year > year:
        return pd.Timestamp(year=year, month=12, day=31)
    if dt.year < year:
        return pd.Timestamp(year=year, month=1, day=1)
    return dt


def new_week_cap() -> pd.DataFrame:
    wb = load_workbook(NEW_WEEK, read_only=True, data_only=True)
    ws = wb.active
    ws.reset_dimensions()
    rows = ws.iter_rows(values_only=True)
    header = next(rows)
    pos = {v: i for i, v in enumerate(header)}
    next(rows, None)
    next(rows, None)
    out = []
    for row in rows:
        try:
            fid = int(float(str(row[pos["Stkcd"]]).strip()))
            text = str(row[pos["Trdwnt"]]).strip()
            year, week = map(int, text.split("-"))
            cap = float(row[pos["Wsmvosd"]])
        except (TypeError, ValueError, OverflowError):
            continue
        if not 2007 <= year <= 2009 or not np.isfinite(cap) or cap <= 0:
            continue
        dt = corrected_week_anchor(year, week)
        if pd.notna(dt):
            out.append((fid, dt, cap))
    wb.close()
    return quarter_end(pd.DataFrame(out, columns=["firm_id", "date", "market_cap"]))


def old_week_cap() -> pd.DataFrame:
    parts = []
    for path in OLD_WEEK:
        for ch in pd.read_stata(
            path,
            columns=["Stkcd", "Trdwnt", "Wsmvosd"],
            convert_categoricals=False,
            chunksize=250_000,
        ):
            fid = pd.to_numeric(ch.Stkcd, errors="coerce")
            text = ch.Trdwnt.astype(str)
            key = pd.to_numeric(text.str.replace("-", "", regex=False), errors="coerce")
            cap = pd.to_numeric(ch.Wsmvosd, errors="coerce")
            good = fid.notna() & key.notna() & cap.gt(0)
            year = (key[good] // 100).astype(int)
            week = (key[good] % 100).astype(int)
            keep = year.between(2010, YEAR_MAX)
            if not keep.any():
                continue
            date = pd.to_datetime(
                year[keep].astype(str) + "-" + week[keep].astype(str).str.zfill(2) + "-1",
                format="%Y-%W-%w",
                errors="coerce",
            )
            raw_year = year[keep].to_numpy()
            spill_forward = date.dt.year.to_numpy() > raw_year
            spill_backward = date.dt.year.to_numpy() < raw_year
            if spill_forward.any():
                date.iloc[np.flatnonzero(spill_forward)] = pd.to_datetime(
                    pd.Series(raw_year[spill_forward]).astype(str) + "-12-31"
                ).to_numpy()
            if spill_backward.any():
                date.iloc[np.flatnonzero(spill_backward)] = pd.to_datetime(
                    pd.Series(raw_year[spill_backward]).astype(str) + "-01-01"
                ).to_numpy()
            z = pd.DataFrame({
                "firm_id": fid[good][keep].astype(np.int32),
                "date": date,
                "market_cap": cap[good][keep].astype(np.float64),
            })
            parts.append(quarter_end(z))
    d = pd.concat(parts, ignore_index=True)
    return quarter_end(d.rename(columns={"date": "date"}))


def market_cap() -> pd.DataFrame:
    new = new_week_cap()
    print(f"new weekly quarter-end rows={len(new):,}", flush=True)
    old = old_week_cap()
    print(f"old weekly quarter-end rows 2010-2019={len(old):,}", flush=True)
    d = pd.concat([new, old], ignore_index=True)
    d.sort_values(["firm_id", "year", "quarter", "date"], inplace=True)
    d = d.drop_duplicates(["firm_id", "year", "quarter"], keep="last")
    return d[["firm_id", "year", "quarter", "market_cap"]]


def new_industry() -> pd.DataFrame:
    wb = load_workbook(NEW_INDUSTRY, read_only=True, data_only=True)
    ws = wb.active
    ws.reset_dimensions()
    rows = ws.iter_rows(values_only=True)
    header = next(rows)
    pos = {v: i for i, v in enumerate(header)}
    next(rows, None)
    next(rows, None)
    out = []
    for row in rows:
        try:
            if str(row[pos["IndustryClassificationID"]]).strip() != "P0201":
                continue
            fid = int(float(str(row[pos["Symbol"]]).strip()))
            year = pd.Timestamp(row[pos["EndDate"]]).year
            code = str(row[pos["IndustryCode2"]]).strip() if row[pos["IndustryCode2"]] is not None else ""
            name = str(row[pos["IndustryName2"]]).strip() if row[pos["IndustryName2"]] is not None else ""
        except (TypeError, ValueError, OverflowError):
            continue
        if year in (2007, 2008) and code:
            out.append((fid, year, "P0201", code, name))
    wb.close()
    return pd.DataFrame(out, columns=["firm_id", "year", "IndustryClassificationID", "IndustryCode2", "IndustryName2"])


def industry_map() -> pd.DataFrame:
    early = new_industry()
    cols = ["EndDate", "IndustryClassificationID", "Symbol", "IndustryCode2", "IndustryName2"]
    d = pd.read_stata(OLD_INDUSTRY, columns=cols, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.Symbol, errors="coerce").astype("Int64")
    d["year"] = pd.to_datetime(d.EndDate, errors="coerce").dt.year.astype("Int64")
    rows = []
    for year in range(2009, 2020):
        std = CSRC_RULE[year]
        rows.append(d[d.year.eq(year) & d.IndustryClassificationID.astype(str).eq(std)].copy())
    later = pd.concat(rows, ignore_index=True)[
        ["firm_id", "year", "IndustryClassificationID", "IndustryCode2", "IndustryName2"]
    ]
    m = pd.concat([early, later], ignore_index=True)
    m = m.dropna(subset=["firm_id", "year", "IndustryCode2"])
    m["firm_id"] = pd.to_numeric(m.firm_id, errors="raise").astype(int)
    m["year"] = pd.to_numeric(m.year, errors="raise").astype(int)
    m = m.sort_values(["firm_id", "year"]).drop_duplicates(["firm_id", "year"], keep="last")
    return m


def construct() -> tuple[pd.DataFrame, dict]:
    start = time.time()
    inc = stream_xlsx(INCOME, "B001300000")
    bal = stream_xlsx(BALANCE, "A001000000")
    q = inc.merge(bal, on=["firm_id", "date"], how="inner", validate="one_to_one")
    del inc, bal
    gc.collect()
    q["year"] = q.date.dt.year.astype(np.int16)
    q["quarter"] = q.date.dt.quarter.astype(np.int8)
    q.sort_values(["firm_id", "year", "quarter"], inplace=True)
    prior_cum = q.groupby(["firm_id", "year"], sort=False).B001300000.shift(1)
    prior_q = q.groupby(["firm_id", "year"], sort=False).quarter.shift(1)
    q["q_operating_income"] = q.B001300000
    later = q.quarter.gt(1)
    consecutive = prior_q.eq(q.quarter - 1)
    q.loc[later & consecutive, "q_operating_income"] = q.loc[later & consecutive, "B001300000"] - prior_cum[later & consecutive]
    q.loc[later & ~consecutive, "q_operating_income"] = np.nan
    q["quarterly_roa"] = q.q_operating_income / q.A001000000
    q.loc[~np.isfinite(q.quarterly_roa), "quarterly_roa"] = np.nan

    cap = market_cap()
    ind = industry_map()
    q = q.merge(cap, on=["firm_id", "year", "quarter"], how="left", validate="one_to_one")
    q = q.merge(ind, on=["firm_id", "year"], how="left", validate="many_to_one")
    q["industry_key"] = q.IndustryClassificationID.astype("string") + "|" + q.IndustryCode2.astype("string")
    valid = q.quarterly_roa.notna() & q.market_cap.gt(0) & q.IndustryCode2.notna()
    v = q.loc[valid, ["firm_id", "year", "quarter", "industry_key", "quarterly_roa", "market_cap"]].copy()
    v["weighted_roa"] = v.quarterly_roa * v.market_cap
    agg = v.groupby(["year", "quarter", "industry_key"], sort=False).agg(
        sum_weighted_roa=("weighted_roa", "sum"),
        sum_cap=("market_cap", "sum"),
        n_firms=("firm_id", "nunique"),
    ).reset_index()
    q = q.merge(agg, on=["year", "quarter", "industry_key"], how="left", validate="many_to_one")
    den = q.sum_cap - q.market_cap
    q["industry_vw_roa_ex_firm"] = np.where(
        den.gt(0) & q.n_firms.gt(1),
        (q.sum_weighted_roa - q.quarterly_roa * q.market_cap) / den,
        np.nan,
    )
    q["quarter_index"] = q.year.astype(int) * 4 + q.quarter.astype(int)
    q.sort_values(["firm_id", "quarter_index"], inplace=True)

    out = []
    for fid, g in q.groupby("firm_id", sort=True):
        g = g.set_index("quarter_index", drop=False)
        for year in range(2009, 2020):
            end = year * 4 + 4
            idx = np.arange(end - 11, end + 1)
            if not np.isin(idx, g.index).all():
                continue
            z = g.loc[idx, ["quarterly_roa", "industry_vw_roa_ex_firm"]].dropna()
            if len(z) != 12:
                continue
            yy = z.quarterly_roa.to_numpy(float)
            xx = np.column_stack([np.ones(12), z.industry_vw_roa_ex_firm.to_numpy(float)])
            beta, _, _, _ = np.linalg.lstsq(xx, yy, rcond=None)
            resid = yy - xx @ beta
            sst = float(((yy - yy.mean()) ** 2).sum())
            r2 = np.nan if sst <= 0 else 1 - float(resid @ resid) / sst
            value = math.log(r2 / (1 - r2)) if np.isfinite(r2) and 0 < r2 < 1 else np.nan
            out.append({
                "firm_id": int(fid),
                "fiscal_year": int(year),
                "FundCorr": value,
                "FundCorr_R2": r2,
                "FundCorr_quarters": 12,
                "FundCorr_weight": "quarter-end weekly circulating market capitalization",
            })
    res = pd.DataFrame(out)
    clean = res.FundCorr.dropna()
    p1, p99 = float(clean.quantile(0.01)), float(clean.quantile(0.99))
    res["FundCorr_w"] = res.FundCorr.clip(p1, p99)
    meta = {
        "quarterly_financial_rows": int(len(q)),
        "quarterly_cap_rows": int(len(cap)),
        "industry_firm_years": int(len(ind)),
        "fundcorr_firm_years": int(len(res)),
        "fundcorr_unique_firms": int(res.firm_id.nunique()),
        "fundcorr_mean": float(clean.mean()),
        "fundcorr_median": float(clean.median()),
        "fundcorr_sd": float(clean.std()),
        "winsor_p1": p1,
        "winsor_p99": p99,
        "elapsed_seconds": float(time.time() - start),
        "regressions_run": 0,
    }
    return res, meta


def audits(res: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    coverage = res.groupby("fiscal_year").FundCorr.agg(["count", "mean", "std", "median", "min", "max"]).reset_index()
    old = pd.read_stata(OLD_FUNDCORR, convert_categoricals=False)
    common = res.merge(old[["firm_id", "fiscal_year", "FundCorr"]], on=["firm_id", "fiscal_year"], suffixes=("_new", "_old"))
    common["abs_diff"] = (common.FundCorr_new - common.FundCorr_old).abs()
    compare = common.groupby("fiscal_year").agg(
        common_firm_years=("firm_id", "size"),
        max_abs_diff=("abs_diff", "max"),
        mean_abs_diff=("abs_diff", "mean"),
        mismatches_gt_1e_10=("abs_diff", lambda x: int((x > 1e-10).sum())),
    ).reset_index()
    s = pd.read_stata(FIXED_STACK, convert_categoricals=False)
    s["firm_id"] = pd.to_numeric(s.firm_id, errors="raise").astype(int)
    s["annual_report_year"] = pd.to_numeric(s.annual_report_year, errors="raise").astype(int)
    m = s.merge(
        res[["firm_id", "fiscal_year", "FundCorr"]],
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "fiscal_year"],
        how="left",
        validate="many_to_one",
        suffixes=("_old", "_new"),
    )
    stack = m.groupby("annual_report_year").agg(
        stack_rows=("firm_id", "size"),
        old_available=("FundCorr_old", lambda x: int(x.notna().sum())),
        repaired_available=("FundCorr_new", lambda x: int(x.notna().sum())),
    ).reset_index()
    stack["rows_recovered"] = stack.repaired_available - stack.old_available
    return coverage, compare, stack


def merge_controls(res: pd.DataFrame) -> Path:
    c = pd.read_stata(REPAIRED_CONTROLS, convert_categoricals=False)
    c["firm_id"] = pd.to_numeric(c.firm_id, errors="raise").astype(int)
    c["fiscal_year"] = pd.to_numeric(c.fiscal_year, errors="raise").astype(int)
    out = c.merge(
        res[["firm_id", "fiscal_year", "FundCorr", "FundCorr_R2", "FundCorr_quarters", "FundCorr_w"]],
        on=["firm_id", "fiscal_year"],
        how="left",
        validate="one_to_one",
    )
    if out.duplicated(["firm_id", "fiscal_year"]).any():
        raise ValueError("Duplicate firm-year after FundCorr merge")
    path = OUT / "gao_controls_firm_year_true_data_repaired_with_fundcorr.dta"
    out.to_stata(path, write_index=False, version=118)
    return path


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    res, meta = construct()
    res.to_csv(OUT / "fundcorr_firm_year_2009_2019_repaired.csv", index=False)
    res.to_stata(OUT / "fundcorr_firm_year_2009_2019_repaired.dta", write_index=False, version=118)
    coverage, compare, stack = audits(res)
    coverage.to_csv(OUT / "fundcorr_repaired_coverage_by_year.csv", index=False)
    compare.to_csv(OUT / "fundcorr_repaired_vs_old.csv", index=False)
    stack.to_csv(OUT / "fundcorr_repaired_stack_coverage.csv", index=False)
    combined = merge_controls(res)
    meta["combined_controls_path"] = str(combined)
    meta["duplicate_firm_years"] = 0
    (OUT / "fundcorr_repaired_build_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    report = [
        "# FundCorr真实数据补齐报告",
        "",
        "使用新下载的2007—2009周度流通市值和2007—2008年P0201年度行业分类，按原公式并行重建2009—2019年FundCorr。跨年周按CSMAR原始YYYY标签保留在标签年份；原始文件未覆盖，未运行回归。",
        "",
        "## 年度覆盖",
        "",
        coverage.to_csv(index=False),
        "## 与旧结果比较",
        "",
        compare.to_csv(index=False),
        "## 当前固定stack覆盖",
        "",
        stack.to_csv(index=False),
        "## 说明",
        "",
        "- 2009和2010为新增可计算年份。",
        "- 新版修正旧代码将YYYY-W53错误归入下一年第一季度的问题；跨年周保留在其CSMAR标签年份。",
        "- 行业缺失、上市不足12季度或季度财务不完整的公司继续保持缺失，没有插补。",
    ]
    (OUT / "fundcorr_repaired_report.md").write_text("\n".join(report), encoding="utf-8")
    print(coverage.to_string(index=False), flush=True)
    print(compare.to_string(index=False), flush=True)
    print(stack.to_string(index=False), flush=True)
    print(json.dumps(meta, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
