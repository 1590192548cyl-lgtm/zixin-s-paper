"""Audit classification backcasting and ST selection; no estimation or repair."""
from pathlib import Path
from zipfile import ZipFile
import tempfile,shutil,sys,json,hashlib,resource,time
import pandas as pd,numpy as np
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);ROOT=Path('/Users/macpro/Desktop/毕业论文');P=ROOT/'堆叠DID重跑';B=W.parent/'huang_basic_reconstruction_20261103';R=W.parent/'huang_week_calendar_repair_20261103';F=R/'fixed_rerun';start=time.time()
ZIP=ROOT/'控制变量/黄文复现补充/公司基本信息表202614412(仅供vip使用).zip'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig')
def js(d,n):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def records(path):
 head={}
 for sheet,rn,vals in xml_rows(path):
  if rn==1:head[sheet]=vals
  if rn>=4:yield rn,{name:vals.get(col,'') for col,name in head[sheet].items()}
protected=list((F/'outputs').glob('*.csv'))+list((F/'outputs').glob('*.ster'))+[F/'outputs/fixed_analysis.dta',P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta',ZIP];manifest=[dict(file=str(p),sha256=sha(p)) for p in protected];js(manifest,'protected_inputs.json')
with ZipFile(ZIP) as z:
 with tempfile.TemporaryFile(suffix='.xlsx') as f:
  with z.open('BDT_CO.xlsx') as inp:shutil.copyfileobj(inp,f,1048576)
  f.seek(0);rr=list(records(f));st=pd.DataFrame([dict(source_row=rn,**r) for rn,r in rr])
  f.seek(0);it=xml_rows(f);first=[next(it) for _ in range(5)];it.close()
st['firm_id']=st.Symbol.astype(int);assert not st.firm_id.duplicated().any();st=st.set_index('firm_id');dates=st.FirstSTDate.ne('');valid_date=pd.to_datetime(st.FirstSTDate.where(dates),errors='coerce');assert valid_date[dates].notna().all()
js(dict(path=str(ZIP),rows=len(st),columns=6,sheet='sheet1',listing_date_min=st.ListedDate.min(),listing_date_max=st.ListedDate.max(),FirstSTDate_nonempty=int(dates.sum()),FirstSTDate_min=st.loc[dates,'FirstSTDate'].min(),FirstSTDate_max=st.loc[dates,'FirstSTDate'].max(),no_duplicate_company=True,first_five_rows=first,warning='上市日期覆盖不是FirstSTDate覆盖；缺公司行与有公司行但日期空必须区分'), 'new_ST_source_audit.json')
data=pd.read_stata(F/'outputs/fixed_analysis.dta',convert_categoricals=False);mapping=pd.read_csv(B/'outputs/policy_mapping_private.csv').set_index('firm_id');ipo=pd.read_stata(ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo=ipo.set_index('firm_id');firstproxy={};parts=[]
for ch in pd.read_stata(ROOT/'原始数据/行业分类_新下载.dta',chunksize=40000,convert_categoricals=False):
 yy=ch.EndDate.str[:4].astype(int);fid=ch.Symbol.astype(int);flag=yy.between(2009,2021)&ch.ShortName.str.upper().str.match(r'^(?:\*?ST|S\*?ST|PT)',na=False)
 for f,y in zip(fid[flag],yy[flag]):firstproxy[f]=min(firstproxy.get(f,9999),y)
 mask=(ch.IndustryClassificationID.eq('P0201')&yy.eq(2011))|(ch.IndustryClassificationID.eq('P0207')&yy.isin([2012,2013,2014]))
 q=ch.loc[mask,['IndustryClassificationID','IndustryCode2','IndustryName2']].copy();q['firm_id']=fid[mask];q['year']=yy[mask];parts.append(q)
ind=pd.concat(parts,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any()
codes=ind.pivot(index='firm_id',columns='year',values='IndustryCode2');names=ind.pivot(index='firm_id',columns='year',values='IndustryName2')
def group(code):return str(code) if str(code).startswith('C') else str(code)[:1]
g12=codes[2012].dropna().map(group);g14=codes[2014].dropna().map(group)
dead=set()
for _,r in records(ROOT/'原始数据/公司基本信息/EVA_Co.xlsx'):
 if r.get('DelistedDate','') and r['DelistedDate']<='2021-12-31':dead.add(int(r['Symbol']))
ids=set(ipo.index[ipo.Listexg.eq('1')&ipo.Listdt.lt('2015-01-01')&ipo.index.to_series().astype(str).str.startswith('6')]);candidate=(ids-dead)&set(mapping.index[~mapping.industry2014.str.startswith('J')]);old_eligible=set(mapping.index[mapping.eligible.eq(1)]);assert candidate-set(firstproxy)==old_eligible
detail=pd.DataFrame(index=pd.Index(sorted(candidate),name='firm_id'));detail['IPODate']=detail.index.map(ipo.Listdt);detail['Treat2014']=detail.index.map(mapping.Treat);detail['old_proxy_ST_year']=detail.index.map(firstproxy);detail['old_retained']=detail.index.isin(old_eligible);detail['new_source_row_present']=detail.index.isin(st.index);detail['FirstSTDate']=detail.index.map(st.FirstSTDate);detail['IsManyTimesST']=detail.index.map(st.IsManyTimesST)
detail['new_ST_bucket']='no_company_row_unknown';present=detail.new_source_row_present;empty=present&detail.FirstSTDate.eq('');detail.loc[empty,'new_ST_bucket']='company_present_date_blank_not_certified_never';has=present&~empty;d=detail.FirstSTDate
for label,cond in [('ST_by2008',d.le('2008-12-31')),('ST_2009_2014',d.between('2009-01-01','2014-12-31')),('ST_2015_2021',d.between('2015-01-01','2021-12-31')),('first_ST_after2021',d.gt('2021-12-31'))]:detail.loc[has&cond,'new_ST_bucket']=label
cur_ids=set(data.loc[data.old_H0_sample.eq(1),'firm_id']);detail['in_current_H0']=detail.index.isin(cur_ids);detail['in_current_H8']=detail.index.isin(set(data.loc[data.old_H8_sample.eq(1),'firm_id']));save(detail.reset_index(),'ST_proxy_vs_FirstSTDate_private.csv')
save(detail.groupby(['old_retained','new_source_row_present','new_ST_bucket'],dropna=False).size().rename('firms').reset_index(),'ST_selection_crosscheck.csv')
summ=[]
for label,firms in [('pre_ST_candidate',candidate),('old_eligible',old_eligible),('current_H0',cur_ids),('current_H8',set(data.loc[data.old_H8_sample.eq(1),'firm_id']))]:
 z=detail.loc[sorted(firms)];doc=z.new_ST_bucket.isin(['ST_by2008','ST_2009_2014','ST_2015_2021']);summ.append(dict(population=label,firms=len(z),new_source_matched=int(z.new_source_row_present.sum()),missing_company_rows=int((~z.new_source_row_present).sum()),documented_FirstST_by2021=int(doc.sum()),new_source_date_blank=int(z.new_ST_bucket.eq('company_present_date_blank_not_certified_never').sum()),first_ST_after2021=int(z.new_ST_bucket.eq('first_ST_after2021').sum())))
save(pd.DataFrame(summ),'ST_source_coverage.csv')
save(detail.loc[~detail.new_source_row_present].reset_index()[['firm_id','IPODate','Treat2014','old_retained','in_current_H0']],'missing_ST_company_rows_download_private.csv')
chron=detail[detail.new_source_row_present&detail.old_proxy_ST_year.notna()&detail.FirstSTDate.notna()&detail.FirstSTDate.ne('')].copy();chron['FirstST_year']=chron.FirstSTDate.str[:4].astype(int);chron['year_gap_true_minus_proxy']=chron.FirstST_year-chron.old_proxy_ST_year;save(chron.reset_index(),'ST_date_chronology_review_private.csv')
# Paired descriptive diagnostics only, based on the frozen, corrected samples.
rows=[];contrib=[];classification=[];pairedsets={}
for model in ['H0','H8']:
 q=data[data[f'old_{model}_sample'].eq(1)].copy();pair=set(q.loc[q.year.eq(2011),'firm_id'])&set(q.loc[q.year.eq(2014),'firm_id']);pairedsets[model]=pair;q=q[q.firm_id.isin(pair)&q.year.isin([2011,2014])].copy();q['code2012']=q.firm_id.map(codes[2012]);q['code2014']=q.firm_id.map(codes[2014]);q['group2012']=q.firm_id.map(g12);q['group2014']=q.firm_id.map(g14)
 stable=set(codes.index[codes[2012].eq(codes[2014])]);sg=set(g12.index[g12.eq(g14.reindex(g12.index))]);matched=set(st.index);doc=set(detail.index[detail.new_ST_bucket.isin(['ST_by2008','ST_2009_2014','ST_2015_2021'])])
 for label,firms in [('all_paired',pair),('same_code_2012_2014',pair&stable),('changed_code_2012_2014',pair-stable),('same_SYN_group_2012_2014',pair&sg),('ST_source_company_missing',pair-matched),('ST_source_company_present',pair&matched),('documented_ST_by2021',pair&doc)]:
  z=q[q.firm_id.isin(firms)];a=z.groupby(['year','Treat']).SYN_w.mean();gap11=a.get((2011,1),np.nan)-a.get((2011,0),np.nan);gap14=a.get((2014,1),np.nan)-a.get((2014,0),np.nan);rows.append(dict(model=model,descriptive_group=label,firms=len(firms),treated=z.loc[z.Treat.eq(1),'firm_id'].nunique(),gap2011=gap11,gap2014=gap14,gap_difference=gap11-gap14,not_a_regression=True))
 if model=='H8':
  wide=q.pivot(index='firm_id',columns='year',values='SYN_w');firm=pd.DataFrame({'delta_2011_minus2014':wide[2011]-wide[2014]});firm['Treat']=firm.index.map(mapping.Treat);firm['industry2014']=firm.index.map(mapping.industry2014);center=firm.delta_2011_minus2014.mean();nt=firm.Treat.value_counts()
  for (code,t),g in firm.groupby(['industry2014','Treat']):contrib.append(dict(industry2014=code,Treat=t,firms=len(g),mean_delta=g.delta_2011_minus2014.mean(),centered_descriptive_contribution=(1 if t==1 else -1)*len(g)/nt[t]*(g.delta_2011_minus2014.mean()-center)))
  for fid in sorted(pair):classification.append(dict(firm_id=fid,code2011=codes.at[fid,2011] if fid in codes.index else '',name2011=names.at[fid,2011] if fid in names.index else '',code2012=codes.at[fid,2012],name2012=names.at[fid,2012],code2014=codes.at[fid,2014],same2012_2014_code=fid in stable,same_SYN_group_2012_2014=fid in sg,ST_source_matched=fid in matched))
save(pd.DataFrame(rows),'frozen_sample_descriptive_strata.csv');save(pd.DataFrame(contrib),'industry_centered_descriptive_contributions.csv');save(pd.DataFrame(classification),'H8_paired_industry_source_review_private.csv')
allsh=set(ipo.index[ipo.Listexg.eq('1')&ipo.index.to_series().astype(str).str.startswith('6')]);bridge=codes.loc[codes.index.isin(allsh)&codes[2011].notna()&codes[2012].notna(),[2011,2012]].copy();bridge['SYNgroup2012']=bridge[2012].map(group);save(bridge.groupby([2011,2012,'SYNgroup2012'],dropna=False).size().rename('firms').reset_index(),'Shanghai_legacy_to2012_crosswalk.csv')
purity=bridge.groupby(2011).agg(firms=(2012,'size'),distinct2012codes=(2012,'nunique'),distinct2012SYNgroups=('SYNgroup2012','nunique')).reset_index();save(purity,'legacy_crosswalk_ambiguity.csv')
# Preserve the corrected SYN and original screens; show excluded cohorts without running counterfactual models.
syn=pd.read_csv(R/'outputs/corrected_SYN_private.csv');raw=syn[syn.firm_id.isin(candidate)&syn.year.isin([2011,2014])&syn.SYN.notna()].copy();raw['Treat']=raw.firm_id.map(mapping.Treat);raw['proxy_excluded']=~raw.firm_id.isin(old_eligible);raw['FirstSTDate_bucket']=raw.firm_id.map(detail.new_ST_bucket);save(raw.groupby(['year','Treat','proxy_excluded','FirstSTDate_bucket'],dropna=False).agg(firms=('firm_id','nunique'),SYN_mean=('SYN','mean')).reset_index(),'selection_groups_corrected_SYN_descriptives.csv')
meta=dict(regressions_run=0,SYN_recomputed=False,analysis_files_written=False,originals_unchanged=all(sha(r['file'])==r['sha256'] for r in manifest),protected_files=len(manifest),new_ST_rows=len(st),new_ST_listed_min=st.ListedDate.min(),new_ST_listed_max=st.ListedDate.max(),candidates=len(candidate),old_eligible=len(old_eligible),current_companies=len(cur_ids),paired_H8=len(pairedsets['H8']),crosswalk_one_to_many_legacy=int(purity.distinct2012codes.gt(1).sum()),crosswalk_one_to_many_SYNgroup=int(purity.distinct2012SYNgroups.gt(1).sum()),seconds=time.time()-start,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
assert meta['originals_unchanged'];js(meta,'audit_execution.json');print(meta);print(pd.DataFrame(summ).to_string(index=False));print(pd.DataFrame(rows).query('model=="H8"').to_string(index=False));print(detail.groupby(['old_retained','new_ST_bucket']).size().to_string())
