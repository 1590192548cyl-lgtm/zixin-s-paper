from pathlib import Path
import hashlib,json,resource
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent
O=W/'outputs';O.mkdir(exist_ok=True)
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
F=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
CUT=P/'gao_exact_replication/outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_winsor_cutoffs.csv'
def save(d,name):d.to_csv(O/name,index=False,encoding='utf-8-sig',float_format='%.17g')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
d=pd.read_stata(F,convert_categoricals=False)
assert len(d)==26711 and int(d.sample_g1.sum())==24659
assert not d.duplicated(['firm_id','stack_id','annual_report_year']).any()
variables=['SYN_CSRC_FAMILY','TreatPost','Size','MB_parent','Lev']
required=variables.copy()
raw=d[required].notna().all(axis=1)
assert raw.eq(d.sample_g1_raw.eq(1)).all()
final=pd.Series(False,index=d.index)
q=d.loc[raw]
good=q.groupby(['firm_id','stack_id']).Post.transform(lambda x:x.eq(0).any() and x.eq(1).any())
final.loc[q.index]=good
assert final.eq(d.sample_g1.eq(1)).all()
rows=[];mask=pd.Series(True,index=d.index)
for stage,v in [('A_original_stack',None)]+[(chr(66+i)+'_nonmissing_'+v,v) for i,v in enumerate(required)]:
    if v is not None:mask &= d[v].notna()
    rows.append({'stage':stage,'stack_N':int(mask.sum()),'unique_firm_years':len(d.loc[mask,['firm_id','annual_report_year']].drop_duplicates()),'firms':d.loc[mask,'firm_id'].nunique()})
rows.append({'stage':'G_prepost_eligible','stack_N':int(final.sum()),'unique_firm_years':len(d.loc[final,['firm_id','annual_report_year']].drop_duplicates()),'firms':d.loc[final,'firm_id'].nunique()})
save(pd.DataFrame(rows),'G1_attrition_waterfall.csv')
for v in required:d['missing_'+v]=d[v].isna().astype(np.int8)
d['complete_case']=raw.astype(np.int8)
d['lost_only_prepost_support']=(raw&~final).astype(np.int8)
d['missing_pattern']=d.apply(lambda r:'+'.join(v for v in required if pd.isna(r[v])) or ('prepost_support' if r.sample_g1==0 else 'retained'),axis=1)
lost=d.loc[~final].copy();assert len(lost)==2052
lost['firm_code']=lost.firm_id.astype(int).astype(str).str.zfill(6)
save(lost,'G1_lost_2052_observations_private.csv')
patterns=lost.groupby('missing_pattern').agg(stack_observations=('firm_id','size'),firms=('firm_id','nunique'),treated_stack_observations=('treated_in_stack','sum')).reset_index()
patterns['unique_firm_years']=[len(lost.loc[lost.missing_pattern.eq(v),['firm_id','annual_report_year']].drop_duplicates()) for v in patterns.missing_pattern]
save(patterns,'G1_loss_patterns.csv')
miss=[]
for v in required:
    z=d.loc[d[v].isna()]
    single=d.loc[d[v].isna()&d[[a for a in required if a!=v]].notna().all(axis=1)]
    miss.append({'variable':v,'missing_stack_observations':len(z),'missing_unique_firm_years':len(z[['firm_id','annual_report_year']].drop_duplicates()),'missing_treated_stack_observations':int(z.treated_in_stack.sum()),'unique_treated_firm_years':len(z.loc[z.treated_in_stack.eq(1),['firm_id','annual_report_year']].drop_duplicates()),'sole_missing_stack_observations':len(single)})
save(pd.DataFrame(miss),'G1_missingness_by_variable.csv')
for key,name in [('annual_report_year','year'),('cohort_report_year','cohort')]:
    z=lost.groupby([key,'missing_pattern','treated_in_stack']).size().reset_index(name='stack_observations')
    save(z,'G1_missingness_by_'+name+'.csv')
keys=lost[['firm_id','firm_code','annual_report_year','syn_year']].drop_duplicates().sort_values(['firm_id','annual_report_year'])
save(keys,'G1_missing_unique_firm_year_keys.csv')
controlkeys=lost.loc[lost[['Size','MB_parent','Lev']].isna().any(axis=1),['firm_id','firm_code','annual_report_year','Size','MB_parent','Lev']].drop_duplicates()
save(controlkeys,'G1_financial_target_keys.csv')
synkeys=lost.loc[lost.SYN_CSRC_FAMILY.isna(),['firm_id','firm_code','annual_report_year','syn_year','n_weeks_CSRC_FAMILY']].drop_duplicates()
save(synkeys,'G1_SYN_target_keys.csv')
cuts=pd.read_csv(CUT).set_index('variable')
cutchecks=[]
for v in ['SYN_CSRC_FAMILY','Size','MB_parent','Lev']:
    clipped=d[v].clip(float(cuts.loc[v,'p1']),float(cuts.loc[v,'p99']))
    assert np.allclose(clipped,d[v+'_w_exact'],atol=1e-12,rtol=0,equal_nan=True)
    cutchecks.append({'variable':v,'p1':float(cuts.loc[v,'p1']),'p99':float(cuts.loc[v,'p99']),'violations':0})
save(pd.DataFrame(cutchecks),'frozen_winsor_cutoffs.csv')
manifest=pd.DataFrame([{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [F,CUT]])
save(manifest,'primary_input_manifest_before.csv')
summary={'original_stack_N':len(d),'original_G1_N':int(final.sum()),'lost_stack_observations':len(lost),'lost_unique_firm_years':len(keys),'complete_case_N':int(raw.sum()),'lost_only_prepost_support':int((raw&~final).sum()),'financial_target_unique_firm_years':len(controlkeys),'SYN_target_unique_firm_years':len(synkeys),'original_sample_rule_reproduced':True,'frozen_winsor_reproduced':True,'Python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
(O/'attrition_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
print(patterns.to_string(index=False),flush=True)
print(pd.DataFrame(miss).to_string(index=False),flush=True)
