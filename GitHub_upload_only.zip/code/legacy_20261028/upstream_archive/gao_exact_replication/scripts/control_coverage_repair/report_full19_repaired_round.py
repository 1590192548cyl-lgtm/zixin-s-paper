from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = ROOT / "outputs/targeted_supplement/control_coverage_repair/full19_repaired_round"
OLD = ROOT / "outputs/targeted_supplement/cohort_2012/fixed_models"
DATA = OUT / "full19_repaired_analysis.dta"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fmt(x: float, digits: int = 4) -> str:
    return f"{x:.{digits}f}"


main = pd.read_csv(OUT / "full19_repaired_main_models.csv")
events = pd.read_csv(OUT / "full19_repaired_event_study.csv")
joint = pd.read_csv(OUT / "full19_repaired_joint_tests.csv")
missing = pd.read_csv(OUT / "full19_repaired_missingness.csv")
sample_audit = pd.read_csv(OUT / "full19_repaired_sample_audit.csv")
value_changes = pd.read_csv(OUT / "full19_repaired_value_changes.csv")
old_main = pd.read_csv(OLD / "cohort_2012_fixed_main_models.csv")
old_events = pd.read_csv(OLD / "cohort_2012_fixed_event_study.csv")
old_joint = pd.read_csv(OLD / "cohort_2012_fixed_joint_tests.csv")

# Exact checksums against the frozen results.
g1_new = main.loc[main.model == "G1_checksum"].iloc[0]
g1_old = old_main.loc[old_main.model == "G1"].iloc[0]
full_new_check = main.loc[main.model == "old_FULL19"].iloc[0]
full_old = old_main.loc[old_main.model == "FULL19"].iloc[0]
for col in ["N", "clusters", "treated_firms", "cohorts", "TreatPost", "SE", "p"]:
    assert np.isclose(g1_new[col], g1_old[col], atol=1e-12), ("G1", col)
    assert np.isclose(full_new_check[col], full_old[col], atol=1e-12), ("FULL19", col)

# Sample transitions and their distribution across cohort and SYN year.
df = pd.read_stata(
    DATA,
    columns=[
        "stack_id", "firm_id", "syn_year", "cohort_report_year",
        "treated_in_stack", "sample_full_old", "sample_full_repaired",
    ],
    convert_categoricals=False,
)
df["transition"] = np.select(
    [
        (df.sample_full_old == 1) & (df.sample_full_repaired == 1),
        (df.sample_full_old == 1) & (df.sample_full_repaired == 0),
        (df.sample_full_old == 0) & (df.sample_full_repaired == 1),
    ],
    ["common", "old_only", "repaired_only"],
    default="neither",
)
transitions = (
    df.groupby(["cohort_report_year", "syn_year", "transition"], observed=True)
    .agg(rows=("firm_id", "size"), firms=("firm_id", "nunique"), treated_rows=("treated_in_stack", "sum"))
    .reset_index()
)
totals = (
    df.groupby("transition", observed=True)
    .agg(rows=("firm_id", "size"), firms=("firm_id", "nunique"), treated_rows=("treated_in_stack", "sum"))
    .reset_index()
)
totals.insert(0, "cohort_report_year", "ALL")
totals.insert(1, "syn_year", "ALL")
pd.concat([totals, transitions], ignore_index=True).to_csv(
    OUT / "full19_repaired_sample_transitions.csv", index=False
)

# Compact model comparison and transparent deltas.
order = [
    "G1_checksum", "old_FULL19", "repaired_FULL19",
    "old_FULL19_common", "repaired_FULL19_common",
]
comparison = main.set_index("model").loc[order].reset_index()
comparison["timing"] = "fiscal_year = syn_year - 1 (frozen)"
comparison["design"] = "same Treat/stack/cohorts/SYN/FE/cluster"
comparison.to_csv(OUT / "full19_repaired_model_comparison.csv", index=False)

old_full = main.loc[main.model == "old_FULL19"].iloc[0]
rep_full = main.loc[main.model == "repaired_FULL19"].iloc[0]
old_common = main.loc[main.model == "old_FULL19_common"].iloc[0]
rep_common = main.loc[main.model == "repaired_FULL19_common"].iloc[0]

decomp = pd.DataFrame(
    [
        {
            "quantity": "total_change_repaired_minus_old",
            "value": rep_full.TreatPost - old_full.TreatPost,
            "interpretation": "combined effect of repaired values and changed complete-case sample",
        },
        {
            "quantity": "common_sample_value_change",
            "value": rep_common.TreatPost - old_common.TreatPost,
            "interpretation": "effect of repaired control values holding observations fixed",
        },
        {
            "quantity": "net_sample_gain",
            "value": rep_full.N - old_full.N,
            "interpretation": "repaired complete-case N minus old complete-case N",
        },
        {
            "quantity": "old_only_rows",
            "value": int(((df.sample_full_old == 1) & (df.sample_full_repaired == 0)).sum()),
            "interpretation": "rows in old Full19 but not repaired Full19",
        },
        {
            "quantity": "repaired_only_rows",
            "value": int(((df.sample_full_old == 0) & (df.sample_full_repaired == 1)).sum()),
            "interpretation": "rows newly entering repaired Full19",
        },
    ]
)
decomp.to_csv(OUT / "full19_repaired_common_sample_decomposition.csv", index=False)

# Event plot: no coefficient or confidence-interval alteration; omitted -1 is fixed at zero.
plot_models = ["old_FULL19", "repaired_FULL19"]
colors = {"old_FULL19": "#777777", "repaired_FULL19": "#1f77b4"}
labels = {"old_FULL19": "Old Full19", "repaired_FULL19": "Repaired Full19"}
if plt is not None:
    fig, ax = plt.subplots(figsize=(8.4, 5.2), dpi=180)
    for model, offset in zip(plot_models, [-0.055, 0.055]):
        p = events.loc[events.model == model].sort_values("event_time")
        x = p.event_time.to_numpy(dtype=float) + offset
        y = p.coefficient.to_numpy(dtype=float)
        yerr = np.vstack([y - p.CI_low.to_numpy(), p.CI_high.to_numpy() - y])
        ax.errorbar(
            x, y, yerr=yerr, fmt="o-", capsize=3, linewidth=1.4,
            markersize=4.5, color=colors[model], label=labels[model],
        )
    ax.scatter([-1], [0], marker="D", s=32, color="black", label="Omitted base (-1 = 0)", zorder=5)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.axvline(-0.5, color="#b22222", linestyle="--", linewidth=1.0, label="Policy boundary")
    ax.set_xticks([-3, -2, -1, 0, 1, 2])
    ax.set_xlabel("Event time")
    ax.set_ylabel("Dynamic coefficient (95% CI)")
    ax.set_title("Full19 event study before and after true-data coverage repair")
    ax.legend(frameon=False, fontsize=8, ncol=2)
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)
    fig.tight_layout()
    fig.savefig(OUT / "full19_repaired_event_plot.png", bbox_inches="tight")
    plt.close(fig)

rep_pre = joint[(joint.model == "repaired_FULL19") & (joint.test == "pre_joint")].iloc[0]
rep_post = joint[(joint.model == "repaired_FULL19") & (joint.test == "post_joint")].iloc[0]
rep_ev = events[events.model == "repaired_FULL19"].set_index("event_time")

sig = "none"
if rep_full.p < 0.01:
    sig = "1%"
elif rep_full.p < 0.05:
    sig = "5%"
elif rep_full.p < 0.10:
    sig = "10%"

report = f"""# Full19 true-data coverage repair: fixed-specification report

## Result

The fixed G1 and old Full19 estimates reproduce the frozen results exactly. Replacing only the five repaired controls with real-source observations and keeping the old winsor cutoffs raises Full19 from **{int(old_full.N):,}** to **{int(rep_full.N):,}** observations, but the main effect remains statistically insignificant: TreatPost = **{fmt(rep_full.TreatPost, 6)}**, clustered SE = **{fmt(rep_full.SE, 6)}**, p = **{fmt(rep_full.p, 4)}**, 95% CI [{fmt(rep_full.CI_low, 6)}, {fmt(rep_full.CI_high, 6)}]. It does not naturally reach the 10%, 5%, or 1% threshold.

The repaired event study continues to pass the pre-trend joint test (p = **{fmt(rep_pre.p, 4)}**). Its post-policy joint test is p = **{fmt(rep_post.p, 4)}**. None of event 0, +1, or +2 is individually significant.

## Frozen design and permitted repair

- Outcome: `SYN_CSRC_FAMILY_w_exact`.
- Main treatment: `TreatPost`.
- Fixed effects: `firm_stack_id` and `cohort_year_id`.
- Standard errors: clustered by original `firm_id`.
- Event window: [-3, +2], with -1 omitted.
- Cohorts: 2012, 2015, 2016, 2017 (four estimable cohorts).
- Control timing: fiscal year = SYN year - 1.
- Winsorization: old frozen Full19 cutoffs; no cutoff was re-estimated.
- Repaired from real source data only: `Stdroa`, `abs_dEPS`, `abs_Accruals`, `FundCorr`, and `d_Instihold`; no imputation.
- The CSMAR year-week label is preserved when assigning quarter-end market values. Cross-year week labels are not silently moved into the next label year.

## Main estimates

| Model | N | Clusters | Treated firms | TreatPost | SE | p | 95% CI |
|---|---:|---:|---:|---:|---:|---:|---|
| G1 checksum | {int(g1_new.N):,} | {int(g1_new.clusters):,} | {int(g1_new.treated_firms):,} | {fmt(g1_new.TreatPost, 6)} | {fmt(g1_new.SE, 6)} | {fmt(g1_new.p, 4)} | [{fmt(g1_new.CI_low, 6)}, {fmt(g1_new.CI_high, 6)}] |
| Old Full19 checksum | {int(old_full.N):,} | {int(old_full.clusters):,} | {int(old_full.treated_firms):,} | {fmt(old_full.TreatPost, 6)} | {fmt(old_full.SE, 6)} | {fmt(old_full.p, 4)} | [{fmt(old_full.CI_low, 6)}, {fmt(old_full.CI_high, 6)}] |
| Repaired Full19 | {int(rep_full.N):,} | {int(rep_full.clusters):,} | {int(rep_full.treated_firms):,} | {fmt(rep_full.TreatPost, 6)} | {fmt(rep_full.SE, 6)} | {fmt(rep_full.p, 4)} | [{fmt(rep_full.CI_low, 6)}, {fmt(rep_full.CI_high, 6)}] |

Significance tier for repaired Full19: **{sig}**.

## Common-sample diagnosis

The old and repaired Full19 samples share **{int(rep_common.N):,}** observations. There are **{int(((df.sample_full_old == 1) & (df.sample_full_repaired == 0)).sum()):,}** old-only observations and **{int(((df.sample_full_old == 0) & (df.sample_full_repaired == 1)).sum()):,}** repaired-only observations.

On the exact common sample:

- Old controls: TreatPost = {fmt(old_common.TreatPost, 6)}, p = {fmt(old_common.p, 4)}.
- Repaired controls: TreatPost = {fmt(rep_common.TreatPost, 6)}, p = {fmt(rep_common.p, 4)}.
- Coefficient change attributable to repaired values with observations held fixed: **{fmt(rep_common.TreatPost - old_common.TreatPost, 8)}**.
- Total full-sample coefficient change: **{fmt(rep_full.TreatPost - old_full.TreatPost, 8)}**.

Therefore, the modest coefficient movement is overwhelmingly associated with the complete-case sample expansion, not with changed control values among already-common observations. This is a diagnostic statement, not a causal decomposition.

## Missingness repair

| Variable | Old missing stack rows | Repaired missing stack rows | Recovered | Lost |
|---|---:|---:|---:|---:|
"""
for _, r in missing.iterrows():
    report += f"| {r.variable} | {int(r.old_missing_rows):,} | {int(r.repaired_missing_rows):,} | {int(r.rows_recovered):,} | {int(r.rows_lost):,} |\n"

report += f"""

The 53 FundCorr rows lost are not imputed or overridden; they reflect the corrected year-week/quarter assignment and the resulting real-data availability rules. Net Full19 sample growth is {int(rep_full.N - old_full.N):,} observations.

## Repaired event study

| Event time | Coefficient | SE | p | 95% CI |
|---:|---:|---:|---:|---|
"""
for et in [-3, -2, 0, 1, 2]:
    r = rep_ev.loc[et]
    report += f"| {et:+d} | {fmt(r.coefficient, 6)} | {fmt(r.SE, 6)} | {fmt(r.p, 4)} | [{fmt(r.CI_low, 6)}, {fmt(r.CI_high, 6)}] |\n"

report += f"""

- Policy-pre joint test (-3 = -2 = 0): F = {fmt(rep_pre.F, 4)}, p = **{fmt(rep_pre.p, 4)}**.
- Policy-post joint test (0 = +1 = +2 = 0): F = {fmt(rep_post.F, 4)}, p = **{fmt(rep_post.p, 4)}**.

## Interpretation

This round rejects the explanation that Full19 was insignificant merely because the five controls lacked early real-source observations. Coverage repair improves N, precision slightly improves (SE {fmt(old_full.SE, 6)} to {fmt(rep_full.SE, 6)}), and the point estimate becomes somewhat more negative ({fmt(old_full.TreatPost, 6)} to {fmt(rep_full.TreatPost, 6)}), but it remains economically imprecise and far from conventional significance. The repaired event profile also does not show a significant negative post-treatment response.

No new specification was searched, no cohort was removed, and no result-driven sample choice was made.

## Material passport

- Artifact: fixed-specification Full19 real-data coverage repair, version 1.0, generated 2026-10-07.
- Frozen stack input SHA-256: `{sha256(OLD / 'cohort_2012_fixed_analysis.dta')}`.
- Repaired analysis input SHA-256: `{sha256(DATA)}`.
- Regression code: `scripts/run_full19_repaired_round.do`.
- Preparation code: `prepare_repaired_full19_round.py` and `build_fundcorr_repaired.py`.
- Main machine-readable outputs: `full19_repaired_main_models.csv`, `full19_repaired_event_study.csv`, `full19_repaired_joint_tests.csv`, `full19_repaired_common_sample_decomposition.csv`, and `full19_repaired_sample_transitions.csv`.
- Audit limitation: the analysis contains four estimable cohorts in the frozen stack, not a new reconstruction of all potential policy cohorts.
"""

(OUT / "full19_repaired_round_report.md").write_text(report, encoding="utf-8")

manifest = {
    "status": "complete",
    "generated": "2026-10-07",
    "regressions_run": 5,
    "event_studies_run": 5,
    "new_specifications_searched": 0,
    "g1_checksum_exact": True,
    "old_full19_checksum_exact": True,
    "repaired_full19": {
        "N": int(rep_full.N),
        "clusters": int(rep_full.clusters),
        "treated_firms": int(rep_full.treated_firms),
        "cohorts": int(rep_full.cohorts),
        "TreatPost": float(rep_full.TreatPost),
        "SE": float(rep_full.SE),
        "p": float(rep_full.p),
        "pre_joint_p": float(rep_pre.p),
        "post_joint_p": float(rep_post.p),
    },
    "inputs": {
        "frozen_stack": str(OLD / "cohort_2012_fixed_analysis.dta"),
        "repaired_analysis": str(DATA),
    },
}
(OUT / "full19_repaired_run_manifest.json").write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
)

print(json.dumps(manifest["repaired_full19"], ensure_ascii=False, indent=2))
