# 本轮仅审计，不重跑

阅读 `outputs/H8_DR估计差异与前趋势来源审计报告.md`。

本轮没有回归、辅助回归、新p值、SYN重算、插补、原始/分析数据修改或删样本。行业/公司贡献是固定权重下的审计分解，不代表删掉这些记录后的估计结果；没有据此选择任何样本。

完整ST下载目标为 `outputs/ST_download_target_candidates922_private.csv`，来自原923家ST筛选前候选，601607继续暂缓。`ST_download_target_DR513_private.csv` 是仅核验当前DR保留公司的最小范围，不能替代原候选池筛选审计。行业实施日期记录与年度快照必须区分。

规范执行目录：`/Users/macpro/Documents/New project/huang_H8_DR_source_audit_20261109`。桌面论文项目同名目录只作归档。脚本含本机来源与工作区相邻路径，不应直接在归档位置执行；审计已完成，无需重新启动。原H8、DR和G1均已保护。

private文件及公司级来源、权重、影响函数含CSMAR衍生数据，不自动公开GitHub。目录中没有新分析DTA。
