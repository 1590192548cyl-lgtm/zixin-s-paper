import io,json,re
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from pypdf import PdfReader
O=Path(__file__).resolve().parent
C=O/'evidence_cache'
def get(u,d=None):
 with urlopen(Request(u,data=d,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.cninfo.com.cn/'}),timeout=30) as r:return r.read()
metadata=json.loads((O/'boundary_filing_metadata.json').read_text())
for code,dates in [('600029','2009-01-01~2009-01-31'),('600841','2008-12-20~2009-01-31')]:
 d=urlencode(dict(pageNum=1,pageSize=100,tabName='fulltext',stock=f'{code},gssh0{code}',searchkey='',column='sse',category='',seDate=dates,isHLtitle='true')).encode()
 r=json.loads(get('https://www.cninfo.com.cn/new/hisAnnouncement/query',d))
 aa=[dict(title=a['announcementTitle'],url='https://static.cninfo.com.cn/'+a['adjunctUrl']) for a in (r.get('announcements') or [])]
 metadata.append(dict(firm_id=code,date_range=dates,total=r.get('totalAnnouncement'),announcements=aa))
(O/'boundary_filing_metadata_extended.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
out=[]
for group in metadata:
 for a in group.get('announcements',[]):
  # Include only named appointment/resignation/governance notices, not capital transactions.
  if not re.search('董事会|辞职|选举|任职|聘任',a['title']):continue
  code=group['firm_id'];u=a['url'];id=u.split('/')[-1].split('.')[0]
  p=C/f'{code}_notice_{id}.pdf';t=p.with_suffix('.txt')
  if not p.exists():p.write_bytes(get(u))
  if not t.exists():
   r=PdfReader(p);pages=[]
   for i,page in enumerate(r.pages):
    if i>=15:break
    s=page.extract_text();pages.append(f'\n===== PDF PAGE {i+1} =====\n'+s)
   t.write_text('\n'.join(pages),encoding='utf-8')
  out.append(dict(firm_id=code,title=a['title'],url=u,pdf_path=str(p),text_path=str(t)))
  print(code,a['title'],id,flush=True)
(O/'boundary_notice_retrieval.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
