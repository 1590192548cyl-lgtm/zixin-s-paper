clear all
set more off
local out "/Users/macpro/Documents/New project/huang_week_calendar_repair_20261103/fixed_rerun/outputs"
import delimited "`out'/event_results_comparison.csv", varnames(1) case(preserve) clear
set obs 52
replace version="before" in 49/50
replace version="corrected" in 51/52
replace model="H0" in 49
replace model="H8" in 50
replace model="H0" in 51
replace model="H8" in 52
replace event_time=-1 if missing(event_time)
replace coefficient=0 if event_time==-1
sort model version event_time
twoway (rcap CI_low CI_high event_time if version=="before",lcolor(gs10)) (connected coefficient event_time if version=="before",lcolor(gs8) mcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if version=="corrected",lcolor(navy)) (connected coefficient event_time if version=="corrected",lcolor(navy) mcolor(navy)), by(model,cols(2) title("Calendar correction: fixed H0/H8",size(medium)) note("95% firm-clustered CI. Only four authorized 2016 records removed. Not author-confirmed replication.",size(vsmall)) legend(position(6))) xlabel(-6(1)6,labsize(small)) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs10)) xtitle("Event time (2014 = -1 reference)",size(small)) ytitle("SYN coefficient",size(small)) legend(order(2 "Before" 4 "Corrected") rows(1)) graphregion(color(white)) xsize(12) ysize(5)
graph export "`out'/event_study_before_after.png", width(2400) replace
display "PLOT_ONLY_COMPLETE"
exit, clear
