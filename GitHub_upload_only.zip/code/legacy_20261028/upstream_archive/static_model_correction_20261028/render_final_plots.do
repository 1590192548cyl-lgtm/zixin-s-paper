version 18
clear all
set more off
capture log close _all
local out "/Users/macpro/Documents/New project/static_model_correction_20261028_work/outputs"
log using "`out'/plot_render.log", text replace
import delimited using "`out'/fixed_W2_event_results.csv", clear varnames(1) case(preserve)
set obs `=_N+2'
local lastrow=_N
local beforelast=_N-1
replace model="original_W2" in `lastrow'
replace model="corrected_W2" in `beforelast'
replace event_time=-1 if missing(event_time)
replace coefficient=0 if event_time==-1
sort model event_time
twoway (rcap CI_low CI_high event_time if model=="original_W2", lcolor(gs10)) (connected coefficient event_time if model=="original_W2", mcolor(gs8) lcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if model=="corrected_W2", lcolor(navy)) (connected coefficient event_time if model=="corrected_W2", mcolor(navy) lcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-1 reference)") ytitle("SYN coefficient") legend(order(2 "Original W2" 4 "Corrected W2") position(6) rows(1) size(small) region(lstyle(none))) graphregion(color(white)) title("Fixed weighted stacked DID: sample correction", size(medium)) note("95% firm-clustered confidence intervals; original weights retained", size(small)) xsize(8) ysize(5)
graph export "`out'/static_W2_event_comparison.png", width(2200) replace

import delimited using "`out'/sa_full_event_corrected_results.csv", clear varnames(1) case(preserve)
set obs `=_N+1'
replace event_time=-1 in L
replace coefficient=0 in L
sort event_time
twoway (rcap CI_low CI_high event_time, lcolor(navy)) (connected coefficient event_time, mcolor(navy) lcolor(navy)), xlabel(-10(2)12) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-1 reference)") ytitle("Market-model SYN coefficient") legend(off) graphregion(color(white)) title("Sun-Abraham diagnostic: full supported event path", size(medium)) note("Full model; cohort composition varies at distant horizons; 95% pointwise CI", size(small)) xsize(8) ysize(5)
graph export "`out'/sa_full_path_diagnostic.png", width(2200) replace
keep if inrange(event_time,-3,2)
twoway (rcap CI_low CI_high event_time, lcolor(navy)) (connected coefficient event_time, mcolor(navy) lcolor(navy)), xlabel(-3(1)2) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs8)) xtitle("Event time (-1 reference)") ytitle("Market-model SYN coefficient") legend(off) graphregion(color(white)) title("Sun-Abraham diagnostic: reference-period correction", size(medium)) note("All supported event times modeled; only [-3,+2] displayed; 95% pointwise CI", size(small)) xsize(8) ysize(5)
graph export "`out'/sa_corrected_event_plot.png", width(2200) replace
log close
exit, clear
