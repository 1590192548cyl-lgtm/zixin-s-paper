"""Save separate audit findings only. No model data imports, merges or recodes."""
import csv,hashlib,json,resource,subprocess
from collections import Counter
from pathlib import Path
from openpyxl import load_workbook
O=Path(__file__).resolve().parent;C=O/'evidence_cache'
dec=json.loads((O/'decisions.json').read_text())
primary={r['firm_id']:r for r in json.loads((O/'primary_report_retrieval.json').read_text())}
notes=json.loads((O/'boundary_notice_retrieval.json').read_text())
raw={r['firm_id']:r for r in csv.DictReader((O/'downloaded_names_2008_snapshot.csv').open(encoding='utf-8-sig'))}
assert len(dec)==18 and len(primary)==18 and len(raw)==18 and '601607' not in raw
assert Counter(r['decision'] for r in dec)=={'确认不兼任':7,'待核验':11}
def writecsv(name,rr):
 with (O/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
rows=[]
for r in dec:
 code=r['firm_id'];src=primary[code];assert src['status']=='retrieved_primary'
 row=dict(股票代码=code,公司简称=r['company'],核验截止日期='2008-12-31',
  下载表董事长原值=raw[code]['chairman_raw'],下载表总经理原值=raw[code]['manager_raw'],
  下载表Excel行号=raw[code]['source_excel_row'],
  核验董事长或主席=r['chairman_at_cutoff'],核验总经理或总裁=r['manager_at_cutoff'],
  兼任核验结论=r['decision'],判断依据=r['reason'],证据定位=r['evidence'],
  年报原文链接=src['source_url'],任免公告链接=';'.join(n['url'] for n in notes if n['firm_id']==code),
  尚需证据=r['needed'],仅审计未写入分析数据=True)
 rows.append(row)
writecsv('18家公司2008年末两职核验.csv',rows)
writecsv('7家已确认不兼任.csv',[r for r in rows if r['兼任核验结论']=='确认不兼任'])
writecsv('11家仍需任免证据.csv',[r for r in rows if r['兼任核验结论']=='待核验'])
source=Path(next(iter(raw.values()))['source_path'])
w=load_workbook(source,read_only=True,data_only=True);s=w.worksheets[0];s.reset_dimensions()
check=[x for x in s.iter_rows(values_only=True) if len(x)>1 and x[1]=='2008-12-31' and str(x[0]) in raw]
assert len(check)==18 and all(bool(x[2])!=bool(x[3]) for x in check)
w.close()
protected=json.loads((O/'protected_before.json').read_text())
after=[dict(path=r['path'],sha256=sha(r['path'])) for r in protected]
assert after==protected
prior=json.loads((O/'execution_audit.json').read_text())
assert sha(source)==prior['source_sha256']
prior.update(protected_changes=[],input_changes=[],all_18_reviewed=True,
 confirmed_not_dual=7,confirmed_dual=0,unresolved=11,
 no_formal_Dual_variable_created=True,no_analysis_data_modified=True,
 independent_XLSX_check={'2008_rows':18,'both_names_present':0,'single_name_present':18},
 note='Unresolved is not evidence of non-duality. No unresolved record was converted to zero.',
 finalization_peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576)
(O/'final_execution_audit.json').write_text(json.dumps(prior,ensure_ascii=False,indent=2))
(O/'protected_after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2))
manifest=[]
for p in sorted(C.glob('*')):
 if p.suffix.lower() in {'.pdf','.txt'}:manifest.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
writecsv('evidence_manifest.csv',manifest)
# Only four additional small page renders, one subprocess at a time.
for code,page in [('600171',11),('600452',10),('600761',8),('600841',7)]:
 png=C/f'{code}_page{page}.png'
 if not png.exists():subprocess.run(['pdftoppm','-f',str(page),'-l',str(page),'-scale-to','1600','-singlefile','-png',str(C/f'{code}_2008_primary.pdf'),str(png.with_suffix(''))],check=True,stderr=subprocess.DEVNULL,timeout=30)
print(json.dumps(dict(reviewed=18,confirmed_not_dual=7,confirmed_dual=0,unresolved=11,protected_unchanged=len(after),independent_read_check='18 rows, each exactly one name missing',memory_MB=prior['finalization_peak_memory_MB']),ensure_ascii=False))
