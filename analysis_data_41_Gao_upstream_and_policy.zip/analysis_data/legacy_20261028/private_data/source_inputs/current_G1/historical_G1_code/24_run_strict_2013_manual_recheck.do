version 18.0
clear all
set more off
set varabbrev off
set maxvar 20000

local out "/Users/macpro/Documents/New project/gao_exact_replication_work/outputs/official_table3_business_manual_recheck"
capture log close _all
log using "`out'/strict_2013_manual_recheck_models.log", text replace

use "`out'/official_table3_stack_analysis.dta", clear
isid stack_id firm_id annual_report_year
assert inrange(event_time,-3,2)
assert annual_report_year==syn_year-1
assert TreatPost==treated_in_stack*Post
assert inlist(cohort_report_year,2013,2015,2016,2017)

local G1 "Size_w_exact MB_parent_w_exact Lev_w_exact"
local FULL "Size_w_exact MB_parent_w_exact Lev_w_exact Stdroa_w_exact abs_dEPS_w_exact abs_Accruals_w_exact Loss Length_MDA_w_exact Length_AR_w_exact Stdret_w_exact FundCorr_w_exact d_Instihold_w_exact Instihold_w_exact Analyst_exact_w_exact Indsize_broad_w_exact Subs_exact_w_exact Big4 Tophold_w_exact Tophold2_w_exact"

* Frozen Gao Appendix Table VIII normalization: t-3 is omitted.
capture drop D_m2 D_m1 D_0 D_p1 D_p2
gen byte D_m2=treated_in_stack==1 & event_time==-2
gen byte D_m1=treated_in_stack==1 & event_time==-1
gen byte D_0 =treated_in_stack==1 & event_time==0
gen byte D_p1=treated_in_stack==1 & event_time==1
gen byte D_p2=treated_in_stack==1 & event_time==2
foreach v in D_m2 D_m1 D_0 D_p1 D_p2 {
    assert inlist(`v',0,1)
    assert `v'==0 if treated_in_stack==0
}

tempname mh eh jh
tempfile models events joint
postfile `mh' str32 model str24 sample long N_before N clusters treated_firms cohorts ///
    double TreatPost SE t p CI_low CI_high using `models', replace
postfile `eh' str32 model str24 sample int event_time long N clusters treated_firms cohorts ///
    double coefficient SE t p CI_low CI_high using `events', replace
postfile `jh' str32 model str24 sample str12 test long N clusters double F p using `joint', replace
global T3_MAIN_POST "`mh'"
global T3_EVENT_POST "`eh'"
global T3_JOINT_POST "`jh'"

capture program drop runmain
program define runmain
    version 18.0
    syntax, Model(string) Sample(name) [Controls(string)]
    quietly count if `sample'==1
    local nb=r(N)
    quietly reghdfe SYN_CSRC_FAMILY_w_exact TreatPost `controls' if `sample'==1, ///
        absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    local n=e(N)
    local nc=e(N_clust)
    local b=_b[TreatPost]
    local se=_se[TreatPost]
    local tv=`b'/`se'
    local pv=2*ttail(e(df_r),abs(`tv'))
    local crit=invttail(e(df_r),.025)
    local lo=`b'-`crit'*`se'
    local hi=`b'+`crit'*`se'
    tempvar es tagt tagc
    gen byte `es'=e(sample)
    egen byte `tagt'=tag(firm_id) if `es' & treated_in_stack==1
    quietly count if `tagt'==1
    local nt=r(N)
    egen byte `tagc'=tag(cohort_report_year) if `es'
    quietly count if `tagc'==1
    local ng=r(N)
    post $T3_MAIN_POST ("`model'") ("`sample'") (`nb') (`n') (`nc') (`nt') (`ng') ///
        (`b') (`se') (`tv') (`pv') (`lo') (`hi')
    drop `es' `tagt' `tagc'
end

capture program drop runevent
program define runevent
    version 18.0
    syntax, Model(string) Sample(name) [Controls(string)]
    quietly reghdfe SYN_CSRC_FAMILY_w_exact D_m2 D_m1 D_0 D_p1 D_p2 `controls' if `sample'==1, ///
        absorb(firm_stack_id cohort_year_id) vce(cluster firm_id)
    local n=e(N)
    local nc=e(N_clust)
    tempvar es tagt tagc
    gen byte `es'=e(sample)
    egen byte `tagt'=tag(firm_id) if `es' & treated_in_stack==1
    quietly count if `tagt'==1
    local nt=r(N)
    egen byte `tagc'=tag(cohort_report_year) if `es'
    quietly count if `tagc'==1
    local ng=r(N)
    foreach spec in "D_m2 -2" "D_m1 -1" "D_0 0" "D_p1 1" "D_p2 2" {
        gettoken v et : spec
        local b=_b[`v']
        local se=_se[`v']
        local tv=`b'/`se'
        local pv=2*ttail(e(df_r),abs(`tv'))
        local crit=invttail(e(df_r),.025)
        local lo=`b'-`crit'*`se'
        local hi=`b'+`crit'*`se'
        post $T3_EVENT_POST ("`model'") ("`sample'") (`et') (`n') (`nc') (`nt') (`ng') ///
            (`b') (`se') (`tv') (`pv') (`lo') (`hi')
    }
    quietly test D_m2 D_m1
    post $T3_JOINT_POST ("`model'") ("`sample'") ("pre_joint") (`n') (`nc') (r(F)) (r(p))
    quietly test D_0 D_p1 D_p2
    post $T3_JOINT_POST ("`model'") ("`sample'") ("post_joint") (`n') (`nc') (r(F)) (r(p))
    drop `es' `tagt' `tagc'
end

runmain, model(M0_no_controls) sample(sample_formula_base)
runmain, model(G1_fixed) sample(sample_g1) controls("`G1'")
runmain, model(FULL19_fixed) sample(sample_full) controls("`FULL'")

runevent, model(M0_no_controls) sample(sample_formula_base)
runevent, model(G1_fixed) sample(sample_g1) controls("`G1'")
runevent, model(FULL19_fixed) sample(sample_full) controls("`FULL'")

postclose `mh'
postclose `eh'
postclose `jh'
preserve
use `models', clear
export delimited using "`out'/strict_2013_manual_recheck_main_models.csv", replace
restore
preserve
use `events', clear
export delimited using "`out'/strict_2013_manual_recheck_event_study.csv", replace
restore
preserve
use `joint', clear
export delimited using "`out'/strict_2013_manual_recheck_joint_tests.csv", replace
restore

log close
exit, clear
