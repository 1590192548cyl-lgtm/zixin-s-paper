from pathlib import Path
import pandas as pd
W=Path(__file__).resolve().parent;O=W/'outputs'
def table(d,cols):
 lines=['|'+'|'.join(cols)+'|','|'+'|'.join(['---']*len(cols))+'|']
 for _,r in d.iterrows():lines.append('|'+'|'.join(f'{r[c]:.6f}' if isinstance(r[c],float) else str(r[c]) for c in cols)+'|')
 return '\n'.join(lines)
m=pd.read_csv(O/'static_results_comparison.csv');j=pd.read_csv(O/'joint_tests_comparison.csv');e=pd.read_csv(O/'event_results_comparison.csv');assert (O/'event_full_vs_posthoc.png').exists()
report=f'''# 黄文±3期：2012—2018文献导向事后对照

日期：2026-11-03。**这是文献导向的事后对照，不是事前预注册、不是作者程序已确认的完整复现。** 已观察过全期结果后，由用户明确授权固定2012—2018估计窗口。全期结果及原G1均保留，不按显著性挑选窗口。

## 结论

2012—2018窗口中，H0/H8政策前两项联合均不能拒绝为零；但两个静态系数均未达到10%，四项政策后联合也均不显著。这说明短窗口未检出事前差异，**不等于政策因果效应或平行趋势假定已获证明**。不能只引用该窗口的事前p值，同时引用全期的静态显著性，将不同估计拼成一个“通过的主回归”。

## 固定设置

唯一输入为周历修复后的全期固定分析数据。仅在原H0/H8各自实际估计公司年中截取2012—2018；不恢复其他记录、不新增ST规则、不改变行业分组。事件0为2015，2014为-1唯一基准，实际估计-3、-2、0、+1、+2、+3。窗口外年份不参与此次估计，未并入基准或合并尾期。

H0无控制；H8仍为Size_w、Age_w、Lev_w、Cent_w、Top10_w、Dual、Board_w、Big4。公司FE、年度FE、公司聚类不变。SYN原值、周历修复值、八控制及既定缩尾值逐条核验一致；没有重新缩尾、重算SYN或扫描年报。

黄文图1仅展示±3期，但主样本写2009—2021、未明确尾期处理。本对照明确实施截样本2012—2018，不能声称作者必然也如此实现。POSTHOC_PLAN.md记录估计前固定的本次对照规则，但不抹去事后增加方案这一事实。

## 静态回归对照

{table(m,['window','model','N','clusters','treated_firms','coefficient','SE','t','p','CI_low','CI_high'])}

两窗口均648家公司，其中439家处理、209家对照；新窗口H0为4,318条，H8为4,170条。窗口截取后没有额外singleton删除或公司剔除，静态与对应动态实际样本完全相同。

H8点估计绝对值由约0.1013变为0.0567，SE由0.0408增至0.0522；H0绝对值亦变小、SE变大。因此不能只说“不显著是样本变少”，点估计和精度都有变化。不同时间窗还改变政策后期限构成、固定效应和控制斜率的估计，不能把全部差异简单归因为去掉2011一年的影响。

## 联合检验对照

{table(j,['window','model','test','F','df_num','df_den','p'])}

解释：全期pre_all为2009—2013五项联合；pre_near为2012/2013两项联合。新窗口pre_all只有2012/2013两项。全期post_all为2015—2021七项，新窗口为2015—2018四项。因此全期与窗口pre_all/post_all并非同一原假设，不能直接按哪个p大来判规格优劣。

窗口政策前：H0 p=0.464808，H8 p=0.503591；窗口政策后：H0 p=0.353421，H8 p=0.506313。全期对应邻近两期pre_near约0.480556、0.534451，两项在各自模型里均不拒绝。全期完整事前p约0.006179、0.001171的已知拒绝结果保留，不因窗口对照而删除或宣布无效。

## 窗口完整动态结果

{table(e[e.window.eq('posthoc_2012_2018')],['model','event_time','coefficient','SE','p','CI_low','CI_high'])}

H8政策当年、+1、+2、+3系数分别约-0.0795、-0.1284、-0.1062、-0.1504；前三期均未达到10%，+3 p约0.0934，仅达到10%，未达到5%。H0的+1、+3分别p约0.0977、0.0543，也仅在10%水平显著；不能据单期近阈值表现筛选年份，也不能忽略不显著的事后联合检验。所有六项均可估计，CI如实保留，未另作多重检验校正。

event_full_vs_posthoc.png同时绘制全期所有事件系数和新窗口系数，2014置0作为基准，不伪造其CI。全期2011等窗外系数仍在图中，不隐藏已知诊断。

## 样本与输入核验

- 新窗口实际键恰为原各模型实际样本与2012—2018的交集，没有按系数、p或行业贡献剔除记录。
- 正式全期数据中的2011记录没有被删除或修改；本次不使用2011仅因用户明确指定的事后估计窗口。
- 原八控制、Treat、Post、TreatPost、event_time及所有其他既有值与输入逐条相等；各年度均有处理/对照。
- 静态和对应事件样本完全相同。样本表actual_sample_audit.csv、window_input_keys_private.csv、H0/H8_sample_private.csv保留核验依据。
- protected_inputs.json/input_integrity_after.json记录全期数据/结果/估计存档、原G1和事后计划的指纹，全部一致。
- 仅运行2次静态及2次动态，plot.do只画图，compare.py/report.py只做核验与汇总；无其他规格。Stata单线程，直接复用约8千行来源面板，不读整库周文件或年报。

## 保留文件及停止

主要输出：static_results_comparison.csv、event_results_comparison.csv、joint_tests_comparison.csv、event_full_vs_posthoc.png、window_analysis.dta、四份ster、fixed_models.log、POSTHOC_PLAN.md以及样本键和输入指纹。含private及分析DTA/ster内容受CSMAR许可约束，不直接公开GitHub。

**按约定完成后停止。** 本轮不能得出“截成黄文窗口后主回归显著”或“黄文已完整复现成功”。结果需要按不同估计范围并列呈现，不拼接窗口检验和全期静态效应，也不自动改论文正式主结果。
'''
(O/'window_comparison_report.md').write_text(report,encoding='utf-8');print('REPORT_COMPLETE')
