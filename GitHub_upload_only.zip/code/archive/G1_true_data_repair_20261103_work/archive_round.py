from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent
D=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/G1_true_data_repair_20261103')
assert not D.exists(), 'Refuse to overwrite an existing audit directory'
s=json.loads((W/'outputs/continuation_status.json').read_text())
assert s['regressions_run']==0 and s['losses_explained']==2052
shutil.copytree(W/'outputs',D)
(D/'code').mkdir()
names=['REPAIR_PLAN.md','CONTINUE_AFTER_DOWNLOAD.md','01_audit_attrition.py','02_trace_financial_sources.py',
       '03_audit_early_industry_and_control_timing.py','04_compile_status_and_download_list.py','archive_round.py']
for n in names:shutil.copy2(W/n,D/'code'/n)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for p in (W/'outputs').iterdir():
    if p.is_file():
        assert sha(p)==sha(D/p.name)
        rows.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(D/p.name)})
for n in names:assert sha(W/n)==sha(D/'code'/n)
(D/'archive_manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'archive':str(D),'output_files':len(rows),'verified_bytes':sum(r['bytes'] for r in rows),
                  'code_and_plan_files':len(names),'regressions_run':0},ensure_ascii=False))
