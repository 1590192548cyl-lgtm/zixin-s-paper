version 18.0
clear all
set more off
set scheme s2color

local out "/Users/macpro/Documents/New project/gao_exact_replication_work/outputs/targeted_supplement/control_coverage_repair/full19_repaired_round"
import delimited using "`out'/full19_repaired_event_study.csv", clear varnames(1)
keep if inlist(model,"old_FULL19","repaired_FULL19")
local n=_N
set obs `=`n'+2'
replace model="old_FULL19" in `=`n'+1'
replace model="repaired_FULL19" in `=`n'+2'
replace event_time=-1 in `=`n'+1'/`=`n'+2'
replace coefficient=0 in `=`n'+1'/`=`n'+2'
replace ci_low=0 in `=`n'+1'/`=`n'+2'
replace ci_high=0 in `=`n'+1'/`=`n'+2'
gen double xpos=event_time+cond(model=="old_FULL19",-.055,.055)
sort model event_time

twoway ///
    (rcap ci_low ci_high xpos if model=="old_FULL19", lcolor(gs8)) ///
    (connected coefficient xpos if model=="old_FULL19", mcolor(gs8) lcolor(gs8) msymbol(O)) ///
    (rcap ci_low ci_high xpos if model=="repaired_FULL19", lcolor(navy)) ///
    (connected coefficient xpos if model=="repaired_FULL19", mcolor(navy) lcolor(navy) msymbol(D)), ///
    yline(0, lcolor(black) lwidth(thin)) ///
    xline(-.5, lcolor(maroon) lpattern(dash)) ///
    xlabel(-3 -2 -1 0 1 2) ///
    xtitle("Event time") ytitle("Dynamic coefficient (95% CI)") ///
    title("Full19 event study before and after coverage repair") ///
    legend(order(2 "Old Full19" 4 "Repaired Full19") rows(1)) ///
    graphregion(color(white)) plotregion(color(white))

graph export "`out'/full19_repaired_event_plot.png", width(1600) replace
exit, clear
