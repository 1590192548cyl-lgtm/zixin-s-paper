#!/usr/bin/env python3
"""Low-memory audit of classification coverage in STK_IndustryClassAnl.xlsx."""

from __future__ import annotations

import argparse
import csv
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET


NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
TARGET_YEARS = set(range(2009, 2026))


def cell_value(cell: ET.Element, shared_strings: list[str]) -> str:
    cell_type = cell.attrib.get("t", "")
    if cell_type == "inlineStr":
        return "".join(node.text or "" for node in cell.iter(f"{NS}t"))
    value_node = cell.find(f"{NS}v")
    if value_node is None or value_node.text is None:
        return ""
    value = value_node.text
    if cell_type == "s":
        return shared_strings[int(value)]
    return value


def read_shared_strings(book: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in book.namelist():
        return []
    strings: list[str] = []
    with book.open("xl/sharedStrings.xml") as stream:
        for event, node in ET.iterparse(stream, events=("end",)):
            if node.tag == f"{NS}si":
                strings.append("".join(part.text or "" for part in node.iter(f"{NS}t")))
                node.clear()
    return strings


def column_number(reference: str) -> int:
    letters = "".join(ch for ch in reference if ch.isalpha())
    number = 0
    for ch in letters:
        number = number * 26 + ord(ch.upper()) - ord("A") + 1
    return number


def extract_year(end_date: str) -> int | None:
    text = end_date.strip()
    if len(text) < 4 or not text[:4].isdigit():
        return None
    return int(text[:4])


def stream_records(source: Path):
    with zipfile.ZipFile(source) as book:
        shared_strings = read_shared_strings(book)
        with book.open("xl/worksheets/sheet1.xml") as stream:
            headers: dict[int, str] = {}
            for event, row in ET.iterparse(stream, events=("end",)):
                if row.tag != f"{NS}row":
                    continue
                row_number = int(row.attrib.get("r", "0"))
                values: dict[int, str] = {}
                for cell in row.findall(f"{NS}c"):
                    values[column_number(cell.attrib.get("r", ""))] = cell_value(cell, shared_strings).strip()
                if row_number == 1:
                    headers = values
                elif row_number >= 4:
                    record = {headers[col]: value for col, value in values.items() if col in headers}
                    yield record
                row.clear()


def yn(value: bool) -> str:
    return "是" if value else "否"


def audit(source: Path) -> list[dict[str, object]]:
    names: dict[str, set[str]] = defaultdict(set)
    firms: dict[str, dict[int, set[str]]] = defaultdict(lambda: defaultdict(set))
    industries: dict[str, dict[int, set[str]]] = defaultdict(lambda: defaultdict(set))
    row_counts: dict[str, int] = defaultdict(int)

    required = {
        "InstitutionID",
        "EndDate",
        "IndustryClassificationID",
        "IndustryClassification",
        "IndustryCode2",
    }
    first_record = True
    for record in stream_records(source):
        if first_record:
            missing = required.difference(record)
            if missing:
                raise RuntimeError(f"Missing required columns: {sorted(missing)}")
            first_record = False
        standard_id = record.get("IndustryClassificationID", "").strip()
        standard_name = record.get("IndustryClassification", "").strip()
        year = extract_year(record.get("EndDate", ""))
        firm_id = record.get("InstitutionID", "").strip()
        industry_code = record.get("IndustryCode2", "").strip()
        if not standard_id or year is None:
            continue
        row_counts[standard_id] += 1
        if standard_name:
            names[standard_id].add(standard_name)
        if firm_id:
            firms[standard_id][year].add(firm_id)
        if industry_code:
            industries[standard_id][year].add(industry_code)

    results: list[dict[str, object]] = []
    for standard_id in sorted(row_counts):
        name_values = sorted(names[standard_id])
        if len(name_values) != 1:
            raise RuntimeError(
                f"{standard_id} has {len(name_values)} IndustryClassification values: {name_values}"
            )
        years = sorted(set(firms[standard_id]) | set(industries[standard_id]))
        if not years:
            continue
        year_set = set(years)
        full = TARGET_YEARS.issubset(year_set)
        has_2009 = 2009 in year_set
        has_2025 = 2025 in year_set
        endpoint_gap = has_2009 and has_2025 and not full
        name = name_values[0]
        related = "证监会" in name or "上市公司协会" in name
        flags = []
        if full:
            flags.append("完整覆盖2009—2025")
        if endpoint_gap:
            flags.append("覆盖端点但中间断年")
        if standard_id == "P0207":
            flags.append("P0207")
        if related:
            flags.append("证监会相关")
        results.append(
            {
                "IndustryClassificationID": standard_id,
                "IndustryClassification": name,
                "earliest_year": min(years),
                "latest_year": max(years),
                "actual_coverage_year_count": len(years),
                "continuous_coverage_2009_2025": yn(full),
                "average_firms_per_year": round(
                    statistics.fmean(len(firms[standard_id].get(year, set())) for year in years), 2
                ),
                "average_industries_per_year": round(
                    statistics.fmean(len(industries[standard_id].get(year, set())) for year in years), 2
                ),
                "has_2009": yn(has_2009),
                "has_2025": yn(has_2025),
                "spans_2009_2025_with_gaps": yn(endpoint_gap),
                "csrc_related": yn(related),
                "special_flag": "；".join(flags),
                "actual_years": ",".join(str(year) for year in years),
                "source_rows": row_counts[standard_id],
            }
        )
    return results


def write_csv(path: Path, results: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)


def md_table(results: list[dict[str, object]]) -> list[str]:
    lines = [
        "| ID | 分类名称（原字段） | 最早年 | 最晚年 | 年数 | 连续覆盖2009—2025 | 平均公司数/年 | 平均行业数/年 | 2009 | 2025 | 特别标记 |",
        "|---|---|---:|---:|---:|:---:|---:|---:|:---:|:---:|---|",
    ]
    for row in results:
        lines.append(
            "| {IndustryClassificationID} | {IndustryClassification} | {earliest_year} | "
            "{latest_year} | {actual_coverage_year_count} | {continuous_coverage_2009_2025} | "
            "{average_firms_per_year:.2f} | {average_industries_per_year:.2f} | "
            "{has_2009} | {has_2025} | {special_flag} |".format(**row)
        )
    return lines


def write_markdown(path: Path, source: Path, results: list[dict[str, object]]) -> None:
    full = [r for r in results if r["continuous_coverage_2009_2025"] == "是"]
    gaps = [r for r in results if r["spans_2009_2025_with_gaps"] == "是"]
    csrc = [r for r in results if r["csrc_related"] == "是"]
    p0207 = next(r for r in results if r["IndustryClassificationID"] == "P0207")

    lines = [
        "# IndustryClassificationID 实际覆盖审计",
        "",
        f"- 数据来源：`{source}`",
        f"- 分类标准数量：{len(results)}",
        "- 统计口径：公司数为同一分类标准、同一年内唯一 InstitutionID 数；行业数为唯一 IndustryCode2 数。",
        "- 每年平均值按该分类标准实际有数据的年份取算术平均。",
        "- 本审计只读取和统计原表，未计算 SYN，未清洗或改写行业数据。",
        "",
        "## 全部分类标准",
        "",
        *md_table(results),
        "",
        "## 特别检查",
        "",
        "### 完整覆盖2009—2025",
        "",
    ]
    if full:
        lines.extend(f"- {r['IndustryClassificationID']}：{r['IndustryClassification']}" for r in full)
    else:
        lines.append("- 无。没有任何单一分类标准连续覆盖2009—2025全部17年。")

    lines.extend(["", "### 同时覆盖2009和2025、但中间断年", ""])
    if gaps:
        lines.extend(f"- {r['IndustryClassificationID']}：{r['IndustryClassification']}" for r in gaps)
    else:
        lines.append("- 无。没有任何分类标准同时包含2009和2025两个端点年份。")

    lines.extend(
        [
            "",
            "### P0207",
            "",
            f"- 分类名称：{p0207['IndustryClassification']}（直接读取 IndustryClassification 字段）",
            f"- 实际覆盖：{p0207['earliest_year']}—{p0207['latest_year']}，共 {p0207['actual_coverage_year_count']} 年。",
            f"- 2009：{p0207['has_2009']}；2025：{p0207['has_2025']}。",
            "",
            "### 证监会行业分类相关标准",
            "",
            "下列项目按原始名称含“证监会”或“上市公司协会”标出；名称均直接来自 IndustryClassification 字段：",
            "",
        ]
    )
    lines.extend(
        f"- {r['IndustryClassificationID']}：{r['IndustryClassification']}，{r['earliest_year']}—{r['latest_year']}"
        for r in csrc
    )
    lines.extend(
        [
            "",
            "## 统一计算2009—2025 SYN的适用性结论",
            "",
            "- 没有任何单一 IndustryClassificationID 完整覆盖2009—2025，因此本文件中不存在可直接用于统一口径计算全时期 SYN 的分类标准。",
            "- P0207只覆盖2012—2022，不能单独承担2009—2025全期统一计算。",
            "- 若要求行业定义在全期严格一致，不应直接拼接多个分类标准；需另行取得同一标准的历史回溯数据或先制定并审计跨标准映射。本审计未执行该映射。",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("csv_output", type=Path)
    parser.add_argument("md_output", type=Path)
    args = parser.parse_args()
    results = audit(args.source)
    if not results:
        raise RuntimeError("No classification standards found")
    write_csv(args.csv_output, results)
    write_markdown(args.md_output, args.source, results)
    print(f"standards={len(results)}")
    print("full=" + ",".join(str(r["IndustryClassificationID"]) for r in results if r["continuous_coverage_2009_2025"] == "是"))
    print("endpoint_gaps=" + ",".join(str(r["IndustryClassificationID"]) for r in results if r["spans_2009_2025_with_gaps"] == "是"))


if __name__ == "__main__":
    main()
