# 四批次G1最终固定复核：只执行一次静态和一次事件研究

## Material Passport

- 日期：2026-11-03；academic-research-suite / experiment-agent，run + validate。
- 用户明确授权：原四批次、原G1设定不变，只重跑一次静态与一次事件研究并比较。
- 不是新规格探索，不把本轮称为历史预注册或已消除全部识别风险。

## 输入与事实

latest_G1_analysis.dta的原始26,711条stack记录完整保留；冻结sample_g1=1共24,659条。
新行业来源确认170条缺二级码记录均为一级M、综合类，分组成员集合未变；当前30条和原20家证据缺口已核清。
真实财务来源没有新增可恢复的G1完整观测；2,052条损失按原规则保留并留存清单。
因此不重新构造SYN、stack、缩尾或控制值；对原分析DTA作逐字节快照后读取快照。

## 唯一模型

Y=SYN_CSRC_FAMILY_w_exact；D=TreatPost；X=Size_w_exact MB_parent_w_exact Lev_w_exact。
FE=firm_stack_id cohort_year_id；vce(cluster firm_id)；单核。
cohort_report_year=2013、2015、2016、2017；[-3,+2]；annual_report_year=syn_year-1。

1. 静态：reghdfe Y D X if sample_g1==1，执行一次。
2. 动态：原-3为唯一省略基准；treated_in_stack×1(event_time=-2,-1,0,+1,+2)，同Y/X/FE/聚类和样本，执行一次。
3. 原动态政策前及政策后联合检验各一次；不新增任何模型或线性对比。
4. 只读取旧ster的系数/协方差作比较，不对旧模型另作回归。

## 验证与输出

输入前后SHA256、快照、真实样本键、全部五期系数/SE/p/95%CI、联合F/p、
原结果比较、旧新ster矩阵比较、输入及样本核验、原审计/缺失/核验清单副本、完整日志及事件图。
CSV归档有单精度/显示舍入，比较时明确其精度；关键b/V直接与旧ster矩阵核对。
运行状态采用一次性启动记录；若失败不自动重复回归。完成后停止，不换控制、不删批次、不加权、不按p值筛样本。
