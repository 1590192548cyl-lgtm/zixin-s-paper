from pathlib import Path
import hashlib,json,resource
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig',float_format='%.17g')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def md(d):
    x=d.fillna('')
    rows=['|'+'|'.join(map(str,x.columns))+'|','|'+'|'.join(['---']*len(x.columns))+'|']
    for row in x.itertuples(index=False,name=None):rows.append('|'+'|'.join(str(v) for v in row)+'|')
    return '\n'.join(rows)

a=json.loads((O/'attrition_summary.json').read_text())
f=json.loads((O/'financial_trace_summary.json').read_text())
i=json.loads((O/'industry_and_control_review_summary.json').read_text())
assert a['lost_stack_observations']==2052 and a['complete_case_N']==25803
assert f['complete_G1_control_firm_years_recoverable']==0 and f['proposed_missing_raw_field_fills']==0
loss=pd.read_csv(O/'all_2052_loss_reason_links_private.csv',dtype={'firm_id':int})
counts=[]
names={'before_A_share_listing_year':'控制财务年度早于A股上市年度',
       'nonpositive_parent_equity_under_frozen_rule':'母公司权益非正，按原MB规则不可用',
       'missing_annual_market_value_after_listing':'上市后年度原始年末总市值缺失'}
for reason,label in names.items():
    direct=int((loss.sample_g1_raw.eq(0)&loss.reason.eq(reason)).sum())
    support=int((loss.sample_g1_raw.eq(1)&loss.pair_missing_causes.eq(reason)).sum())
    counts.append({'原因':label,'直接缺失损失':direct,'连带前后支持损失':support,'合计':direct+support})
assert sum(r['合计'] for r in counts)==2052
decomp=pd.DataFrame(counts);save(decomp,'all_2052_loss_complete_decomposition.csv')
co=loss.groupby(['cohort_report_year','sample_g1_raw']).size().unstack(fill_value=0).rename(columns={0:'直接缺失损失',1:'连带前后支持损失'}).reset_index()
save(co,'attrition_by_cohort.csv')
sources=pd.read_csv(O/'financial_source_crosscheck_private.csv',dtype={'firm_code':str})
conf=sources.loc[sources.checkpoint_value.notna()&sources.old_nonmissing_matches.eq(0)]
save(conf,'conflicting_financial_records_not_applied_private.csv')
assert conf.variable.eq('equity_parent').all() and conf.candidate_max.lt(0).all()

requests=pd.DataFrame([
 {'priority':'必需','data':'CSMAR同期年度行业分类','years':'2010—2011为当前G1必要；建议2009—2011一次导出',
  'scope':'全A股、P0201（证监会行业分类2001年版），每年12月31日；不要只导出当前30家公司',
  'fields':'股票代码Symbol、InstitutionID、EndDate、IndustryClassificationID、IndustryClassification、一级行业代码/名称、二级行业代码/名称',
  'purpose':'核实完整同行收益池，识别缺二级码的综合类等层级问题；不改变原G1行业分组原则',
  'notes':'字段名以CSMAR界面为准。年度表若没有一级字段，请提供同期完整行业代码的历史分类记录及生效/终止日期；不能再仅提供IndustryCode2。'},
 {'priority':'可选核验，不必全库重下','data':'10个公司年度的原始年末总市值/全年交易状态','years':'600057：2010；其余清单9家：2012',
  'scope':'见market_value_target_10.csv，只核验这10个公司年度',
  'fields':'股票代码、交易年度/年末日期、Ysmvttl或同定义年末总市值、单位；对应停复牌或上市交易状态记录',
  'purpose':'区分真实无年末交易市值与下载遗漏；不会用IPO价格、未来市值或自行前向填充值替代',
  'notes':'若CSMAR该年原始值确实不存在，保持缺失即可。不得为了补值改变年末总市值定义。'},
 {'priority':'无需重复下载','data':'整套资产负债表或IPO前历史财务库','years':'686个缺口公司年度',
  'scope':'已核验本地真实来源；608个上市前年份、68个权益非正，不是反复下载财务库即可恢复',
  'fields':'不适用','purpose':'避免无效下载及额外磁盘/内存消耗','notes':'不把上市前MB不存在或负权益改成正常样本。'}])
save(requests,'CSMAR_download_requests.csv')
market=pd.read_csv(O/'post_listing_market_value_gap_checks.csv',dtype={'firm_code':str})
save(market[['firm_code','fiscal_year','eligible_weekly_return_rows_calendar_year']],'market_value_target_10.csv')
bad=pd.read_csv(O/'early_industry_placeholder_pool_private.csv',dtype={'firm_code':str,'InstitutionID':str})
save(bad[['firm_code','InstitutionID','industry_year','IndustryClassificationID','IndustryClassification','IndustryCode2','IndustryName2']],
     'industry_placeholder_targets_2009_2011.csv')
ledger=pd.DataFrame(columns=['firm_code','fiscal_year','variable','old_value','new_value','source_file','source_row','repair_rule','applied'])
save(ledger,'applied_repair_ledger.csv')

before=pd.read_csv(O/'primary_input_manifest_before.csv')
before['sha256_after']=[sha(Path(p)) for p in before.path]
before['unchanged']=before.sha256.eq(before.sha256_after)
assert before.unchanged.all()
save(before,'primary_input_integrity_after.csv')
for name in ['financial_source_integrity_after.csv','early_industry_source_inventory.csv','industry_and_stack_input_integrity.csv']:
    z=pd.read_csv(O/name);assert z.unchanged.all(),name

download='''# 需要补充的CSMAR数据：本轮只需定点下载

## 1. 必需：早期完整行业分类

- 分类标准：P0201，证监会行业分类2001年版。
- 年份：当前四批次G1必要2010—2011；建议2009—2011一次导出，方便保留原SYN前史。
- 范围：全A股、每年12月31日，不只下载回归中的30家公司。行业收益需要完整同行集合。
- 字段：股票代码Symbol、InstitutionID、EndDate、IndustryClassificationID、IndustryClassification、一级行业代码和名称、二级行业代码和名称。
- 字段名称以CSMAR实际界面为准。重点是一级/完整行业码，不能再次只有二级行业码。
- 若年度表无法提供一级字段，导出同标准完整历史行业分类，保留股票代码、完整行业代码/名称、实施开始日期和终止日期或变更轨迹，使2010/2011年末状态可核验。
- 不使用后来年度行业回填，不改用申万/中信，也不要求把P0207追溯到其尚未实施的年份。
- 当前只有IndustryCode2的原文件里，2009/2010/2011分别有64/53/53家公司缺二级码；不意味着这些公司都不合格。
- 当前G1直接涉及30条2011观测；10家有同期综合类M的历史记录，另20家尚缺同期直接证据。10家也不能在同行集合未确认前单独拼成一个收益组。

## 2. 可选：10个年度市值缺口的定点核验

- 2010年：600057。
- 2012年：000038、000403、000498、000670、000672、000681、000757、000831、600817。
- 原字段：TRD_Year的Ysmvttl，年末总市值，千元；或能证明同日期、同定义的CSMAR原始年末总市值。
- 最好一并导出全年交易/停复牌状态。已有周缓存中，这10个公司年度均无满足原有效收益/正市值条件的周记录；这与全年停牌相符，但仅凭缺行不能确认停牌事实。
- 若原始年末市值确实无值，保留缺失，不用更早市值前向填充，不用IPO发行价或以后年份替代。

## 不需要做的事

无需重新下载全量年报、周收益或整套财务报表。608个IPO前财务年度没有该A股代码的上市年末交易市值；68个非正权益年度按原规则不能计算MB。反复下载不能消除这些定义限制。

下载后放入 /Users/macpro/Desktop/毕业论文/控制变量 下一个新文件夹，保留CSMAR字段说明，不覆盖旧文件；告诉我文件夹名称即可。收到并核验后再完成修复并执行本轮保留的一次静态G1和一次事件研究。
'''
(O/'CSMAR下载清单.md').write_text(download,encoding='utf-8')

report=f'''# 四批次G1真实数据修复：审计结果及待下载事项

## Material Passport

- 日期：2026-11-03；来源技能：academic-research-suite / experiment-agent，以及spreadsheets审计规范。
- 状态：数据审计与真实来源核验完成；修复和唯一一次正式重跑待补行业分类来源。**本轮回归次数=0**。
- 没有改Treat、stack、cohort、政策时点、event_time、原FE、firm_id聚类或任何控制定义；未扫描年报。
- 原完整研究总体26,711条，原G1 24,659条；四批次2013/2015/2016/2017保持不变。
- 不以p值判断采用哪些来源；既有值、负权益、缺市值、行业未核实记录不人为改成合格。

## 一、2,052条损失已逐条解释

{md(decomp)}

直接财务缺失908条；完整案例但原“公司—stack至少一前一后”不满足而退出1,144条。
原完整案例25,803条，经过该支持条件后为24,659条，规则逐行复现一致。

按单变量：Size缺583条，Lev缺583条，二者与MB同时缺失；仅MB缺失325条。
因此MB总缺908条，不能把583+583+908相加当作不同损失。
908条对应686个唯一公司年度：608个上市前财务年度、68个母公司权益非正年度、10个上市后缺年末市值年度。
2,052条全部损失对应1,822个唯一公司年度；完整逐行清单及其对应的公司—stack缺失原因已保存。

{md(co)}

## 二、为什么上市前财务年度会出现在原stack

本项目annual_report_year=t，syn_year=t+1，收益窗口为t+1年5月至t+2年4月。
新上市公司可能在该收益窗口已有足够交易周，因而有SYN；但它在t年末尚未A股上市，没有原MB定义所需的上市年末市场价值。
不能为保留这些公司，把控制年度偷偷移到上市后或用IPO价格回填t年末市值。
一些公司—stack仅有的政策前行属于这种缺口，删除缺失行后只剩政策后，原规则就同时使其余完整行退出。
这说明损失主要是时序和变量定义下的支持限制，不是已查实的程序漏合并。

## 三、真实财务来源检查及修复结果

- 按文件流式检查{f['source_rows_streamed']:,}条记录，未一次载入财务全库。
- 核验来源包括原完整资产负债表、独立资产/负债表、母公司权益分表、年末市值表，以及只读原CSMAR检查点。
- 原balance和market检查点的文件尺寸/修改时间签名与当前同源文件一致；原始表的定点记录另有逐行复核。
- 两份TRD_Year.xlsx内容指纹完全相同，第二份不增加覆盖。
- 找到可按同字段、同年度、合并口径新增填补的原始数值：0；能恢复完整三控制的缺口公司年度：0。
- 有3个2019年母公司权益来源数值不一致（000687、000803、000835）；所有候选值仍为负，不改变原MB不可用判断。本轮没有挑选某个数值覆盖旧值。
- 608个IPO前年度和68个非正权益年度无需为了保样本反复下载财务库。
- 另外10个年度缺市值，在本地周缓存中也无原规则下的有效周交易记录；只能说明与全年暂停交易相符，不能仅凭缺行断言其官方停牌状态。定点核验清单已提供。

**修复清单applied_repair_ledger.csv为空是实际核验结果，不是遗漏执行；本轮未插补或人为赋值。**

## 四、SYN与早期行业分类

现有26,711条stack内SYN缺失为0；这不意味着全A股原始SYN构造没有数据损失。
原stack以已经生成的SYN公司年度为起点，未生成SYN的公司年度不属于这2,052条损失。
本轮不重新构建stack，因此没有额外增加那些stack外记录，也没有下调30周门槛。

原行业分类文件仍缺一级行业字段，二级码占位符在2009/2010/2011分别涉及64/53/53家公司年度。
当前G1直接涉及30条2011观测，均是2013批次的-3期；10家有同期P0201=M、综合类历史记录，另20家无同期直接记录。
“缺二级码”不等于“公司行业错误”，尤其综合类可能本来就没有更细的二级码。
但也不能把未核实成员全部默认成M，或只拿已核实10家组成不完整行业收益池。

行业收益需要完整同行集合，因此真正需要补下载的是同期完整行业码/一级字段，而不是再次扫描年报或直接剔除这些公司。
当前四批次最早SYN为2011，其边界滞后周可能用2010分类；必要覆盖2010—2011，建议2009—2011一次取得，兼容原构造前史。
行业分类原则不变：仍沿用原P0201/P0207年度规则；不会把本轮变为“所有非制造业一级”的另一套SYN口径。
有证据补齐后，只修复确需纠正的行业映射及受影响的SYN，使用原因子、窗口和冻结缩尾点；不得通过新SYN增加stack外观测。

## 五、三项控制变量审查：不自动替换

|变量|原定义|因果属性核查|
|---|---|---|
|Size|合并年末总资产自然对数|政策可能通过投资/融资影响后续资产，不能自动视为未受政策影响|
|MB_parent|年末总市值×1000/归属于母公司权益，权益>0|估值可能直接响应披露监管，存在中介或政策后控制风险|
|Lev|合并年末负债/合并年末总资产|可能反映政策引致融资变化，需明确总效应与条件效应区别|

已确认的fiscal_year=syn_year-1对齐不变；“早于收益窗口”不等于“早于政策”。
首个适用财务年度的控制值是否早于具体公布日需按政策日期进一步判断；后续适用年度的值不属于严格政策前基线。
这是一项因果风险审查，不是已证明某控制有错，也不能据此自动删除MB或改用政策前值。
本轮三控制均未替换，也没有运行Treat→控制变量的显著性检验来决定取舍。
[方法依据：Caetano等，Difference in Differences with Time-Varying Covariates](https://arxiv.org/abs/2202.02903)。

## 六、需要用户补充的数据

请先阅读同目录的CSMAR下载清单.md。

1. 必需：P0201同期完整年度行业分类，必要2010—2011、建议2009—2011；全A股；股票代码、机构ID、年末日期、标准ID和名称、一级及二级行业代码和名称。不要只下载30家公司，不能仅含二级字段。
2. 可选定点核验：600057的2010年，以及000038、000403、000498、000670、000672、000681、000757、000831、600817的2012年原始年末总市值和全年交易状态。若确实无原始市值，则保持缺失。
3. 不需要下载全量年报、周收益、完整财务库，也不需要新增变量。

## 七、原设定、输入保护和资源

- 原Treat、控制组和全部stack记录保持不变；不按p值筛选样本或行业口径。
- 原SYN及三控制值和原缩尾边界保持原样；尚未生成新的分析DTA。
- 输入文件指纹核对全部通过；SQLite以mode=ro打开，未改原缓存。
- 本轮各Python步骤峰值RSS最高约{max(a['Python_peak_RSS_MiB'],f['Python_peak_RSS_MiB'],i['Python_peak_RSS_MiB']):.1f}MiB；未载入全量周收益或年报。
- 本轮没有任何回归，也没有重复已完成的估计目标分解。
- 收到分类来源并完成核验后，才进行保留的唯一一次静态G1和一次原基准事件研究；不先用不完整分类跑一个版本观察p值。

## 八、当前停止位置

数据审计完成；财务本地修复0条；行业修复等待同期完整字段。**不能把旧G1的p值当作本轮“修复后结果”。**
下一步仅加载用户补充的分类/定点核验文件，沿用本轮损失清单和代码继续，不重做全量审计或重新扫描年报。
'''
(O/'G1_true_data_repair_status_report.md').write_text(report,encoding='utf-8')
(O/'READ_FIRST.md').write_text('# 当前状态：待补分类来源，尚未重跑\n\n先看G1_true_data_repair_status_report.md和CSMAR下载清单.md。\n\n2,052条损失已逐条追踪；本地无完整G1控制可恢复；未运行回归。\n\n所有private文件含CSMAR衍生数据，请勿上传公开GitHub。收到新数据后从此目录续跑，不重扫年报。\n',encoding='utf-8')
status={'stage':'AUDIT_COMPLETE_AWAITING_CONTEMPORANEOUS_INDUSTRY_SOURCE','regressions_run':0,
        'original_stack_N':26711,'original_G1_N':24659,'losses_explained':2052,'financial_control_firm_years_recovered':0,
        'applied_repairs':0,'required_industry_download':True,'optional_market_value_firm_years':10,
        'all_recorded_input_integrity_checks_passed':True,'peak_RSS_MiB':max(a['Python_peak_RSS_MiB'],f['Python_peak_RSS_MiB'],i['Python_peak_RSS_MiB'])}
(O/'continuation_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)
print(decomp.to_string(index=False),flush=True)
