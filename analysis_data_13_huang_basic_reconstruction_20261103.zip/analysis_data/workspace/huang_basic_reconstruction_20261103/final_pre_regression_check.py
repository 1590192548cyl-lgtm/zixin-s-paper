"""Enforce the already specified May listing cutoff before any regression."""
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs'
sys_path='/Users/macpro/Documents/New project/huang_replication_data_audit_20261103'
import sys
sys.path.insert(0,sys_path)
from audit_sources import sha
manifest=json.loads((O/'input_manifest.json').read_text())
after=[dict(**r,unchanged=sha(Path(r['file']))==r['sha256']) for r in manifest]
assert all(r['unchanged'] for r in after)
(O/'input_integrity_after_build.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),encoding='utf-8')
d=pd.read_stata(O/'analysis.dta',convert_categoricals=False)
ipo=pd.read_stata('/Users/macpro/Desktop/毕业论文/原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd')
ipo['firm_id']=ipo.Stkcd.astype(int);lookup=ipo.set_index('firm_id').Listdt
bad=~d.firm_id.map(lookup).lt(d.year.astype(str)+'-05-01')
d.loc[bad,['firm_id','year']].assign(reason='IPO_not_before_May01_as_prespecified').to_csv(O/'pre_regression_listing_cutoff_exclusions.csv',index=False)
d=d.loc[~bad].copy();cols=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4'];assert d[cols].notna().all(axis=1).eq(d.sample8.eq(1)).all()
cuts=[]
for v in ['SYN']+cols:
 if v in ['Dual','Big4']:continue
 lo,hi=(d[v] if v=='SYN' else d.loc[d.sample8.eq(1),v]).quantile([.01,.99]);d[v+'_w']=d[v].clip(lo,hi);cuts.append(dict(variable=v,p1=lo,p99=hi))
pd.DataFrame(cuts).to_csv(O/'final_frozen_winsor_cutoffs.csv',index=False)
assert not d.duplicated(['firm_id','year']).any();assert d.Treat.isin([0,1]).all();assert d.TreatPost.eq(d.Treat*d.Post).all()
for label,mask in [('H0',d.SYN_w.notna()),('H8',d.sample8.eq(1))]:
 support=d.loc[mask].groupby(['year','Treat']).size();assert len(support)==26 and support.min()>0
 support.rename('N').to_csv(O/f'{label}_final_support.csv')
d.to_stata(O/'final_analysis.dta',write_index=False,version=118)
stats=dict(listing_cutoff_excluded=int(bad.sum()),final_N=len(d),complete8=int(d.sample8.sum()),sample_controls=cols,plan_sha256=hashlib.sha256((W/'PRE_ANALYSIS_PLAN.md').read_bytes()).hexdigest(),models_run_before_this_check=0)
(O/'final_pre_regression_audit.json').write_text(json.dumps(stats,indent=2),encoding='utf-8');print(stats)
