"""Read-only source inspection. No merges, SYN construction, or regressions."""
from pathlib import Path
import argparse
import gc
import hashlib
import json

import pandas as pd
import pdfplumber

OUT = Path(__file__).resolve().parent
PDF = Path('/Users/macpro/Desktop/毕业论文/参考文献/黄炳艺，2025_分行业信息披露监管影响资本市场定价效率吗.pdf')
IND = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/data_work/industry_new_standardized.dta')

parser = argparse.ArgumentParser()
parser.add_argument('--skip-pdf', action='store_true')
args = parser.parse_args()
if not args.skip_pdf:
    with pdfplumber.open(PDF) as doc:
        text = '\n\n'.join(f'=== PHYSICAL PAGE {n+1} ===\n{p.extract_text(layout=False)}' for n, p in enumerate(doc.pages))
        (OUT / 'huang2025_fresh_text.txt').write_text(text, encoding='utf-8')
        for n in [2, 3, 7]:
            doc.pages[n].to_image(resolution=140).save(OUT / f'huang_page_{n+1}.png')

with pd.read_stata(IND, iterator=True, convert_categoricals=False) as reader:
    fields = list(reader.variable_labels())
print(json.dumps({'industry_fields': fields}, ensure_ascii=False))

cols = [c for c in ['EndDate','IndustryClassificationID','IndustryClassification','Symbol',
                    'IndustryCode1','IndustryName1','IndustryCode2','IndustryName2'] if c in fields]
parts = []
with pd.read_stata(IND, columns=cols, chunksize=25000, convert_categoricals=False) as reader:
    for chunk in reader:
        years = pd.to_datetime(chunk['EndDate'], errors='coerce').dt.year
        keep = years.between(2009, 2020) & chunk.IndustryClassificationID.isin(['P0201', 'P0207'])
        q = chunk.loc[keep].copy()
        q['year'] = years[keep]
        if len(q):
            parts.append(q)
        del chunk
        gc.collect()
industry = pd.concat(parts, ignore_index=True)
del parts
industry = industry.sort_values('EndDate').drop_duplicates(['Symbol','year','IndustryClassificationID'], keep='last')
rows = []
for (year, standard), g in industry.groupby(['year','IndustryClassificationID']):
    rawcode = g.IndustryCode2.astype(str).str.strip()
    valid = rawcode.str.fullmatch(r'[A-Z][0-9]+', na=False)
    invalid = g.loc[~valid, ['Symbol','IndustryCode2','IndustryName2']]
    code = rawcode[valid]
    # Descriptive code-level counts only; this is NOT a new classification panel.
    manufacturing = code.str.startswith('C')
    name = g.IndustryName2.astype(str)
    d = {'year': int(year), 'standard_id': standard, 'standard_name_from_file': str(g.IndustryClassification.iloc[0]),
         'firms': int(g.Symbol.nunique()), 'current_code2_groups': int(code.nunique()),
         'invalid_code_rows': int((~valid).sum()), 'invalid_code_examples': invalid.head(3).to_dict('records'),
         'manufacturing_code2_groups': int(code[manufacturing].nunique()),
         'nonmanufacturing_code2_groups': int(code[~manufacturing].nunique()),
         'nonmanufacturing_prefix_groups': int(code[~manufacturing].str[0].nunique()),
         'code_name_examples': g.loc[code.index[~manufacturing],['IndustryCode2','IndustryName2']].drop_duplicates().head(8).to_dict('records')}
    if 'IndustryCode1' in g:
        d['code1_groups'] = int(g.IndustryCode1.nunique())
    rows.append(d)
result = {'purpose':'METHOD_AND_COVERAGE_AUDIT_ONLY', 'source_pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),
          'regressions_run':0, 'syn_recomputed':False, 'input_files_modified':False,
          'industry_fields':fields, 'coverage_and_granularity':rows}
raw_code = industry.IndustryCode2.astype(str).str.strip()
bad = industry.loc[~raw_code.str.fullmatch(r'[A-Z][0-9]+', na=False)].copy()
bad['numeric_id'] = pd.to_numeric(bad.Symbol, errors='coerce')
bad_keys = set((int(r.numeric_id), int(r.year)) for r in bad.itertuples() if pd.notna(r.numeric_id))
latest = pd.read_stata(
    '/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta',
    columns=['firm_id','syn_year','sample_g1','cohort_report_year','event_time'], convert_categoricals=False)
sample = latest.loc[latest.sample_g1.eq(1)]
affected = [(int(r.firm_id), int(r.syn_year)) for r in sample.itertuples()
            if (int(r.firm_id), int(r.syn_year)) in bad_keys]
result['invalid_source_code_audit'] = {
    'note':'Key comparison only; no merge written, no outcome or sample changed. Industry lookup follows original syn_year key.',
    'invalid_source_rows':len(bad), 'latest_G1_stack_observations_with_invalid_source_key':len(affected),
    'latest_G1_unique_firm_syn_year_with_invalid_source_key':len(set(affected)),
    'affected_current_keys': [
        {'firm_id':f'{int(r.firm_id):06d}', 'syn_year':int(r.syn_year),
         'cohort_report_year':int(r.cohort_report_year), 'event_time':int(r.event_time)}
        for r in sample.itertuples() if (int(r.firm_id),int(r.syn_year)) in bad_keys]}
(OUT / 'source_inspection.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
print(json.dumps({'selected_industry_rows':len(industry),'year_standard_cells':len(rows),'regressions_run':0}, ensure_ascii=False))
