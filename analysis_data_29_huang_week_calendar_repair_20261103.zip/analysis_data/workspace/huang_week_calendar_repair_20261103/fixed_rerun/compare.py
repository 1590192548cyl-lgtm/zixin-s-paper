from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent.parent/'huang_basic_reconstruction_20261103'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert 'HUANG_CALENDAR_FIXED_RERUN_COMPLETE' in (O/'fixed_models.log').read_text()
bad=pd.read_csv(O/'authorized_four_exclusions_private.csv');excluded=set(map(tuple,bad[['firm_id','year']].to_numpy()));audits=[]
for m,n in [('H0',7883),('H8',7609)]:
 old=pd.read_csv(B/f'outputs/{m}_sample_private.csv');new=pd.read_csv(O/f'{m}_sample_private.csv')
 expected=set(map(tuple,old.loc[old.static_sample.eq(1),['firm_id','year']].to_numpy()))-excluded
 actual=set(map(tuple,new.loc[new.static_sample.eq(1),['firm_id','year']].to_numpy()))
 assert actual==expected and len(actual)==n and new.static_sample.eq(new.event_sample).all()
 audits.append(dict(model=m,N=len(actual),clusters=new.loc[new.static_sample.eq(1),'firm_id'].nunique(),exactly_authorized_four_removed=True,no_additional_exclusions=True,same_static_event_sample=True))
pd.DataFrame(audits).to_csv(O/'post_regression_sample_audit.csv',index=False)
for name in ['static_results','event_results','joint_tests']:
 frames=[]
 for label,p in [('before',B/'outputs'),('corrected',O)]:
  d=pd.read_csv(p/f'{name}.csv');d.insert(0,'version',label);frames.append(d)
 allrows=pd.concat(frames,ignore_index=True);allrows.to_csv(O/f'{name}_comparison.csv',index=False)
 if name=='event_results':assert len(allrows)==48 and allrows.SE.gt(0).all()
manifest=json.loads((O/'protected_inputs.json').read_text());after=[dict(**r,unchanged=sha(r['file'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);(O/'input_integrity_after_rerun.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),encoding='utf-8')
done=dict(status='complete',static_models=2,event_models=2,additional_specifications=0,additional_SYN_recalculations=0,only_four_authorized_records_excluded=True,original_G1_unchanged=True)
(O/'run_completed.json').write_text(json.dumps(done,indent=2),encoding='utf-8');print(pd.read_csv(O/'static_results_comparison.csv').to_string(index=False));print(pd.read_csv(O/'joint_tests_comparison.csv').to_string(index=False))
