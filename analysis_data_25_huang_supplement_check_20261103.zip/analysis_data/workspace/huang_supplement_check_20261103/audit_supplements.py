#!/usr/bin/env python3
"""Audit only. Inspect ZIP members sequentially, store key diagnostics on disk.
No control variables, analytical merge, treatment, SYN or regression is produced.
"""
import csv, gc, hashlib, json, math, re, resource, shutil, sqlite3, sys, tempfile, time
from collections import Counter, defaultdict
from pathlib import Path
from zipfile import ZipFile
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows, norm, sha

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/macpro/Desktop/毕业论文/控制变量/黄文复现补充')
OLD=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/huang_replication_data_audit_20261103')

def csvout(name,rows):
 if not rows:return
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def num(s):
 try:
  x=float(s)
  return x if math.isfinite(x) else None
 except (ValueError,TypeError):return None

def main():
 start=time.time();previous=json.loads((OLD/'execution_audit.json').read_text());g1=Path(previous['original_G1_path']);g1h=sha(g1)
 # The database is temporary audit state, not a merged analysis file.
 with tempfile.TemporaryDirectory(prefix='huang_supplement_audit_') as td:
  db=sqlite3.connect(str(Path(td)/'audit.sqlite'))
  db.execute('PRAGMA cache_size=-12000');db.execute('PRAGMA temp_store=FILE')
  db.executescript('''
  CREATE TABLE ranks(firm TEXT,year INTEGER,rank INTEGER,n INTEGER,valid_n INTEGER,first_fp TEXT,conflict INTEGER,PRIMARY KEY(firm,year,rank));
  CREATE TABLE controller(firm TEXT,year INTEGER,criterion TEXT,n INTEGER,nonmissing INTEGER,first_value TEXT,conflict INTEGER,PRIMARY KEY(firm,year,criterion));
  CREATE TABLE shares(firm TEXT,year INTEGER,n INTEGER,ttl INTEGER,nn INTEGER,a INTEGER,first_fp TEXT,conflict INTEGER,PRIMARY KEY(firm,year));
  ''')
  sqlrank='''INSERT INTO ranks VALUES(?,?,?,?,?,?,?) ON CONFLICT(firm,year,rank) DO UPDATE SET n=n+1,valid_n=valid_n+excluded.valid_n,conflict=max(conflict,first_fp<>excluded.first_fp)'''
  sqlctl='''INSERT INTO controller VALUES(?,?,?,?,?,?,?) ON CONFLICT(firm,year,criterion) DO UPDATE SET n=n+1,nonmissing=nonmissing+excluded.nonmissing,conflict=max(conflict,first_value<>excluded.first_value)'''
  sqlshares='''INSERT INTO shares VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(firm,year) DO UPDATE SET n=n+1,ttl=ttl+excluded.ttl,nn=nn+excluded.nn,a=a+excluded.a,conflict=max(conflict,first_fp<>excluded.first_fp)'''
  inventories=[];sources=[];year_rows=[];special=[]
  for zp in sorted(ROOT.glob('*.zip')):
   zh=sha(zp)
   with ZipFile(zp) as z:
    for info in z.infolist():
     inventories.append(dict(archive=str(zp),archive_size_bytes=zp.stat().st_size,archive_mtime_ns=zp.stat().st_mtime_ns,archive_sha256=zh,member=info.filename,uncompressed_bytes=info.file_size))
     if not info.filename.lower().endswith('.xlsx'):continue
     print('Reading',zp.name,info.filename,flush=True)
     sid=('shareholders' if info.filename.startswith('HLD_Shareholders') else 'controller' if info.filename.startswith('HLD_Contrshr') else 'capital')
     with tempfile.TemporaryFile(suffix='.xlsx') as tf:
      hh=hashlib.sha256()
      with z.open(info) as inp:
       for chunk in iter(lambda:inp.read(1024*1024),b''):tf.write(chunk);hh.update(chunk)
      tf.seek(0);heads={};labels={};units={};first=[];raw=Counter();annual=Counter();nonmiss=Counter();validfirms=defaultdict(set);cols=set();nr=0;dates=[];dmin=None;dmax=None;invalid=Counter();batch=[];sheets=Counter()
      for sheet,rn,vals in xml_rows(tf):
       sheets[sheet]+=1;cols.update(k for k,v in vals.items() if v!='')
       if rn==1:heads[sheet]=vals
       if rn==2:labels[sheet]=vals
       if rn==3:units[sheet]=vals
       if rn<=5:first.append(dict(sheet=sheet,row=rn,values=vals))
       if rn<4:continue
       nr+=1;rec={name:vals.get(c,'') for c,name in heads[sheet].items()};date=rec.get('Reptdt','')
       match=re.match(r'^(19\d{2}|20\d{2})',date)
       if not match:invalid['invalid_date']+=1;continue
       year=int(match[1]);raw[year]+=1;dmin=min(dmin or date,date);dmax=max(dmax or date,date)
       code=norm(rec.get('Stkcd','')).zfill(6)
       if not re.fullmatch(r'\d{6}',code):invalid['invalid_stock_code']+=1;continue
       if not date.endswith('-12-31'):continue
       annual[year]+=1;validfirms[year].add(code)
       if not 2009<=year<=2021:continue
       if sid=='shareholders':
        ranknum=num(rec.get('S0306a'));ratio=num(rec.get('S0304a'));rank=int(ranknum) if ranknum is not None and ranknum.is_integer() else -1
        good=ratio is not None and 0<=ratio<=100
        if rank not in range(1,11):invalid['yearend_rank_outside_1_10']+=1
        if ratio is None:invalid['yearend_ratio_missing']+=1
        elif ratio<0 or ratio>100:invalid['yearend_ratio_outside_0_100']+=1
        if rank==1 and ratio is not None and ratio<=0:invalid['nonpositive_rank1_ratio']+=1
        fp=hashlib.sha256((rec.get('S0301a','')+'\0'+str(ratio)).encode()).hexdigest()
        batch.append((code,year,rank,1,int(good),fp,0));q=sqlrank
       elif sid=='controller':
        v=norm(rec.get('S0702b',''));c=norm(rec.get('S0701a',''))
        good=v not in ('','None','nan','.')
        if not good:invalid['yearend_nature_missing_rows']+=1
        if ',' in v:invalid['yearend_multiple_nature_codes_rows']+=1
        batch.append((code,year,c,1,int(good),v,0));q=sqlctl
       else:
        a=[num(rec.get(v)) for v in ('Nshrttl','Nshrnn','Nshra')]
        for field,value in zip(('Nshrttl','Nshrnn','Nshra'),a):
         nonmiss[year,field]+=value is not None
         if value is not None and value<0:invalid['negative_'+field]+=1
        if a[0] is not None and a[0]<=0:invalid['nonpositive_total_shares']+=1
        if a[0] is not None and a[2] is not None and a[2]>a[0]:invalid['circulating_A_exceeds_total_shares']+=1
        if all(v is not None for v in a):
         # A source reconciliation check, NOT construction of A-share totals.
         if abs(a[0]-a[1]-a[2])>1:invalid['total_minus_nontradable_minus_circA_nonzero']+=1
        fp=hashlib.sha256(str(a).encode()).hexdigest()
        batch.append((code,year,1,*(int(v is not None) for v in a),fp,0));q=sqlshares
       if len(batch)>=2000:db.executemany(q,batch);batch.clear()
      if batch:db.executemany(q,batch)
      db.commit()
      result=dict(archive=str(zp),member=info.filename,member_sha256=hh.hexdigest(),source=sid,data_rows=nr,nonempty_columns=len(cols),actual_sheet_nonempty_rows=dict(sheets),headers=heads,labels=labels,units=units,first_five_rows=first,min_date=dmin,max_date=dmax,raw_years=sorted(raw),annual_years=sorted(annual),diagnostic_counts=dict(invalid))
      sources.append(result)
      for y,n in sorted(raw.items()):year_rows.append(dict(source=sid,member=info.filename,year=y,raw_rows=n,yearend_rows=annual[y],yearend_unique_firms=len(validfirms[y])))
      print(sid,nr,dmin,dmax,dict(invalid),flush=True)
      (OUT/'new_source_audit.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8');del validfirms;gc.collect()
   assert sha(zp)==zh
  csvout('zip_inventory.csv',inventories);csvout('new_source_year_coverage.csv',year_rows)
  # Top ten export fragments are audited together for rank completeness only.
  detail=[]
  query='''SELECT firm,year,COUNT(*),SUM(n),SUM(CASE WHEN rank BETWEEN 1 AND 10 THEN 1 ELSE 0 END),SUM(CASE WHEN rank BETWEEN 1 AND 5 THEN 1 ELSE 0 END),SUM(CASE WHEN rank BETWEEN 1 AND 10 AND valid_n>0 THEN 1 ELSE 0 END),SUM(CASE WHEN rank BETWEEN 1 AND 5 AND valid_n>0 THEN 1 ELSE 0 END),SUM(n>1),SUM(conflict) FROM ranks GROUP BY firm,year'''
  counters=defaultdict(Counter)
  for firm,year,nkeys,nrows,r10,r5,v10,v5,dup,conf in db.execute(query):
   for pop in ['all_exchanges']+(['SSE_A_code6'] if firm.startswith('6') else []):
    c=counters[year,pop];c['firm_years']+=1;c['ranks_1_10_present']+=r10==10;c['ranks_1_5_present']+=r5==5;c['ranks_1_10_valid_ratios']+=v10==10;c['ranks_1_5_valid_ratios']+=v5==5;c['duplicate_rank_firm_years']+=dup>0;c['different_record_same_rank_firm_years']+=conf>0
   if r10<10 or v10<10 or dup or conf:detail.append(dict(firm_id=firm,year=year,rank_count_1_10=r10,valid_ratio_rank_count_1_10=v10,rank_count_1_5=r5,valid_ratio_rank_count_1_5=v5,duplicate_rank_keys=dup,different_record_same_rank_keys=conf,reason='完整性/并列排名待核；未计算Cent或Top10'))
  csvout('shareholder_rank_coverage.csv',[dict(year=y,population=p,**c) for (y,p),c in sorted(counters.items())]);csvout('shareholder_rank_exceptions_private.csv',detail)
  # Controller profile by reported/computed criterion: no SOE recoding.
  ctl=[]
  for row in db.execute('SELECT year,criterion,COUNT(*),SUM(n),SUM(nonmissing>0),SUM(n>1),SUM(conflict) FROM controller GROUP BY year,criterion ORDER BY year,criterion'):
   ctl.append(dict(zip(['year','criterion','unique_firms','rows','firms_with_nonmissing_nature','firms_with_multiple_rows','firms_with_different_nature_strings'],row)))
  csvout('controller_by_year_criterion.csv',ctl)
  cap=[]
  for row in db.execute('SELECT year,COUNT(*),SUM(n),SUM(ttl>0),SUM(nn>0),SUM(a>0),SUM(n>1),SUM(conflict) FROM shares GROUP BY year ORDER BY year'):
   cap.append(dict(zip(['year','unique_firms','rows','total_shares_nonmissing_firms','nontradable_nonmissing_firms','circulating_A_nonmissing_firms','duplicate_firm_years','conflicting_firm_years'],row)))
  csvout('capital_year_coverage.csv',cap)
  db.close()
 # Validate previously audited sources without rescanning their data rows.
 comparisons=[]
 for old in json.loads((OLD/'source_audit.json').read_text()):
  p=Path(old['path']);h=sha(p)
  comparisons.append(dict(source=old['source'],path=str(p),same_sha256_as_previous_audit=h==old['sha256'],sha256=h))
 csvout('previous_source_integrity.csv',comparisons)
 assert sha(g1)==g1h
 meta=dict(regressions=0,analytical_merges=0,new_controls=0,source_archives_unchanged=True,original_G1_sha256_before=g1h,original_G1_sha256_after=sha(g1),seconds=time.time()-start,peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,source_archives=len(list(ROOT.glob('*.zip'))),xlsx_members=len(sources),temporary_extractions_removed=True,audit_database_removed=True)
 (OUT/'execution_audit.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(meta,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
