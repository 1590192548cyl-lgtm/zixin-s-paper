version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/huang_posthoc_window_2012_2018_20261103/outputs"
log using "`out'/fixed_models.log", text replace
which reghdfe
tempname mh eh jh
tempfile main events joint
postfile `mh' str4 model long N clusters treated_firms double coefficient double SE double t double p double CI_low double CI_high using `main', replace
postfile `eh' str4 model int event_time long N clusters double coefficient double SE double p double CI_low double CI_high using `events', replace
postfile `jh' str4 model str16 test double F double df_num double df_den double p using `joint', replace
foreach model in H0 H8 {
 use "`out'/window_analysis.dta", clear
 isid firm_id year
 assert TreatPost==Treat*Post
 assert event_time==year-2015
 local x ""
 local cond "window_H0_sample==1"
 if "`model'"=="H8" {
  local x "Size_w Age_w Lev_w Cent_w Top10_w Dual Board_w Big4"
  local cond "window_H8_sample==1"
 }
 quietly count if `cond'
 local preN=r(N)
 reghdfe SYN_w TreatPost `x' if `cond', absorb(firm_id year) vce(cluster firm_id)
 local n=e(N)
 local nc=e(N_clust)
 local df=e(df_r)
 local b=_b[TreatPost]
 local s=_se[TreatPost]
 local c=invttail(`df',.025)
 gen byte static_sample=e(sample)
 egen byte tag_t=tag(firm_id) if static_sample & Treat==1
 quietly count if tag_t==1
 local nt=r(N)
 post `mh' ("`model'") (`n') (`nc') (`nt') (`b') (`s') (`b'/`s') (2*ttail(`df',abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
 estimates save "`out'/`model'_static.ster", replace
 display as result "SAMPLE `model': complete-case=`preN'; final=`n'; singleton loss=" `preN'-`n'
 local terms ""
 local preterms ""
 local postterms ""
 forvalues k=-3/3 {
  if `k'!=-1 {
   local term "D_p`k'"
   if `k'<0 local term "D_m`=abs(`k')'"
   gen byte `term'=Treat==1 & event_time==`k'
   assert `term'==0 if Treat==0 | event_time==-1
   local terms "`terms' `term'"
   if `k'<-1 local preterms "`preterms' `term'"
   if `k'>=0 local postterms "`postterms' `term'"
  }
 }
 reghdfe SYN_w `terms' `x' if static_sample==1, absorb(firm_id year) vce(cluster firm_id)
 assert e(N)==`n'
 gen byte event_sample=e(sample)
 assert event_sample==static_sample
 local c=invttail(e(df_r),.025)
 forvalues k=-3/3 {
  if `k'!=-1 {
   local term "D_p`k'"
   if `k'<0 local term "D_m`=abs(`k')'"
   local b=_b[`term']
   local s=_se[`term']
   assert `s'>0 & !missing(`s')
   post `eh' ("`model'") (`k') (e(N)) (e(N_clust)) (`b') (`s') (2*ttail(e(df_r),abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
  }
 }
 test `preterms'
 post `jh' ("`model'") ("pre_all") (r(F)) (r(df)) (r(df_r)) (r(p))
 test `postterms'
 post `jh' ("`model'") ("post_all") (r(F)) (r(df)) (r(df_r)) (r(p))
 estimates save "`out'/`model'_event.ster", replace
 preserve
 keep firm_id year Treat event_time static_sample event_sample sample8 window_H0_sample window_H8_sample
 export delimited using "`out'/`model'_sample_private.csv", replace
 restore
}
postclose `mh'
postclose `eh'
postclose `jh'
use `main', clear
export delimited using "`out'/static_results.csv", replace
use `events', clear
export delimited using "`out'/event_results.csv", replace
use `joint', clear
export delimited using "`out'/joint_tests.csv", replace
display as result "HUANG_POSTHOC_WINDOW_COMPLETE"
log close
exit, clear


