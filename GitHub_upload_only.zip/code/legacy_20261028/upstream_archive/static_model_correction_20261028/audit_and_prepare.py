from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

WORK = Path('/Users/macpro/Documents/New project/static_model_correction_20261028_work')
OUT = WORK / 'outputs'
OUT.mkdir(parents=True, exist_ok=True)
P = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
INPUTS = {
    'weighted_stack': P / 'pretrend_balance_weighting/weighted_stack.dta',
    'original_stack': P / 'own_controls_systematic_test/stacked_did_own_controls.dta',
    'original_models': P / 'pretrend_balance_weighting/weighted_vs_unweighted.csv',
    'original_events': P / 'pretrend_balance_weighting/weighted_event_study.csv',
    'original_do': P / 'pretrend_balance_weighting/run_weighted_did.do',
    'weights': P / 'pretrend_balance_weighting/entropy_weights.csv',
    'cutoffs': P / 'own_controls_systematic_test/own_winsor_cutoffs.csv',
    'syn_source': P / 'data_work/syn_firm_year_recovered.dta',
    'core_mapping': P / '年报指引识别/final_mapping/gao_firm_iidg_mapping_core.csv',
    'supplemented_mapping': P / 'gao_exact_replication/outputs/targeted_supplement/gao_firm_iidg_mapping_supplemented.csv',
    'strict_2013': P / 'gao_treatment_eligibility_strict_recheck/strict_2013_manual_eligibility_decisions.csv',
    'earlier57': P / 'first_treatment_validity_audit/confirmed_earlier_treatment_corrections.csv',
    'alternative_master': P / 'modern_did_syn_extension/alternative_modern_master.dta',
    'alternative_old_results': P / 'modern_did_syn_extension/modern_did_alternative_syn.csv',
}
CONTROLS = 'Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w'.split()
BALANCE = [v for v in CONTROLS if v != 'Stdret_w']
KEY = ['firm_id', 'stack_id', 'syn_year']


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(d: pd.DataFrame, name: str) -> None:
    d.to_csv(OUT / name, index=False, encoding='utf-8-sig')


def read_csv(key: str) -> pd.DataFrame:
    return pd.read_csv(INPUTS[key], dtype=str, keep_default_na=False)


def code(s: pd.Series) -> pd.Series:
    return s.astype(str).str.replace(r'\.0$', '', regex=True).str.zfill(6)


manifest = [{'role': k, 'path': str(f), 'bytes': f.stat().st_size, 'sha256': sha(f)} for k, f in INPUTS.items()]
save(pd.DataFrame(manifest), 'input_manifest_sha256.csv')
configuration = {'primary_model': 'W2', 'controls': CONTROLS, 'balance_variables': BALANCE,
                 'outcome': 'SYN_w_Gao', 'treatment': 'TreatPost', 'fixed_effects': ['firm_stack_id', 'cohort_year_id'],
                 'cluster': 'firm_cluster_id', 'weight': 'ebal_weight_frozen', 'cohorts': [2015, 2016, 2017, 2018, 2019],
                 'window': [-3, 2], 'control_timing': 'syn_year-1', 'new_specs_allowed': False}
(OUT / 'frozen_model.json').write_text(json.dumps(configuration, ensure_ascii=False, indent=2), encoding='utf-8')

d = pd.read_stata(INPUTS['weighted_stack'], convert_categoricals=False)
d['firm_id'] = code(d.firm_id)
d['audit_row_id'] = np.arange(1, len(d) + 1, dtype=np.int32)
audits = []
fixes = []


def check(name: str, count: int, interpretation: str, fatal: bool = False) -> None:
    audits.append({'check': name, 'violations': int(count), 'interpretation': interpretation})
    if fatal and count:
        save(pd.DataFrame(audits), 'structural_data_audit.csv')
        raise ValueError(f'{name}: {count}; cannot resolve without changing frozen design')


dup = d.duplicated(KEY, keep=False)
check('duplicate_firm_stack_year', dup.sum(), 'Exact duplicates may be removed; conflicts are not resolved by selecting outcomes.')
if dup.any():
    exact = d.drop(columns='audit_row_id').duplicated(keep='first')
    conflict = d.loc[dup & ~exact].duplicated(KEY, keep=False)
    check('conflicting_duplicates', conflict.sum(), 'Unresolved conflicting keys block estimation.', True)
else:
    exact = pd.Series(False, index=d.index)
check('cohort_set_changed', set(d.cohort_report_year.unique()) != {2015,2016,2017,2018,2019}, 'Frozen five cohorts required.', True)
check('stack_cohort_not_unique', (d.groupby('stack_id').cohort_report_year.nunique() != 1).sum(), 'Stack IDs retain original cohort mapping.', True)
check('effective_year_inconsistent', d.cohort_effective_syn_year.ne(d.cohort_report_year + 1).sum(), 'Do not reset policy timing.', True)
check('event_time_inconsistent', d.event_time.ne(d.syn_year - d.cohort_effective_syn_year).sum(), 'Frozen event time must follow existing effective year.', True)
check('outside_window', (~d.event_time.between(-3,2)).sum(), 'Original weighted stack must already be restricted to [-3,+2].', True)
check('treated_not_binary', (~d.treated_in_stack.isin([0,1])).sum(), 'Treatment status is not reconstructed.', True)
check('treated_changes_within_firm_stack', d.groupby(['firm_id','stack_id']).treated_in_stack.nunique().gt(1).sum(), 'No within-stack treatment switching.', True)
check('cluster_id_not_one_to_one', d.groupby('firm_id').firm_cluster_id.nunique().ne(1).sum() + d.groupby('firm_cluster_id').firm_id.nunique().ne(1).sum(), 'Clusters must be original companies.', True)
check('firm_stack_fe_collision', d.groupby('firm_stack_id').apply(lambda g: len(g[['firm_id','stack_id']].drop_duplicates()), include_groups=False).ne(1).sum(), 'No FE collision.', True)
check('cohort_year_fe_collision', d.groupby('cohort_year_id').apply(lambda g: len(g[['cohort_report_year','syn_year']].drop_duplicates()), include_groups=False).ne(1).sum(), 'No FE collision.', True)

for col, expected in [('post', d.event_time.ge(0).astype(np.int8)), ('TreatPost', (d.treated_in_stack.eq(1)&d.event_time.ge(0)).astype(np.int8))]:
    bad = d[col].ne(expected)
    check(f'{col}_formula_mismatch', bad.sum(), 'Mechanical correction of a derived flag only; treatment status and time anchors unchanged.')
    for i in d.index[bad]:
        fixes.append({'audit_row_id': int(d.at[i,'audit_row_id']), 'firm_id': d.at[i,'firm_id'], 'variable': col, 'old': d.at[i,col], 'new': expected.at[i], 'basis': 'existing treatment status and event_time'})
    d.loc[bad,col] = expected.loc[bad]
check('control_fiscal_year_mismatch', d.control_fiscal_year.ne(d.syn_year-1).sum(), 'No automatic source-year replacement; would block frozen model.', True)
check('weight_nonpositive_matched', (d.weight_merge.eq(3)&(d.ebal_weight.le(0)|~np.isfinite(d.ebal_weight))).sum(), 'Matched weights must be positive and finite.', True)
check('weight_varies_within_firm_stack', d.loc[d.weight_merge.eq(3)].groupby(['firm_id','stack_id']).ebal_weight.nunique().gt(1).sum(), 'Frozen weight is fixed within each firm-stack.', True)

base = pd.read_stata(INPUTS['original_stack'], columns=KEY + ['SYN','SYN_w_Gao'] + CONTROLS, convert_categoricals=False)
base['firm_id'] = code(base.firm_id)
comp = d.merge(base, on=KEY, how='left', validate='one_to_one', suffixes=('','_source'), indicator='frozen_source_merge')
check('frozen_source_unmatched', comp.frozen_source_merge.ne('both').sum(), 'Every row is traceable to frozen source.', True)
for v in ['SYN','SYN_w_Gao'] + CONTROLS:
    same = np.isclose(comp[v], comp[v+'_source'], rtol=0, atol=1e-12, equal_nan=True)
    check('frozen_value_changed_'+v, (~same).sum(), 'Preserve existing outcome, controls and winsorization.', True)
del base, comp

syn = pd.read_stata(INPUTS['syn_source'], columns=['firm_id','report_year','SYN','R2','n_weeks'], convert_categoricals=False)
syn['firm_id'] = code(syn.firm_id)
syn = syn.rename(columns={'report_year':'syn_year','SYN':'quality_source_syn','R2':'quality_R2','n_weeks':'quality_n_weeks'})
d = d.merge(syn, on=['firm_id','syn_year'], how='left', validate='many_to_one', indicator='quality_merge')
check('syn_quality_source_unmatched', d.quality_merge.ne('both').sum(), 'Missing provenance goes to review, not arbitrary outcome selection.', True)
check('syn_source_value_mismatch', (~np.isclose(d.SYN,d.quality_source_syn,atol=1e-10,rtol=0,equal_nan=True)).sum(), 'Mismatch is an unresolved data version problem.', True)
valid_r2 = d.quality_R2.between(0,1,inclusive='neither')
check('invalid_R2', (~valid_r2).sum(), 'R2 outside (0,1) cannot support finite logit SYN.')
check('weeks_below_30', d.quality_n_weeks.lt(30).sum(), 'Apply existing 30-week requirement, no new threshold.')
check('loss_not_binary', (d.Loss.notna()&~d.Loss.isin([0,1])).sum(), 'Cannot infer valid Loss from a nonbinary value.', True)
check('logit_R2_not_equal_syn', (valid_r2 & ~np.isclose(d.SYN,np.log(d.quality_R2/(1-d.quality_R2)),atol=1e-9,rtol=0,equal_nan=True)).sum(), 'Audit formula, never recalculate SYN.', True)

# Positive policy evidence only. A rejected or unconfirmed record never proves no exposure.
evidence = []
for key in ['core_mapping','supplemented_mapping']:
    m = read_csv(key)
    m['firm_id'] = code(m.firm_id)
    for idx, r in m.iterrows():
        yr = pd.to_numeric(r['treat_year_core'], errors='coerce')
        if pd.notna(yr):
            evidence.append({'firm_id': r.firm_id, 'report_year': int(yr), 'iidg_id': r.iidg_id,
                             'source_file': str(INPUTS[key]), 'source_csv_data_row': int(idx+1),
                             'status': r.evidence_status, 'basis': r.get('decision_reason',''),
                             'source_document': r.get('source_path',''),
                             'evidence_excerpt': str(r.get('evidence_text',''))[:900]})
m = read_csv('strict_2013')
m['firm_id'] = code(m.firm_id)
for idx,r in m.loc[m.strict_include.eq('1')].iterrows():
    evidence.append({'firm_id':r.firm_id,'report_year':int(float(r.cohort_year)),'iidg_id':r.iidg_id,
                     'source_file':str(INPUTS['strict_2013']),'source_csv_data_row':int(idx+1),
                     'status':'strict_manual_include_1','basis':r.decision_rule,'source_document':r.get('report_url',''),
                     'evidence_excerpt':(r.get('policy_specific_context','') or r.get('business_context',''))[:900]})
m = read_csv('earlier57')
m['firm_id'] = code(m.firm_id)
assert m.final_needs_manual_review.isin(['0','0.0']).all()
for idx,r in m.iterrows():
    evidence.append({'firm_id':r.firm_id,'report_year':int(float(r.final_first_treat_report_year)),
                     'iidg_id':r.strict_prior_iidgs,'source_file':str(INPUTS['earlier57']),
                     'source_csv_data_row':int(idx+1),'status':r.final_validity_status,'basis':r.final_decision_basis,
                     'source_document':'existing completed annual-report adjudication','evidence_excerpt':''})
ev = pd.DataFrame(evidence).drop_duplicates(['firm_id','report_year','iidg_id','source_file'])
ev = ev.sort_values(['firm_id','report_year','source_file']).reset_index(drop=True)
ev['evidence_id'] = [f'E{i:05}' for i in range(1,len(ev)+1)]
save(ev, 'confirmed_policy_evidence.csv')
first = ev.sort_values(['firm_id','report_year','evidence_id']).drop_duplicates('firm_id')
first = first[['firm_id','report_year','evidence_id','source_file','iidg_id']].rename(columns={'report_year':'confirmed_first_report_year','source_file':'policy_evidence_file'})
d = d.merge(first, on='firm_id', how='left', validate='many_to_one')
d['confirmed_first_effective_year'] = d.confirmed_first_report_year+1
d['stack_window_end_year'] = d.cohort_effective_syn_year+2

fg = d[['firm_id','stack_id','cohort_report_year','cohort_effective_syn_year','treated_in_stack','confirmed_first_report_year','confirmed_first_effective_year','stack_window_end_year','evidence_id','policy_evidence_file','iidg_id']].drop_duplicates(['firm_id','stack_id'])
fg['contaminated_control'] = fg.treated_in_stack.eq(0)&fg.confirmed_first_effective_year.le(fg.stack_window_end_year)
fg['treated_already_exposed'] = fg.treated_in_stack.eq(1)&fg.confirmed_first_report_year.lt(fg.cohort_report_year)
fg['review_later_only_evidence'] = fg.treated_in_stack.eq(1)&fg.confirmed_first_report_year.gt(fg.cohort_report_year)
fg['policy_keep'] = ~(fg.contaminated_control|fg.treated_already_exposed)
save(fg, 'firm_stack_policy_audit.csv')
save(fg.loc[fg.review_later_only_evidence], 'unresolved_kept_for_review.csv')
d = d.merge(fg[['firm_id','stack_id','contaminated_control','treated_already_exposed','policy_keep']],on=['firm_id','stack_id'],validate='many_to_one')
d['quality_keep'] = valid_r2.to_numpy() & d.quality_n_weeks.ge(30) & np.isfinite(d.SYN)
d['exact_duplicate'] = exact.to_numpy()
d['objective_keep'] = d.policy_keep & d.quality_keep & ~d.exact_duplicate
d['exclusion_reason'] = ''
for col, reason in [('contaminated_control','confirmed_exposure_by_stack_window_end'),('treated_already_exposed','confirmed_exposure_before_assigned_cohort'),('exact_duplicate','exact_duplicate')]:
    d.loc[d[col],'exclusion_reason'] += reason+';'
d.loc[~d.quality_keep,'exclusion_reason'] += 'invalid_original_syn_quality;'
d['model_complete'] = np.isfinite(d[['SYN_w_Gao','TreatPost','ebal_weight']+CONTROLS]).all(axis=1)&d.weight_merge.eq(3)
check('old_sample_W2_flag_mismatch', d.model_complete.ne(d.sample_W2.eq(1)).sum(), 'Reproduces original complete-case definition.', True)

cols=['audit_row_id']+KEY+['cohort_report_year','event_time','treated_in_stack','model_complete','objective_keep','exclusion_reason','confirmed_first_report_year','confirmed_first_effective_year','stack_window_end_year','evidence_id','policy_evidence_file','quality_n_weeks','quality_R2']
save(d.loc[~d.objective_keep,cols], 'excluded_observation_list.csv')
save(d.loc[d.objective_keep,cols], 'retained_observation_list.csv')
save(pd.DataFrame(fixes,columns=['audit_row_id','firm_id','variable','old','new','basis']), 'derived_code_corrections.csv')
save(pd.DataFrame(audits), 'structural_data_audit.csv')

flows=[]
for label, mask in [('original_stack',pd.Series(True,index=d.index)),('original_W2_complete',d.model_complete),('objective_eligible_stack',d.objective_keep),('corrected_W2_complete',d.model_complete&d.objective_keep)]:
    for co in [None]+sorted(d.cohort_report_year.unique()):
        sub=d.loc[mask if co is None else mask&d.cohort_report_year.eq(co)]
        flows.append({'stage':label,'cohort':'all' if co is None else int(co),'observations':len(sub),'firms':sub.firm_id.nunique(),'firm_stacks':sub[['firm_id','stack_id']].drop_duplicates().shape[0],'treated_firms':sub.loc[sub.treated_in_stack.eq(1),'firm_id'].nunique(),'control_firms':sub.loc[sub.treated_in_stack.eq(0),'firm_id'].nunique(),'cohorts':sub.cohort_report_year.nunique()})
save(pd.DataFrame(flows),'sample_flow.csv')
cells=[]
for stage,mask in [('old',d.model_complete),('corrected',d.model_complete&d.objective_keep)]:
    for (co,et,tr),sub in d.loc[mask].groupby(['cohort_report_year','event_time','treated_in_stack']):
        cells.append({'stage':stage,'cohort':int(co),'event_time':int(et),'treated':int(tr),'observations':len(sub),'firms':sub.firm_id.nunique(),'weight_sum':sub.ebal_weight.sum()})
save(pd.DataFrame(cells),'event_cell_composition.csv')

# Weight audit observes frozen weights; does not optimize or select a replacement weight.
balances=[]
wd=[]
for stage, mask in [('original',pd.Series(True,index=d.index)),('corrected',d.objective_keep)]:
    pre=d.loc[mask&d.event_time.eq(-1)&d.weight_merge.eq(3)]
    for co,g in pre.groupby('cohort_report_year'):
        tt=g.loc[g.treated_in_stack.eq(1)]
        cc=g.loc[g.treated_in_stack.eq(0)]
        wt=tt.ebal_weight.to_numpy(); wc=cc.ebal_weight.to_numpy()
        for v in BALANCE:
            xt=tt[v].to_numpy(); xc=cc[v].to_numpy()
            mt=np.average(xt,weights=wt); mc=np.average(xc,weights=wc)
            def wsd(x,w):
                return np.sqrt(np.dot(w,(x-np.average(x,weights=w))**2)/(w.sum()-(w@w)/w.sum()))
            sd=np.sqrt((wsd(xt,wt)**2+wsd(xc,wc)**2)/2)
            balances.append({'stage':stage,'cohort':int(co),'variable':v,'treated_mean':mt,'control_mean':mc,'SMD':(mt-mc)/sd})
        wd.append({'stage':stage,'cohort':int(co),'treated_N':len(tt),'control_N':len(cc),'treated_weight_sum':wt.sum(),'control_weight_sum':wc.sum(),'control_ESS':wc.sum()**2/(wc@wc),'max_control_weight':wc.max(),'control_to_treated_weight_ratio':wc.sum()/wt.sum(),'max_abs_SMD':max(abs(x['SMD']) for x in balances if x['stage']==stage and x['cohort']==int(co))})
save(pd.DataFrame(balances),'frozen_weight_balance.csv')
save(pd.DataFrame(wd),'frozen_weight_diagnostics.csv')

required=['audit_row_id']+KEY+['cohort_report_year','cohort_effective_syn_year','event_time','treated_in_stack','post','TreatPost','firm_stack_id','cohort_year_id','firm_cluster_id','SYN','SYN_w_Gao','control_fiscal_year','ebal_weight']+CONTROLS
analysis=d[required].copy()
for c in ['objective_keep','model_complete','contaminated_control','treated_already_exposed','quality_keep']:
    analysis[c]=d[c].astype(np.int8)
analysis.to_stata(OUT/'static_corrected_analysis.dta',write_index=False,version=118)
summary={'original_rows':len(d),'original_complete':int(d.model_complete.sum()),'excluded_all_rows':int((~d.objective_keep).sum()),'excluded_complete_rows':int((~d.objective_keep&d.model_complete).sum()),'corrected_complete':int((d.objective_keep&d.model_complete).sum()),'excluded_control_firm_stacks':int(fg.contaminated_control.sum()),'excluded_treated_firm_stacks':int(fg.treated_already_exposed.sum()),'excluded_distinct_firms':int(d.loc[~d.objective_keep,'firm_id'].nunique()),'code_flag_corrections':len(fixes),'cohorts_preserved':sorted(int(x) for x in d.loc[d.objective_keep&d.model_complete,'cohort_report_year'].unique())}
(OUT/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))

# Prepare, but do not estimate, all supported relative-time indicators for the previously flawed diagnostic.
alt=pd.read_stata(INPUTS['alternative_master'],convert_categoricals=False)
alt['core_complete']=np.isfinite(alt[['SYN_MARKET_ONLY_w','Size_w','Lev_w','MB_w','Age_w']]).all(axis=1).astype(np.int8)
supported=sorted(int(x) for x in alt.loc[alt.core_complete.eq(1)&alt.g.gt(0),'event_time'].dropna().unique())
terms=[]
for k in supported:
    if k==-1: continue
    name='A_m'+str(-k) if k<0 else 'A_p'+str(k)
    alt[name]=(alt.g.gt(0)&alt.event_time.eq(k)).astype(np.int8)
    terms.append({'term':name,'event_time':k})
assert alt.loc[alt.g.gt(0)&alt.event_time.ne(-1)&alt.core_complete.eq(1),[x['term'] for x in terms]].sum(axis=1).eq(1).all()
assert alt.loc[alt.g.eq(0),[x['term'] for x in terms]].eq(0).all().all()
assert alt.loc[alt.event_time.eq(-1),[x['term'] for x in terms]].eq(0).all().all()
alt.to_stata(OUT/'sa_full_event_indicators.dta',write_index=False,version=118)
save(pd.DataFrame(terms),'sa_all_event_terms.csv')
print('Prepared full-supported SA indicators:',supported)
print('All source inputs unchanged:',all(sha(Path(x['path']))==x['sha256'] for x in manifest))
