from pathlib import Path
import pandas as pd,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);R=W.parent;B=R.parent/'huang_basic_reconstruction_20261103'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert not (W/'run_started.json').exists(),'One authorized rerun only; inspect prior run before proceeding'
inputs=[R/'outputs/corrected_analysis.dta',R/'outputs/mechanically_unavailable_fixed_sample_private.csv',B/'outputs/final_analysis.dta',B/'outputs/final_frozen_winsor_cutoffs.csv',Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta')]+list((B/'outputs').glob('*.ster'))+list((B/'outputs').glob('*results.csv'))+[B/'outputs/joint_tests.csv']
manifest=[dict(file=str(p),sha256=sha(p)) for p in inputs];(O/'protected_inputs.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
d=pd.read_stata(inputs[0],convert_categoricals=False);old=pd.read_stata(B/'outputs/final_analysis.dta',convert_categoricals=False).set_index(['firm_id','year']);bad=pd.read_csv(inputs[1])
assert set(map(tuple,bad[['firm_id','year']].to_numpy()))=={(600545,2016),(600551,2016),(600979,2016),(601700,2016)}
mask=pd.MultiIndex.from_frame(d[['firm_id','year']]).isin(pd.MultiIndex.from_frame(bad[['firm_id','year']]))
assert mask.sum()==4 and d.loc[mask,'SYN'].isna().all() and d.loc[~mask&d.old_H0_sample.eq(1),'SYN'].notna().all()
excluded=d.loc[mask,['firm_id','year','n_weeks_before','n_weeks','SYN_before','old_H0_sample','old_H8_sample']].copy();excluded['reason']='verified calendar correction: 30 to 29 complete weeks; explicitly authorized mechanical exclusion';excluded.to_csv(O/'authorized_four_exclusions_private.csv',index=False,encoding='utf-8-sig');d=d.loc[~mask].copy();assert not d.duplicated(['firm_id','year']).any()
idx=pd.MultiIndex.from_frame(d[['firm_id','year']]);compare=old.reindex(idx)
unchanged=['Treat','Post','TreatPost','event_time','Size','Age','Lev','Cent','Top10','Dual','Board','Big4','Size_w','Age_w','Lev_w','Cent_w','Top10_w','Board_w','sample8']
for col in unchanged:
 assert pd.Series(d[col].to_numpy()).equals(pd.Series(compare[col].to_numpy())),col
cuts=pd.read_csv(B/'outputs/final_frozen_winsor_cutoffs.csv').set_index('variable').loc['SYN'];assert (d.SYN_w-d.SYN.clip(cuts.p1,cuts.p99)).abs().dropna().max()<1e-12
audit=[]
for m,n in [('H0',7883),('H8',7609)]:
 s=d[d[f'old_{m}_sample'].eq(1)];assert len(s)==n and s.firm_id.nunique()==648 and s.groupby('firm_id').size().min()>1
 assert len(s.groupby(['year','Treat']))==26
 audit.append(dict(model=m,expected_N=n,clusters=648,treated_firms=s.loc[s.Treat.eq(1),'firm_id'].nunique(),minimum_firm_rows=s.groupby('firm_id').size().min(),controls_unchanged=True,SYN_cutoffs_unchanged=True))
d.to_stata(O/'fixed_analysis.dta',write_index=False,version=118);pd.DataFrame(audit).to_csv(O/'pre_regression_checks.csv',index=False)
authorization=dict(user_permission='Only exclude the four authorized 2016 records; run original H0/H8 static and event models once; no other specification',expected_models=4,original_G1_protected=True,exclude_count=4,new_SYN_computation=False)
(O/'authorization_and_scope.json').write_text(json.dumps(authorization,ensure_ascii=False,indent=2),encoding='utf-8');print(pd.DataFrame(audit).to_string(index=False))
