from pathlib import Path
import json,hashlib,re,resource,math
import pandas as pd
import numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(n,x):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def chi2_sf(stat,df):
    # Exact upper incomplete-gamma recurrence for integer chi-square df.
    x=stat/2
    if df%2==0:a=1.;q=math.exp(-x)
    else:a=.5;q=math.erfc(math.sqrt(x))
    while a<df/2:
        q+=math.exp(a*math.log(x)-x-math.lgamma(a+1)) if x>0 else 0
        a+=1
    return min(1.,max(0.,q))
def table(d):
    d=d.copy()
    for c in d.columns:
        if pd.api.types.is_float_dtype(d[c]):d[c]=d[c].map(lambda v:f'{v:.6f}' if np.isfinite(v) else 'NA')
    return '| '+' | '.join(map(str,d.columns))+' |\n|'+'|'.join(['---']*len(d.columns))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in d.itertuples(index=False,name=None))
meta=json.loads((O/'prepared.json').read_text());execution=json.loads((O/'stata_execution.json').read_text())
assert execution['status']=='COMPLETE' and execution['completed_pairs']==12
log=(O/'drdid_fixed.log').read_text(errors='replace')
assert len(re.findall(r'^FIXED_PAIR_START ',log,re.M))==12
assert len(re.findall(r'^FIXED_PAIR_COMPLETE ',log,re.M))==12
assert not re.search(r'^r\(\d+\);',log,re.M)
assert 'EXPORT_ONLY_COMPLETE_NO_REFITS' in (O/'export_only.log').read_text()
assert 'JOINT_PVALUES_INDEPENDENTLY_VERIFIED_NO_REFITS' in (O/'joint_test_validation.log').read_text()
r=pd.read_csv(O/'drdid_results_full_precision.csv').set_index('model');m=r.loc['main_static']
a=pd.read_csv(O/'company_sample_audit_private.csv').set_index('firm_id'); base=pd.read_csv(O/'baseline_2008_private.csv').set_index('firm_id')
eligible=a.index[a.included]; COV=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4']
validation=[]; overlaps=[]; balances=[]; influence={}; weights=[]
for label,row in r.iterrows():
    f=pd.read_csv(O/f'{label}_influence_private.csv').set_index('firm_id')
    assert f.index.is_unique and set(f.index)<=set(eligible)
    assert set(f.Treat)=={0,1} and len(f)==row.clusters and 2*len(f)==row.panel_rows
    assert np.array_equal(f.Treat.to_numpy(),a.loc[f.index,'Treat'].to_numpy())
    assert f[['pscore','att_weight','recentered_IF']].notna().all().all()
    b=f.recentered_IF.mean();se=np.sqrt(np.sum((f.recentered_IF-b)**2))/len(f)
    assert abs(b-row.ATT)<1e-10 and abs(se-row.SE)<1e-10
    influence[label]=(f.recentered_IF-row.ATT)/len(f)
    validation.append(dict(model=label,firms=len(f),treated=int(f.Treat.sum()),control=int(f.Treat.eq(0).sum()),mean_RIF_matches_ATT=True,IF_SE_matches_Stata=True,ATT_absolute_error=abs(b-row.ATT),SE_absolute_error=abs(se-row.SE)))
    t=f[f.Treat.eq(1)];c=f[f.Treat.eq(0)];w=c.att_weight.to_numpy();normw=w/w.sum()
    overlaps.append(dict(model=label,firms=len(f),treated=len(t),controls=len(c),PS_min=f.pscore.min(),PS_max=f.pscore.max(),treated_PS_min=t.pscore.min(),treated_PS_max=t.pscore.max(),control_PS_min=c.pscore.min(),control_PS_max=c.pscore.max(),treated_outside_control_PS_range=int(((t.pscore<c.pscore.min())|(t.pscore>c.pscore.max())).sum()),control_weight_min=w.min(),control_weight_median=np.median(w),control_weight_max=w.max(),control_ESS=w.sum()**2/(w@w),max_control_weight_share=normw.max(),top5_control_weight_share=np.sort(normw)[-5:].sum(),default_PS_trimming_disabled=True,control_PS_above_default_995=int(c.pscore.gt(.995).sum()),implementation_PS_cap_triggered=bool(f.pscore.gt(1-1e-6).any())))
    if label=='main_static':
        for v in COV:
            tv=base.loc[t.index,v].to_numpy();cv=base.loc[c.index,v].to_numpy()
            sd=np.sqrt((tv.var(ddof=1)+cv.var(ddof=1))/2)
            balances.append(dict(variable=v,treated_mean=tv.mean(),control_mean_before=cv.mean(),control_mean_after=np.average(cv,weights=w),SMD_before=(tv.mean()-cv.mean())/sd,SMD_after=(tv.mean()-np.average(cv,weights=w))/sd))
        weights=f.reset_index();weights['normalized_ATT_weight']=weights.att_weight
        weights.loc[weights.Treat.eq(0),'normalized_ATT_weight'] *= len(t)/w.sum()
        save('main_weights_private.csv',weights)
r['firms']=[len(pd.read_csv(O/f'{label}_influence_private.csv')) for label in r.index]
r['treated']=[int(pd.read_csv(O/f'{label}_influence_private.csv').Treat.sum()) for label in r.index]
r['controls']=r.firms-r.treated
save('drdid_static_result.csv',r.loc[['main_static']].reset_index())
event=r.loc[[f'year_{y}' for y in list(range(2009,2013))+list(range(2015,2022))]].reset_index()
event.insert(1,'year',event.model.str.replace('year_','',regex=False).astype(int));event['relative_to_2013']=True
save('drdid_yearly_results.csv',event);save('overlap_and_weight_diagnostics.csv',overlaps);save('covariate_balance.csv',balances);save('estimator_validation.csv',validation)
joint=[];covariance=[]
for name,years in [('pre_2009_2012',list(range(2009,2013))),('post_2015_2021',list(range(2015,2022)))]:
    labels=[f'year_{y}' for y in years]
    # Zero denotes no influence contribution from an unobserved pair, never imputed SYN.
    mat=pd.concat([influence[k].rename(k) for k in labels],axis=1).reindex(eligible).fillna(0).to_numpy()
    V=mat.T@mat;b=r.loc[labels,'ATT'].to_numpy();rank=np.linalg.matrix_rank(V)
    assert rank==len(labels),'Joint covariance is singular; do not change model.'
    stat=float(b@np.linalg.solve(V,b));p=chi2_sf(stat,rank)
    joint.append(dict(test=name,chi2=stat,df=rank,p=p,pair_sample_sizes=';'.join(str(int(r.loc[k,'firms'])) for k in labels),same_firms_every_pair=len(set(tuple(influence[k].index.sort_values()) for k in labels))==1,normalization='IF/n_pair aligned by original firm_id'))
    for i,yi in enumerate(years):
        for j,yj in enumerate(years):covariance.append(dict(test=name,year_i=yi,year_j=yj,covariance=V[i,j]))
save('drdid_joint_tests.csv',joint);save('joint_covariance.csv',covariance)
assert max(abs(b['SMD_after']) for b in balances)<1e-4,'IPT balance score not sufficiently small; convergence concern.'
protected=json.loads((O/'protected_before.json').read_text());after=[]
for v in protected:
    h=sha(v['path']);after.append(dict(path=v['path'],sha256=h,unchanged=h==v['sha256']))
dump('protected_after.json',after);assert all(v['unchanged'] for v in after)
runhash=[dict(path=str(p),sha256=sha(p)) for p in [W/'PLAN.md',W/'prepare.py',W/'run_fixed.do',W/'launch.py',W/'export_precision.do',W/'verify_joint.do',W/'summarize.py']]
dump('reproduction_code_hashes.json',runhash)
old=pd.read_csv(W.parent/'huang_transition_static_H8_20261104/outputs/static_results.csv')
old.to_csv(O/'original_H8_results_reference_only.csv',index=False,encoding='utf-8-sig')
pre_p=joint[0]['p'];post_p=joint[1]['p']; mainover=overlaps[0]
excluded=a[~a.included].reset_index();exsum=excluded.groupby(['primary_exclusion_reason','Treat']).size().unstack(fill_value=0).reset_index()
exsum.columns=['排除主因','对照组','处理组']
exsum['排除主因']=exsum['排除主因'].replace({'deferred_601607':'601607按用户要求暂缓','incomplete_2008_baseline':'2008基线控制仍缺失','no_legal_2013_SYN':'缺少合法2013年基准SYN','not_listed_by_2008':'2008年末尚未上市'})
save('exclusion_summary.csv',exsum)
postcounts=a[a.included].groupby(['Treat','post_year_count']).size().rename('firms').reset_index();save('post_year_count_distribution.csv',postcounts)
pretext='拒绝政策前差分联合为零，条件平行趋势仍未得到支持' if pre_p<.05 else '5%水平不能拒绝政策前差分联合为零，但这不证明平行趋势成立'
warnings=[]
if pre_p<.05:warnings.append('政策前联合检验失败，因此不能将政策后ATT直接解释为已识别的因果效应。')
if mainover['treated_outside_control_PS_range']>0:warnings.append(f"{mainover['treated_outside_control_PS_range']}家处理公司倾向得分超出观察到的对照组范围，存在外推风险。")
if mainover['control_ESS']<.5*mainover['controls']:warnings.append('对照组加权有效样本量少于原对照组一半，精度及重叠需谨慎。')
if any(z['implementation_PS_cap_triggered'] for z in overlaps):warnings.append('至少一个配对达到程序内置概率上界，须谨慎解释实现的数值保护；未改程序或另换方法。')
status=dict(status='COMPLETE_STOPPED',main_firms=int(m.clusters),ATT=float(m.ATT),SE=float(m.SE),p=float(m.p),CI_low=float(m.CI_low),CI_high=float(m.CI_high),pre_joint_p=pre_p,post_joint_p=post_p,conditional_parallel_trends_supported_at_5pct=pre_p>=.05,main_control_ESS=mainover['control_ESS'],exclusions=len(excluded),protected_files=len(after),all_originals_unchanged=True,SYN_recomputed=False,missing_imputed=False,cohort_or_Treat_changed=False,PS_trimmed=False,static_fits=1,year_contrasts=11,alternative_specs_tried=0,Stata_peak_RSS_MiB=execution['Stata_peak_RSS_MiB'],preparation_peak_RSS_MiB=meta['peak_RSS_MiB'],report_peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,warnings=warnings)
dump('completed.json',status)
report=f'''# 限定2008基线完整样本的DR-DID结果

## 结果

固定静态ATT = **{m.ATT:.6f}**，公司聚类SE = **{m.SE:.6f}**，双侧p = **{m.p:.6f}**，95%CI = **[{m.CI_low:.6f}, {m.CI_high:.6f}]**。10%、5%、1%分别是否显著：{m.p<.10}、{m.p<.05}、{m.p<.01}。不替代原H8/G1。

纯政策前联合检验：chi2({joint[0]['df']}) = {joint[0]['chi2']:.6f}，p = **{pre_p:.8f}**，{pretext}。政策后7项联合p = {post_p:.8f}。年度p值为逐项未校正p值，不据此挑年或改样本。

## 固定样本与排除

初始原H8公司648家，2008年末前上市526家。最终513家：处理358、对照155。排除135家（原因可能重叠，下表按预定先后顺序计唯一主因）：

{table(exsum)}

3家额外缺少合法2013基准结果：600058、600606、600763。这里是“2013基准缺失”，不宣称它们所有政策前年份都没有SYN。601515因2008年未上市排除，不因本轮修改行业池或补周收益。9家待核验Dual保持缺失，601607单列暂缓。9家已确认不兼任的真实0来自公告核验台账，有来源清单，不是缺失填0。

静态估计采用513家公司、1,026个合成两期面板行（每公司一行2013、一行后期均值）。原始合法结果实际使用4,054个公司年度，包括513个2013基准和3,541个政策后结果。不能将1,026误写成原始公司年度观测N。每公司后期5—7年，两组平均后期数见覆盖表。本轮不把2015—2021不平衡缺年插补为完整7年。

{table(postcounts)}

## 估计对象与方法

使用冻结SYN_w。基准SYN2013窗口2013年5月—2014年4月；2014过渡窗口完全不作纯前期或后期对比，原Post定义不改。政策后为2015—2021已观察合法年度SYN的公司内均值。估计目标是本轮完整样本中处理公司的“可观察后期平均SYN变化”ATT，并非原H8的TWFE系数，也不无条件等同于固定7年ATT。若后期是否可观察与潜在结果有关，仍会带来选择问题。

8项2008基线固定为Size、Age、Lev、Cent、Top10、Dual、Board、Big4。Size=ln资产2008；Lev=负债2008/资产2008；Age=ln(2008-原始上市年+1)；Cent=第2—5股东持股和/第1；Top10=第1—10持股比例和/100；Board=ln年末在职董事数；Big4沿用原精确名称映射。股份排名11—15从不计入Top10。无当期/政策后控制、不改基线缩尾、仅线性标准化连续X。财报实际披露日期未逐家核验，不能把年末会计日期等同于市场获知日期。

采用Stata现有drdid 1.91的panel drimp（IPT倾向权重与控制组加权线性变化回归），使用全部8项X及常数。按原firm_id聚类的解析影响函数标准误。两期panel公司差分净除固定公司水平，并以对照组净除共同期别变化，不另行更换或添加H8固定效应。不存在“保证平行趋势”的双重稳健性质：该方法仍要求给定X后的平行趋势、重叠、无预期干预及合法样本选择。[作者方法及实现说明](https://psantanna.com/DRDID/index.html)，[Stata实现说明](https://friosavila.github.io/playingwithstata/drdid/drdid_stata.html)。

## 重叠和权重

主样本倾向得分范围[{mainover['PS_min']:.6f}, {mainover['PS_max']:.6f}]。155家对照组权重ESS={mainover['control_ESS']:.2f}；最大单家对照权重份额={mainover['max_control_weight_share']:.2%}；最大5家合计份额={mainover['top5_control_weight_share']:.2%}。处理组超出对照得分范围{mainover['treated_outside_control_PS_range']}家。显式pscoretrim(1)，没有倾向得分剔除或权重截尾。程序内置1-1e-6保护是否触发：{any(z['implementation_PS_cap_triggered'] for z in overlaps)}。基线均值平衡不代表政策前结果趋势必然平衡。

{table(pd.DataFrame(balances)[['variable','SMD_before','SMD_after']])}

## 各年对2013的固定DR差分

2009—2012是相对2013的前期安慰剂差分，不是实际政策效应。2013省略为0。各年配对只使用主样本中该年合法结果可观察的公司，N可能不同，故不伪称全年完全同样本。

{table(event[['year','ATT','SE','p','CI_low','CI_high','firms','treated','controls']])}

联合检验用公司级影响函数按firm_id对齐构造协方差，检验各配对子样本的联合零假设。估计方程外贡献记0仅用于影响函数协方差，不是给缺失SYN赋0。保存完整联合协方差及各配对N。

## 与原结果的关系和限制

原保留2014过渡项的H8：系数-0.0916718332，SE0.0436880939，p0.0362635682，7,609公司年度、648簇；原政策前联合p0.0009485776。本轮改变了可识别目标人群、控制变量时点、时间聚合和估计方法，不能把系数或p值差异只归因于加权算法，更不能据此证明原始数据错误。本轮未授权额外同样本TWFE分解，因此未跑。

{chr(10).join('- '+x for x in warnings) if warnings else '诊断未发现本方案预设的主要警示，但不代表识别假设已被证明。'}

行业回溯、处理边界和历史ST筛选等既有未经作者确认的限制继续保留。本轮不会因为不显著而修改这些规则。此分析仍是未经作者确认的重建实证，不是原论文完全复刻。

## 复现和保护

已完成1个静态及11个固定年度配对，没有其他控制规格、样本筛选实验、重新计算SYN或重新扫描年报。所有12份估计存档和日志均已保存。高精度导出只读取估计存档，零重估；影响函数独立核对所有ATT、SE与Stata相符。日志摘要脚本将代码中的“error”和“r()”误标为错误，已逐行确认无Stata r(n)退出且有12项完成标记。

原数据、H8、G1和既有证据共{len(after)}个受保护文件SHA256前后一致。样本准备峰值{meta['peak_RSS_MiB']:.1f}MiB，Stata峰值{execution['Stata_peak_RSS_MiB']:.1f}MiB，单核顺序运行。完成后停止，没有继续搜索显著规格。

关键文件：drdid_static_result.csv、drdid_yearly_results.csv、drdid_joint_tests.csv、excluded_firms_private.csv、company_sample_audit_private.csv、sample_attrition.csv、baseline_2008_private.csv、verified_duality_evidence.csv、main_weights_private.csv、overlap_and_weight_diagnostics.csv、covariate_balance.csv、dr_analysis_wide.dta、drdid_fixed.log、protected_before/after.json。带private的表含公司级原始信息，不直接公开至GitHub。
'''
(O/'DR_DID结果报告.md').write_text(report,encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2))
