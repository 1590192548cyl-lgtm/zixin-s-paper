# Gao口径公司—行业指引映射低内存报告

生成时间：2026-08-06T09:57:13  
规则版本：gao_relaxed_business_v1_20260806  
随机抽查种子：20260806

## 最终规模

- 核心公司—IIDG：867
- 核心处理公司：629
- 扩展新增公司—IIDG：4
- 扩展新增公司：4
- probable_business：4
- 可作为清洁对照候选：3671

## 轻量放宽复核

- business_confirmed_direct：1
- business_confirmed_composite：0
- probable_business：4
- 继续business_not_supported：2519

## 质量检查

```json
{
  "strict_confirmed_source_rows": 137,
  "strict_confirmed_dedup_firm_iidg": 131,
  "strict_confirmed_firm_iidg_mapped": 131,
  "earlier_confirmed_source_rows": 481,
  "earlier_confirmed_split_firm_iidg_expected": 426,
  "earlier_confirmed_split_firm_iidg_mapped": 426,
  "original_mda_confirmed_rows": 418,
  "original_mda_confirmed_firm_iidg_expected": 398,
  "original_mda_confirmed_firm_iidg_mapped": 398,
  "mda_tasks_total": 2943,
  "duplicate_evidence_keys": 0,
  "duplicate_core_firm_iidg": 0,
  "treat_before_policy": 0,
  "treat_before_listing": 0,
  "firm_first_year_min_errors": 0,
  "negative_entered_core": 0,
  "unsupported_clean_control_errors": 0,
  "core_sampled": 50,
  "core_file_exists": 50,
  "core_evidence_token_found": 50,
  "expanded_added_sampled": 4,
  "expanded_added_file_exists": 4,
  "expanded_added_evidence_token_found": 4,
  "unsupported_sampled": 50,
  "unsupported_file_exists": 50,
  "unsupported_evidence_token_found": 50
}
```

说明：附件预期133/480，但当前经人工复核后保存的严格文件实际为137/481原始行；本程序全部保留，另列去重口径，不人为删行。更早记录中一行可能明确包含多个IIDG，映射时拆分后再按公司—IIDG—证据年度去重。清洁对照资格必须继承既有公司总体资格，且本轮不存在任何候选/审计记录；business_not_supported不会自动转成清洁对照。

## 性能

- 峰值内存：38.95 MB
- 总运行时间：2.83 秒
- 未读取annual_report_explicit_hits_all.csv，未扫描全部年报。
