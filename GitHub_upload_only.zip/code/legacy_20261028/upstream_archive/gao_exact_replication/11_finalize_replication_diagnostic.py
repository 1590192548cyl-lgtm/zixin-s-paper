from pathlib import Path
import json

import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"


PAPER_DESC = {
    "Syn_spec": (-0.259, -0.193, 0.861, -2.572, -0.821, 0.370, 1.474),
    "Treat": (0.139, 0.000, 0.346, 0.000, 0.000, 0.000, 1.000),
    "Post": (0.517, 1.000, 0.500, 0.000, 0.000, 1.000, 1.000),
    "Size": (22.251, 22.146, 1.202, 19.517, 21.442, 22.953, 25.649),
    "MB": (3.074, 2.109, 3.295, 0.298, 1.322, 3.473, 21.374),
    "Lev": (0.453, 0.447, 0.204, 0.066, 0.297, 0.606, 0.943),
    "Stdroa": (0.028, 0.017, 0.035, 0.001, 0.008, 0.033, 0.202),
    "abs_dEPS": (0.246, 0.117, 0.363, 0.001, 0.042, 0.284, 2.258),
    "abs_Accruals": (0.062, 0.044, 0.065, 0.001, 0.020, 0.080, 0.352),
    "Loss": (0.218, 0.000, 0.413, 0.000, 0.000, 0.000, 1.000),
    "Length_MDA": (8.724, 8.729, 0.444, 7.555, 8.433, 9.019, 9.784),
    "Length_AR": (11.864, 11.860, 0.246, 11.264, 11.707, 12.018, 12.517),
    "Stdret": (0.029, 0.027, 0.010, 0.013, 0.022, 0.033, 0.057),
    "FundCorr": (-2.676, -2.112, 2.007, -10.021, -3.560, -1.208, -0.257),
    "d_Instihold": (0.000, 0.000, 0.053, -0.155, -0.023, 0.020, 0.172),
    "Instihold": (0.063, 0.041, 0.067, 0.000, 0.012, 0.094, 0.314),
    "Analyst": (1.462, 1.386, 1.155, 0.000, 0.000, 2.398, 3.689),
    "Indsize": (5.813, 6.172, 1.188, 2.485, 4.920, 6.820, 7.251),
    "Subs": (2.524, 2.565, 0.968, 0.000, 1.946, 3.135, 4.942),
    "Big4": (0.057, 0.000, 0.233, 0.000, 0.000, 0.000, 1.000),
    "Tophold": (0.343, 0.323, 0.147, 0.088, 0.226, 0.441, 0.743),
    "Tophold2": (0.139, 0.104, 0.115, 0.008, 0.051, 0.194, 0.552),
}


def fmt(x, n=4):
    return "" if pd.isna(x) else f"{x:.{n}f}"


def main():
    confirmed = pd.read_csv(OUT / "gao_exact_replication_models.csv")
    augmented = pd.read_csv(OUT / "gao_sse_augmented_replication_models.csv")
    paper = pd.DataFrame(
        [
            {
                "model": "Gao_Table3_col7_no_controls", "sample": "authors_final",
                "N_before": 27518, "N": 27518, "clusters": pd.NA,
                "treated_firms": pd.NA, "cohorts": 4, "TreatPost": -0.100,
                "SE": abs(-0.100 / -3.45), "t": -3.45, "p": 0.0006,
                "CI_low": -0.100 - 1.96 * abs(-0.100 / -3.45),
                "CI_high": -0.100 + 1.96 * abs(-0.100 / -3.45),
                "mapping": "authors_manual_mapping",
            },
            {
                "model": "Gao_Table3_col8_full_controls", "sample": "authors_final",
                "N_before": 27518, "N": 27518, "clusters": pd.NA,
                "treated_firms": pd.NA, "cohorts": 4, "TreatPost": -0.095,
                "SE": abs(-0.095 / -3.21), "t": -3.21, "p": 0.0013,
                "CI_low": -0.095 - 1.96 * abs(-0.095 / -3.21),
                "CI_high": -0.095 + 1.96 * abs(-0.095 / -3.21),
                "mapping": "authors_manual_mapping",
            },
        ]
    )
    confirmed["mapping"] = "current_confirmed_mapping"
    augmented["mapping"] = "official_SSE_direct_scope_augmented"
    models = pd.concat([paper, confirmed, augmented], ignore_index=True, sort=False)
    models.to_csv(OUT / "gao_replication_model_comparison.csv", index=False)

    local_desc = pd.read_csv(OUT / "sse_augmented_winsorized_descriptives.csv")
    paper_rows = []
    for v, vals in PAPER_DESC.items():
        paper_rows.append(
            dict(variable=v, paper_N=27518, paper_mean=vals[0], paper_median=vals[1],
                 paper_sd=vals[2], paper_min=vals[3], paper_p25=vals[4],
                 paper_p75=vals[5], paper_max=vals[6])
        )
    desc = local_desc.merge(pd.DataFrame(paper_rows), on="variable", how="outer")
    desc["mean_difference_local_minus_paper"] = desc["mean"] - desc["paper_mean"]
    desc["mean_ratio_local_to_paper"] = desc["mean"] / desc["paper_mean"].where(desc.paper_mean.ne(0))
    desc["diagnostic_flag"] = "close_or_sample_composition"
    desc.loc[desc.variable.isin(["Instihold", "Stdret"]), "diagnostic_flag"] = "major_scale_or_source_mismatch"
    desc.loc[desc.variable.isin(["Length_MDA", "Length_AR"]), "diagnostic_flag"] = "text_counting_or_section_boundary_mismatch"
    desc.loc[desc.variable.isin(["Analyst", "Indsize"]), "diagnostic_flag"] = "close_after_coding_correction"
    desc.to_csv(OUT / "gao_replication_descriptive_comparison.csv", index=False)

    core_counts = pd.read_csv(OUT / "confirmed_stack_vs_gao_table1.csv")
    aug_counts = pd.read_csv(OUT / "official_sse_augmented_stack_vs_gao_table1.csv")
    cohort = core_counts.rename(columns={"project_rows": "core_rows"})[
        ["cohort_report_year", "treated_in_stack", "Post", "core_rows", "gao_paper_rows"]
    ].merge(
        aug_counts.rename(columns={"project_rows": "sse_augmented_rows"})[
            ["cohort_report_year", "treated_in_stack", "Post", "sse_augmented_rows"]
        ],
        on=["cohort_report_year", "treated_in_stack", "Post"], how="outer"
    )
    cohort["core_gap"] = cohort.core_rows - cohort.gao_paper_rows
    cohort["sse_augmented_gap"] = cohort.sse_augmented_rows - cohort.gao_paper_rows
    cohort.to_csv(OUT / "gao_replication_cohort_comparison.csv", index=False)

    missing = pd.read_csv(OUT / "sse_augmented_missingness.csv").sort_values("missing_rate", ascending=False)
    gaps = pd.DataFrame(
        [
            [1, "treatment_mapping", "critical", "Current mapping contains only 7 SSE policies; paper universe has 27 industry-specific SSE guidelines. The paper's largest SH real-estate and second-largest SH chemical treated industries are absent from the current mapping."],
            [2, "author_manual_firm_IIDG_list", "critical", "Online Appendix Table III / authors' firm-level manual mapping is not locally available; official-scope augmentation cannot be certified identical."],
            [3, "FundCorr_coverage", "critical", f"Missing in {missing.set_index('variable').loc['FundCorr','missing_rate']:.1%} of augmented stack rows; local construction starts only in 2011."],
            [4, "Stdroa_and_Stdret_coverage", "high", f"Stdroa missing {missing.set_index('variable').loc['Stdroa','missing_rate']:.1%}; Stdret missing {missing.set_index('variable').loc['Stdret','missing_rate']:.1%}."],
            [5, "Instihold_source", "high", "Local mean 0.459 versus paper 0.063, indicating a materially different institutional-ownership field/universe."],
            [6, "Stdret_scale", "high", "Local mean 0.136 versus paper 0.029 despite the stated three-year monthly-return formula; source frequency/field or paper implementation differs."],
            [7, "text_length_measurement", "high", "Local Length_MD&A and Length_AR are materially longer than paper, consistent with different section extraction and character-counting conventions."],
            [8, "Analyst_zero_semantics", "corrected", "Raw analyst file contains only positive counts; no-record firm-years were mechanically coded as zero. Mean moved close to paper."],
            [9, "Indsize_granularity", "corrected", "Prior code used two-digit CSRC subsectors. Broad CSRC sector count produces a distribution much closer to Gao."],
            [10, "Length_AR_transform", "corrected", "Prior regressions used raw annual-report character count in places; replication now uses natural log as Gao defines."],
        ],
        columns=["priority", "item", "severity", "finding"],
    )
    gaps.to_csv(OUT / "gao_replication_gap_priorities.csv", index=False)

    core_base = confirmed.loc[confirmed.model.eq("formula_base_no_controls")].iloc[0]
    core_full = confirmed.loc[confirmed.model.eq("full_controls_available")].iloc[0]
    aug_base = augmented.loc[augmented.model.eq("augmented_formula_base_no_controls")].iloc[0]
    aug_full_nc = augmented.loc[augmented.model.eq("augmented_full_sample_no_controls")].iloc[0]
    aug_full = augmented.loc[augmented.model.eq("augmented_full_controls")].iloc[0]
    sample_sizes = pd.read_csv(OUT / "sse_augmented_sample_sizes.csv")
    full_n = int(sample_sizes.loc[sample_sizes["sample"].eq("sample_full"), "rows"].iloc[0])

    report = f"""# Gao et al. (2024) 主回归原样复刻与数据差距诊断

## 结论

按论文的四批次 stacked DID、[-3,+2]、clean control、cohort×firm 与 cohort×year 固定效应、公司聚类标准误、`Syn_spec(t+1)` 和完整控制变量定义重新执行后，**现有项目仍不能称为对 Gao 的样本级精确复刻**。方程已经复刻；作者的人工 firm–IIDG 处理清单、完整文本与若干控制变量源尚未复刻。

现有严格确认映射的无控制模型为 {fmt(core_base.TreatPost)}（SE={fmt(core_base.SE)}，p={fmt(core_base.p)}，N={int(core_base.N):,}）。补入官方直接行业范围内遗漏的16项上交所指引后，同一模型变为 {fmt(aug_base.TreatPost)}（SE={fmt(aug_base.SE)}，p={fmt(aug_base.p)}，N={int(aug_base.N):,}）。方向和绝对值向论文的 -0.100 移动，但仍不显著。

在当前可获得完整控制变量的共同样本中，无控制模型为 {fmt(aug_full_nc.TreatPost)}（SE={fmt(aug_full_nc.SE)}，p={fmt(aug_full_nc.p)}）；加入论文全部19项控制变量后为 {fmt(aug_full.TreatPost)}（SE={fmt(aug_full.SE)}，p={fmt(aug_full.p)}，N={int(aug_full.N):,}）。控制变量只使系数变化 {fmt(aug_full.TreatPost-aug_full_nc.TreatPost)}，因此“不显著主要因为控制变量选错”不成立。

## 与论文 Table 3 的直接比较

| 结果 | Treat×Post | SE | t | p | N |
|---|---:|---:|---:|---:|---:|
| Gao Table 3 (7)，无控制 | -0.1000 | 0.0290 | -3.45 | <0.001 | 27,518 |
| Gao Table 3 (8)，全控制 | -0.0950 | 0.0296 | -3.21 | 0.001 | 27,518 |
| 当前严格确认映射，无控制 | {fmt(core_base.TreatPost)} | {fmt(core_base.SE)} | {fmt(core_base.t,2)} | {fmt(core_base.p)} | {int(core_base.N):,} |
| 官方SSE范围补齐，无控制 | {fmt(aug_base.TreatPost)} | {fmt(aug_base.SE)} | {fmt(aug_base.t,2)} | {fmt(aug_base.p)} | {int(aug_base.N):,} |
| 补齐映射的全控制共同样本，无控制 | {fmt(aug_full_nc.TreatPost)} | {fmt(aug_full_nc.SE)} | {fmt(aug_full_nc.t,2)} | {fmt(aug_full_nc.p)} | {int(aug_full_nc.N):,} |
| 补齐映射的全控制模型 | {fmt(aug_full.TreatPost)} | {fmt(aug_full.SE)} | {fmt(aug_full.t,2)} | {fmt(aug_full.p)} | {int(aug_full.N):,} |

论文显著性差距同时来自系数与样本：本项目补齐映射后的全控制系数绝对值约为论文的 {abs(aug_full.TreatPost)/0.095:.1%}，SE约为论文的 {aug_full.SE/(0.095/3.21):.1%}。也就是说，主要不是“标准误太大”，而是当前处理组与因变量数据产生的平均效应本身约只有论文的一半。

## 处理组映射差距

论文说明截至2020年，上交所共28项IIDG，其中27项为行业专门指引；深交所主板和创业板分别15项和18项。现有核心映射只有35项政策，其中上交所仅7项，而且遗漏论文明确指出占处理样本最多的上交所房地产、第二多的上交所化工。

本轮仅按官方政策中可以直接对应CSRC行业分类的范围补入16项上交所指引，没有按回归结果选择公司或政策。新增489家此前漏标或晚标公司，stack从24,650行增至28,596行，处理公司从290家增至725家。不过，扩展后的批次构成仍不等于论文 Table 1：第一批次仍明显少标，2015/2016批次则在未施加作者完整缺失筛选前偏多。这说明作者人工阅读得到的 firm–IIDG 名单仍是精确复刻的关键缺口。

## 变量与样本差距

官方SSE补齐后，基础样本为28,596行；G1完整样本26,039行；论文19项控制变量共同完整样本只有{full_n:,}行，而论文为27,518行。最大缺失来源为 FundCorr（34.5%），随后为 Stdroa（18.7%）、Stdret（15.0%）、ΔInstihold（11.6%）和MD&A长度（10.6%）。

经过本轮可验证的编码纠正，Analyst均值1.563（论文1.462），Indsize均值5.608（论文5.813），Size、Lev、Stdroa、Big4、Tophold也已接近论文。仍有四个实质性不一致：

1. Instihold均值0.459，论文0.063，表明现有“机构投资者持股比例”字段与作者使用的机构范围不同；
2. Stdret均值0.136，论文0.029，虽均标称过去三年月收益率标准差，但数据频率、收益字段或作者实际实现存在尺度差异；
3. Length_MD&A均值9.463，论文8.724，当前年报切段或字符计数明显更长；
4. Length_AR均值12.112，论文11.864，当前全文文本包含的内容比作者CNRDS口径更多。

SYN本身在当前全控制样本的均值为-0.237、标准差0.886，已接近论文的-0.259和0.861；因此SYN并非唯一、也未必是最大的差距来源。

## 已确认的真实代码/口径问题

- 漏掉大量上交所行业政策，尤其房地产与化工；
- 部分旧模型把年报字符数原值作为 Length_AR，论文要求自然对数；
- 旧 Indsize 使用二位CSRC子行业，论文分布对应更宽的CSRC行业层级；
- 分析师原始表只记录正数，旧代码把“无记录”当缺失并删除；按定义应为0；
- 子公司原始表是一行一个子公司，无记录代表计数0，不是统计插补；
- 本轮确认 `annual_report_year = syn_year - 1`，时间匹配正确。

## 最终判断

当前不显著不是通过换控制变量能够解决的问题。补齐最大一类政策映射缺口后，系数从接近0变为约-0.03至-0.04，但仍未达到论文的-0.095。要实现真正的样本级原样复刻，必须先获得或重建作者 Online Appendix Table III 对应的完整 firm–IIDG 人工名单，并统一 Instihold、Stdret、MD&A/年报字符计数口径，同时补齐 FundCorr 等早期年份数据。完成这些数据修复之前，不应再依据p值调整回归规格。

## 输出文件

- `gao_replication_model_comparison.csv`
- `gao_replication_cohort_comparison.csv`
- `gao_replication_descriptive_comparison.csv`
- `gao_replication_gap_priorities.csv`
- `gao_replication_report.md`
- `gao_sse_augmented_replication_models.csv`
- `gao_sse_augmented_replication.log`

所有原始文件均未覆盖；新增数据与代码只保存在本复刻目录。
"""
    (OUT / "gao_replication_report.md").write_text(report, encoding="utf-8")

    manifest = []
    for p in sorted(OUT.iterdir()):
        if p.is_file():
            manifest.append({"file": p.name, "bytes": p.stat().st_size})
    pd.DataFrame(manifest).to_csv(OUT / "output_manifest.csv", index=False)

    summary = {
        "paper_full_beta": -0.095,
        "paper_full_se": abs(-0.095 / -3.21),
        "core_no_control_beta": float(core_base.TreatPost),
        "augmented_no_control_beta": float(aug_base.TreatPost),
        "augmented_full_beta": float(aug_full.TreatPost),
        "augmented_full_p": float(aug_full.p),
        "augmented_full_N": int(aug_full.N),
        "main_diagnosis": "treatment mapping and data-source/measurement non-equivalence; not control-variable selection",
    }
    (OUT / "gao_replication_final_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
