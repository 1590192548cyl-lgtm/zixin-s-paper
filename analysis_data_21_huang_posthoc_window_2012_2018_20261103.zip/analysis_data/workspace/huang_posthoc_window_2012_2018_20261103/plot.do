clear all
set more off
local out "/Users/macpro/Documents/New project/huang_posthoc_window_2012_2018_20261103/outputs"
import delimited "`out'/event_results_comparison.csv", varnames(1) case(preserve) clear
set obs 40
replace window="full_2009_2021" in 37/38
replace window="posthoc_2012_2018" in 39/40
replace model="H0" in 37
replace model="H8" in 38
replace model="H0" in 39
replace model="H8" in 40
replace event_time=-1 if missing(event_time)
replace coefficient=0 if event_time==-1
sort model window event_time
twoway (rcap CI_low CI_high event_time if window=="full_2009_2021",lcolor(gs10)) (connected coefficient event_time if window=="full_2009_2021",lcolor(gs8) mcolor(gs8) lpattern(dash)) (rcap CI_low CI_high event_time if window=="posthoc_2012_2018",lcolor(navy)) (connected coefficient event_time if window=="posthoc_2012_2018",lcolor(navy) mcolor(navy)), by(model,cols(2) title("Full sample and post-hoc window comparison",size(medium)) note("Literature-motivated post-hoc comparison, not author-confirmed replication. 95% firm-clustered CI.",size(vsmall)) legend(position(6))) xlabel(-6(1)6,labsize(small)) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs10)) xtitle("Event time (2014 = -1 reference)",size(small)) ytitle("SYN coefficient",size(small)) legend(order(2 "Full: 2009-2021" 4 "Post-hoc: 2012-2018") rows(1)) graphregion(color(white)) xsize(12) ysize(5)
graph export "`out'/event_full_vs_posthoc.png", width(2400) replace
display "PLOT_ONLY_COMPLETE"
exit, clear
