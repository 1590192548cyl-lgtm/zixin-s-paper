"""Read-only targeted public disclosure metadata. No analytical data operations."""
import hashlib,json,math,resource
from datetime import date,timedelta
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
O=Path(__file__).resolve().parent
P=Path('/Users/macpro/Documents/New project/duality_2008_name_verification_20261109')
(O/'metadata_complete').mkdir(exist_ok=True)
(O/'query_windows').mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
protected=json.loads((P/'protected_after.json').read_text())
# Preserve prior adjudications, generated results, scripts, and primary evidence as well.
targets=[r['path'] for r in protected]+[str(p) for p in P.rglob('*') if p.is_file()]
before=[dict(path=p,sha256=sha(p)) for p in targets]
if not (O/'protected_before.json').exists():(O/'protected_before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2))
tasks=[('600029','2008-12-01~2009-01-31'),('600050','2008-05-01~2009-04-10'),
 ('600248','2008-03-01~2009-01-31'),('600249','2008-04-01~2009-05-31'),
 ('600305','2007-04-01~2009-04-30'),('600329','2007-01-01~2009-03-31'),
 ('600345','2008-03-01~2009-03-31'),('600629','2007-03-01~2009-03-31'),
 ('600790','2008-11-01~2009-03-31'),('600805','2007-10-01~2009-01-31'),
 ('601008','2008-12-01~2009-02-28')]
def query(task):
 code,dates=task;p=O/'metadata_complete'/f'{code}.json'
 if p.exists():return json.loads(p.read_text())
 org='9900002722' if code=='601008' else 'gssh0'+code
 rows=[];total=None;err='';pages=0;windows=[]
 try:
  def window(start,end):
   nonlocal pages
   key=f'{code}_{start}_{end}.json';cache=O/'query_windows'/key
   data=urlencode(dict(pageNum=1,pageSize=30,tabName='fulltext',stock=f'{code},{org}',searchkey='',column='sse',category='',seDate=f'{start}~{end}',isHLtitle='true')).encode()
   req=Request('https://www.cninfo.com.cn/new/hisAnnouncement/query',data=data,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.cninfo.com.cn/','Content-Type':'application/x-www-form-urlencoded'})
   if cache.exists():d=json.loads(cache.read_text())
   else:
    with urlopen(req,timeout=35) as r:d=json.load(r)
    cache.write_text(json.dumps(d,ensure_ascii=False))
   pages+=1;n=d.get('totalAnnouncement') or 0;aa=d.get('announcements') or []
   if n>len({a['announcementId'] for a in aa}) and start<end:
    mid=start+(end-start)//2
    return window(start,mid)+window(mid+timedelta(days=1),end)
   windows.append(dict(start=str(start),end=str(end),reported_total=n,unique_returned=len({a['announcementId'] for a in aa}),complete=n<=len({a['announcementId'] for a in aa})))
   return [dict(title=a['announcementTitle'],url='https://static.cninfo.com.cn/'+a['adjunctUrl'],id=a['announcementId']) for a in aa]
  start,end=[date.fromisoformat(x) for x in dates.split('~')]
  rows=window(start,end);rows=list({r['id']:r for r in rows}.values());total=sum(w['reported_total'] for w in windows)
 except Exception as e:err=str(e)
 result=dict(firm_id=code,date_range=dates,reported_total=total,queries_read=pages,records=len(rows),complete=not err and bool(windows) and all(w['complete'] for w in windows),error=err,windows=windows,announcements=rows)
 p.write_text(json.dumps(result,ensure_ascii=False,indent=2))
 return result
out=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(query,t) for t in tasks]):
  r=f.result();out.append(r);print(r['firm_id'],r['records'],r['complete'],r['error'],flush=True)
out.sort(key=lambda r:r['firm_id'])
(O/'query_summary.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='announcements'} for r in out],ensure_ascii=False,indent=2))
(O/'query_runtime.json').write_text(json.dumps(dict(peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,threads=2,no_merge=True,no_regressions=True,no_SYN_recomputation=True),indent=2))
