"""Read-only transfer verification. Never runs research code or Stata."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
def check(base):
    manifest=base/'manifest.json'
    if not manifest.is_file():raise SystemExit('Missing manifest: '+str(manifest))
    rows=json.loads(manifest.read_text());bad=[]
    for r in rows:
        p=base/r['path']
        if not p.is_file():bad.append(r['path']+' MISSING');continue
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
        if p.stat().st_size!=r['bytes'] or h.hexdigest()!=r['sha256']:bad.append(r['path']+' CHANGED')
    if bad:
        print('\n'.join(bad));raise SystemExit(1)
    print('PASS:',base.name,len(rows),'files; integrity only, no regressions.')
check(root)
private=root.parent/'private_data_DO_NOT_UPLOAD'
if private.is_dir():check(private)
else:print('Private package absent: public handoff readable; microdata replication unavailable.')
