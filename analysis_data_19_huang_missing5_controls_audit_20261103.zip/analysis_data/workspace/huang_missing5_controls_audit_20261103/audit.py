"""Read-only field/year/key audit. No ROA/BM/Turn/List/SOE is constructed.
No analytical panel is merged, no DTA is written, no regression is run.
"""
from pathlib import Path
from zipfile import ZipFile
import sys,json,sqlite3,tempfile,shutil,hashlib,resource,time
from collections import defaultdict,Counter
import pandas as pd,numpy as np
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows,norm
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);ROOT=Path('/Users/macpro/Desktop/毕业论文');RAW=ROOT/'控制变量';P=ROOT/'堆叠DID重跑';start=time.time()
FULL=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs';WIN=W.parent/'huang_posthoc_window_2012_2018_20261103/outputs';PRIOR=W.parent/'huang_replication_data_audit_20261103'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(d,n):pd.DataFrame(d).to_csv(O/n,index=False,encoding='utf-8-sig')
def js(d,n):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def rows(path):
 heads={}
 for sheet,rn,vs in xml_rows(path):
  if rn==1:heads[sheet]=vs
  if rn>=4:yield rn,{name:vs.get(col,'') for col,name in heads[sheet].items()}
protected=[FULL/'fixed_analysis.dta',WIN/'window_analysis.dta',P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta']+list(FULL.glob('*.ster'))+list(WIN.glob('*.ster'))+[FULL/'static_results.csv',FULL/'event_results.csv',FULL/'joint_tests.csv',WIN/'static_results.csv',WIN/'event_results.csv',WIN/'joint_tests.csv']
manifest=[dict(path=str(p),sha256=sha(p)) for p in protected];js(manifest,'protected_results.json')
targets={}
for label,folder,flag in [('full',FULL,'old'),('posthoc',WIN,'window')]:
 d=pd.read_stata(folder/('fixed_analysis.dta' if label=='full' else 'window_analysis.dta'),convert_categoricals=False)
 for model in ['H0','H8']:
  q=d[d[f'{flag}_{model}_sample'].eq(1)];targets[f'{label}_{model}']=set(map(tuple,q[['firm_id','year']].to_numpy()))
 del d
old=json.loads((PRIOR/'source_audit.json').read_text());integrity=[]
for r in old:
 p=Path(r['path']);h=sha(p);integrity.append(dict(source=r['source'],path=str(p),sha256=h,same_as_complete_source_audit=h==r['sha256']))
assert all(r['same_as_complete_source_audit'] for r in integrity);save(integrity,'previous_source_integrity.csv')
cache=W.parent/'gao_full_controls_work/gao_controls_staging.sqlite';con=sqlite3.connect('file:'+str(cache)+'?mode=ro',uri=True)
for sid in ['balance','income','market']:
 sig=con.execute('SELECT signature,path FROM source_done WHERE source_id=?',(sid,)).fetchone();r=next(r for r in old if r['source']==sid);s=Path(r['path']).stat();assert sig[0]==f'{s.st_size}:{s.st_mtime_ns}',sid
fields=['total_assets','net_profit','operating_income','equity_total','equity_parent','market_value_thousand'];sets={};vals={};annual=[]
for field in fields:
 result=con.execute('SELECT firm_id,year,value FROM num_values WHERE variable=? AND conflict=0 AND year BETWEEN 2008 AND 2021',(field,)).fetchall();v={(int(f),int(y)):float(x) for f,y,x in result if x is not None};vals[field]=v;sets[field]=set(v)
 for y in range(2008,2022):
  z=[x for (f,yy),x in v.items() if yy==y];annual.append(dict(source='verified_readonly_component_cache',field=field,year=y,nonmissing_unique_firm_years=len(z),nonpositive=sum(x<=0 for x in z)))
con.close();save(annual,'financial_component_year_coverage.csv')
components=[];missing=[]
def inspect_keys(label,available):
 for pop,keys in targets.items():
  lack=keys-available;components.append(dict(population=pop,requirement=label,N=len(keys),available=len(keys&available),missing=len(lack),coverage=len(keys&available)/len(keys)))
  for f,y in sorted(lack):missing.append(dict(population=pop,requirement=label,firm_id=f,year=y))
for field in fields:inspect_keys(field,sets[field])
lag_assets={(f,y+1) for f,y in sets['total_assets']};inspect_keys('previous_year_assets',lag_assets)
inspect_keys('ROA_net_profit_and_end_assets_components_only',sets['net_profit']&sets['total_assets'])
inspect_keys('ROA_net_profit_and_two_asset_years_components_only',sets['net_profit']&sets['total_assets']&lag_assets)
inspect_keys('BM_total_equity_and_market_components_only',sets['equity_total']&sets['market_value_thousand'])
inspect_keys('BM_parent_equity_and_market_components_only',sets['equity_parent']&sets['market_value_thousand'])
headers=[]
for rel in ['总市值/TRD_Year.xlsx','年个股回报率/TRD_Year.xlsx','月个股收益率/TRD_Mnth.xlsx','年个股换手率/LIQ_TOVER_Y.xlsx']:
 p=RAW/rel;it=xml_rows(p);first=[next(it) for _ in range(5)];it.close();headers.append(dict(path=str(p),sha256=sha(p),first_five_rows=first))
js(headers,'trade_source_headers.json')
capkeys=defaultdict(set);capvalues={};ctlkeys=set();naturekeys=set();ctls=defaultdict(set);ctln=Counter();ctlraw=Counter();ctlannual=Counter();examples=[];source=[]
for pattern,member,sid in [('股本结构*.zip','CG_Capchg.xlsx','capital'),('上市公司控制人*.zip','HLD_Contrshr.xlsx','controller')]:
 zp=next((RAW/'黄文复现补充').glob(pattern));h=sha(zp);nr=0;raw_years=Counter();ann=Counter();first=[]
 with ZipFile(zp) as z:
  members=[dict(name=i.filename,bytes=i.file_size) for i in z.infolist()]
  with tempfile.TemporaryFile(suffix='.xlsx') as tmp:
   with z.open(member) as inp:shutil.copyfileobj(inp,tmp,1048576)
   tmp.seek(0);it=xml_rows(tmp);first=[next(it) for _ in range(5)];it.close();tmp.seek(0)
   for rn,r in rows(tmp):
    nr+=1;date=r.get('Reptdt','');f=r.get('Stkcd','');
    if len(date)<4 or not date[:4].isdigit() or not f.isdigit():continue
    y=int(date[:4]);raw_years[y]+=1
    if not date.endswith('-12-31') or not 2009<=y<=2021:continue
    key=(int(f),y);ann[y]+=1
    if sid=='capital':
     assert key not in capvalues;v={}
     for field in ['Nshrttl','Nshrnn','Nshra']:
      try:x=float(r.get(field,''))
      except:x=np.nan
      v[field]=x
      if np.isfinite(x):capkeys[field].add(key)
     capvalues[key]=v
    else:
     ctlkeys.add(key);criterion=norm(r.get('S0701a',''));nature=norm(r.get('S0702b',''));ctln[key,criterion]+=1;ctlannual[y,criterion]+=1
     if nature:
      naturekeys.add(key);ctls[key,criterion].add(nature);ctlraw[nature]+=1
     if any(t in r.get('S0701b','') for t in ['国有资产监督','人民政府','财政部','财政局','财政厅']) and len(examples)<25:
      examples.append(dict(firm_id=key[0],year=y,criterion=criterion,nature_raw=nature,ultimate_controller_name=r.get('S0701b',''),note='name-based audit lead, NOT a SOE assignment'))
 assert sha(zp)==h;source.append(dict(source=sid,archive=str(zp),archive_sha256=h,member=member,members=members,data_rows=nr,raw_years=dict(raw_years),annual_rows_by_year=dict(ann),first_five_rows=first,input_unchanged=True))
js(source,'supplement_source_audit.json')
for field,k in capkeys.items():inspect_keys(field,k)
inspect_keys('SOE_source_row_present',ctlkeys);inspect_keys('SOE_any_nonmissing_nature_before_coding',naturekeys)
ctrlstats=[]
for pop,keys in targets.items():
 c1={k for k in keys if ctln[k,'1']>0};valid1={k for k in keys if ctls[k,'1']};valid2={k for k in keys if ctls[k,'2']}
 def tokens(k,c):return {t.strip() for v in ctls[k,c] for t in v.split(',') if t.strip()}
 ctrlstats.append(dict(population=pop,N=len(keys),source_rows_present=len(keys&ctlkeys),any_nature_available=len(keys&naturekeys),criterion1_rows_present=len(c1),criterion1_nonempty_nature=len(valid1),criterion1_exactly_one_distinct_token=sum(len(tokens(k,'1'))==1 for k in valid1),criterion1_multiple_distinct_tokens=sum(len(tokens(k,'1'))>1 for k in valid1),criterion2_only_when_criterion1_empty=len(valid2-valid1),criterion1_vs2_different_token_sets=sum(tokens(k,'1')!=tokens(k,'2') for k in valid1&valid2),note='coverage diagnostics only; no token was mapped to SOE 0/1'))
save(ctrlstats,'SOE_criterion_availability.csv');save([dict(raw_nature_code_string=k,rows=v) for k,v in ctlraw.most_common()],'SOE_raw_code_frequency.csv');save(examples,'SOE_state_related_name_review_private.csv')
capstats=[]
for pop,keys in targets.items():
 good=[capvalues[k] for k in keys if k in capvalues and all(np.isfinite(capvalues[k][f]) for f in ['Nshrttl','Nshrnn','Nshra'])]
 capstats.append(dict(population=pop,complete_capital_components=len(good),residual_total_minus_nontradable_minus_circulating_A_nonzero=sum(abs(v['Nshrttl']-v['Nshrnn']-v['Nshra'])>1 for v in good),circulating_A_exceeds_total=sum(v['Nshra']>v['Nshrttl'] for v in good),note='source reconciliation only; no List ratio or A-share total derived'))
save(capstats,'capital_scope_reconciliation.csv');save(components,'component_coverage_on_frozen_samples.csv');save(missing,'missing_component_keys_private.csv')
sign=[]
for pop,keys in targets.items():
 for field in ['total_assets','equity_total','equity_parent','market_value_thousand']:
  a=[vals[field][k] for k in keys&sets[field]];sign.append(dict(population=pop,field=field,nonmissing=len(a),nonpositive=sum(x<=0 for x in a),negative=sum(x<0 for x in a)))
save(sign,'component_sign_audit.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);js(after,'protected_results_after.json');js(dict(regressions_run=0,new_empirical_variables=0,analytical_merges=0,DTA_files_written=0,source_XLSX_modified=False,protected_files_unchanged=True,financial_sources_reused_by_hash_verified_prior_audit=True,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'audit_execution.json')
print(pd.DataFrame(components).query('population=="full_H8"').to_string(index=False));print(pd.DataFrame(ctrlstats).to_string(index=False));print(pd.DataFrame(capstats).to_string(index=False))
