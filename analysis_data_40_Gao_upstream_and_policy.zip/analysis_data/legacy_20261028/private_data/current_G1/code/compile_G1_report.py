from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

WORK=Path('/Users/macpro/Documents/New project/four_cohort_G1_latest_recheck_20261028_work')
O=WORK/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
OLD=P/'gao_exact_replication/outputs/official_table3_rebuild'
STRICT=P/'gao_treatment_eligibility_strict_recheck'


def sha(f):
    h=hashlib.sha256()
    with Path(f).open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(f,**kw):return pd.read_csv(O/f,**kw)
def save(d,f):d.to_csv(O/f,index=False,encoding='utf-8-sig')
def md(d,fmt=None):
    fmt=fmt or {}
    rows=['|'+'|'.join(d.columns)+'|','|'+'|'.join(['---']*len(d.columns))+'|']
    for _,r in d.iterrows():rows.append('|'+'|'.join(fmt[c](r[c]) if c in fmt else str(r[c]) for c in d.columns)+'|')
    return '\n'.join(rows)


log=(O/'four_cohort_G1_rerun.log').read_text()
assert 'FOUR_COHORT_G1_FIXED_RECHECK_COMPLETE' in log
assert not any(x.startswith('r(') for x in log.splitlines())
s=json.loads((O/'pre_regression_audit_summary.json').read_text())
m=read('G1_static_rerun_results.csv')
e=read('G1_event_results.csv')
j=read('G1_event_joint_tests.csv')
repro=[]
for current,file in [('old_G1',OLD/'official_table3_main_models.csv'),('strict_G1',STRICT/'strict_2013_manual_recheck_main_models.csv')]:
    ref=pd.read_csv(file).query("model=='G1_fixed'").iloc[0]
    run=m.loc[m.model.eq(current)].iloc[0]
    for v in ['TreatPost','SE','p','N','clusters','treated_firms','cohorts']:
        diff=float(run[v])-float(ref[v]);assert abs(diff)<1e-8,(current,v,diff)
        repro.append({'model':current,'metric':v,'archived':ref[v],'rerun':run[v],'difference':diff,'tolerance':1e-8,'pass':True})
refe=pd.read_csv(OLD/'official_table3_event_study.csv').query("model=='G1_fixed'")
for _,r in e.loc[e.model.eq('old_G1')].iterrows():
    ref=refe.loc[refe.event_time.eq(r.event_time)].iloc[0]
    for v in ['coefficient','SE','p']:
        diff=float(r[v])-float(ref[v]);assert abs(diff)<1e-8,(v,diff)
        repro.append({'model':'old_G1_event_'+str(int(r.event_time)),'metric':v,'archived':ref[v],'rerun':r[v],'difference':diff,'tolerance':1e-8,'pass':True})
refj=pd.read_csv(OLD/'official_table3_joint_tests.csv').query("model=='G1_fixed'")
for _,r in j.loc[j.model.eq('old_G1')].iterrows():
    ref=refj.loc[refj.test.eq(r.test)].iloc[0]
    for v in ['F','p']:
        diff=float(r[v])-float(ref[v]);tol=2e-7 if v=='F' else 1e-8
        assert abs(diff)<tol,(v,diff)
        repro.append({'model':'old_G1_'+r.test,'metric':v,'archived':ref[v],'rerun':r[v],'difference':diff,'tolerance':tol,'pass':True})
save(pd.DataFrame(repro),'historical_reproduction_check.csv')

verification=[]
K=['firm_id','stack_id','annual_report_year']
for version in ['old','strict','latest']:
    d=pd.read_stata(O/(version+'_G1_analysis.dta'),convert_categoricals=False)
    actual=read(version+'_G1_estimation_sample.csv')
    keys=d[K+['sample_g1']].merge(actual[K+['actual_es']],on=K,how='outer',validate='one_to_one',indicator=True)
    assert keys._merge.eq('both').all() and keys.sample_g1.eq(keys.actual_es).all()
    verification.append({'version':version,'check':'static_e_sample_equals_fixed_G1_sample','violations':0,'N':int(keys.actual_es.sum())})
    if version in ['old','latest']:
        event=read(version+'_G1_event_sample.csv')
        z=actual[K+['actual_es']].merge(event[K+['event_es']],on=K,how='outer',validate='one_to_one',indicator=True)
        assert z._merge.eq('both').all() and z.actual_es.eq(z.event_es).all()
        verification.append({'version':version,'check':'event_e_sample_equals_static_e_sample','violations':0,'N':int(z.event_es.sum())})
for version in ['old','latest']:
    d=pd.read_stata(O/(version+'_G1_analysis.dta'),columns=K+['common_G1_sample'],convert_categoricals=False)
    actual=read(version+'_G1_common_estimation_sample.csv')
    z=d.merge(actual[K+['actual_es']],on=K,validate='one_to_one')
    assert z.common_G1_sample.eq(z.actual_es).all()
    verification.append({'version':version+'_common','check':'common_e_sample_matches_frozen_intersection','violations':0,'N':int(z.actual_es.sum())})
save(pd.DataFrame(verification),'actual_sample_verification.csv')
manifest=read('input_manifest.csv')
manifest['sha256_after']=[sha(f) for f in manifest.path]
manifest['unchanged']=manifest.sha256_before.eq(manifest.sha256_after)
assert manifest.unchanged.all()
save(manifest,'input_integrity_after_run.csv')

labels={'old_G1':'p=0.0345历史版','strict_G1':'2013严格补漏版','latest_G1':'最新核验版（主结果）','old_G1_common':'历史版共同样本','latest_G1_common':'最新版共同样本'}
m.insert(1,'label',m.model.map(labels))
save(m,'G1_historical_vs_latest_comparison.csv')
main=m.loc[m.model.eq('latest_G1')].iloc[0]
old=m.loc[m.model.eq('old_G1')].iloc[0]
strict=m.loc[m.model.eq('strict_G1')].iloc[0]
oc=m.loc[m.model.eq('old_G1_common')].iloc[0]
nc=m.loc[m.model.eq('latest_G1_common')].iloc[0]
decomp=pd.DataFrame([
    {'step':'historical_full_to_historical_common','coefficient_change':oc.TreatPost-old.TreatPost,'explanation':'restrict old coding to the frozen common observations'},
    {'step':'coding_change_same_common_observations','coefficient_change':nc.TreatPost-oc.TreatPost,'explanation':'only treatment coding differs; frozen values and FE groupings equivalent'},
    {'step':'latest_common_to_latest_full','coefficient_change':main.TreatPost-nc.TreatPost,'explanation':'add latest-only eligible observations'},
    {'step':'total_historical_full_to_latest_full','coefficient_change':main.TreatPost-old.TreatPost,'explanation':'sum of the three path-dependent diagnostic components'},
    {'step':'strict_2013_to_latest_control_correction','coefficient_change':main.TreatPost-strict.TreatPost,'explanation':'exclude the 73 already-exposed control observations'}])
assert abs(decomp.coefficient_change.iloc[:3].sum()-decomp.coefficient_change.iloc[3])<1e-12
save(decomp,'G1_coefficient_difference_decomposition.csv')

pre=j.loc[j.model.eq('latest_G1')&j.test.eq('pre_joint')].iloc[0]
post=j.loc[j.model.eq('latest_G1')&j.test.eq('post_joint')].iloc[0]
ce=e.loc[e.model.eq('latest_G1')].copy()
delta=read('sample_and_coding_difference_summary.csv')
impact=read('latest_control_exclusion_evidence.csv',dtype={'firm_code':str})
f4=lambda x:f'{float(x):.4f}'
fi=lambda x:f'{int(x):,}'
table=m[['label','TreatPost','SE','p','N','clusters','treated_firms','cohorts']].copy()
table.columns=['模型','TreatPost','SE','p','N','公司簇','处理公司','批次']
tablemd=md(table,{'TreatPost':f4,'SE':f4,'p':lambda x:f'{float(x):.6f}','N':fi,'公司簇':fi,'处理公司':fi,'批次':fi})
et=ce[['event_time','coefficient','SE','p','CI_low','CI_high']].copy()
et.columns=['事件期','系数','SE','p','CI下限','CI上限']
etmd=md(et,{'事件期':lambda x:f'{int(x):+d}',**{v:f4 for v in ['系数','SE','p','CI下限','CI上限']}})
diffd=delta[['comparison','old_stack_N','new_stack_N','old_only_stack_N','new_only_stack_N','common_treatment_changed','common_TreatPost_changed']].copy()
diffd.columns=['比较','旧stack行','新stack行','仅旧版行','仅新版行','共同处理身份改变','共同TreatPost改变']

report=f'''# 四批次G1最新核验名单重跑报告

## Material Passport

- 日期：2026-10-28；状态：旧静态、严格补漏静态及旧事件研究均实际复现，最新静态和事件研究实际执行。
- 范围：用户选定四批次G1，保持原三控制、SYN版本、缩尾、FE及聚类；未增加任何cohort或运行其他控制组合。
- 本轮规则与证据在重估前冻结。历史p值已知，不能把这条研究路径写成从未探索过的历史事前注册。
- 原始及历史输入14份文件的SHA256运行前后一致，没有扫描年报或重新计算SYN。

## 一、最新静态主结果

{tablemd}

最新G1：TreatPost={main.TreatPost:.7f}，SE={main.SE:.7f}，t={main.t:.7f}，p={main.p:.7f}，95%CI=[{main.CI_low:.7f}, {main.CI_high:.7f}]。

N={int(main.N):,}，公司簇={int(main.clusters):,}，处理公司={int(main.treated_firms)}，控制公司={int(main.control_firms):,}；2013、2015、2016、2017全部保留。按名义双侧聚类t检验达到5%显著，未达到1%。置信区间上限接近0，属于5%边界附近证据，应报告精确p值和区间。

这是真实静态TreatPost结果，没有把某个事件期系数当作主回归，也没有回退到旧的p=0.0345名单。

## 二、原模型设定保持不变

- 因变量：SYN_CSRC_FAMILY_w_exact，保持旧四批次精确构造版本；不混入另一套W2的SYN_w_Gao。
- 控制：Size_w_exact、MB_parent_w_exact、Lev_w_exact。MB仍用旧G1的母公司权益口径；未换定义或重新缩尾。
- 固定效应：firm_stack_id、cohort_year_id；cluster：原股票代码数值firm_id；无熵平衡或其他权重。
- 事件窗[-3,+2]；annual_report_year=syn_year-1；event_time=annual_report_year-cohort_report_year。
- G1的原完整样本和公司—stack同时存在政策前/后观测条件保留，不添加ST、退市、IPO等新筛选。

该四批次样本的annual_report_year实际覆盖2010—2019，syn_year覆盖2011—2020。研究批次、财务年度和周收益窗口不同概念，不能称其包含2021新处理批次，也不能声称这组主识别覆盖全部2025年度。

## 三、最新名单包括哪些更正

第一层：沿用最新2013严格核验的24条公司—指引肯定决定，不用strict_include=0反推不适用。该层资料中的18家公司实际进入2013年stack，已在历史审计留证。

第二层：核对后续已完成的肯定政策暴露证据，发现严格补漏stack仍有5家公司在部分stack中被错误保留为清洁控制。这些公司为000158、002098、002537、300106、300304，涉及13个公司—stack、73条G1控制观测。

规则为：若确认适用报告年不晚于该stack报告窗末年cohort_report_year+2，则在该stack窗口内已受其他IIDG影响，不能继续当作清洁控制。只排除受污染的公司—stack，不将公司永久删除；它们在其他更早且仍符合条件的stack可以保留。不新增处理组，不新增2018/2019/2020或2021批次。

每条记录保存证据ID、原文件、既有裁定依据及年度，见latest_control_exclusions.csv与latest_control_exclusion_evidence.csv。该规则在看到本轮系数前固定，73条全部按同一规则处理。

## 四、相对p=0.0345版的差异

{md(diffd)}

历史版→2013严格补漏版：完整stack仅旧111行、仅新76行，共同观测29行处理身份变化，其中14行TreatPost发生变化；G1样本24,767→24,732。

严格补漏版→最新版：仅删除73条已确认受污染控制观测，无共同记录的Treat或TreatPost改值；G1样本24,732→24,659。其余公司观测的SYN、三控制和时间标识逐值相同，FE类别分组等价。

因此p从0.034528→0.050251→0.046419，来自先前有证据的公司适用修正和此次清洁控制纠错，不是增加政策批次或更换控制。0.05两侧的小幅变化不能解释为效应发生质变。

## 五、共同样本诊断

共同G1观测24,583行，旧编码和最新编码的系数分别为{oc.TreatPost:.7f}（p={oc.p:.7f}）与{nc.TreatPost:.7f}（p={nc.p:.7f}）。在同样观测上，处理编码修正使系数变化{nc.TreatPost-oc.TreatPost:+.7f}。

全样本旧→新总变化为{main.TreatPost-old.TreatPost:+.7f}，按本轮固定诊断路径分解为：旧全样本→旧共同样本{oc.TreatPost-old.TreatPost:+.7f}；同共同观测编码变化{nc.TreatPost-oc.TreatPost:+.7f}；新共同样本→新全样本{main.TreatPost-nc.TreatPost:+.7f}。这说明变化并非单纯由样本数量减少解释；共同观测编码变化与进入/退出观测共同作用。分解依赖此路径，不是唯一的因果贡献分解。

共同样本仅诊断差异，不作为新的主样本，即使其p值更小也不以它替换最新全样本主结果。

## 六、原口径事件研究与平行趋势

沿用历史四批次代码的event_time=-3为唯一省略基准。估计treated_in_stack×1(event_time=-2,-1,0,+1,+2)，控制组全为0。原[-3,+2]之外没有观测，五项交互项均可估计；四个cohort每个事件期均同时有处理与控制观测。最新版事件与静态模型e(sample)完全相同。

{etmd}

政策前联合检验D_m2=D_m1=0：F={pre.F:.7f}，p={pre.p:.7f}，df=(2,{int(pre.df_den)})。未拒绝共同为0，与该短窗平行趋势假设一致，但不能证明平行趋势成立。

政策后联合检验D_0=D_p1=D_p2=0：F={post.F:.7f}，p={post.p:.7f}。0、+1、+2方向均为负，但各期均不显著，政策后联合也不显著。不能声称有稳定、逐期显著的动态改善。

静态TreatPost与上述政策后联合检验不是同一个假设：静态模型将政策前各期作为参考并约束共同政策后系数；该事件检验考察各后期相对单独-3期是否均为0，并允许其他时期分别估计。两者不必得到相同p值。本轮不切换事件基准或窗口以改变显著性。

图G1_event_old_vs_latest.png直接使用原始系数和95%公司聚类置信区间，-3设0且不虚构基准期置信区间。图中显示历史与最新两版，不挑单期结果替代主回归。

## 七、复现及原文件保护

历史G1的p=0.034527916、严格补漏G1的p=0.050250899、历史G1五个动态系数及联合检验p值均复现。系数、SE和p值按1e-8绝对容差；归档F值受约8位显示精度限制按2e-7容差核验。完整检查见historical_reproduction_check.csv。

所有静态e(sample)与其冻结sample_g1完全相同；共同样本回归与交集清单一致；事件研究与同版静态e(sample)一致。本轮没有任何额外singleton删除或运行后按结果改名单。

共同记录冻结值和FE等价检查见frozen_values_and_design_audit.csv；14份输入指纹全部一致。新分析DTA、清单、代码、ster、CSV和完整日志均另存，没有覆盖p=0.0345版或严格补漏版。

## 八、统计解释核验（11/11）

|检查|结论或范围|
|---|---|
|辛普森悖论|本轮不按单批次方向筛选；共同样本分解与全样本均报告|
|生态谬误|结论限定公司收益同步性，不直接推断投资者学习机制|
|选择偏误|三版样本及73条排除逐项披露，名单并非作者原名单|
|碰撞变量|三控制固定，未宣称完成所有因果角色审查|
|基率忽略|非分类任务，不适用|
|均值回归|未使用SYN极端值或回归残差选择公司|
|幸存者偏误|保留原G1可用样本规则，不新增存续/退市限制|
|多重检验|整项研究历史探索已知；当前名义5%不能当作校正全部历史检验后的结论|
|分析路径选择|用户明确选定四批次，全部历史与共同样本结果保留，不称历史预注册|
|相关与因果|前检验不显著不证明识别成立，单期动态和后联合不显著如实保留|
|反向因果|时序固定；制度资格和同期行业冲击仍有识别限制|

## 九、结论与停止点

四批次、最新核验名单、原Size/MB/Lev的静态G1呈负向5%边界附近证据；没有达到1%。政策前短窗联合未拒绝，但动态后期估计不精确。因此可以据此如实报告静态结果及其限制，不能承诺三星或将全部动态检验表述为通过。

本轮完成固定任务后停止；没有M0、FULL19、新批次、新控制、权重或机制/异质性搜索。
'''
(O/'four_cohort_G1_latest_report.md').write_text(report,encoding='utf-8')
print(m[['model','N','clusters','treated_firms','TreatPost','SE','p']].to_string(index=False))
print(j.to_string(index=False))
print('Historical checks passed:',len(repro),'all source inputs unchanged:',manifest.unchanged.all())
