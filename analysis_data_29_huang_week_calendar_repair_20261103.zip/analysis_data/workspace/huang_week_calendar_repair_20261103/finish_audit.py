from pathlib import Path
import pandas as pd,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent/'huang_basic_reconstruction_20261103'
d=pd.read_csv(O/'SYN_fixed_sample_comparison_private.csv');d['abs_change']=(d.SYN-d.SYN_before).abs();a=d.groupby('year').agg(original_rows=('firm_id','size'),corrected_SYN_nonmissing=('SYN','count'),mean_abs_change=('abs_change','mean'),max_abs_change=('abs_change','max'),mean_old_weeks=('n_weeks_before','mean'),mean_corrected_weeks=('n_weeks','mean')).reset_index();a.to_csv(O/'SYN_year_comparison.csv',index=False)
c=pd.read_csv(O/'week_research_year_comparison.csv');c=c[(c.year_old.eq(2016)|c.year_corrected.eq(2016))&c.year_old.ne(c.year_corrected)];c=c.merge(pd.read_csv(O/'confirmed_week_calendar.csv'),on='week',how='left');c.to_csv(O/'2016_boundary_moved_source_periods.csv',index=False)
meta=json.loads((O/'repair_audit.json').read_text());assert meta['missing_fixed_sample_N']==4 and not meta['may_run_fixed_models']
f=pd.read_csv(O/'mechanically_unavailable_fixed_sample_private.csv');assert f.year.eq(2016).all() and f.n_weeks_before.eq(30).all() and f.n_weeks.eq(29).all()
rows=[]
for m in ['H0','H8']:
 old=pd.read_csv(B/f'outputs/{m}_sample_private.csv');old=old[old.static_sample.eq(1)];bad=set(map(tuple,f[['firm_id','year']].to_numpy()));keep=~pd.MultiIndex.from_frame(old[['firm_id','year']]).isin(bad);remaining=old.loc[keep]
 rows.append(dict(model=m,original_actual_N=len(old),mechanically_unavailable=4,remaining_before_any_new_regression=len(remaining),firms=remaining.firm_id.nunique(),minimum_firm_observations=remaining.groupby('firm_id').size().min(),minimum_year_observations=remaining.groupby('year').size().min(),estimated=False))
pd.DataFrame(rows).to_csv(O/'fixed_sample_feasibility.csv',index=False)
text='''# 黄文基础重建：周历核实及SYN唯一修复

2026-11-03。当前状态：周历已通过本地独立验证，受影响SYN已重算；因固定样本出现4条不合格SYN，按用户“不筛样本”要求暂停回归。**本轮没有生成修复后系数或p值，既定的一次修复重跑尚未使用。**

## 核实依据与规则

取得CSMAR原厂《交易数据库使用指南（2012版）》：https://cn.ceibs.edu/pdf/library/40030.pdf ，表九TRD_Week列出Opndt（周开盘日期）、Clsdt（周收盘日期）；计算方法说明周回报以相邻计算期末的可比价格计算。本地现有三份核心周DTA均未导出这两个日期字段，旧周个股/市场Excel也无实际日期。

指南并未明确周首日，不能冒称厂商书面确认了周日起算。本次采用独立的数据内验证：2010—2021年1,125家上海新股，用真实首次上市日期核对原始第一条周记录。**1月1日所在周为第1周、周日起算的规则匹配1,125/1,125；周一起算匹配899/1,125；ISO匹配734/1,125。** 上市首周Wretwd常缺失，所以验证没有误用“首个非缺失收益周”。清单及规则对照均保存。

因此，本地周数据采用的周编号规则已获得强一致证据，可由标签确定日历区间。confirmed_week_calendar.csv中的start/end是截在公历年内的源日历区间，不是逐股实际开收盘交易日期；节假日、停牌会使实际日期位于该区间内部。该区别不应隐瞒。

原ISO假设由我上一轮实现引入，并不符合本地数据。现修复只采用一种规则，不比较各周历的回归显著性。

## 唯一修复及不变项

- 跨年源分段均保留，按源日历区间先后接滞后；没有删除一段、把部分收益相加或擅自合成完整周。
- 研究年仍按该源日历周的周一锚点归属五月至次年四月，保留原跨月归属原则，不重新定义论文事件时点。
- 重算受影响的2009、2010、2011、2015、2016、2020、2021年SYN；2012—2014、2017—2019的周成员/滞后行业年度不变，直接沿用原SYN并校验。
- 原始收益、市场/行业收益池、当周流通市值权重、行业留一、行业分类回溯、30完整周/满秩要求均不变。指南中关于权重的其他细节不在本轮偷偷调整。
- 原H0/H8实际公司年度键、处理组、筛选规则、八控制及已缩尾控制值原样锁定；SYN仍用旧最终固定1%/99%点，未重算缩尾阈值。原G1未改。

## 已发生的SYN变化

逐年绝对差、旧/新周数见SYN_year_comparison.csv。2011的558条原分析记录全部有修复SYN，平均绝对变化约0.0575，最大约0.6276；2014的597条不变。不能仅凭SYN改变便推断2011前置系数或联合检验将如何变化。

ISO日期碰撞并不意味着上轮已经去重或删除原收益段。源标签的时间顺序本来一致；实际本轮修复的主要变化是研究年五月边界及对应行业年度键。不能夸大为每一处跨年碰撞都损坏了所有滞后收益。

## 回归前发现的客观冲突

|公司代码|年度|修复前完整周|修复后完整周|原H0/H8均包含|
|---|---:|---:|---:|---|
|600545|2016|30|29|是|
|600551|2016|30|29|是|
|600979|2016|30|29|是|
|601700|2016|30|29|是|

2016-18源周按核实规则对应2016-04-24—2016-04-30这一日历区间，周一为2016-04-25，应归SYN研究年2015。旧ISO解析把它定位到2016年5月2日，错误归入SYN研究年2016。因此这4条2016记录各少1个完整周，跌破已固定30周门槛。边界来源见2016_boundary_moved_source_periods.csv。

不能同时维持“原样本键完全不减少”“30完整周门槛不变”和“全部使用正确重算SYN”。本轮没有：①把29改为30；②使用旧SYN填缺；③将门槛改为29；④自动删除4条后跑回归。

若用户允许**只按原30完整周门槛接受这4条机械缺失**，事前可用计数将为H0 7,883、H8 7,609条，均仍648家公司；该计数不是回归e(N)。只读检查未发现由此产生的新公司/年度单观测组。应在获得授权后再实际运行原模型并核验样本，不再改变任何其他筛选。

2011没有被删除。先前2011前置系数、全事前p值和静态结果原样保留，但仍是修复前、需核验的结果。本次不能编造修复后对比表的系数部分。

## 保护与资源

保护清单的修复前结果、原分析DTA、估计存档、原G1及修复方案SHA256前后一致；三份原始周源只读。SYN按年检查点保存；每块40,000行、单进程，修复主进程峰值RSS约196.1 MiB、约20秒，未重扫年报。周缓存约44 MB仅留在工作目录，项目交付不重复复制缓存。

主要文件：REPAIR_PLAN.md、calendar_rule_validation.csv、IPO_first_week_calendar_validation_private.csv、confirmed_week_calendar.csv、SYN_year_comparison.csv、mechanically_unavailable_fixed_sample_private.csv、fixed_sample_feasibility.csv、corrected_analysis.dta、repair_audit.json。corrected_analysis.dta为预回归检查文件，含4条缺失SYN，**不是已完成估计的数据成果**。private清单与CSMAR衍生数据不公开GitHub。
'''
(O/'week_calendar_repair_report.md').write_text(text,encoding='utf-8');print(pd.DataFrame(rows).to_string(index=False));print(c.to_string(index=False))
