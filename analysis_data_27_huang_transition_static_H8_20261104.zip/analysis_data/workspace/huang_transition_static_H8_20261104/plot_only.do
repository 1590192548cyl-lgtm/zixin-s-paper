clear all
set more off
local out "/Users/macpro/Documents/New project/huang_transition_static_H8_20261104/outputs"
import delimited "`out'/event_plot_data.csv", varnames(1) case(preserve) clear
twoway (rcap CI_low CI_high event_time,lcolor(navy)) (connected coefficient event_time,lcolor(navy) mcolor(navy)) (scatter coefficient event_time if event_time==-1,mcolor(orange_red) msymbol(D) msize(medlarge)) (scatter coefficient event_time if event_time==-2,mcolor(black) msymbol(Oh) msize(medlarge)), xlabel(-6(1)6,labsize(small)) yline(0,lcolor(gs10)) xtitle("Event time: 2013 (-2) omitted; 2014 (-1) transition",size(small)) ytitle("SYN coefficient",size(small)) title("H8: transition-year adjustment",size(medium)) subtitle("Same 7,609 observations; firm and year FE; firm clustering",size(small)) note("95% CI. 2013 normalized to zero without CI. Pre-test: 2009-2012; 2014 excluded." "Formal policy starts during 2014 (-1); 2015 (0) is the first full post-policy window.",size(vsmall)) legend(order(2 "Dynamic coefficient" 3 "2014 transition" 4 "2013 reference") position(6) ring(1) rows(1) size(small)) graphregion(color(white)) xsize(10) ysize(6)
graph export "`out'/transition_event_study.png", width(2400) replace
display "PLOT_ONLY_NO_FITS_COMPLETE"
exit, clear
