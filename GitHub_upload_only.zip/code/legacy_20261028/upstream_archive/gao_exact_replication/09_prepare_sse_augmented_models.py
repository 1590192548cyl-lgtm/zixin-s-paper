from pathlib import Path
import json

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"
STACK = OUT / "gao_official_sse_augmented_stack.dta"
MDA = OUT / "length_mda_sse_augmented_firm_year.csv"
FUNDCORR = OUT / "fundcorr_firm_year_2009_2019.dta"

CONTINUOUS = [
    "SYN_CSRC_FAMILY", "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS",
    "abs_Accruals", "Length_MDA", "Length_AR", "Stdret", "FundCorr",
    "d_Instihold", "Instihold", "Analyst_exact", "Indsize_broad", "Subs_exact",
    "Tophold", "Tophold2",
]
FULL_CONTROLS = [
    "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
    "Length_MDA", "Length_AR", "Stdret", "FundCorr", "d_Instihold", "Instihold",
    "Analyst_exact", "Indsize_broad", "Subs_exact", "Big4", "Tophold", "Tophold2",
]


def impose_prepost(df, base_flag, out_flag):
    df[out_flag] = 0
    q = df[df[base_flag].eq(1)].copy()
    ok = q.groupby(["stack_id", "firm_id"], sort=False).Post.transform(
        lambda x: x.eq(0).any() and x.eq(1).any()
    )
    df.loc[q.index[ok], out_flag] = 1


def main():
    d = pd.read_stata(STACK, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.firm_id, errors="raise").astype(int)
    d["annual_report_year"] = pd.to_numeric(d.annual_report_year, errors="raise").astype(int)

    m = pd.read_csv(MDA, low_memory=False)
    m["firm_id"] = pd.to_numeric(m.firm_id, errors="coerce").astype("Int64")
    m["report_year"] = pd.to_numeric(m.report_year, errors="coerce").astype("Int64")
    m = m[["firm_id", "report_year", "Length_MDA", "extraction_status"]].drop_duplicates(
        ["firm_id", "report_year"], keep="last"
    )
    d = d.merge(
        m,
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "report_year"],
        how="left",
        validate="many_to_one",
    )

    f = pd.read_stata(FUNDCORR, convert_categoricals=False)
    f["firm_id"] = pd.to_numeric(f.firm_id, errors="coerce").astype("Int64")
    f["fiscal_year"] = pd.to_numeric(f.fiscal_year, errors="coerce").astype("Int64")
    d = d.merge(
        f[["firm_id", "fiscal_year", "FundCorr"]],
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "fiscal_year"],
        how="left",
        validate="many_to_one",
        suffixes=("", "_fund"),
    )
    if "fiscal_year_fund" in d:
        d.drop(columns=["fiscal_year_fund"], inplace=True)

    d["Length_AR"] = np.log(pd.to_numeric(d.Length_AR_chars, errors="coerce").where(lambda x: x > 0))

    # Gao's table has zero as the minimum for both variables.  The local raw
    # analyst table contains only positive coverage counts, and the subsidiary
    # table contains one row per named subsidiary; absence therefore represents
    # a count of zero rather than a value to impute statistically.
    d["Analyst_zero_record"] = d["Analyst"].isna().astype(np.int8)
    d["Subs_zero_record"] = d["Subs"].isna().astype(np.int8)
    d["Analyst_exact"] = d["Analyst"].fillna(0)
    d["Subs_exact"] = d["Subs"].fillna(0)

    # The paper's Indsize distribution is consistent with broad CSRC sectors,
    # whereas the prior local code counted two-digit subsectors.  Count the
    # first-letter CSRC sector within cohort stack and annual-report year.
    d["industry_broad"] = d["industry_code"].astype("string").str.slice(0, 1)
    d["Indsize_broad_count"] = d.groupby(
        ["stack_id", "annual_report_year", "industry_broad"], dropna=False
    ).firm_id.transform("nunique")
    d["Indsize_broad"] = np.log(
        d.Indsize_broad_count.where(d.industry_broad.notna() & d.Indsize_broad_count.gt(0))
    )

    d["sample_formula_base"] = 1
    d["sample_g1_raw"] = d[["SYN_CSRC_FAMILY", "TreatPost", "Size", "MB_parent", "Lev"]].notna().all(axis=1).astype(int)
    d["sample_full_raw"] = d[["SYN_CSRC_FAMILY", "TreatPost"] + FULL_CONTROLS].notna().all(axis=1).astype(int)
    impose_prepost(d, "sample_g1_raw", "sample_g1")
    impose_prepost(d, "sample_full_raw", "sample_full")

    cuts = []
    full = d.sample_full.eq(1)
    for v in CONTINUOUS:
        s = pd.to_numeric(d.loc[full, v], errors="coerce").dropna()
        lo, hi = float(s.quantile(0.01)), float(s.quantile(0.99))
        d[v + "_w_exact"] = pd.to_numeric(d[v], errors="coerce").clip(lo, hi)
        cuts.append({"variable": v, "N_cutoff_sample": len(s), "p1": lo, "p99": hi})
    pd.DataFrame(cuts).to_csv(OUT / "sse_augmented_winsor_cutoffs.csv", index=False)

    sample_rows = []
    for name in ["sample_formula_base", "sample_g1", "sample_full"]:
        z = d[d[name].eq(1)]
        sample_rows.append(
            {
                "sample": name,
                "rows": len(z),
                "firms": int(z.firm_id.nunique()),
                "treated_firms": int(z.loc[z.treated_in_stack.eq(1), "firm_id"].nunique()),
                "cohorts": int(z.cohort_report_year.nunique()),
                "treated_rows": int(z.treated_in_stack.sum()),
                "pre_rows": int(z.Post.eq(0).sum()),
                "post_rows": int(z.Post.eq(1).sum()),
            }
        )
    pd.DataFrame(sample_rows).to_csv(OUT / "sse_augmented_sample_sizes.csv", index=False)

    missing = []
    for v in ["SYN_CSRC_FAMILY"] + FULL_CONTROLS:
        missing.append(
            {
                "variable": v,
                "stack_rows": len(d),
                "missing_rows": int(d[v].isna().sum()),
                "missing_rate": float(d[v].isna().mean()),
                "missing_treated_rows": int(d.loc[d.treated_in_stack.eq(1), v].isna().sum()),
                "missing_control_rows": int(d.loc[d.treated_in_stack.eq(0), v].isna().sum()),
            }
        )
    pd.DataFrame(missing).to_csv(OUT / "sse_augmented_missingness.csv", index=False)

    # Fair descriptive comparison: Gao reports continuous variables after
    # winsorization, so use the *_w_exact fields in the full sample.
    z = d[d.sample_full.eq(1)]
    desc_rows = []
    name_map = {
        "SYN_CSRC_FAMILY": "Syn_spec", "MB_parent": "MB",
        "Analyst_exact": "Analyst", "Indsize_broad": "Indsize", "Subs_exact": "Subs",
        "treated_in_stack": "Treat", "Post": "Post",
    }
    for v in ["SYN_CSRC_FAMILY", "treated_in_stack", "Post"] + FULL_CONTROLS:
        if v in {"treated_in_stack", "Post", "Loss", "Big4"}:
            s = pd.to_numeric(z[v], errors="coerce").dropna()
        else:
            s = pd.to_numeric(z[v + "_w_exact"], errors="coerce").dropna()
        desc_rows.append(
            {
                "variable": name_map.get(v, v), "N": len(s), "mean": s.mean(),
                "median": s.median(), "sd": s.std(), "min": s.min(),
                "p25": s.quantile(.25), "p75": s.quantile(.75), "max": s.max(),
            }
        )
    pd.DataFrame(desc_rows).to_csv(OUT / "sse_augmented_winsorized_descriptives.csv", index=False)

    d.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    d.to_stata(OUT / "gao_sse_augmented_exact_available_analysis.dta", write_index=False, version=118)
    meta = {
        "stack_rows": len(d),
        "sample_formula_base": int(d.sample_formula_base.sum()),
        "sample_g1": int(d.sample_g1.sum()),
        "sample_full": int(d.sample_full.sum()),
        "analyst_absent_raw_rows_recoded_zero": int(d.Analyst_zero_record.sum()),
        "subsidiary_absent_raw_rows_recoded_zero": int(d.Subs_zero_record.sum()),
        "indsize_definition": "ln unique firms in broad CSRC sector x cohort stack x annual-report year",
        "no_statistical_imputation": True,
    }
    (OUT / "sse_augmented_model_preparation_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print(pd.DataFrame(sample_rows).to_string(index=False))


if __name__ == "__main__":
    main()
