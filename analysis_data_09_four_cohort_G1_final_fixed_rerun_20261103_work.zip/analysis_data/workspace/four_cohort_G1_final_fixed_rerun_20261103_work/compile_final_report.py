from pathlib import Path
import hashlib,json,re,resource
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
SRC=P/'four_cohort_G1_latest_recheck_20261028'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig',float_format='%.17g')
def md(d):
    rows=['|'+'|'.join(map(str,d.columns))+'|','|'+'|'.join(['---']*len(d.columns))+'|']
    for row in d.itertuples(index=False,name=None):
        vals=[f'{v:.7f}' if isinstance(v,(float,np.floating)) else str(v) for v in row]
        rows.append('|'+'|'.join(vals)+'|')
    return '\n'.join(rows)

execution=json.loads((O/'execution_once_status.json').read_text())
assert execution['stage']=='COMPLETED' and execution['launch_attempts']==1
assert execution['static_completion_markers']==1 and execution['event_completion_markers']==1
body=(O/'final_fixed_rerun.log').read_text(encoding='utf-8')
regressions=len(re.findall(r'^\. reghdfe\s',body,flags=re.M))
assert regressions==2,regressions
original=pd.read_csv(SRC/'G1_static_rerun_results.csv').query("model=='latest_G1'").iloc[0]
new=pd.read_csv(O/'final_G1_static.csv').iloc[0]
olde=pd.read_csv(SRC/'G1_event_results.csv').query("model=='latest_G1'").set_index('event_time').sort_index()
newe=pd.read_csv(O/'final_G1_event_study.csv').set_index('event_time').sort_index()
oldj=pd.read_csv(SRC/'G1_event_joint_tests.csv').query("model=='latest_G1'").set_index('test').sort_index()
newj=pd.read_csv(O/'final_G1_joint_tests.csv').set_index('test').sort_index()
staticcols=['N','clusters','treated_firms','control_firms','cohorts','TreatPost','SE','t','p','CI_low','CI_high','df_r']
sc=pd.DataFrame([{'version':'original_archived_CSV',**{k:original[k] for k in staticcols}},
                 {'version':'final_fixed_rerun',**{k:new[k] for k in staticcols}}])
save(sc,'original_vs_final_static.csv')
events=[];joints=[];checks=[]
def test(name,old,val,tol):
    delta=float(val)-float(old)
    checks.append({'metric':name,'original':old,'rerun':val,'delta':delta,'absolute_tolerance':tol,'passed':abs(delta)<=tol})
for col in staticcols:
    tol=0 if col in ['N','clusters','treated_firms','control_firms','cohorts','df_r'] else (2e-7 if col=='t' else (1e-7 if col=='p' else 1e-8))
    test('static_'+col,original[col],new[col],tol)
for k in [-2,-1,0,1,2]:
    record={'event_time':k}
    for col in ['coefficient','SE','t','p','CI_low','CI_high','N','clusters']:
        record['original_'+col]=olde.loc[k,col];record['rerun_'+col]=newe.loc[k,col]
        record['delta_'+col]=float(newe.loc[k,col])-float(olde.loc[k,col])
        test(f'event_{k}_{col}',olde.loc[k,col],newe.loc[k,col],0 if col in ['N','clusters'] else (2e-7 if col=='t' else (1e-7 if col=='p' else 1e-8)))
    events.append(record)
for name in ['pre_joint','post_joint']:
    record={'test':name}
    for col in ['F','df_num','df_den','p','N','clusters']:
        record['original_'+col]=oldj.loc[name,col];record['rerun_'+col]=newj.loc[name,col]
        record['delta_'+col]=float(newj.loc[name,col])-float(oldj.loc[name,col])
        test(name+'_'+col,oldj.loc[name,col],newj.loc[name,col],0 if col in ['N','clusters','df_num','df_den'] else (1e-7 if col=='p' else 1e-8))
    joints.append(record)
save(pd.DataFrame(events),'original_vs_final_event_study.csv')
save(pd.DataFrame(joints),'original_vs_final_joint_tests.csv')
save(pd.DataFrame(checks),'archived_CSV_precision_comparison.csv')
assert all(c['passed'] for c in checks)
matrices=pd.read_csv(O/'archived_ster_matrix_comparison.csv')
assert matrices.max_abs_b_difference.eq(0).all() and matrices.max_abs_V_difference.eq(0).all()

K=['firm_id','stack_id','annual_report_year']
actual=pd.read_csv(O/'actual_estimation_sample_private.csv')
samplechecks=[]
for model,flag,file,oldflag in [('static','static_es','latest_G1_estimation_sample.csv','actual_es'),
                              ('event','event_es','latest_G1_event_sample.csv','event_es')]:
    old=pd.read_csv(SRC/file)
    oldkeys=set(map(tuple,old.loc[old[oldflag].eq(1),K].to_numpy()))
    newkeys=set(map(tuple,actual.loc[actual[flag].eq(1),K].to_numpy()))
    assert oldkeys==newkeys and len(newkeys)==24659
    samplechecks.append({'model':model,'old_N':len(oldkeys),'new_N':len(newkeys),'old_only_keys':len(oldkeys-newkeys),
                         'new_only_keys':len(newkeys-oldkeys),'identical':True})
assert not actual.duplicated(K).any()
assert actual.static_es.eq(actual.event_es).all() and actual.static_es.eq(actual.sample_g1).all()
save(pd.DataFrame(samplechecks),'actual_sample_identity_check.csv')
before=pd.read_csv(O/'input_manifest_before.csv')
before['sha256_after']=[sha(p) for p in before.path]
before['unchanged']=before.sha256_before.eq(before.sha256_after)
assert before.unchanged.all()
save(before,'input_integrity_after.csv')
snap=O/'input_snapshot/latest_G1_analysis_original.dta'
assert sha(snap)==sha(SRC/'latest_G1_analysis.dta')
snapshot={'source':str(SRC/'latest_G1_analysis.dta'),'snapshot':'input_snapshot/latest_G1_analysis_original.dta',
          'sha256':sha(snap),'byte_identical_to_original':True,'original_rows':26711,'frozen_estimation_rows':24659,
          'original_variables_overwritten':0,'source_control_values_filled':0,'source_industry_membership_changed':0}
(O/'input_snapshot_integrity.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')

metrics={'stage':'COMPLETED_STOPPED','formal_static_runs':1,'formal_event_runs':1,'total_reghdfe_calls':regressions,
         'N':int(new.N),'clusters':int(new.clusters),'treated_firms':int(new.treated_firms),'control_role_firms':int(new.control_firms),
         'cohorts':int(new.cohorts),'TreatPost':float(new.TreatPost),'SE':float(new.SE),'p':float(new.p),
         'CI_low':float(new.CI_low),'CI_high':float(new.CI_high),
         'pre_joint_p':float(newj.loc['pre_joint','p']),'post_joint_p':float(newj.loc['post_joint','p']),
         'old_new_estimates_b_and_V_exactly_equal':True,'actual_sample_keys_identical':True,
         'nominal_5pct':bool(new.p<.05),'nominal_1pct':bool(new.p<.01),
         'all_input_hashes_unchanged':True,'archived_CSV_precision_checks_passed':len(checks),
         'Stata_peak_RSS_MiB':execution['Stata_child_peak_RSS_MiB'],
         'Python_report_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
(O/'final_run_summary.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
eventtable=newe.reset_index()[['event_time','coefficient','SE','p','CI_low','CI_high']].rename(columns={
    'event_time':'事件期','coefficient':'系数','SE':'聚类SE','p':'p值','CI_low':'95%CI下限','CI_high':'95%CI上限'})
statictable=sc[['version','TreatPost','SE','p','N','clusters','treated_firms','cohorts','CI_low','CI_high']].copy()
statictable['version']=['原归档结果','本轮固定复核']
report=f'''# 四批次G1：最终固定静态与事件研究复核

## Material Passport

- 日期：2026-11-03；Origin Skill：academic-research-suite / experiment-agent；Mode：run + validate。
- Verification Status：VERIFIED（原模型实际执行、样本及原ster系数/协方差矩阵复现；不是因果假设认证）。
- 执行范围：静态回归1次、事件研究1次；正式reghdfe调用恰好2次；没有试其他规格。
- 原数据、核验和缺失清单均保留；所有写入在新目录，不覆盖任何历史分析或原始文件。

## 一、主结果和原结果比较

{md(statictable)}

本轮TreatPost={new.TreatPost:.10f}，SE={new.SE:.10f}，t={new.t:.7f}，p={new.p:.10f}，95%CI=[{new.CI_low:.10f},{new.CI_high:.10f}]。
名义双侧公司聚类t检验达到5%，未达到1%；区间上限接近0，应保留边界证据的谨慎解释。
系数以原SYN logit单位呈现，不在缺少适当尺度依据时随意分类为小、中、大经济效应。

**与原归档ster相比，静态和事件模型的全部系数b及全部协方差V最大绝对差均为0。**
不是仅主系数相近，整个估计结果矩阵完全一致。N、公司簇及实际样本键也完全相同。
原CSV部分字段以较低存储/展示精度保存，CSV细小末位差异不代表模型结果变化；{len(checks)}项明示精度比较全部通过。
旧postfile的p/t等字段以单精度存储后导出，旧CSV的p值核对容差为1e-7、t为2e-7；系数/SE/CI为1e-8，计数严格相等。
全精度核对独立采用旧ster的全部b/V，最大差严格为0；CSV容差不是修改回归结果或允许模型偏移。

## 二、冻结设定

- 样本总体：原stack 26,711条；原sample_g1=1的24,659条。
- 四批次：报告年度2013、2015、2016、2017；没有增加或删除批次。
- 因变量：SYN_CSRC_FAMILY_w_exact；原始和缩尾SYN未重新计算。
- 静态核心变量：TreatPost；控制：Size_w_exact、MB_parent_w_exact、Lev_w_exact。
- FE：firm_stack_id、cohort_year_id；标准误：vce(cluster firm_id)，仍为原始公司层级。
- event_time窗口[-3,+2]；annual_report_year=syn_year-1；控制年度口径不变。
- 无熵平衡或其他权重；无新控制、机制、异质性、留一批次或按p值筛选。
- 原四批次代码省略-3期，本轮保留该基准，不混用其他旧模型的-1。

## 三、完整事件研究

{md(eventtable)}

省略基准-3的系数按定义为0，不估计其SE或虚构置信区间。
五个解释项均为treated_in_stack×1(event_time=k)，不是单独事件时间虚拟变量；控制组全部为0。
所有动态项可估计，SE均大于0；没有被FE吸收。

|联合检验|F|df|p|
|---|---:|---|---:|
|政策前：-2=-1=0|{newj.loc['pre_joint','F']:.7f}|({int(newj.loc['pre_joint','df_num'])},{int(newj.loc['pre_joint','df_den'])})|{newj.loc['pre_joint','p']:.10f}|
|政策后：0=+1=+2=0|{newj.loc['post_joint','F']:.7f}|({int(newj.loc['post_joint','df_num'])},{int(newj.loc['post_joint','df_den'])})|{newj.loc['post_joint','p']:.10f}|

政策前联合未拒绝为0，但这不证明平行趋势成立；政策后各期及联合检验未显著。
0/+1/+2点估计均为负，但不能声称有稳定、逐期显著的改善。
静态平均前后差异与动态后期相对单独-3期的检验不是同一假设；此次只是重现原结果，不再追加分解回归。

## 四、为什么新下载没有改变回归结果

新P0201行业表补齐170条原二级码占位记录的真实一级分类，包括当前G1的30条2011观测和原先无直接证据的20家公司。
这些记录全部属于M、综合类，原None组与真实M组成员完全一致；其他有效二级行业码也未变。
因此这次完成的是证据核实，不是行业收益池划分的实质改变。
本轮没有转用“所有非制造业一级”的黄文式替代口径，没有因其此前p较小而选用。

真实财务来源未新增可恢复的完整G1控制值。原2,052条退出理由保留：上市前财务年度及连带支持限制1,879条，非正母公司权益及连带支持限制135条，原年度市值缺失及连带支持限制38条。
没有用IPO价、未来市值、总权益替代母公司权益，或前向/后向填补，去人为恢复样本。

## 五、样本、输入和原数据保护

- 公司簇1,770；处理公司636；承担控制角色的公司1,300；角色可跨不同stack重叠，不能相加当独立公司数。
- 静态和动态actual e(sample)均逐条等于冻结sample_g1，且与旧实际样本键完全一致，无额外singleton删除。
- 无重复firm_id+stack_id+annual_report_year；四批次全部48个cohort×event×role单元都有支持。
- 原连续变量冻结缩尾点、Treat/Post/时间字段和FE设计全部通过18项运行前检查。
- {len(before)}份受跟踪输入运行前后SHA256全部相同；原DTA快照与来源文件逐字节一致。
- input_snapshot保留本轮实际读取的原分析数据副本；audit_evidence保留前两轮全部损失与行业核验清单副本。
- 没有复制财务SQLite、周缓存或年报；没有扫描年报、加载周收益全库或建立新stack。

## 六、资源与运行次数

- 单核Stata18；启动次数1；用时约{execution['elapsed_seconds']:.2f}秒。
- 系统记录Stata子进程峰值RSS约{execution['Stata_child_peak_RSS_MiB']:.1f}MiB；本报告Python步骤峰值约{metrics['Python_report_peak_RSS_MiB']:.1f}MiB。
- 日志标记STATIC_ONE_DONE与EVENT_ONE_DONE各1次；恰好两条reghdfe执行命令。
- 启动和完成状态保存在execution_once_status.json，不自动重复回归。

## 七、统计解释检查（11/11）

|事项|结论与边界|
|---|---|
|组成/辛普森|同一冻结样本及四批次，不改变组成，不按批次系数筛选|
|生态推断|仅讨论公司收益同步性，不把结果直接等同投资者学习机制|
|选择偏误|原缺失/前后支持规则完整保留，其可推广性限制仍在|
|碰撞变量|三控制未换；既有政策后控制潜在风险未因复现而消失|
|基率|非分类任务，不适用|
|均值回归|未按极端SYN、残差或系数筛样本|
|幸存者|未新增存续、退市或ST筛选，未声称原规则不存在选择限制|
|多重检验|报告所有本轮结果；名义p未校正全部历史规格探索，不称新确证证据|
|分析路径|计划和输入先固定；只静态/动态各一次，无择优回退|
|相关与因果|前趋势未拒绝不证明因果识别；控制变量风险仍明确保留|
|反向因果|政策时序未变；本轮不重新认证政策适用外生性|

## 八、交付与停止

final_G1_static.csv、final_G1_event_study.csv、final_G1_joint_tests.csv为本轮实际输出。
original_vs_final_*为原结果比较，archived_ster_matrix_comparison.csv为全矩阵核对。
final_G1_event_plot.png使用实际系数及95%区间；-3期只标0点，没有基准置信区间。
完整日志、原数据快照、实际样本、18项预检查、输入指纹及历史核验清单均已保存。

当前完成并停止。结果仍为负向、名义5%边界附近，未达到三星；没有继续更换控制、权重、样本或批次。
'''
(O/'final_fixed_G1_report.md').write_text(report,encoding='utf-8')
(O/'READ_FIRST.md').write_text('# 四批次G1固定复核完成\n\n先看final_fixed_G1_report.md。\n\n静态和动态各执行一次；旧新全部b/V矩阵完全一致，样本不变。静态名义5%，未到1%。\n\ninput_snapshot为原分析数据逐字节快照；audit_evidence为完整原核验清单。含CSMAR衍生数据，不应公开上传GitHub。\n\n本轮完成后停止，未搜索其他规格。\n',encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False,indent=2),flush=True)
