from pathlib import Path
import gc
import json
import time

import numpy as np
import pandas as pd


ROOT = Path("/Users/macpro/Desktop/毕业论文")
PROJECT = ROOT / "堆叠DID重跑"
OUT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work/outputs")
OUT.mkdir(parents=True, exist_ok=True)

WEEK_FILES = [
    ROOT / "原始数据/周度数据重下/TRD_Week.dta",
    ROOT / "原始数据/周度数据重下/TRD_Week1.dta",
    ROOT / "原始数据/周度数据重下/TRD_Week2.dta",
]
IPO = ROOT / "原始数据/公司基本信息/IPO_Cobasic.dta"
IND = PROJECT / "data_work/industry_new_standardized.dta"

# Gao's annual-report sample is 2009--2019 and Syn_spec(t+1) is used.
# Only Syn years 2010--2020 are therefore needed for the replication.
MIN_SYN_YEAR = 2010
MAX_SYN_YEAR = 2020
CSRC_RULE = {
    **{y: "P0201" for y in range(2009, 2012)},
    **{y: "P0207" for y in range(2012, 2021)},
}
FIN_PATTERN = r"银行|证券|保险|金融|信托"


def firm_int(s):
    return pd.to_numeric(
        s.astype(str).str.replace(r"\.0$", "", regex=True), errors="coerce"
    ).astype("Int32")


def report_year_from_week(keys):
    keys = np.asarray(keys)
    years = (keys // 100).astype(int)
    weeks = (keys % 100).astype(int)
    anchor = pd.to_datetime(
        pd.Series(years.astype(str))
        + "-"
        + pd.Series(weeks.astype(str)).str.zfill(2)
        + "-1",
        format="%Y-%W-%w",
        errors="coerce",
    )
    return np.where(anchor.dt.month.ge(5), anchor.dt.year, anchor.dt.year - 1).astype(
        np.int16
    )


def load_weekly():
    a = pd.read_stata(IPO, columns=["Stkcd"], convert_categoricals=False)
    aset = set(firm_int(a["Stkcd"]).dropna().astype(np.int32).tolist())
    frames = []
    audit = []
    for p in WEEK_FILES:
        kept = 0
        read = 0
        for ch in pd.read_stata(
            p,
            columns=["Stkcd", "Trdwnt", "Wsmvosd", "Wretwd"],
            convert_categoricals=False,
            chunksize=200_000,
        ):
            read += len(ch)
            f = firm_int(ch["Stkcd"])
            w = pd.to_numeric(
                ch["Trdwnt"].astype(str).str.replace("-", "", regex=False),
                errors="coerce",
            )
            good_week = w.notna()
            ry = pd.Series(np.nan, index=ch.index)
            if good_week.any():
                ry.loc[good_week] = report_year_from_week(w.loc[good_week].astype(np.int64))
            keep = (
                f.notna()
                & good_week
                & ry.between(MIN_SYN_YEAR, MAX_SYN_YEAR)
                & ch["Wretwd"].notna()
                & ch["Wsmvosd"].notna()
                & ch["Wsmvosd"].gt(0)
                & f.isin(aset)
            )
            z = pd.DataFrame(
                {
                    "firm_int": f[keep].astype(np.int32),
                    "week_key": w[keep].astype(np.int32),
                    "report_year": ry[keep].astype(np.int16),
                    "ret": pd.to_numeric(ch.loc[keep, "Wretwd"]).astype(np.float64),
                    "cap": pd.to_numeric(ch.loc[keep, "Wsmvosd"]).astype(np.float64),
                }
            )
            frames.append(z)
            kept += len(z)
            del ch, z, f, w, ry, keep
        audit.append({"file": str(p), "rows_read": read, "rows_kept": kept})
    d = pd.concat(frames, ignore_index=True)
    del frames
    gc.collect()
    if d.duplicated(["firm_int", "week_key"]).any():
        raise AssertionError("weekly firm-week key is not unique")

    week_keys = np.sort(d.week_key.unique())
    prev = pd.Series(np.r_[np.nan, week_keys[:-1]], index=week_keys)
    prev_year = pd.Series(report_year_from_week(week_keys), index=week_keys)
    d["prev_week_key"] = d["week_key"].map(prev)
    d["prev_report_year"] = d["prev_week_key"].map(prev_year)
    d["num"] = d["ret"] * d["cap"]
    d.sort_values(["firm_int", "week_key"], inplace=True)
    prev_obs_week = d.groupby("firm_int", sort=False)["week_key"].shift(1)
    consecutive = prev_obs_week.eq(d["prev_week_key"])
    d["own_cap_lag"] = (
        d.groupby("firm_int", sort=False)["cap"].shift(1).where(consecutive, 0.0)
    )
    d["own_num_lag"] = (
        d.groupby("firm_int", sort=False)["num"].shift(1).where(consecutive, 0.0)
    )
    return d, audit


def add_market_returns(d):
    m = d.groupby("week_key", sort=True).agg(mnum=("num", "sum"), mden=("cap", "sum"))
    d = d.copy()
    d["mnum"] = d["week_key"].map(m["mnum"])
    d["mden"] = d["week_key"].map(m["mden"])
    d["mnum_lag"] = d["prev_week_key"].map(m["mnum"])
    d["mden_lag"] = d["prev_week_key"].map(m["mden"])
    den = d["mden"] - d["cap"]
    denlag = d["mden_lag"] - d["own_cap_lag"]
    d["MARET"] = np.where(den > 0, (d["mnum"] - d["num"]) / den, np.nan)
    d["MARET_lag"] = np.where(
        denlag > 0, (d["mnum_lag"] - d["own_num_lag"]) / denlag, np.nan
    )
    return d


def load_industry():
    cols = [
        "EndDate",
        "IndustryClassificationID",
        "IndustryClassification",
        "Symbol",
        "IndustryCode2",
        "IndustryName2",
    ]
    z = pd.read_stata(IND, columns=cols, convert_categoricals=False)
    z["firm_int"] = firm_int(z["Symbol"])
    z["year"] = pd.to_datetime(z["EndDate"], errors="coerce").dt.year
    z = z[z["firm_int"].notna() & z["year"].notna()].copy()
    z["firm_int"] = z["firm_int"].astype(np.int32)
    z["year"] = z["year"].astype(np.int16)
    z = z.sort_values(
        ["IndustryClassificationID", "firm_int", "year", "EndDate"]
    ).drop_duplicates(["IndustryClassificationID", "firm_int", "year"], keep="last")
    rows = []
    for y, std in sorted(CSRC_RULE.items()):
        q = z[(z.year.eq(y)) & (z.IndustryClassificationID.eq(std))].copy()
        q["selected_standard"] = std
        rows.append(q)
    m = pd.concat(rows, ignore_index=True)
    m["financial"] = m["IndustryName2"].fillna("").str.contains(FIN_PATTERN, regex=True)
    m["industry_key"] = (
        m["selected_standard"].astype(str) + "|" + m["IndustryCode2"].astype(str)
    )
    m["ind_id"] = pd.factorize(m["industry_key"], sort=True)[0].astype(np.int32) + 1
    m["fykey"] = m["firm_int"].astype(np.int64) * 10000 + m["year"].astype(np.int64)
    return m


def estimate_groups(d):
    xcols = ["MARET", "MARET_lag", "INDRET", "INDRET_lag"]
    c = d[["firm_int", "report_year", "ret"] + xcols].dropna()
    rows = []
    for (fid, y), g in c.groupby(["firm_int", "report_year"], sort=True):
        n = len(g)
        if n < 30:
            continue
        yy = g["ret"].to_numpy(float)
        xx = np.column_stack([np.ones(n), g[xcols].to_numpy(float)])
        beta, _, rank, _ = np.linalg.lstsq(xx, yy, rcond=None)
        resid = yy - xx @ beta
        sse = float(resid @ resid)
        yc = yy - yy.mean()
        sst = float(yc @ yc)
        r2 = np.nan if sst <= 0 else 1 - sse / sst
        syn = float(np.log(r2 / (1 - r2))) if np.isfinite(r2) and 0 < r2 < 1 else np.nan
        rows.append(
            {
                "firm_int": int(fid),
                "syn_year": int(y),
                "SYN_CSRC_FAMILY": syn,
                "R2_CSRC_FAMILY": r2,
                "n_weeks_CSRC_FAMILY": n,
                "rank_CSRC_FAMILY": int(rank),
            }
        )
    return pd.DataFrame(rows)


def main():
    started = time.time()
    base, read_audit = load_weekly()
    ind = load_industry()
    look = ind.set_index("fykey")
    key = base["firm_int"].astype(np.int64) * 10000 + base["report_year"].astype(np.int64)
    base["ind_id"] = key.map(look["ind_id"])
    base["financial"] = key.map(look["financial"]).fillna(True)
    d = base[base["ind_id"].notna() & ~base["financial"]].copy()
    del base
    gc.collect()
    d["ind_id"] = d["ind_id"].astype(np.int32)
    d = add_market_returns(d)
    it = (
        d.groupby(["week_key", "ind_id"], sort=True)
        .agg(inum=("num", "sum"), iden=("cap", "sum"), ifirms=("firm_int", "nunique"))
        .reset_index()
    )
    d = d.merge(it, on=["week_key", "ind_id"], how="left", validate="many_to_one")
    den = d["iden"] - d["cap"]
    d["INDRET"] = np.where(
        (den > 0) & (d["ifirms"] > 1), (d["inum"] - d["num"]) / den, np.nan
    )
    prev_key = (
        d["firm_int"].astype(np.int64) * 10000
        + pd.to_numeric(d["prev_report_year"], errors="coerce")
        .fillna(-999)
        .astype(np.int64)
    )
    d["ind_id_lag"] = prev_key.map(look["ind_id"])
    lag = it.rename(
        columns={
            "week_key": "prev_week_key",
            "ind_id": "ind_id_lag",
            "inum": "inum_lag",
            "iden": "iden_lag",
            "ifirms": "ifirms_lag",
        }
    )
    d = d.merge(lag, on=["prev_week_key", "ind_id_lag"], how="left", validate="many_to_one")
    prev_same = (
        d.groupby("firm_int", sort=False)["ind_id"].shift(1).eq(d["ind_id_lag"])
        & d.groupby("firm_int", sort=False)["week_key"].shift(1).eq(d["prev_week_key"])
    )
    owncap = d["own_cap_lag"].where(prev_same, 0.0)
    ownnum = d["own_num_lag"].where(prev_same, 0.0)
    denlag = d["iden_lag"] - owncap
    d["INDRET_lag"] = np.where(
        (denlag > 0) & ((d["ifirms_lag"] - prev_same.astype(int)) > 0),
        (d["inum_lag"] - ownnum) / denlag,
        np.nan,
    )
    res = estimate_groups(d)
    res["firm_id"] = res["firm_int"].astype(str).str.zfill(6)
    res.sort_values(["firm_int", "syn_year"], inplace=True)
    res.to_stata(OUT / "syn_csrc_family_2010_2020.dta", write_index=False, version=118)
    res.to_csv(OUT / "syn_csrc_family_2010_2020.csv", index=False)

    annual = (
        res.groupby("syn_year")["SYN_CSRC_FAMILY"]
        .agg(N="count", mean="mean", sd="std", median="median", min="min", max="max")
        .reset_index()
    )
    annual.to_csv(OUT / "syn_csrc_family_annual_audit.csv", index=False)
    map_audit = (
        ind.groupby(["year", "selected_standard", "financial"])["firm_int"]
        .nunique()
        .reset_index(name="firms")
    )
    map_audit.to_csv(OUT / "csrc_taxonomy_mapping_audit.csv", index=False)
    meta = {
        "minimum_weeks": 30,
        "syn_year_min": int(res.syn_year.min()),
        "syn_year_max": int(res.syn_year.max()),
        "firm_years": int(len(res)),
        "unique_firms": int(res.firm_int.nunique()),
        "taxonomy_rule": CSRC_RULE,
        "weekly_files": read_audit,
        "elapsed_seconds": time.time() - started,
    }
    (OUT / "syn_csrc_family_build_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
