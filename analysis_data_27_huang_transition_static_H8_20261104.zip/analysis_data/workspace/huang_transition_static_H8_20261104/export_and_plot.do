version 18
clear all
set more off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/huang_transition_static_H8_20261104/outputs"
local old "/Users/macpro/Documents/New project/huang_week_calendar_repair_20261103/fixed_rerun/outputs"
log using "`out'/stored_estimates_export.log", text replace
* Export only from stored estimates. NO regression command appears in this file.
tempname bh eh jh oh fh
tempfile st ev jt oe
postfile `bh' str20 model str24 term long N clusters treated_firms double coefficient double SE double t double p double CI_low double CI_high using `st', replace
postfile `eh' str20 model int event_time long N clusters double coefficient double SE double p double CI_low double CI_high using `ev', replace
postfile `jh' str28 model str24 test double F double df_num double df_den double p using `jt', replace
postfile `oh' str28 model int event_time long N clusters double coefficient double SE double p double CI_low double CI_high using `oe', replace
estimates use "`out'/H8_transition_static.ster"
foreach v in TreatPost TreatTransition {
 local b=_b[`v']
 local s=_se[`v']
 local c=invttail(e(df_r),.025)
 post `bh' ("H8_transition") ("`v'") (e(N)) (e(N_clust)) (439) (`b') (`s') (`b'/`s') (2*ttail(e(df_r),abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
}
postclose `bh'
estimates use "`old'/H8_event.ster"
local oldrss=e(rss)
forvalues k=-6/6 {
 if `k'!=-2 {
  local term "D_p`k'"
  if `k'<0 local term "D_m`=abs(`k')'"
  local expr "`term' - D_m2"
  if `k'==-1 local expr "-D_m2"
  quietly lincom `expr'
  post `oh' ("old_H8_rebased2013") (`k') (e(N)) (e(N_clust)) (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
 }
}
test (D_m6=D_m2) (D_m5=D_m2) (D_m4=D_m2) (D_m3=D_m2)
post `jh' ("old_H8_rebased2013") ("pre_2009_2012") (r(F)) (r(df)) (r(df_r)) (r(p))
test (D_p0=D_m2) (D_p1=D_m2) (D_p2=D_m2) (D_p3=D_m2) (D_p4=D_m2) (D_p5=D_m2) (D_p6=D_m2)
post `jh' ("old_H8_rebased2013") ("post_2015_2021") (r(F)) (r(df)) (r(df_r)) (r(p))
postclose `oh'
estimates use "`out'/H8_transition_event.ster"
local newrss=e(rss)
local c=invttail(e(df_r),.025)
forvalues k=-6/6 {
 if `k'!=-2 {
  local term "D_p`k'"
  if `k'<0 local term "D_m`=abs(`k')'"
  local b=_b[`term']
  local s=_se[`term']
  post `eh' ("H8_transition") (`k') (e(N)) (e(N_clust)) (`b') (`s') (2*ttail(e(df_r),abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
 }
}
test D_m6 D_m5 D_m4 D_m3
post `jh' ("H8_transition") ("pre_2009_2012") (r(F)) (r(df)) (r(df_r)) (r(p))
test D_p0 D_p1 D_p2 D_p3 D_p4 D_p5 D_p6
post `jh' ("H8_transition") ("post_2015_2021") (r(F)) (r(df)) (r(df_r)) (r(p))
postclose `eh'
postclose `jh'
file open `fh' using "`out'/event_fit_invariance.csv", write text replace
file write `fh' "old_rss,new_rss,old_N,new_N" _n
file write `fh' %22.15g (`oldrss') "," %22.15g (`newrss') ",7609,7609" _n
file close `fh'
use `st', clear
export delimited using "`out'/static_results.csv", replace
use `ev', clear
export delimited using "`out'/event_results.csv", replace
use `jt', clear
export delimited using "`out'/joint_tests.csv", replace
use `oe', clear
export delimited using "`out'/old_event_rebased2013.csv", replace
* Figure only: baseline coefficient is normalized to zero with no invented CI.
use `ev', clear
set obs 13
replace event_time=-2 in 13
replace coefficient=0 in 13
gen year=event_time+2015
sort event_time
export delimited using "`out'/event_plot_data.csv", replace
twoway (rcap CI_low CI_high event_time, lcolor(navy)) (connected coefficient event_time,lcolor(navy) mcolor(navy)) (scatter coefficient event_time if event_time==-1,mcolor(orange_red) msymbol(D) msize(medlarge)) (scatter coefficient event_time if event_time==-2,mcolor(black) msymbol(Oh) msize(medlarge)), xlabel(-6(1)6,labsize(small)) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs10)) xtitle("Event time: 2013 (-2) omitted; 2014 (-1) transition",size(small)) ytitle("SYN coefficient",size(small)) title("H8: transition-year adjustment",size(medium)) subtitle("Same 7,609 observations; firm and year FE; firm clustering",size(small)) note("95% CI. 2013 normalized to zero without CI. Pre-test: 2009-2012; 2014 excluded from pre-test.",size(vsmall)) legend(order(2 "Dynamic coefficient" 3 "2014 transition" 4 "2013 reference") rows(1) size(small)) graphregion(color(white)) xsize(11) ysize(6)
graph export "`out'/transition_event_study.png", width(2400) replace
display as result "STORED_ESTIMATES_EXPORT_AND_PLOT_COMPLETE_NO_FITS"
log close
exit, clear
