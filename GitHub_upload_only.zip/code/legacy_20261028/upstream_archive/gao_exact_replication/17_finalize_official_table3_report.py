#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import json

import pandas as pd


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = ROOT / "outputs/official_table3_rebuild"


def f(x: float, digits: int = 4) -> str:
    return f"{x:.{digits}f}"


def main() -> None:
    new = pd.read_csv(OUT / "official_table3_main_models.csv")
    events = pd.read_csv(OUT / "official_table3_event_study.csv")
    joint = pd.read_csv(OUT / "official_table3_joint_tests.csv")
    cohorts = pd.read_csv(OUT / "official_table3_cohort_diagnostics.csv")
    cells = pd.read_csv(OUT / "official_table3_stack_vs_gao_table1.csv")
    policies = pd.read_csv(OUT / "official_table3_policy_count_comparison.csv")
    samples = pd.read_csv(OUT / "official_table3_sample_audit.csv")
    build = json.loads((OUT / "official_table3_build_audit.json").read_text(encoding="utf-8"))

    old_g1 = pd.read_csv(
        ROOT / "outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_main_models.csv"
    )
    old_full = pd.read_csv(
        ROOT / "outputs/targeted_supplement/control_coverage_repair/full19_repaired_round/full19_repaired_main_models.csv"
    )
    old_signal = pd.read_csv("/private/tmp/gao_signal_diagnosis.csv")

    old_rows = [
        {
            "model": "old_M0_no_controls",
            "scope": "pre-Appendix-III correction",
            "N": int(old_signal.loc[old_signal.model.eq("current_stack_no_controls"), "N"].iloc[0]),
            "TreatPost": old_signal.loc[old_signal.model.eq("current_stack_no_controls"), "b"].iloc[0],
            "SE": old_signal.loc[old_signal.model.eq("current_stack_no_controls"), "se"].iloc[0],
            "p": old_signal.loc[old_signal.model.eq("current_stack_no_controls"), "p"].iloc[0],
        },
        {
            "model": "old_G1",
            "scope": "pre-Appendix-III correction",
            "N": int(old_g1.loc[old_g1.model.eq("G1"), "N"].iloc[0]),
            "TreatPost": old_g1.loc[old_g1.model.eq("G1"), "TreatPost"].iloc[0],
            "SE": old_g1.loc[old_g1.model.eq("G1"), "SE"].iloc[0],
            "p": old_g1.loc[old_g1.model.eq("G1"), "p"].iloc[0],
        },
        {
            "model": "old_repaired_FULL19",
            "scope": "pre-Appendix-III correction",
            "N": int(old_full.loc[old_full.model.eq("repaired_FULL19"), "N"].iloc[0]),
            "TreatPost": old_full.loc[old_full.model.eq("repaired_FULL19"), "TreatPost"].iloc[0],
            "SE": old_full.loc[old_full.model.eq("repaired_FULL19"), "SE"].iloc[0],
            "p": old_full.loc[old_full.model.eq("repaired_FULL19"), "p"].iloc[0],
        },
    ]
    new_rows = [
        {
            "model": "corrected_" + r.model,
            "scope": "official Appendix-III cohort correction",
            "N": int(r.N),
            "TreatPost": r.TreatPost,
            "SE": r.SE,
            "p": r.p,
        }
        for r in new.itertuples(index=False)
    ]
    comparison = pd.DataFrame(old_rows + new_rows)
    comparison.to_csv(OUT / "official_table3_old_new_model_comparison.csv", index=False)

    lines = [
        "# Gao Appendix Table III处理组与政策时点纠正报告",
        "",
        "## Material Passport",
        "",
        "- 状态：ANALYZED（代码重跑完成；不能声称复刻作者未公开公司名单）",
        "- 主要来源：Gao et al. (2024)正文、Online Appendix Tables I、III、VIII",
        "- 原始数据改动：无",
        "- 年报重新扫描：无",
        "- 目标数量用于筛选公司：否；仅用于事后外部校验",
        "- 固定效应：cohort×firm、cohort×year；公司聚类标准误",
        "- 事件窗：[-3,+2]；动态模型以t-3为基准",
        "",
        "## 纠正内容",
        "",
        "正文脚注11说明2012年为创业板最初两项IIDG的adoption year，但同时明确部分初始IIDG因严格数据要求未进入回归。Appendix Table III显示正式四批次第一批是2013年上交所房地产、煤炭及油气开采，而非创业板广播影视和医药。旧stack因此同时存在第一批次行业错误和政策年份错误。",
        "",
        "本轮直接行业采用政策采用年度P0207行业、交易所和板块范围；业务边界行业只使用此前已确认且证据年度不晚于政策批次的公司映射。公司第一次处理年度按已知更早IIDG与Appendix Table III候选年度两者的最早值确定。",
        "",
        "## 样本校验",
        "",
        f"- 重建stack：{build['stack_rows']:,}条，Gao为27,518条，差{build['stack_rows']-27518:+,}条。",
        f"- 唯一公司：{build['unique_firms']:,}家；跨stack处理公司：{build['treated_firms']:,}家。",
        f"- G1完整样本：{int(samples.loc[samples['sample'].eq('sample_g1'),'rows'].iloc[0]):,}条。",
        f"- FULL19完整样本：{int(samples.loc[samples['sample'].eq('sample_full'),'rows'].iloc[0]):,}条，明显少于Gao的27,518条。",
        "",
        "| 批次 | 本项目处理观测 | Gao处理观测 | 差异 |",
        "|---:|---:|---:|---:|",
    ]
    for cohort in [2013, 2015, 2016, 2017]:
        q = cells[(cells.cohort_report_year.eq(cohort)) & cells.treated_in_stack.eq(1)]
        ours = int(q.project_rows.sum())
        paper = int(q.gao_rows.sum())
        lines.append(f"| {cohort} | {ours:,} | {paper:,} | {ours-paper:+,} |")

    lines += [
        "",
        "2015—2017处理组总量已经接近原文；2013批次仍少204条。Appendix Table III没有披露公司代码，因此剩余差距不能在不重新取得公司级业务证据的情况下机械消除。",
        "",
        "## 静态主回归",
        "",
        "| 模型 | N | TreatPost | SE | p | 95%CI |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for r in new.itertuples(index=False):
        lines.append(
            f"| {r.model} | {int(r.N):,} | {f(r.TreatPost)} | {f(r.SE)} | {f(r.p)} | [{f(r.CI_low)}, {f(r.CI_high)}] |"
        )
    lines += [
        "",
        "无控制模型和预先固定G1均达到5%显著，方向与Gao一致；FULL19仍不显著。FULL19不显著不能解释为加入控制变量后效应消失，因为其N仅15,097、处理公司415家，与Gao完整控制模型N=27,518并非同一覆盖水平。",
        "",
        "## 与纠正前比较",
        "",
        "| 模型 | 纠正前TreatPost(p) | 纠正后TreatPost(p) |",
        "|---|---:|---:|",
        f"| 无控制 | -0.0455 (0.0901) | {f(new.loc[new.model.eq('M0_no_controls'),'TreatPost'].iloc[0])} ({f(new.loc[new.model.eq('M0_no_controls'),'p'].iloc[0])}) |",
        f"| G1 | -0.0349 (0.1967) | {f(new.loc[new.model.eq('G1_fixed'),'TreatPost'].iloc[0])} ({f(new.loc[new.model.eq('G1_fixed'),'p'].iloc[0])}) |",
        f"| repaired FULL19 | -0.0188 (0.5907) | {f(new.loc[new.model.eq('FULL19_fixed'),'TreatPost'].iloc[0])} ({f(new.loc[new.model.eq('FULL19_fixed'),'p'].iloc[0])}) |",
        "",
        "该变化来自预先有依据的批次、行业和政策时点修正，并非根据p值删批次或筛公司。",
        "",
        "## Gao口径动态效应（t-3为基准）",
        "",
    ]
    for model in ["M0_no_controls", "G1_fixed", "FULL19_fixed"]:
        lines += [
            f"### {model}",
            "",
            "| 事件期 | 系数 | SE | p |",
            "|---:|---:|---:|---:|",
        ]
        for r in events[events.model.eq(model)].itertuples(index=False):
            lines.append(f"| {int(r.event_time):+d} | {f(r.coefficient)} | {f(r.SE)} | {f(r.p)} |")
        pre = joint[(joint.model.eq(model)) & joint.test.eq("pre_joint")].p.iloc[0]
        post = joint[(joint.model.eq(model)) & joint.test.eq("post_joint")].p.iloc[0]
        lines += ["", f"政策前联合p={f(pre)}；政策后联合p={f(post)}。", ""]

    lines += [
        "三种样本的政策前联合检验均不能拒绝为零，纠正前明显的政策前趋势已经消失。但0、+1、+2期均未显著，尚未复刻Gao在+1期的显著负效应。",
        "",
        "## 批次异质性审计",
        "",
        "| 批次 | TreatPost | SE | p |",
        "|---:|---:|---:|---:|",
    ]
    for r in cohorts.itertuples(index=False):
        lines.append(f"| {int(r.cohort)} | {f(r.coefficient)} | {f(r.SE)} | {f(r.p)} |")

    lines += [
        "",
        "合并显著性主要来自2013和2015批次；2016仍为正、2017接近零。这是必须披露的真实异质性，不能据此删除批次。",
        "",
        "## 结论与剩余限制",
        "",
        "1. 已确认此前存在真实的处理行业和政策时点错误；纠正后M0与G1自然达到5%。",
        "2. 不能把FULL19称为Gao完整复刻：控制变量覆盖只有15,097条，而且Stdret和Instihold的数量级仍与Gao Appendix Table X不一致。",
        "3. Appendix Table III只有行业观测数，没有公司代码。2013批次少204条，主要集中在房地产、煤炭和油气行业，仍需作者名单或公司级采用年业务证据才能进一步修复。",
        "4. 静态主效应显著，但动态政策后联合检验不显著。因此目前可以报告平均政策后效应，不能声称已经复刻Gao的+1期动态效应。",
        "5. 本轮停止于预先固定模型，不继续搜索其他规格。",
        "",
        "## 关键输出",
        "",
        "- `official_table3_policy_crosswalk.csv`",
        "- `official_table3_candidate_mapping.csv`",
        "- `official_table3_stack_analysis.dta`",
        "- `official_table3_main_models.csv`",
        "- `official_table3_event_study.csv`",
        "- `official_table3_joint_tests.csv`",
        "- `official_table3_policy_count_comparison.csv`",
        "- `official_table3_old_new_model_comparison.csv`",
    ]
    (OUT / "official_table3_rebuild_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
