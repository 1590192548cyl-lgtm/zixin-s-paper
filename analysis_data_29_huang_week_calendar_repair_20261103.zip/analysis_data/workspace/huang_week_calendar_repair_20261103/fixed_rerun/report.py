from pathlib import Path
import pandas as pd,json
W=Path(__file__).resolve().parent;O=W/'outputs'
def table(df,cols):
 lines=['|'+'|'.join(cols)+'|','|'+'|'.join(['---']*len(cols))+'|']
 for _,r in df.iterrows():
  lines.append('|'+'|'.join(f'{r[c]:.6f}' if isinstance(r[c],float) else str(r[c]) for c in cols)+'|')
 return '\n'.join(lines)
m=pd.read_csv(O/'static_results_comparison.csv');j=pd.read_csv(O/'joint_tests_comparison.csv');e=pd.read_csv(O/'event_results_comparison.csv');assert (O/'event_study_before_after.png').exists()
text=f'''# 周历修复后：原H0/H8固定重跑结果

2026-11-03。**本轮完成：仅接受用户明确允许的4条机械剔除，2次静态＋2次对应动态估计，未试其他规格。** 仍标注“未经作者确认的黄文基础重建”，不是原文13控制完整复现。

## 主要结论

修复后H0/H8静态效应仍为负、达到5%但未达到1%。全事前联合检验仍拒绝为零；2011前置系数仍在5%显著。周历错误是真实需要修复的问题，但**本次结果不支持它足以解释掉2011前趋势**。不能因政策后联合检验达到5%或邻近两期事前不拒绝，就宣称全期平行趋势通过。

## 静态修复前后

{table(m,['version','model','N','clusters','treated_firms','coefficient','SE','t','p','CI_low','CI_high'])}

H0无控制。H8为Size_w、Age_w、Lev_w、Cent_w、Top10_w、Dual、Board_w、Big4。两者仍为公司和年度FE、原始公司聚类。均648家公司、439家处理公司、209家对照公司。H0系数较原来变化约+0.000722，H8约+0.001025，均略趋近零。

“before”是原先ISO周历版本，“corrected”同时包含唯一周历修复和4条获准的机械剔除。本轮没有额外估计用于分离这两个影响的规格，不能把全部数值变化分摊为纯周历或纯样本效应。

## 平行趋势与政策后联合检验

pre_all：2009—2013全部五个前置项；pre_near：2012/2013两项；post_all：2015—2021全部七项。2014唯一省略基准，未缩短窗口或把尾期并入基准。

{table(j,['version','model','test','F','df_num','df_den','p'])}

修复后全事前p：H0=0.006179，H8=0.001171，均不能通过5%平行趋势检验。邻近两期p约0.4806/0.5345，只表示两期单独联合不能拒绝，不代表全部事前满足平行趋势。修复后全事后p约0.0203/0.0226，虽然达到5%，但不能覆盖事前识别风险。

## 重点核验2011前置项

{table(e[e.event_time.eq(-4)],['version','model','event_time','coefficient','SE','p','CI_low','CI_high'])}

2011对应事件期-4。H0由-0.175120变为-0.174569；H8由-0.172509变为-0.171401。两者仍显著，未删除2011，也未变更基准。共同公司描述中发现的相对差异仍不能直接等同于纯经济趋势：早期行业回溯、重点行业名单及ST代理等局限依旧存在。本轮没有借修复同时调整这些规则。

## 修复后完整动态结果

{table(e[e.version.eq('corrected')],['model','event_time','coefficient','SE','p','CI_low','CI_high'])}

H8的0、+1、+2均为负，p分别约0.3959、0.1594、0.2490，均未达10%。+3、+4、+6分别达到10%、5%、1%，仅如实描述，不据此选择时期或宣称已验证因果效应；未另做多重检验调整。

## 四条机械剔除与样本保护

600545、600551、600979、601700各自2016年度：周历修复后由30个完整周变为29。仅这4个公司年被剔除；清单含新旧周数及理由，见authorized_four_exclusions_private.csv。未把旧SYN填回、未放宽30周门槛、未恢复原先其他被排除记录。

实际样本键核验：修复后H0恰等于原H0实际样本减这4条（7,887→7,883），H8恰等于原H8实际样本减这4条（7,613→7,609）。未产生额外singleton剔除。对应静态和动态样本逐条完全相同，12个动态交互项均可估计，无固定效应吸收或零标准误。见pre_regression_checks.csv、post_regression_sample_audit.csv和fixed_models.log。

八控制原值和缩尾值、Treat、Post、TreatPost、event_time均与原数据逐条核验一致；SYN采用上一轮最终固定1%/99%阈值，不重新估计缩尾点。除获准4条外，原样本规则、行业映射、ST/退市代理规则、年窗、FE及聚类均不变。

## 资源与可追溯性

直接复用上轮已完成的日历修复SYN，不再扫描全部周文件，更不扫描年报。Stata单线程处理约8千条公司年。原G1、修复前原分析DTA、原ster和原结果CSV指纹前后一致，见input_integrity_after_rerun.json。修复前数据和结果不覆盖。

prepare.py保存授权与输入检查；run_fixed.do执行唯一获准的4个模型；compare.py核验实际样本并汇总；plot.do只画图，不重新估计；report.py只编制报告。run_completed.json记录完成状态。上层repair_audit.json是用户授权剔除前的暂停快照，保留不改；本报告及本层run_completed.json为后续完成状态。

## 交付文件与停止

- static_results_comparison.csv：静态修复前后对照。
- event_results_comparison.csv：完整动态修复前后系数/SE/p/95%CI。
- joint_tests_comparison.csv：全事前、邻近事前、全事后联合检验对照。
- event_study_before_after.png：全期事件图，基准期置0，不伪造CI。
- fixed_analysis.dta、四份ster、fixed_models.log：本轮分析数据、估计存档和日志。
- authorized_four_exclusions_private.csv、各模型sample_private.csv：剔除与实际样本清单，受CSMAR许可约束，不公开GitHub。

**本轮完成后停止，不新增规格。** 本次没有取得1%静态显著或通过全期平行趋势；不能宣称黄文已完整复现成功，也不能将静态5%显著直接作为已确认的政策因果主结果。
'''
(O/'calendar_fixed_rerun_report.md').write_text(text,encoding='utf-8');print('REPORT_COMPLETE')
