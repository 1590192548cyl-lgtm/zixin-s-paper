#!/usr/bin/env python3
"""Prepare the frozen-stack repaired Full19 analysis and audits.

Only five raw controls are replaced with verified repairs: Stdroa, abs_dEPS,
abs_Accruals, d_Instihold, and FundCorr.  All old complete-case winsor cutoffs
are frozen, treatment/outcome/stack design is unchanged, and no regression is
run here.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OLD = ROOT / "outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_analysis.dta"
CUTS = ROOT / "outputs/targeted_supplement/cohort_2012/fixed_models/cohort_2012_fixed_winsor_cutoffs.csv"
CONTROLS = ROOT / "outputs/targeted_supplement/control_coverage_repair/fundcorr_weekyear_corrected/gao_controls_firm_year_true_data_repaired_with_fundcorr.dta"
NEW_WEEK = Path("/Users/macpro/Desktop/控制变量/2007-2009周个股回报率/TRD_Week.xlsx")
OUT = ROOT / "outputs/targeted_supplement/control_coverage_repair/full19_repaired_round"

REPAIRED = ["Stdroa", "abs_dEPS", "abs_Accruals", "FundCorr", "d_Instihold"]
CONTINUOUS = [
    "SYN_CSRC_FAMILY", "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS",
    "abs_Accruals", "Length_MDA", "Length_AR", "Stdret", "FundCorr",
    "d_Instihold", "Instihold", "Analyst_exact", "Indsize_broad", "Subs_exact",
    "Tophold", "Tophold2",
]
FULL_RAW = [
    "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
    "Length_MDA", "Length_AR", "Stdret", "FundCorr", "d_Instihold", "Instihold",
    "Analyst_exact", "Indsize_broad", "Subs_exact", "Big4", "Tophold", "Tophold2",
]
FULL_W = [
    "Size_w_exact", "MB_parent_w_exact", "Lev_w_exact", "Stdroa_w_exact",
    "abs_dEPS_w_exact", "abs_Accruals_w_exact", "Loss", "Length_MDA_w_exact",
    "Length_AR_w_exact", "Stdret_w_exact", "FundCorr_w_exact",
    "d_Instihold_w_exact", "Instihold_w_exact", "Analyst_exact_w_exact",
    "Indsize_broad_w_exact", "Subs_exact_w_exact", "Big4", "Tophold_w_exact",
    "Tophold2_w_exact",
]


def impose_prepost(frame: pd.DataFrame, raw: str, target: str) -> None:
    frame[target] = np.int8(0)
    q = frame.loc[frame[raw].eq(1), ["stack_id", "firm_id", "Post"]]
    ok = q.groupby(["stack_id", "firm_id"], sort=False).Post.transform(
        lambda x: x.eq(0).any() and x.eq(1).any()
    )
    frame.loc[q.index[ok], target] = np.int8(1)


def week_audit() -> pd.DataFrame:
    wb = load_workbook(NEW_WEEK, read_only=True, data_only=True)
    ws = wb.active
    ws.reset_dimensions()
    rows = ws.iter_rows(values_only=True)
    header = next(rows)
    pos = {x: i for i, x in enumerate(header)}
    next(rows, None)
    next(rows, None)
    out = []
    for row in rows:
        text = str(row[pos["Trdwnt"]] or "")
        try:
            year, week = map(int, text.split("-"))
        except ValueError:
            continue
        parsed = pd.to_datetime(f"{year}-{week:02d}-1", format="%Y-%W-%w", errors="coerce")
        if pd.isna(parsed):
            continue
        out.append((year, week, parsed.year, int(parsed.year != year)))
    wb.close()
    q = pd.DataFrame(out, columns=["label_year", "week", "parsed_year_old", "year_mismatch"])
    return q.groupby(["label_year", "week", "parsed_year_old"], as_index=False).agg(rows=("year_mismatch", "size"), affected_rows=("year_mismatch", "sum"))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    d = pd.read_stata(OLD, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.firm_id, errors="raise").astype(int)
    d["annual_report_year"] = pd.to_numeric(d.annual_report_year, errors="raise").astype(int)
    if d.duplicated(["stack_id", "firm_id", "annual_report_year"]).any():
        raise ValueError("Duplicate frozen stack key")
    if not d.annual_report_year.eq(d.syn_year - 1).all():
        raise ValueError("Time alignment changed")
    if not d.TreatPost.eq(d.treated_in_stack * d.Post).all():
        raise ValueError("TreatPost definition changed")

    # Preserve the complete old model columns and samples for exact comparisons.
    d["sample_full_old"] = d.sample_full.astype(np.int8)
    for name in FULL_W:
        d["old_" + name] = d[name]
    for name in REPAIRED:
        d["oldraw_" + name] = d[name]

    c = pd.read_stata(CONTROLS, columns=["firm_id", "fiscal_year"] + REPAIRED, convert_categoricals=False)
    c["firm_id"] = pd.to_numeric(c.firm_id, errors="raise").astype(int)
    c["fiscal_year"] = pd.to_numeric(c.fiscal_year, errors="raise").astype(int)
    c = c.rename(columns={v: "repair_" + v for v in REPAIRED})
    d = d.merge(
        c,
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "fiscal_year"],
        how="left",
        validate="many_to_one",
    )
    for name in REPAIRED:
        d[name] = d["repair_" + name]

    # Freeze all previously estimated 1/99 cutoffs.  Only repaired raw values are
    # re-clipped; unchanged controls and outcome remain exact checksums.
    cut = pd.read_csv(CUTS).set_index("variable")
    for name in CONTINUOUS:
        target = name + "_w_exact"
        if name in REPAIRED:
            d[target] = pd.to_numeric(d[name], errors="coerce").clip(
                float(cut.loc[name, "p1"]), float(cut.loc[name, "p99"])
            )

    d["sample_full_repaired_raw"] = d[["SYN_CSRC_FAMILY", "TreatPost"] + FULL_RAW].notna().all(axis=1).astype(np.int8)
    impose_prepost(d, "sample_full_repaired_raw", "sample_full_repaired")
    d["sample_full_common"] = (d.sample_full_old.eq(1) & d.sample_full_repaired.eq(1)).astype(np.int8)

    missing = []
    for name in FULL_RAW:
        oldname = "oldraw_" + name if name in REPAIRED else name
        missing.append({
            "variable": name,
            "old_missing_rows": int(d[oldname].isna().sum()),
            "repaired_missing_rows": int(d[name].isna().sum()),
            "rows_recovered": int((d[oldname].isna() & d[name].notna()).sum()),
            "rows_lost": int((d[oldname].notna() & d[name].isna()).sum()),
        })
    pd.DataFrame(missing).to_csv(OUT / "full19_repaired_missingness.csv", index=False)

    samples = []
    for sample in ["sample_g1", "sample_full_old", "sample_full_repaired", "sample_full_common"]:
        z = d[d[sample].eq(1)]
        samples.append({
            "sample": sample,
            "rows": int(len(z)),
            "firms": int(z.firm_id.nunique()),
            "clusters": int(z.firm_id.nunique()),
            "treated_firms": int(z.loc[z.treated_in_stack.eq(1), "firm_id"].nunique()),
            "cohorts": int(z.cohort_report_year.nunique()),
            "treated_pre_rows": int(((z.treated_in_stack == 1) & (z.Post == 0)).sum()),
            "treated_post_rows": int(((z.treated_in_stack == 1) & (z.Post == 1)).sum()),
        })
    pd.DataFrame(samples).to_csv(OUT / "full19_repaired_sample_audit.csv", index=False)

    changes = []
    for name in REPAIRED:
        both = d["oldraw_" + name].notna() & d[name].notna()
        diff = (pd.to_numeric(d.loc[both, "oldraw_" + name]) - pd.to_numeric(d.loc[both, name])).abs()
        changes.append({
            "variable": name,
            "common_nonmissing_rows": int(both.sum()),
            "max_abs_value_change": float(diff.max()) if not diff.empty else np.nan,
            "rows_changed_gt_1e_10": int((diff > 1e-10).sum()),
            "newly_nonmissing_rows": int((d["oldraw_" + name].isna() & d[name].notna()).sum()),
        })
    pd.DataFrame(changes).to_csv(OUT / "full19_repaired_value_changes.csv", index=False)

    wa = week_audit()
    wa.to_csv(OUT / "week_year_assignment_audit.csv", index=False)
    d.to_stata(OUT / "full19_repaired_analysis.dta", write_index=False, version=118)
    meta = {
        "stack_rows": int(len(d)),
        "duplicate_stack_keys": 0,
        "time_alignment_violations": 0,
        "treatpost_violations": 0,
        "winsor_cutoffs": "frozen from cohort_2012_fixed_winsor_cutoffs.csv",
        "repaired_variables": REPAIRED,
        "regressions_run": 0,
    }
    (OUT / "full19_repaired_preparation_audit.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(pd.DataFrame(samples).to_string(index=False), flush=True)
    print(pd.DataFrame(missing).to_string(index=False), flush=True)
    print(pd.DataFrame(changes).to_string(index=False), flush=True)
    print(wa[wa.affected_rows.gt(0)].to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
