"""Two implementations of selected weekly inputs; no regression and no SYN calculation."""
from pathlib import Path
from datetime import date,timedelta
import json,hashlib,math,sqlite3,resource,time
import pandas as pd,numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);BASE=W.parent;R=BASE/'huang_week_calendar_repair_20261103';B=BASE/'huang_basic_reconstruction_20261103';ROOT=Path('/Users/macpro/Desktop/毕业论文');start=time.time()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def js(x,n):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(x,n):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
manifest=json.loads((BASE/'huang_mapping_SYN_lineage_audit_20261104/outputs/protected_before.json').read_text());assert all(sha(r['path'])==r['sha256'] for r in manifest)
reads=json.loads((R/'outputs/source_reads.json').read_text());rawstatus=[]
for r in reads:
 h=sha(r['file']);assert h==r['sha256'];rawstatus.append(dict(path=r['file'],sha256=h,hash_matches_cache_build_log=True))
js(manifest,'protected_before.json');js(rawstatus,'weekly_source_integrity.json')
planhash=sha(W/'PLAN.md')
d=pd.read_stata(R/'fixed_rerun/outputs/fixed_analysis.dta',columns=['firm_id','year','old_H8_sample'],convert_categoricals=False);m=pd.read_csv(B/'outputs/policy_mapping_private.csv').set_index('firm_id')
years=[2011,2014,2021];q=d[d.old_H8_sample.eq(1)&d.year.isin(years)];eligible=set(q.groupby('firm_id').year.nunique().loc[lambda x:x==3].index);chosen=[]
for label,prefix in [('equipment_C34','C34'),('information_I','I'),('agriculture_A','A'),('retail_F52','F52'),('control_C30','C30'),('control_F51','F51')]:
 candidates=sorted(f for f in eligible if m.at[f,'industry2014'].startswith(prefix))
 if candidates:
  f=candidates[0];chosen.append(dict(stratum=label,firm_id=f,industry2014=m.at[f,'industry2014'],Treat=int(m.at[f,'Treat']),years='2011;2014;2021',candidate_firms=len(candidates)))
save(chosen,'selected_companies_private.csv');js(dict(plan_sha256=planhash,selection_uses=['firm_id','year','old_H8_sample','industry2014','Treat'],selection_does_not_use=['SYN','R2','coefficient','p'],companies=chosen),'selection_lock.json');print('SELECTION LOCKED',chosen,flush=True)
# Source classification read once in bounded chunks. No source rewriting.
parts=[]
for ch in pd.read_stata(ROOT/'原始数据/行业分类_新下载.dta',columns=['Symbol','EndDate','IndustryClassificationID','IndustryCode2'],chunksize=40000,convert_categoricals=False):
 y=ch.EndDate.str[:4].astype(int);z=ch[ch.IndustryClassificationID.eq('P0207')&y.between(2012,2021)].copy();z['firm_id']=z.Symbol.astype(int);z['year']=z.EndDate.str[:4].astype(int);parts.append(z[['firm_id','year','IndustryCode2']])
ind=pd.concat(parts).set_index(['firm_id','year']).IndustryCode2.to_dict()
classification_checks=[]
for r in chosen:
 f=r['firm_id'];assert ind.get((f,2014))==r['industry2014']
 for y in years:classification_checks.append(dict(firm_id=f,year=y,source_classification='P0207',source_year=max(y,2012),source_code=ind.get((f,max(y,2012))),frozen2014_code=r['industry2014'],frozen_Treat=r['Treat'],author_policy_identity_confirmed=False,note='source classification verified, not an author or SSE treatment roster'))
save(classification_checks,'selected_classification_provenance_private.csv')
def group(f,y):
 c=ind.get((int(f),max(int(y),2012)))
 return c if c and c.startswith('C') else c[:1] if c else None
db=sqlite3.connect('file:'+str(R/'cache/weekly_corrected.sqlite')+'?mode=ro',uri=True)
weeks=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',db);prev=dict(zip(weeks.week.to_numpy()[1:],weeks.week.to_numpy()[:-1]));wy=weeks.set_index('week').year.to_dict()
targets={x['firm_id'] for x in chosen};needed=set();ref=[];summary=[]
cached=pd.read_csv(R/'outputs/corrected_SYN_private.csv').set_index(['firm_id','year'])
# Independent calendar: enumerate dates, use strftime %U and Jan1 offset, not source calendar formula.
cal={}
for yy in range(2010,2023):
 dt=date(yy,1,1);offset=int(dt.weekday()!=6)
 while dt.year==yy:
  k=int(dt.strftime('%U'))+offset;key=yy*100+k
  if key not in cal:cal[key]=[dt,dt]
  else:cal[key][1]=dt
  dt+=timedelta(days=1)
def dated(k):
 a,z=cal[int(k)];sun=a-timedelta(days=(a.weekday()+1)%7);mon=sun+timedelta(days=1);return a,z,mon,mon.year-int(mon.month<5)
for year in years:
 first=int(weeks.loc[weeks.year.eq(year),'week'].min());lagfirst=int(prev[first]);z=pd.read_sql_query('SELECT firm_id,week,year,ret,cap FROM weekly WHERE year=? OR week=? ORDER BY week,firm_id',db,params=[year,lagfirst]);z['group']=[group(f,y) for f,y in zip(z.firm_id,z.year)];z['num']=z.ret*z.cap
 market=z.groupby('week').agg(num=('num','sum'),cap=('cap','sum'));it=z.dropna(subset=['group']).groupby(['week','group']).agg(num=('num','sum'),cap=('cap','sum'));own=z.set_index(['firm_id','week']);byweek={int(w):g for w,g in z.groupby('week')}
 # Direct peer lists and compensated summation are independent of subtract-self totals.
 def direct(f,w):
  peers=byweek.get(int(w));g=group(f,wy[w])
  if peers is None:return [np.nan,np.nan,0,0,False]
  den=math.fsum(float(x) for x in peers.cap);mr=math.fsum(float(a)*float(b) for a,b in zip(peers.ret,peers.cap))/den
  peers=peers[peers.group.eq(g)&peers.firm_id.ne(f)] if g else peers.iloc[0:0];dc=math.fsum(float(x) for x in peers.cap);ir=math.fsum(float(a)*float(b) for a,b in zip(peers.ret,peers.cap))/dc if dc>0 else np.nan
  return [mr,ir,len(byweek[w]),len(peers),bool(peers.firm_id.eq(f).any())]
 def replay(f,w):
  mr=market.at[w,'num']/market.at[w,'cap'];g=group(f,wy[w])
  if (w,g) not in it.index:return mr,np.nan
  total=it.loc[(w,g)];oc=on=0.
  if (f,w) in own.index:
   r=own.loc[(f,w)]
   if r['group']==g:oc=float(r.cap);on=float(r.num)
  return mr,(float(total.num)-on)/(float(total.cap)-oc) if float(total.cap)>oc else np.nan
 for f in sorted(targets):
  records=z[z.firm_id.eq(f)&z.year.eq(year)];ncomplete=0;maxerr=0.;calendar_errors=0;peer_errors=0
  for row in records.itertuples():
   w=int(row.week);pw=int(prev[w]);a,end,mon,yy=dated(w);calendar_errors+=int(yy!=year);pa,pe,pm,py=dated(pw)
   peer_errors+=int(pe>=a);needed.add((f,w));needed.add((f,pw));cur=direct(f,w);lag=direct(f,pw);rm,ri=replay(f,w);lm,li=replay(f,pw)
   vals=[float(row.ret),cur[0],lag[0],cur[1],lag[1]];complete=all(math.isfinite(x) for x in vals);ncomplete+=int(complete)
   differences=[]
   for u,v in zip([cur[0],cur[1],lag[0],lag[1]],[rm,ri,lm,li]):
    if np.isfinite(u) and np.isfinite(v):differences.append(abs(u-v))
    elif not (pd.isna(u) and pd.isna(v)):differences.append(float('inf'))
   err=max(differences,default=0);maxerr=max(maxerr,err)
   ref.append(dict(firm_id=f,year=year,week=w,period_start=str(a),period_end=str(end),Monday_anchor=str(mon),lag_week=pw,lag_period_end=str(pe),return_value=float(row.ret),cap=float(row.cap),industry_source_year=max(year,2012),industry_group=group(f,year),lag_industry_source_year=max(wy[pw],2012),lag_industry_group=group(f,wy[pw]),market=cur[0],market_lag=lag[0],industry_leave_self_out=cur[1],industry_lag_leave_self_out=lag[1],market_members=cur[2],industry_peers_excluding_self=cur[3],input_complete=complete,replay_max_abs_error=err))
  old=int(cached.at[(f,year),'n_weeks']);summary.append(dict(firm_id=f,year=year,cached_firm_weeks=len(records),independently_complete_weeks=ncomplete,stored_complete_weeks=old,complete_week_count_matches=ncomplete==old,replay_vs_independent_max_abs_error=maxerr,calendar_year_errors=calendar_errors,lag_date_order_errors=peer_errors))
 print('INPUTS CHECKED year',year,flush=True)
db.close();save(ref,'weekly_input_trace_private.csv');save(summary,'company_year_input_checks_private.csv')
# Verify only selected source keys against original exports. Streaming, four fields, no pooled recomputation.
rawrows=[];scan=[];raw_expected=set();raw_invalid_selected_periods=0
for src in reads:
 n=keep=0
 for ch in pd.read_stata(src['file'],columns=['Stkcd','Trdwnt','Wretwd','Wsmvosd'],chunksize=40000,convert_categoricals=False):
  n+=len(ch);fid=ch.Stkcd.astype(int);sub=ch[fid.isin(targets)].copy()
  if sub.empty:continue
  sub['firm_id']=sub.Stkcd.astype(int);sub['week']=sub.Trdwnt.str.replace('-','',regex=False).astype(int)
  for r in sub.itertuples():
   if int(r.week) in cal and dated(int(r.week))[3] in years:
    if pd.notna(r.Wretwd) and pd.notna(r.Wsmvosd) and r.Wsmvosd>0:raw_expected.add((int(r.firm_id),int(r.week)))
    else:raw_invalid_selected_periods+=1
  sub=sub[[tuple(x) in needed for x in sub[['firm_id','week']].to_numpy()]];keep+=len(sub)
  rawrows.extend(dict(firm_id=int(r.firm_id),week=int(r.week),ret=r.Wretwd,cap=r.Wsmvosd,source=Path(src['file']).name) for r in sub.itertuples())
 scan.append(dict(source=src['file'],streamed_rows=n,selected_rows=keep,chunk=40000));print('RAW SOURCE CHECKED',Path(src['file']).name,keep,flush=True)
raw=pd.DataFrame(rawrows);assert not raw.duplicated(['firm_id','week']).any();raw=raw.set_index(['firm_id','week']);db=sqlite3.connect('file:'+str(R/'cache/weekly_corrected.sqlite')+'?mode=ro',uri=True);checks=[]
for f,w in sorted(needed):
 hit=db.execute('SELECT ret,cap FROM weekly WHERE firm_id=? AND week=?',(int(f),int(w))).fetchone()
 if hit:
  present=(f,w) in raw.index;r=raw.loc[(f,w)] if present else None;checks.append(dict(firm_id=f,week=w,raw_row_present=present,cache_row_present=True,return_abs_error=abs(float(r.ret)-hit[0]) if present else np.nan,cap_abs_error=abs(float(r.cap)-hit[1]) if present else np.nan))
db.close();save(checks,'raw_to_cache_selected_checks_private.csv');save(scan,'raw_read_audit.csv')
cache_target={(int(r['firm_id']),int(r['week'])) for r in ref};missing=raw_expected-cache_target;extra=cache_target-raw_expected
js(dict(raw_valid_target_period_keys=len(raw_expected),cache_target_period_keys=len(cache_target),valid_source_keys_missing_from_cache=len(missing),cache_keys_without_valid_source=len(extra),source_invalid_return_or_cap_in_target_periods=raw_invalid_selected_periods,missing_keys=sorted(missing),extra_keys=sorted(extra)),'raw_period_coverage_check.json')
assert all(sha(x['path'])==x['sha256'] for x in rawstatus)
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);js(after,'protected_after.json');js(dict(regressions_run=0,SYN_reestimated=False,new_R2_computed=False,new_analysis_DTA=0,Treat_changed=False,selection_plan_sha256=planhash,companies=len(targets),company_years=len(summary),weekly_input_rows=len(ref),source_keys_checked=len(checks),all_complete_week_counts_match=all(r['complete_week_count_matches'] for r in summary),max_input_replay_error=max(r['replay_vs_independent_max_abs_error'] for r in summary),all_raw_rows_present=all(r['raw_row_present'] for r in checks),max_raw_return_error=max(r['return_abs_error'] for r in checks),max_raw_cap_error=max(r['cap_abs_error'] for r in checks),protected_files=len(after),peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'execution_audit.json');print((O/'execution_audit.json').read_text())
