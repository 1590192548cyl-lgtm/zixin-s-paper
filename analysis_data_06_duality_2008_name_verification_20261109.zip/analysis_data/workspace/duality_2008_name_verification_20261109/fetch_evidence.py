"""Targeted public filing retrieval, 18 firms only; no dataset/model changes."""
import csv, hashlib, html, json, re, resource, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urljoin

sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows,norm
OUT=Path(__file__).resolve().parent
CACHE=OUT/'evidence_cache';CACHE.mkdir(exist_ok=True)
ROOT=Path('/Users/macpro/Desktop/2008年控制变量下载清单_20261104')
SOURCE=next(p for p in ROOT.rglob('CG_Ybasic.xlsx') if '203110168' in str(p))
DES=SOURCE.with_name('CG_Ybasic[DES][xlsx].txt')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def js(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def writecsv(name,rr):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def get(url):
 with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=35) as r:
  raw=r.read()
 return raw.decode('gb18030',errors='replace')
protected=json.loads(Path('/Users/macpro/Documents/New project/controls_2008_supplement_followup_20261109/protected_after.json').read_text())
protected_before=[dict(path=r['path'],sha256=sha(r['path'])) for r in protected]
js('protected_before.json',protected_before)
input_before={str(SOURCE):sha(SOURCE),str(DES):sha(DES)}
targets=list(csv.DictReader(Path('/Users/macpro/Documents/New project/controls_2008_supplement_followup_20261109/仍需补充_18家两职合一.csv').open()))
codes={r['股票代码'] for r in targets};assert len(codes)==18 and '601607' not in codes
header={};snapshot=[]
for sh,rn,v in xml_rows(SOURCE):
 if rn==1:header=v
 if rn<4:continue
 d={f:v.get(c,'') for c,f in header.items()}
 if norm(d['Stkcd']).zfill(6) in codes and d['Reptdt']=='2008-12-31':
  snapshot.append(dict(firm_id=norm(d['Stkcd']).zfill(6),date=d['Reptdt'],chairman_raw=d['Y0801b'],manager_raw=d['Y0901b'],source_excel_row=rn,source_path=str(SOURCE)))
writecsv('downloaded_names_2008_snapshot.csv',snapshot)

def fetch(code):
 index=f'https://vip.stock.finance.sina.com.cn/corp/go.php/vCB_AllBulletin/stockid/{code}.phtml?ftype=ndbg'
 item=dict(firm_id=code,index_url=index,status='',title='',source_url='',cache_file='',error='')
 try:
  s=get(index)
  aa=re.findall(r'<a[^>]+href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>',s,re.S|re.I)
  aa=[(h,html.unescape(re.sub('<[^>]*>','',t)).strip()) for h,t in aa]
  candidates=[(h,t) for h,t in aa if '2008' in t and ('年度报告' in t or '年报' in t) and '摘要' not in t]
  if not candidates: item['status']='no_2008_annual_link';return item
  url,title=candidates[0]; url=urljoin(index,url)
  body=get(url)
  pre=re.findall(r'<pre[^>]*>(.*?)</pre>',body,re.S|re.I)
  if not pre: item['status']='no_report_pre_block';item['source_url']=url;return item
  text=html.unescape(re.sub('<[^>]*>','',max(pre,key=len)))
  p=CACHE/f'{code}_2008_report.txt';p.write_text(text,encoding='utf-8')
  item.update(status='retrieved',title=title,source_url=url,cache_file=str(p))
  # Preserve URLs to any primary PDF linked by the original filing mirror.
  item['linked_pdfs']=re.findall(r'https?[^\s\"\'<>]+\.[Pp][Dd][Ff](?:\?[^\s\"\'<>]*)?',body)
 except Exception as e:item.update(status='error',error=str(e))
 return item

results=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for fut in as_completed([pool.submit(fetch,code) for code in sorted(codes)]):
  item=fut.result();results.append(item);print(item['firm_id'],item['status'],flush=True)
results.sort(key=lambda x:x['firm_id']);js('public_report_retrieval.json',results)
after=[dict(path=r['path'],sha256=sha(r['path'])) for r in protected]
js('protected_after.json',after)
changed=[r['path'] for r,s in zip(protected_before,after) if r!=s]
input_changes=[p for p,h in input_before.items() if sha(p)!=h]
js('execution_audit.json',dict(target_firms=len(codes),deferred_601607=True,source_path=str(SOURCE),source_sha256=input_before[str(SOURCE)],protected_files=len(protected),protected_changes=changed,input_changes=input_changes,
 no_merge=True,no_SYN_recalculation=True,no_regressions=True,no_original_file_writes=True,peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576))
assert not changed and not input_changes
print('Retrieval completed',len(results),flush=True)
