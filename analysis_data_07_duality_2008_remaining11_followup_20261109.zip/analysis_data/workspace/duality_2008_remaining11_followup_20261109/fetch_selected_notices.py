"""Retrieve only explicit selected notices; reuse prior files, never rewrite them."""
import hashlib,json,re,resource
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from urllib.request import Request,urlopen
from pypdf import PdfReader
O=Path(__file__).resolve().parent
P=Path('/Users/macpro/Documents/New project/duality_2008_name_verification_20261109')
C=O/'evidence';C.mkdir(exist_ok=True)
selection={
 '600029':['47340119'],
 '600050':['39984682','39813734','39843462','41605315'],
 '600248':['38744613','41523966','48297939'],
 '600249':['39623215','40025138','41410630','49932776','51411303','39623214','39420370'],
 '600305':['30847158','35238178','41715694','45882364','48108343'],
 '600329':['20627454','36385140','34971200','30264171','41410372','49571754','35269685','35269686','49571755'],
 '600345':['39160205','41598541','49385632'],
 '600629':['23223690','29453221','34971476','41452985','48540289','31262931'],
 '600790':['47356694'],
 '600805':['35340748','35238263','36142191','41715749'],
 '601008':['48019836']}
jobs=[]
for code,ids in selection.items():
 d=json.loads((O/'metadata_complete'/f'{code}.json').read_text())
 assert d['complete'],code
 aa={r['id']:r for r in d['announcements']}
 for id in ids:
  assert id in aa,(code,id)
  jobs.append(dict(firm_id=code,**aa[id]))
def fetch(a):
 a=dict(a);code=a['firm_id'];id=a['id']
 p=C/f'{code}_{id}.pdf';t=p.with_suffix('.txt')
 prior=P/'evidence_cache'/f'{code}_notice_{id}.pdf'
 try:
  if prior.exists():p=prior
  elif not p.exists():
   req=Request(a['url'],headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.cninfo.com.cn/'})
   with urlopen(req,timeout=35) as r:raw=r.read()
   assert raw.startswith(b'%PDF'),a['url'];p.write_bytes(raw);del raw
  if not t.exists():
   reader=PdfReader(p);texts=[]
   for i,page in enumerate(reader.pages):
    if i>=35:break
    texts.append(f'\n===== PDF PAGE {i+1} =====\n'+page.extract_text())
   t.write_text('\n'.join(texts),encoding='utf-8')
   del reader,texts
  a.update(status='retrieved',pdf_path=str(p),text_path=str(t),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 except Exception as e:a.update(status='error',error=str(e))
 return a
out=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(fetch,a) for a in jobs]):
  a=f.result();out.append(a);print(a['firm_id'],a['id'],a['status'],a.get('error',''),flush=True)
  (O/'selected_notice_retrieval.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
(O/'notice_runtime.json').write_text(json.dumps(dict(peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,threads=2,target_notices=len(jobs),no_merge=True,no_regression=True,no_SYN_recalculation=True),indent=2))
