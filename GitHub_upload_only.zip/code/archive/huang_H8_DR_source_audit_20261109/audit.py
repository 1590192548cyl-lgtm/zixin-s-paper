from pathlib import Path
from collections import defaultdict
from zipfile import ZipFile
import json,hashlib,sys,subprocess,time,resource,csv,tempfile,shutil,re
import pandas as pd
import numpy as np

W=Path(__file__).resolve().parent;B=W.parent;O=W/'outputs';O.mkdir(exist_ok=True)
ROOT=Path('/Users/macpro/Desktop/毕业论文');P=ROOT/'堆叠DID重跑'
H=B/'huang_transition_static_H8_20261104/outputs';D=B/'huang_DR_DID_2008_complete_20261109/outputs'
SRC=B/'huang_week_calendar_repair_20261103/fixed_rerun/outputs/fixed_analysis.dta'
MAP=B/'huang_basic_reconstruction_20261103/outputs/policy_mapping_private.csv'
IND=ROOT/'原始数据/行业分类_新下载.dta'
sys.path.insert(0,str(B/'huang_replication_data_audit_20261103'))
from audit_sources import xml_rows,norm
start=time.monotonic()
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(n,x):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def records(p):
    head={}
    for sh,rn,v in xml_rows(p):
        if rn==1:head[sh]=v
        if rn>=4:yield {field:v.get(col,'') for col,field in head[sh].items()}
def read_first(p):
    it=xml_rows(p);out=[]
    try:
        for _ in range(3):out.append(next(it))
    except StopIteration:pass
    finally:it.close()
    return out

assert not (O/'audit_metrics.json').exists(),'Completed audit exists; do not overwrite.'
protected=json.loads((D/'protected_after.json').read_text());protected=[dict(path=r['path'],sha256=r['sha256']) for r in protected]
assert all(sha(r['path'])==r['sha256'] for r in protected)
known={r['path'] for r in protected}
def protect(p):
    p=Path(p)
    if str(p) not in known:protected.append(dict(path=str(p),sha256=sha(p)));known.add(str(p))
for p in [SRC,MAP,IND]+list(D.glob('*'))+list(H.glob('*')):
    if p.is_file():protect(p)

# Filename/ZIP-directory inventory only: no annual-report text search.
scan_roots=[ROOT/'控制变量',ROOT/'原始数据/公司基本信息',ROOT/'行业分类',Path('/Users/macpro/Desktop/2008年控制变量下载清单_20261104')]
inventory=[];st_sources=[];industry_xlsx=[]
for root in scan_roots:
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        st=p.stat();r=dict(path=str(p),size_bytes=st.st_size,mtime_ns=st.st_mtime_ns,suffix=p.suffix,inspection='filename_inventory')
        if p.suffix.lower()=='.zip':
            with ZipFile(p) as z:
                members=z.namelist();r['zip_members']=';'.join(members)
                for m in members:
                    if m.lower().endswith('.xlsx') and Path(m).name.upper() in ['BDT_CO.XLSX','EVA_CO.XLSX']:
                        st_sources.append((p,m));protect(p);r['inspection']='ST_source_directory_match'
        if p.suffix.lower()=='.xlsx' and p.name.upper() in ['BDT_CO.XLSX','EVA_CO.XLSX']:
            st_sources.append((p,None));protect(p);r['inspection']='ST_source_filename_match'
        if p.suffix.lower()=='.xlsx' and ('industry' in p.name.lower()):
            industry_xlsx.append(p);protect(p);r['inspection']='industry_source_candidate'
        inventory.append(r)
save('searched_source_inventory.csv',inventory);dump('protected_before.json',protected)
print('Protected',len(protected),'files. Extracting existing estimates; no fits.',flush=True)
t0=time.monotonic();proc=subprocess.run(['/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp','-b','do','extract_existing.do'],cwd=W,capture_output=True,text=True,timeout=60)
log=(O/'stored_estimates_read_only.log').read_text(errors='replace')
assert proc.returncode==0 and 'READ_EXISTING_ESTIMATES_COMPLETE_ZERO_FITS' in log
assert not re.search(r'^r\(\d+\);',log,re.M)
assert not re.search(r'^\.\s*(reghdfe|drdid|regress|areg|xtreg|logit|mlexp)\s',log,re.M)
dump('stored_estimate_read_execution.json',dict(exit_code=proc.returncode,seconds=time.monotonic()-t0,fit_commands=0,read_only=True))

d=pd.read_stata(SRC,convert_categoricals=False);assert not d.duplicated(['firm_id','year']).any()
mapping=pd.read_csv(MAP).set_index('firm_id');state=pd.read_csv(D/'company_sample_audit_private.csv').set_index('firm_id')
ids=set(d.loc[d.old_H8_sample.eq(1),'firm_id']);assert ids==set(state.index) and len(ids)==648
dr_ids=set(state.index[state.included]);assert len(dr_ids)==513
inactive=d[~d.firm_id.isin(ids)].copy()
assert inactive.old_H0_sample.eq(0).all() and inactive.old_H8_sample.eq(0).all()
save('source_rows_outside_both_frozen_models_private.csv',inactive[['firm_id','year','Treat','old_H0_sample','old_H8_sample','n_weeks']])
assert np.array_equal(d.Treat.to_numpy(),d.firm_id.map(mapping.Treat).to_numpy())
legal=d.old_H0_sample.eq(1)&d.n_weeks.ge(30)&np.isfinite(d.SYN)&np.isfinite(d.SYN_w)&d.R2.gt(0)&d.R2.lt(1)
assert np.array_equal(legal,d.old_H0_sample.eq(1))
assert np.allclose(d.loc[legal,'SYN_w'],d.loc[legal,'SYN'].clip(-2.6623991805823506,1.555292310918417),atol=1e-12,rtol=0)
original=d[d.old_H8_sample.eq(1)].copy();dr_rows=d[legal&d.firm_id.isin(dr_ids)&(d.year.eq(2013)|d.year.between(2015,2021))].copy()
assert len(original)==7609 and len(dr_rows)==4054
key=d[['firm_id','year','Treat','old_H0_sample','old_H8_sample','n_weeks']].copy()
key['DR_company']=key.firm_id.isin(dr_ids);key['DR_actual_outcome_row']=key.index.isin(dr_rows.index)
key['row_overlap_H8_DR']=key.old_H8_sample.eq(1)&key.DR_actual_outcome_row
save('row_membership_audit_private.csv',key)
rows=[]
for year in range(2009,2022):
    for t in [0,1]:
        z=key[key.year.eq(year)&key.Treat.eq(t)]
        rows.append(dict(year=year,Treat=t,H8_rows=int(z.old_H8_sample.sum()),H8_rows_DR_companies=int((z.old_H8_sample.eq(1)&z.DR_company).sum()),DR_actual_rows=int(z.DR_actual_outcome_row.sum()),overlap=int(z.row_overlap_H8_DR.sum()),DR_rows_missing_current_H8_controls=int((z.DR_actual_outcome_row&z.old_H8_sample.eq(0)).sum())))
save('sample_membership_by_year.csv',rows)
firm=state.copy();firm['industry2014']=firm.index.map(mapping.industry2014)
firm['H8_rows']=original.groupby('firm_id').size();firm['DR_actual_rows']=dr_rows.groupby('firm_id').size().reindex(firm.index,fill_value=0)
save('company_membership_comparison_private.csv',firm.reset_index())
phase=[]
for name,years in [('pure_pre',[2009,2010,2011,2012,2013]),('transition',[2014]),('post',list(range(2015,2022)))]:
    for group,fs in [('H8_648',ids),('DR_513',dr_ids)]:
        for t in [0,1]:
            z=original[original.year.isin(years)&original.firm_id.isin(fs)&original.Treat.eq(t)]
            phase.append(dict(population=group,phase=name,Treat=t,rows=len(z),firms=z.firm_id.nunique(),SYN_w_mean=z.SYN_w.mean(),input_weight_per_row=1,not_H8_implicit_coefficient_weight=True))
save('H8_phase_input_composition.csv',phase)

meta=pd.read_csv(O/'stored_model_metadata.csv').fillna('');assert all(meta.loc[meta.model.str.startswith('H8'),'weight_type'].eq(''))
timing=[dict(model='H8_transition',companies=648,source_company_year_rows=7609,estimation_panel_rows=7609,pre_reference='2009-2013 enter static; event normalized to 2013',transition='2014 separate TreatTransition; retained',post='2015-2021 original available annual rows',covariates='annual Size_w Age_w Lev_w Cent_w Top10_w Dual Board_w Big4',explicit_weights='none',company_id_cluster='firm_id',estimand='static TWFE coefficient; not simple average of event coefficients'),dict(model='DR_static',companies=513,source_company_year_rows=4054,estimation_panel_rows=1026,pre_reference='SYN2013 only',transition='2014 not used in long difference',post='observed legal 2015-2021 within-company average; 5-7 years',covariates='raw 2008 Size Age Lev Cent Top10 Dual Board Big4, linear rescaling only',explicit_weights='frozen IPT ATT weights, treated weight=1',company_id_cluster='firm_id',estimand='ATT of observed-post-average minus SYN2013 in eligible treated firms')]
save('estimand_timing_weight_comparison.csv',timing)
coef=pd.read_csv(O/'stored_coefficients.csv');eventcoef=coef[coef.model.eq('H8_event')&coef.matrix_name.eq('e(b)')].set_index('term').coefficient
staticcoef=coef[coef.model.eq('H8_static')&coef.matrix_name.eq('e(b)')].set_index('term').coefficient

# Descriptive bridge: raw moments, not newly estimated counterfactual models.
wide=d[legal].pivot(index='firm_id',columns='year',values='SYN_w')
H10=set(original.loc[original.year.eq(2010),'firm_id']);H13=set(original.loc[original.year.eq(2013),'firm_id'])
hp=H10&H13
f10=pd.read_csv(D/'year_2010_influence_private.csv').set_index('firm_id');drpair=set(f10.index)
assert drpair==dr_ids&set(wide.index[wide[2010].notna()&wide[2013].notna()])
common=hp&drpair
bridge=[];contrib=[];industries=[];aggregate=[]
def pair_contribution(name,fs,w=None):
    ix=sorted(fs);z=pd.DataFrame(index=pd.Index(ix,name='firm_id'))
    z['Treat']=z.index.map(mapping.Treat);z['industry2014']=z.index.map(mapping.industry2014)
    z['SYN2010']=wide.loc[ix,2010];z['SYN2013']=wide.loc[ix,2013];z['delta_2010_minus2013']=z.SYN2010-z.SYN2013
    z['raw_weight']=1. if w is None else w.reindex(z.index)
    assert z.notna().all().all()
    for t in [0,1]:
        mask=z.Treat.eq(t);z.loc[mask,'group_normalized_weight']=z.loc[mask,'raw_weight']/z.loc[mask,'raw_weight'].sum()
    z['signed_weight']=np.where(z.Treat.eq(1),1.,-1.)*z.group_normalized_weight
    assert abs(z.signed_weight.sum())<1e-12
    z['contribution_2010']=z.signed_weight*(z.SYN2010-z.SYN2010.mean())
    z['contribution_minus2013']=-z.signed_weight*(z.SYN2013-z.SYN2013.mean())
    z['contribution_total']=z.contribution_2010+z.contribution_minus2013
    gap10=(z.signed_weight*z.SYN2010).sum();gap13=(z.signed_weight*z.SYN2013).sum();gap=gap10-gap13
    assert abs(z.contribution_total.sum()-gap)<1e-12
    row=dict(stage=name,firms=len(z),treated=int(z.Treat.sum()),controls=int(z.Treat.eq(0).sum()),gap2010=gap10,gap2013=gap13,difference_2010_minus2013=gap,regression=False)
    bridge.append(row);z['population']=name
    if name in ['H8_fixed_pair','DR_2010_frozen_IPT']:
        contrib.extend(z.reset_index().to_dict('records'))
        for (code,t),g in z.groupby(['industry2014','Treat']):
            industries.append(dict(population=name,industry2014=code,Treat=t,firms=len(g),contribution_2010=g.contribution_2010.sum(),contribution_minus2013=g.contribution_minus2013.sum(),contribution_total=g.contribution_total.sum(),weighted_group_share=g.group_normalized_weight.sum(),mean_SYN2010=g.SYN2010.mean(),mean_SYN2013=g.SYN2013.mean()))
    aggregate.append(row)
    return z
g=original[original.year.isin([2010,2013])].groupby(['year','Treat']).SYN_w.mean()
gap10=g[2010,1]-g[2010,0];gap13=g[2013,1]-g[2013,0]
bridge.append(dict(stage='H8_original_annual_available',firms=len(H10|H13),treated=np.nan,controls=np.nan,gap2010=gap10,gap2013=gap13,difference_2010_minus2013=gap10-gap13,regression=False))
pair_contribution('H8_fixed_pair',hp)
pair_contribution('H8_DR_common_pair',common)
pair_contribution('DR_2010_pair_equal_weights',drpair)
drdecomp=pair_contribution('DR_2010_frozen_IPT',drpair,f10.att_weight)
dr_result=pd.read_csv(D/'drdid_yearly_results.csv').set_index('year').loc[2010]
delta_exact=drdecomp.contribution_total.sum()-dr_result.ATT
assert abs(delta_exact)<1e-8,'Frozen weighted raw gap does not equal archived DR ATT; do not label exact.'
for i,r in enumerate(bridge):r['change_from_previous']=np.nan if i==0 else r['difference_2010_minus2013']-bridge[i-1]['difference_2010_minus2013']
save('descriptive_2010_2013_bridge.csv',bridge)
save('company_2010_2013_contributions_private.csv',contrib);save('industry_2010_2013_contributions.csv',industries)
company=pd.DataFrame(contrib);top=[]
for pop,z in company.groupby('population'):
    z=z.copy();z['abs_contribution']=z.contribution_total.abs();z=z.sort_values('abs_contribution',ascending=False)
    denom=z.abs_contribution.sum()
    top.append(dict(population=pop,firm_count=len(z),sum_signed_contributions=z.contribution_total.sum(),sum_abs_contributions=denom,largest_abs_share=z.abs_contribution.iloc[0]/denom,top5_abs_share=z.abs_contribution.head(5).sum()/denom,top10_abs_share=z.abs_contribution.head(10).sum()/denom,not_share_of_causal_effect=True))
    save(f'{pop}_company_contribution_order_private.csv',z)
save('contribution_concentration.csv',top)
inf=f10[['Treat','recentered_IF','pscore','att_weight']].copy();inf['industry2014']=inf.index.map(mapping.industry2014)
inf['centered_IF']=inf.recentered_IF-dr_result.ATT;inf['linearized_estimator_contribution']=inf.centered_IF/len(inf)
inf['abs_linearized_contribution']=inf.linearized_estimator_contribution.abs()
save('DR2010_influence_diagnostic_private.csv',inf.reset_index().sort_values('abs_linearized_contribution',ascending=False))

# Exact point-contribution audit of main DR ATT (not variance or delete-one effects).
mw=pd.read_csv(D/'main_weights_private.csv').set_index('firm_id');postcols=list(range(2015,2022));ix=sorted(dr_ids)
z=pd.DataFrame(index=pd.Index(ix,name='firm_id'));z['Treat']=z.index.map(mapping.Treat);z['industry2014']=z.index.map(mapping.industry2014)
z['Ypre2013']=wide.loc[ix,2013];z['Ymeanpost']=wide.loc[ix,postcols].mean(axis=1);z['n_post']=wide.loc[ix,postcols].notna().sum(axis=1)
z['delta']=z.Ymeanpost-z.Ypre2013;z['raw_weight']=mw.att_weight.reindex(ix)
for t in [0,1]:
    mask=z.Treat.eq(t);z.loc[mask,'group_weight']=z.loc[mask,'raw_weight']/z.loc[mask,'raw_weight'].sum()
z['signed_weight']=np.where(z.Treat.eq(1),1.,-1.)*z.group_weight
z['point_contribution']=z.signed_weight*(z.delta-z.delta.mean())
mainr=pd.read_csv(D/'drdid_static_result.csv').iloc[0]
assert abs(z.point_contribution.sum()-mainr.ATT)<1e-8
save('DR_static_company_point_contributions_private.csv',z.reset_index())
save('DR_static_industry_point_contributions.csv',z.groupby(['industry2014','Treat']).agg(firms=('Treat','size'),point_contribution=('point_contribution','sum')).reset_index())
annual=[]
for f,r in z.iterrows():
    annual.append(dict(firm_id=f,year=2013,Treat=r.Treat,outcome_weight=-r.signed_weight,SYN_w=r.Ypre2013,part='pre'))
    for y in postcols:
        if pd.notna(wide.at[f,y]):annual.append(dict(firm_id=f,year=y,Treat=r.Treat,outcome_weight=r.signed_weight/r.n_post,SYN_w=wide.at[f,y],part='post'))
aw=pd.DataFrame(annual);aw['weighted_outcome_contribution']=aw.outcome_weight*aw.SYN_w
assert abs(aw.weighted_outcome_contribution.sum()-mainr.ATT)<1e-8
save('DR_static_frozen_outcome_weights_private.csv',aw)
save('DR_static_time_group_weights.csv',aw.groupby(['year','Treat','part']).agg(firms=('firm_id','nunique'),signed_weight_sum=('outcome_weight','sum'),outcome_contribution=('weighted_outcome_contribution','sum')).reset_index())

dump('intermediate_audit_facts.json',dict(H8_N=len(original),H8_firms=len(ids),DR_firms=len(dr_ids),DR_actual_rows=len(dr_rows),H8_DR_row_overlap=int(key.row_overlap_H8_DR.sum()),DR_rows_not_in_H8=int((key.DR_actual_outcome_row&key.old_H8_sample.eq(0)).sum()),H8_2010_firms=len(H10),H8_2013_firms=len(H13),H8_pair_firms=len(hp),common_pair_firms=len(common),DR_2010_pair_firms=len(drpair),DR2010_point_identity_error=delta_exact,DR_static_point_identity_error=z.point_contribution.sum()-mainr.ATT,H8_exact_implicit_weights_recovered=False,reason='No stored residualized treatment or FE projections; auxiliary regression prohibited',H8_event2010=float(eventcoef['D_m5']),H8_static=float(staticcoef['TreatPost'])))
print('Sample and frozen-weight decompositions complete. Reading classification/ST evidence.',flush=True)

# Current raw classification: keep only target year/standard rows, small chunks.
with pd.read_stata(IND,iterator=True,convert_categoricals=False) as reader:available=list(reader.variable_labels())
cols=['Symbol','EndDate','IndustryClassificationID','IndustryCode2','IndustryName2']
if 'InstitutionID' in available:cols.append('InstitutionID')
parts=[];rawcov=defaultdict(lambda:[0,set()]);institution=defaultdict(set)
for ch in pd.read_stata(IND,columns=cols,chunksize=12000,convert_categoricals=False):
    yy=ch.EndDate.str[:4].astype(int);fid=ch.Symbol.astype(int)
    for (sid,y),g in ch.assign(yy=yy,fid=fid).groupby(['IndustryClassificationID','yy']):
        a0=rawcov[sid,int(y)];a0[0]+=len(g);a0[1].update(g.fid)
    if 'InstitutionID' in ch:
        for inst,f,y in zip(ch.InstitutionID,fid,yy):institution[norm(inst),int(y)].add(int(f))
    flag=(ch.IndustryClassificationID.eq('P0201')&yy.isin([2009,2010,2011]))|(ch.IndustryClassificationID.eq('P0207')&yy.isin([2012,2013,2014]))
    q=ch.loc[flag,['IndustryClassificationID','IndustryCode2','IndustryName2']].copy();q['firm_id']=fid[flag];q['year']=yy[flag];parts.append(q)
ind=pd.concat(parts,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any()
codes=ind.pivot(index='firm_id',columns='year',values='IndustryCode2');names=ind.pivot(index='firm_id',columns='year',values='IndustryName2')
save('current_original_classification_year_coverage.csv',[dict(standard=s,year=y,rows=v[0],firms=len(v[1])) for (s,y),v in sorted(rawcov.items())])
sourcecoverage=[];classheaders=[]
save('institution_year_multiple_security_keys_private.csv',[dict(InstitutionID=k[0],year=k[1],symbols=';'.join(map(str,sorted(v))),H8_symbols=';'.join(map(str,sorted(v&ids)))) for k,v in institution.items() if len(v)>1])
for p in industry_xlsx:
    header=read_first(p);classheaders.append(dict(path=str(p),first_rows=header))
    counts=defaultdict(lambda:[0,set()]);target=defaultdict(set)
    for r in records(p):
        sid=r.get('IndustryClassificationID','');dt=r.get('EndDate','')
        if not sid or not dt[:4].isdigit():continue
        y=int(dt[:4]);k=r.get('Symbol',r.get('Stkcd',''))
        if not k and 'InstitutionID' in r:
            candidates=institution.get((norm(r['InstitutionID']),y),set());within=candidates&ids
            # Audit-only key linking: never pick among multiple H8 firms.
            if len(within)==1:k=next(iter(within))
            elif len(candidates)==1:k=next(iter(candidates))
        k=norm(k);key0=(sid,y);counts[key0][0]+=1
        if k.isdigit():counts[key0][1].add(int(k))
        if k.isdigit() and int(k) in dr_ids:target[key0].add(int(k))
    for (sid,y),vv in sorted(counts.items()):sourcecoverage.append(dict(path=str(p),standard=sid,year=y,rows=vv[0],mapped_firms=len(vv[1]),DR513_firms=len(target[sid,y]),standard_ID_field_present=True))
    if not counts:sourcecoverage.append(dict(path=str(p),standard='',year='',rows='',mapped_firms='',DR513_firms='',standard_ID_field_present=any('IndustryClassificationID' in rr[2].values() for rr in header if rr[1]==1)))
    print('Read classification evidence',p.parent.name,p.name,flush=True)
save('additional_classification_year_coverage.csv',sourcecoverage);dump('classification_header_evidence.json',classheaders)

def syngroup(c):return c if str(c).startswith('C') else str(c)[:1]
review=[]
for f in sorted(ids):
    r=dict(firm_id=f,Treat=int(mapping.at[f,'Treat']),industry2014=mapping.at[f,'industry2014'],in_DR=f in dr_ids,in_H8_2010_2013_pair=f in hp,in_DR2010_pair=f in drpair)
    for y in [2009,2010,2011,2012,2013,2014]:
        r[f'code{y}']=codes.at[f,y] if f in codes.index else np.nan
        r[f'name{y}']=names.at[f,y] if f in names.index else np.nan
    r['stable_2012_2013_2014']=pd.notna(r['code2012']) and r['code2012']==r['code2013']==r['code2014']
    r['stable_SYN_group_2012_2013_2014']=pd.notna(r['code2012']) and syngroup(r['code2012'])==syngroup(r['code2013'])==syngroup(r['code2014'])
    r['historical_2010_P0207_certified']=False
    r['backcast_risk']='2010 SYN uses company 2012 P0207; P0201 differs by classification version, not automatic miscoding'
    review.append(r)
review=pd.DataFrame(review);save('industry_backcast_review_private.csv',review)
cross=codes[codes.index.isin(ids)&codes[2010].notna()&codes[2012].notna()][[2010,2012]].copy()
cross['syn_group2012']=cross[2012].map(syngroup)
save('sample_2010_legacy_2012_crosswalk.csv',cross.groupby([2010,2012,'syn_group2012']).size().rename('firms').reset_index())
amb=cross.groupby(2010).agg(firms=(2012,'size'),new_codes=(2012,'nunique'),new_SYN_groups=('syn_group2012','nunique')).reset_index()
save('sample_crosswalk_ambiguity.csv',amb)
strata=[]
for pop,zz in [('H8_fixed_pair',company[company.population.eq('H8_fixed_pair')]),('DR_2010_frozen_IPT',company[company.population.eq('DR_2010_frozen_IPT')])]:
    rr=review.set_index('firm_id')
    zz=zz.copy();zz['stable_codes']=zz.firm_id.map(rr.stable_2012_2013_2014)
    for stable,g in zz.groupby('stable_codes'):
        strata.append(dict(population=pop,stable_2012_2013_2014=stable,firms=len(g),sum_original_full_sample_contributions=g.contribution_total.sum(),weights_not_renormalized=True,not_a_new_subset_estimate=True))
save('industry_stability_contribution_audit.csv',strata)

# Current ST candidates. No missing dates are changed to 0 or "never ST".
ST=[];STheads=[]
def consume_st(p,member,stream):
    header=read_first(stream);STheads.append(dict(path=str(p),member=member,first_rows=header))
    if hasattr(stream,'seek'):stream.seek(0)
    for rr in records(stream):
        k=norm(rr.get('Symbol',rr.get('Stkcd','')))
        if not k.isdigit():continue
        if 'FirstSTDate' in rr:
            ST.append(dict(firm_id=int(k),source=str(p),member=member or '',ListedDate=rr.get('ListedDate',''),FirstSTDate=rr.get('FirstSTDate',''),IsManyTimesST=rr.get('IsManyTimesST',''),DelistedDate=rr.get('DelistedDate','')))
for p,member in st_sources:
    if member:
        with ZipFile(p) as zf, tempfile.TemporaryFile(suffix='.xlsx') as temp:
            with zf.open(member) as stream:shutil.copyfileobj(stream,temp,1048576)
            temp.seek(0);consume_st(p,member,temp)
    else:consume_st(p,None,p)
dump('ST_header_evidence.json',STheads);st=pd.DataFrame(ST)
assert len(st)>0
save('ST_observed_source_records_private.csv',st)
STsummary=[]
for (src,member),g in st.groupby(['source','member']):
    STsummary.append(dict(path=src,member=member,rows=len(g),firms=g.firm_id.nunique(),ListedDate_min=g.ListedDate.min(),ListedDate_max=g.ListedDate.max(),H8_firms=g[g.firm_id.isin(ids)].firm_id.nunique(),DR_firms=g[g.firm_id.isin(dr_ids)].firm_id.nunique(),source_date_blank=int(g.FirstSTDate.eq('').sum())))
save('current_ST_source_coverage.csv',STsummary)
oldst=pd.read_csv(B/'huang_industry_ST_audit_20261103/outputs/ST_proxy_vs_FirstSTDate_private.csv').set_index('firm_id')
st_detail=[]
for f in sorted(ids):
    zst=st[st.firm_id.eq(f)];dates=sorted(set(zst.loc[zst.FirstSTDate.ne(''),'FirstSTDate']))
    bkt='no_company_row_unknown' if len(zst)==0 else 'company_present_date_blank_not_never' if not dates else 'conflicting_first_dates' if len(dates)>1 else 'documented_first_date'
    st_detail.append(dict(firm_id=f,Treat=int(mapping.at[f,'Treat']),in_DR=f in dr_ids,source_rows=len(zst),status=bkt,FirstSTDate=';'.join(dates),documented_first_ST_by2021=bool(dates and dates[0]<='2021-12-31'),old_proxy_ST_year=oldst.at[f,'old_proxy_ST_year'] if f in oldst.index else np.nan,old_retained=oldst.at[f,'old_retained'] if f in oldst.index else np.nan,not_certified_full_status_history=True))
st_detail=pd.DataFrame(st_detail);save('current_ST_company_check_private.csv',st_detail)
save('ST_still_missing_DR_companies_private.csv',st_detail[st_detail.in_DR&st_detail.status.eq('no_company_row_unknown')])
riskcounts=[]
for pop,subset in [('H8_648',st_detail),('DR_513',st_detail[st_detail.in_DR])]:
    riskcounts.append(dict(population=pop,firms=len(subset),ST_company_row_missing=int(subset.status.eq('no_company_row_unknown').sum()),ST_date_blank=int(subset.status.eq('company_present_date_blank_not_never').sum()),documented_first_ST_by2021=int(subset.documented_first_ST_by2021.sum()),full_ST_history_certified_firms=0))
save('ST_risk_summary.csv',riskcounts)
post_excluded=oldst[oldst.old_retained.eq(False)&oldst.old_proxy_ST_year.between(2015,2021)].reset_index()
save('existing_postpolicy_ST_screened_company_list_private.csv',post_excluded)
save('old_ST_screen_phase_counts.csv',oldst.assign(proxy_period=np.where(oldst.old_proxy_ST_year.between(2015,2021),'first_proxy_after_policy',np.where(oldst.old_proxy_ST_year.between(2009,2014),'first_proxy_pre_or_transition','no_observed_proxy'))).groupby(['old_retained','proxy_period']).size().rename('firms').reset_index())

after=[dict(path=r['path'],sha256=sha(r['path']),unchanged=sha(r['path'])==r['sha256']) for r in protected]
dump('protected_after.json',after);assert all(r['unchanged'] for r in after)
facts=json.loads((O/'intermediate_audit_facts.json').read_text());facts.update(regressions_run=0,auxiliary_regressions_run=0,new_p_values_computed=0,SYN_recomputed=False,original_or_analysis_data_modified=False,new_analysis_DTA=False,deleted_records=0,protected_files=len(after),all_originals_unchanged=True,classification_xlsx_examined=len(industry_xlsx),ST_sources_examined=len(st_sources),ST_source_rows=len(st),ST_source_coverage=riskcounts,legacy_codes_in_H8=int(len(amb)),one_to_many_legacy_codes=int(amb.new_codes.gt(1).sum()),one_to_many_SYN_groups=int(amb.new_SYN_groups.gt(1).sum()),industry_backcast_risk_resolved=False,ST_screening_risk_resolved=False,DR2010_abs_contribution_concentration=top,seconds=time.monotonic()-start,peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,Stata_peak_RSS_MiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss/1024**2)
dump('audit_metrics.json',facts)
print(json.dumps(facts,ensure_ascii=False,indent=2),flush=True)
