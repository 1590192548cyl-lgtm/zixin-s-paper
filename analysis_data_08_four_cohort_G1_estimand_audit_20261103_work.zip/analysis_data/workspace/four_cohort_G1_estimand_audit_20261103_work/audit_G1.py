"""Read-only inputs; exact decompositions of the frozen four-cohort G1."""
from pathlib import Path
import argparse
import hashlib
import json
import resource
import time
import numpy as np
import pandas as pd

WORK = Path(__file__).resolve().parent
OUT = WORK / 'outputs'
SRC = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028')
DATA = SRC / 'latest_G1_analysis.dta'
KEY = ['firm_id', 'stack_id', 'annual_report_year']
X = ['Size_w_exact', 'MB_parent_w_exact', 'Lev_w_exact']
Y = 'SYN_CSRC_FAMILY_w_exact'
TERMS = ['D_m2', 'D_m1', 'D_0', 'D_p1', 'D_p2']
TIMES = [-2, -1, 0, 1, 2]
INPUTS = [DATA, SRC/'G1_static_rerun_results.csv', SRC/'G1_event_results.csv',
          SRC/'G1_event_joint_tests.csv', SRC/'latest_G1_estimation_sample.csv',
          SRC/'latest_G1_event_sample.csv', SRC/'code/run_four_cohort_G1.do',
          SRC/'four_cohort_G1_latest_report.md', SRC/'latest_G1.ster',
          SRC/'latest_G1_event.ster']


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def write(df, name):
    df.to_csv(OUT/name, index=False, encoding='utf-8-sig', float_format='%.17g')


def manifest():
    return pd.DataFrame([{'path':str(p), 'bytes':p.stat().st_size,
                          'sha256':sha(p)} for p in INPUTS])


def check_row(rows, name, value, passed, note=''):
    rows.append({'check':name, 'value':value, 'passed':bool(passed), 'note':note})


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    m=manifest()
    assert not (OUT/'input_manifest_before.csv').exists(), 'Do not overwrite an existing audit.'
    write(m, 'input_manifest_before.csv')
    d=pd.read_stata(DATA, convert_categoricals=False)
    checks=[]
    check_row(checks,'source_rows',len(d),len(d)==26711)
    check_row(checks,'duplicate_firm_stack_year',int(d.duplicated(KEY).sum()),not d.duplicated(KEY).any())
    check_row(checks,'TreatPost_identity',int((d.TreatPost != d.treated_in_stack*d.Post).sum()),
              (d.TreatPost == d.treated_in_stack*d.Post).all())
    check_row(checks,'Post_identity',int((d.Post != (d.event_time>=0)).sum()),(d.Post==(d.event_time>=0)).all())
    check_row(checks,'time_identity',int((d.syn_year != d.annual_report_year+1).sum()),(d.syn_year==d.annual_report_year+1).all())
    check_row(checks,'event_identity',int((d.event_time != d.annual_report_year-d.cohort_report_year).sum()),
              (d.event_time==d.annual_report_year-d.cohort_report_year).all())
    for col in ['treated_in_stack','Post','TreatPost']:
        check_row(checks,col+'_binary',str(sorted(d[col].unique())),d[col].isin([0,1]).all())
    vary=d.groupby(['firm_id','stack_id']).treated_in_stack.nunique().gt(1).sum()
    check_row(checks,'within_firm_stack_role_changes',int(vary),vary==0)
    for fe,keys in [('firm_stack_id',['firm_id','stack_id']),('cohort_year_id',['stack_id','annual_report_year'])]:
        bad1=d.groupby(fe)[keys].nunique().max().max()>1
        bad2=d.groupby(keys)[fe].nunique().max()>1
        check_row(checks,fe+'_partition_bijection',int(bad1 or bad2),not(bad1 or bad2))
    s=d.loc[d.sample_g1.eq(1)].copy()
    check_row(checks,'frozen_G1_N',len(s),len(s)==24659)
    check_row(checks,'G1_missing_frozen_values',int(s[[Y,'TreatPost']+X].isna().sum().sum()),not s[[Y,'TreatPost']+X].isna().any().any())
    check_row(checks,'four_cohorts',str(sorted(s.cohort_report_year.unique().tolist())),
              sorted(s.cohort_report_year.unique())==[2013,2015,2016,2017])
    check_row(checks,'event_window',str(sorted(s.event_time.unique().tolist())),sorted(s.event_time.unique())==[-3,-2,-1,0,1,2])
    for f,flag in [('latest_G1_estimation_sample.csv','actual_es'),('latest_G1_event_sample.csv','event_es')]:
        a=pd.read_csv(SRC/f)
        actual=set(map(tuple,a.loc[a[flag].eq(1),KEY].to_numpy()))
        expected=set(map(tuple,s[KEY].to_numpy()))
        check_row(checks,f+'_key_difference',len(actual.symmetric_difference(expected)),actual==expected)
    support=s.groupby(['cohort_report_year','event_time','treated_in_stack']).agg(N=('firm_id','size'),firms=('firm_id','nunique')).reset_index()
    check_row(checks,'cohort_event_role_support',len(support),len(support)==48 and support.N.min()>0)
    c=pd.DataFrame(checks)
    write(c,'sample_and_coding_audit.csv')
    write(support,'cohort_event_support.csv')
    assert c.passed.all(), c.loc[~c.passed].to_dict('records')
    print(json.dumps({'stage':'PREPARED','raw_N':len(d),'G1_N':len(s),'checks':len(c),'all_passed':True},ensure_ascii=False),flush=True)


def absorb(a, groups):
    """Independent alternating FE projections; never construct a dense dummy matrix."""
    z=np.array(a,dtype=np.float64,copy=True)
    codes=[pd.factorize(g,sort=True)[0] for g in groups]
    counts=[np.bincount(g).astype(float) for g in codes]
    for it in range(10000):
        largest=0.0
        for g,n in zip(codes,counts):
            for j in range(z.shape[1]):
                means=np.bincount(g,weights=z[:,j])/n
                largest=max(largest,float(np.max(np.abs(means))))
                z[:,j]-=means[g]
        if largest<1e-12:
            return z,it+1,largest
    raise AssertionError('FE projection did not converge')


def table(df, cols=None, digits=6):
    q=df if cols is None else df[cols]
    rows=['|'+'|'.join(map(str,q.columns))+'|','|'+'|'.join(['---']*len(q.columns))+'|']
    for r in q.itertuples(index=False,name=None):
        vals=[]
        for v in r:
            if isinstance(v,(float,np.floating)):
                vals.append(f'{v:.{digits}f}')
            else:
                vals.append(str(v))
        rows.append('|'+'|'.join(vals)+'|')
    return '\n'.join(rows)


def compile_audit():
    start=time.monotonic()
    d=pd.read_stata(DATA,convert_categoricals=False)
    s=d.loc[d.sample_g1.eq(1)].copy().sort_values(KEY).reset_index(drop=True)
    r=pd.read_csv(OUT/'observation_weight_audit_private.csv').sort_values(KEY).reset_index(drop=True)
    assert s[KEY].equals(r[KEY].astype(s[KEY].dtypes))
    for col in [Y,'TreatPost','treated_in_stack','event_time','firm_stack_id','cohort_year_id']+X:
        assert np.allclose(s[col],r[col],rtol=0,atol=1e-12),col
    assert (r.static_es==r.dynamic_es).all() and r.static_es.eq(1).all()
    st=pd.read_csv(OUT/'static_reproduction.csv').iloc[0]
    ev=pd.read_csv(OUT/'dynamic_reproduction.csv').set_index('term').loc[TERMS]
    jt=pd.read_csv(OUT/'joint_tests.csv')
    contrasts=pd.read_csv(OUT/'static_dynamic_contrasts.csv')
    comp=[]
    old=pd.read_csv(SRC/'G1_static_rerun_results.csv').query("model=='latest_G1'").iloc[0]
    for a,b in [('N','N'),('clusters','clusters'),('coefficient','TreatPost'),('SE','SE'),('p','p')]:
        v=float(st[a]); expected=float(old[b]); tol=0 if a in ['N','clusters'] else 1e-8
        comp.append({'metric':'static_'+a,'archived':expected,'audit':v,'difference':v-expected,'tolerance':tol,'passed':abs(v-expected)<=tol})
    oldev=pd.read_csv(SRC/'G1_event_results.csv').query("model=='latest_G1'").set_index('event_time')
    for term,k in zip(TERMS,TIMES):
        for col in ['coefficient','SE','p']:
            v=float(ev.loc[term,col]); expected=float(oldev.loc[k,col]); tol=1e-8
            comp.append({'metric':f'dynamic_{k}_{col}','archived':expected,'audit':v,'difference':v-expected,'tolerance':tol,'passed':abs(v-expected)<=tol})
    write(pd.DataFrame(comp),'reproduction_check.csv')
    assert all(a['passed'] for a in comp)

    # Independent Python projection; inference remains the original Stata clustered inference.
    E=np.column_stack([(s.treated_in_stack.eq(1)&s.event_time.eq(k)).astype(float) for k in TIMES])
    arr=np.column_stack([s[Y],s.TreatPost,s[X].to_numpy(),E])
    z,it,err=absorb(arr,[s.firm_stack_id,s.cohort_year_id])
    yf,df,xf,ef=z[:,0],z[:,1],z[:,2:5],z[:,5:]
    coef=np.linalg.lstsq(np.column_stack([df,xf]),yf,rcond=None)[0]
    dyncoef=np.linalg.lstsq(np.column_stack([ef,xf]),yf,rcond=None)[0]
    rd=df-xf@np.linalg.lstsq(xf,df,rcond=None)[0]
    ry=yf-xf@np.linalg.lstsq(xf,yf,rcond=None)[0]
    den=float(rd@rd)
    a=(rd@E)/den
    checks=[]
    def exact(name,left,right,tol=1e-8):
        diff=float(np.max(np.abs(np.asarray(left,dtype=float)-np.asarray(right,dtype=float))))
        checks.append({'check':name,'max_abs_difference':diff,'tolerance':tol,'passed':diff<=tol})
    exact('Python_vs_Stata_static_beta',coef[0],st.coefficient)
    exact('Python_vs_Stata_dynamic_beta',dyncoef[:5],ev.coefficient.to_numpy())
    exact('Python_vs_Stata_rd',rd,r.rd.to_numpy())
    exact('Python_vs_Stata_d_FE',df,r.d_fe.to_numpy())
    exact('Python_vs_Stata_ry',ry,r.ry.to_numpy())
    exact('stack_to_cohort_partition',s.groupby('stack_id').cohort_report_year.nunique().to_numpy(),1,0)
    exact('cohort_to_stack_partition',s.groupby('cohort_report_year').stack_id.nunique().to_numpy(),1,0)
    exact('static_as_dynamic_linear_combination',a@ev.coefficient.to_numpy(),st.coefficient)
    exact('FWL_beta_reconstruction',rd@ry/den,st.coefficient)
    w=rd/den
    r['outcome_weight_exact']=w
    r['FWL_score_exact']=rd*ry/den
    r['treated_post_effect_weight']=w*r.TreatPost
    cell=r.groupby(['cohort_report_year','event_time','treated_in_stack']).agg(
        N=('firm_id','size'),firms=('firm_id','nunique'),signed_outcome_weight=('outcome_weight_exact','sum'),
        mean_residual_D=('rd','mean'),FWL_score_contribution=('FWL_score_exact','sum')).reset_index()
    write(cell,'cohort_event_role_weights.csv')
    cancel=cell.pivot(index=['cohort_report_year','event_time'],columns='treated_in_stack',values='signed_outcome_weight').sum(axis=1)
    exact('treated_control_event_weight_cancellation',cancel.to_numpy(),0,1e-9)
    exact('post_treated_weights_sum_one',w[r.TreatPost.eq(1)].sum(),1,1e-9)
    exact('pre_treated_weights_sum_minus_one',w[r.treated_in_stack.eq(1)&r.Post.eq(0)].sum(),-1,1e-9)
    for fe in ['firm_stack_id','cohort_year_id']:
        exact(fe+'_residual_weight_sum_zero',r.groupby(fe).outcome_weight_exact.sum().to_numpy(),0,1e-9)

    # Exact cohort decomposition with the original pooled control coefficients held fixed.
    gamma=coef[1:]
    ya=s[Y].to_numpy()-s[X].to_numpy()@gamma
    denfe=float(df@df)
    total_tf=sum(g.loc[g.treated_in_stack.eq(1),'firm_id'].nunique() for _,g in r.groupby('cohort_report_year'))
    total_tp=int(r.TreatPost.sum())
    cohorts=[]
    for g,ix in r.groupby('cohort_report_year').groups.items():
        idx=np.asarray(list(ix)); q=r.loc[idx]; dg=df[idx]
        ss=float(dg@dg)
        adjusted=float(dg@ya[idx]/ss)
        tp=q.TreatPost.eq(1)
        cohorts.append({'cohort_report_year':int(g),'N':len(q),
            'treated_firms':q.loc[q.treated_in_stack.eq(1),'firm_id'].nunique(),
            'control_firms':q.loc[q.treated_in_stack.eq(0),'firm_id'].nunique(),
            'treated_post_observations':int(tp.sum()),'sample_share':len(q)/len(r),
            'treated_firm_share':q.loc[q.treated_in_stack.eq(1),'firm_id'].nunique()/total_tf,
            'treated_post_obs_share':int(tp.sum())/total_tp,'equal_cohort_share':.25,
            'FE_design_variance_weight':ss/denfe,
            'adjusted_DID_holding_pooled_control_slopes':adjusted,
            'adjusted_DID_contribution':ss/denfe*adjusted,
            'FWL_rd_variance_share':float(rd[idx]@rd[idx]/den),
            'FWL_residual_score_contribution':float((rd[idx]*ry[idx]).sum()/den),
            'conditional_treated_post_effect_weight':float((w[idx]*q.TreatPost).sum())})
    cg=pd.DataFrame(cohorts)
    write(cg,'cohort_weight_and_contribution.csv')
    exact('cohort_adjusted_DID_contributions_sum',cg.adjusted_DID_contribution.sum(),st.coefficient)
    exact('cohort_FWL_contributions_sum',cg.FWL_residual_score_contribution.sum(),st.coefficient)
    exact('cohort_FE_variance_weights_sum',cg.FE_design_variance_weight.sum(),1)
    exact('cohort_conditional_post_weights_sum',cg.conditional_treated_post_effect_weight.sum(),1)

    decomp=[]
    for k in [-3,-2,-1,0,1,2]:
        ix=r.treated_in_stack.eq(1)&r.event_time.eq(k)
        ak=float(w[ix].sum())
        bk=0 if k==-3 else float(ev.loc[TERMS[TIMES.index(k)],'coefficient'])
        decomp.append({'event_time':k,'reference':int(k==-3),'static_projection_weight':ak,
                       'dynamic_coefficient':bk,'contribution_to_static_beta':ak*bk})
    dec=pd.DataFrame(decomp)
    write(dec,'static_from_dynamic_decomposition.csv')
    exact('event_contributions_sum_static',dec.contribution_to_static_beta.sum(),st.coefficient)
    exact('dynamic_projection_post_weights_sum',dec.loc[dec.event_time.ge(0),'static_projection_weight'].sum(),1)
    exact('dynamic_projection_pre_weights_sum',dec.loc[dec.event_time.lt(0),'static_projection_weight'].sum(),-1)

    vv=pd.read_csv(OUT/'dynamic_covariance.csv').pivot(index='row_term',columns='col_term',values='covariance').loc[TERMS,TERMS].to_numpy()
    se=np.sqrt(np.diag(vv)); corr=vv/np.outer(se,se)
    write(pd.DataFrame(corr,index=TERMS,columns=TERMS).reset_index(names='term'),'dynamic_coefficient_correlation.csv')
    linweights={'post_mean_vs_m3':np.array([0,0,1,1,1])/3,
                'pre_mean_vs_m3':np.array([1,1,0,0,0])/3,
                'post_mean_minus_pre_mean':np.array([-1,-1,1,1,1])/3,
                'exact_static_projection_dynamic_V':a}
    for name,l in linweights.items():
        row=contrasts.set_index('contrast').loc[name]
        exact(name+'_coefficient',l@ev.coefficient.to_numpy(),row.coefficient)
        exact(name+'_SE',np.sqrt(l@vv@l),row.SE)
    vc=[]
    for name,l in linweights.items():
        diagonal=float(np.sum(l*l*np.diag(vv)))
        total=float(l@vv@l)
        vc.append({'contrast':name,'diagonal_variance':diagonal,'cross_covariance_contribution':total-diagonal,'total_variance':total,'SE':np.sqrt(total)})
    write(pd.DataFrame(vc),'dynamic_contrast_variance_components.csv')
    lp=linweights['post_mean_vs_m3']; lpre=linweights['pre_mean_vs_m3']
    mean_cov=float(lp@vv@lpre)
    mean_corr=mean_cov/np.sqrt((lp@vv@lp)*(lpre@vv@lpre))
    write(pd.DataFrame([{'post_mean_variance':float(lp@vv@lp),
                        'pre_mean_variance':float(lpre@vv@lpre),
                        'post_pre_mean_covariance':mean_cov,
                        'post_pre_mean_correlation':mean_corr,
                        'difference_variance':float((lp-lpre)@vv@(lp-lpre))}]),
          'reference_mean_covariance_summary.csv')

    # Repeated firm-years are expected in a stack; their cluster identity must be preserved.
    fy=r.groupby(['firm_id','annual_report_year']).agg(copies=('stack_id','size'),treated_copies=('treated_in_stack','sum'),
        outcome_variants=(Y,'nunique'),size_variants=(X[0],'nunique'),MB_variants=(X[1],'nunique'),Lev_variants=(X[2],'nunique'),
        aggregated_outcome_weight=('outcome_weight_exact','sum')).reset_index()
    exact('repeated_firm_year_frozen_values',fy[['outcome_variants','size_variants','MB_variants','Lev_variants']].to_numpy(),1,0)
    dup=fy.groupby('copies').agg(unique_firm_years=('firm_id','size'),unique_firms=('firm_id','nunique')).reset_index()
    dup['stack_observations']=dup.copies*dup.unique_firm_years
    write(dup,'firm_year_stack_multiplicity.csv')
    fs=r.groupby(['firm_id','stack_id','treated_in_stack']).agg(N=('event_time','size'),pre=('Post',lambda v:int((v==0).sum())),post=('Post','sum')).reset_index()
    bal=fs.groupby('treated_in_stack').agg(firm_stack_pairs=('firm_id','size'),full_six_period_pairs=('N',lambda v:int((v==6).sum())),min_periods=('N','min'),max_periods=('N','max')).reset_index()
    write(bal,'panel_completeness_descriptive.csv')
    exact('each_firm_stack_pre_and_post',np.minimum(fs.pre,fs.post).gt(0).to_numpy(),True,0)
    cf=r.groupby('firm_id').treated_in_stack.agg(['min','max'])
    target=pd.DataFrame([
        {'metric':'stack_observations','value':len(r)},
        {'metric':'unique_firm_years','value':len(fy)},
        {'metric':'unique_original_firm_clusters','value':r.firm_id.nunique()},
        {'metric':'unique_treated_firms','value':r.loc[r.treated_in_stack.eq(1),'firm_id'].nunique()},
        {'metric':'sum_treated_firms_across_cohorts','value':total_tf},
        {'metric':'firms_serving_both_roles_across_stacks','value':int(((cf['min']==0)&(cf['max']==1)).sum())},
        {'metric':'max_stack_copies_per_firm_year','value':int(fy.copies.max())},
        {'metric':'negative_treated_post_observation_weights','value':int(((r.TreatPost==1)&(w < -1e-10)).sum())},
        {'metric':'negative_treated_post_weight_mass','value':float(w[(r.TreatPost==1)&(w < -1e-10)].sum())},
        {'metric':'max_cohort_weight_gap_vs_treated_firm_share','value':float((cg.conditional_treated_post_effect_weight-cg.treated_firm_share).abs().max())},
        {'metric':'max_cohort_weight_gap_vs_treated_post_obs_share','value':float((cg.conditional_treated_post_effect_weight-cg.treated_post_obs_share).abs().max())},
        {'metric':'max_cohort_event_treated_control_weight_imbalance','value':float(cancel.abs().max())},
        {'metric':'FE_projection_iterations','value':it},
        {'metric':'FE_projection_last_adjustment','value':err}])
    write(target,'estimand_target_summary.csv')
    write(pd.DataFrame(checks),'algebra_and_independent_validation.csv')
    assert all(q['passed'] for q in checks),[q for q in checks if not q['passed']]
    after=manifest(); before=pd.read_csv(OUT/'input_manifest_before.csv')
    after['unchanged']=after.sha256.to_numpy()==before.sha256.to_numpy()
    write(after,'input_integrity_after.csv')
    assert after.unchanged.all()
    metrics={'static_beta':float(st.coefficient),'static_SE':float(st.SE),'static_p':float(st.p),
             'pre_joint_p':float(jt.set_index('test').loc['pre_joint','p']),
             'post_joint_p':float(jt.set_index('test').loc['post_joint','p']),
             'static_restrictions_joint_p':float(jt.set_index('test').loc['static_restrictions_joint','p']),
             'pre_reference_component':float(dec.loc[dec.event_time.lt(0),'contribution_to_static_beta'].sum()),
             'post_reference_component':float(dec.loc[dec.event_time.ge(0),'contribution_to_static_beta'].sum()),
             'N':len(r),'clusters':r.firm_id.nunique(),'unique_firm_years':len(fy),
             'negative_post_weights':int(((r.TreatPost==1)&(w < -1e-10)).sum()),
             'post_pre_mean_correlation':mean_corr,
             'algebra_checks':len(checks),'source_hash_checks':len(INPUTS),
             'python_peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,
             'compile_seconds':time.monotonic()-start}
    (OUT/'audit_summary.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    write_report(st,ev,jt,contrasts,cg,dec,target,dup,bal,metrics)
    print(json.dumps(metrics,ensure_ascii=False,indent=2),flush=True)


def write_report(st,ev,jt,contrasts,cg,dec,target,dup,bal,m):
    report=f'''# 四批次G1估计目标、隐含权重及静态—动态差异审计

## Material Passport

- 日期：2026-11-03；Origin Skill：academic-research-suite / experiment-agent；Mode：validate。
- Verification Status：VERIFIED（原模型数值复现及独立线性代数核对，非因果识别认证）。
- 唯一主对象：最新核验名单原G1；本轮不是黄文式行业口径回归。
- 冻结：原SYN/三控制/样本/四批次/政策时点/FE/公司聚类/[-3,+2]/原-3基准。
- 只复现原静态、原动态各一次；辅助投影和线性组合仅用于代数审计。
- 不运行单批次、删批次、再加权或新的控制组合；无新分析DTA；不扫描年报。

## 一、结论先行

原静态系数{st.coefficient:.7f}，SE={st.SE:.7f}，p={st.p:.7f}，95%CI=[{st.CI_low:.7f},{st.CI_high:.7f}]；N={int(st.N):,}，公司簇={int(st.clusters):,}。完整复现原结果。

|比较对象|系数|SE|p|
|---|---:|---:|---:|
|原静态TreatPost|{st.coefficient:.7f}|{st.SE:.7f}|{st.p:.7f}|
|原动态：政策后三期均值相对-3|{contrasts.set_index('contrast').loc['post_mean_vs_m3','coefficient']:.7f}|{contrasts.set_index('contrast').loc['post_mean_vs_m3','SE']:.7f}|{contrasts.set_index('contrast').loc['post_mean_vs_m3','p']:.7f}|
|原动态：政策后均值减政策前均值|{contrasts.set_index('contrast').loc['post_mean_minus_pre_mean','coefficient']:.7f}|{contrasts.set_index('contrast').loc['post_mean_minus_pre_mean','SE']:.7f}|{contrasts.set_index('contrast').loc['post_mean_minus_pre_mean','p']:.7f}|

后两行只是同一个原动态模型的线性对比，不是新增回归。比较相同的“前后平均差异”时，原动态也给出接近原静态的边界5%结果，不能说动态模型与静态完全相反。

静态显著而原动态政策后不显著，不是两套样本造成，也不是事件项被FE吸收。
在完全相同样本上，静态系数精确等于原动态系数的一个确定性线性组合。
这同时说明：单个后期相对-3的检验、三个后期共同为0的检验，均不等于静态模型的单一前后差异检验。

下表把静态系数相对-3基准分成：政策前已出现的相对差异部分，以及政策后相对差异部分。
这是线性投影恒等式，不是政策前造成多少“偏误”的因果分解。

|分量|对静态系数的代数贡献|
|---|---:|
|政策前非基准期项|{m['pre_reference_component']:.7f}|
|政策后各期项|{m['post_reference_component']:.7f}|
|合计|{st.coefficient:.7f}|

## 二、现有模型究竟估计什么

现有OLS估计的是在原双交互固定效应和三控制条件下，TreatPost的共同线性投影系数。
静态模型限制处理组政策前三期相对差异不变、政策后三期的增量相同；动态模型放开这些限制。
若要将该系数解释为平均因果效应，还需清洁控制、无提前反应、适当的条件平行趋势及控制变量的因果角色等假设。
不因一个pre检验未拒绝就宣称全部成立。

它不是按四个cohort各25%平均，也不自动等于每个处理公司等权或每条处理后firm-year等权的ATT。
本报告仅展示这些目标与实际权重的差异，不在看过结果后选择一个最显著的目标。

## 三、批次贡献：保持原共同控制斜率的精确分解

令F为原FE，d_F=M_F D，原静态控制系数为γ，Y_adj=Y-Xγ。
每批次b_g=d_Fg'Y_adj_g/(d_Fg'd_Fg)，q_g=(d_Fg'd_Fg)/(d_F'd_F)。
由于FE嵌套在stack内，原静态系数精确等于Σq_g b_g。
这是原模型的一次代数分解，没有另跑四个单批次回归；b_g没有独立估计的SE/p，不能按它决定删除批次。

{table(cg,['cohort_report_year','N','treated_firms','control_firms','FE_design_variance_weight','adjusted_DID_holding_pooled_control_slopes','adjusted_DID_contribution'])}

各批次贡献以系数单位表示，可直接加总，不是显著性评分。
共同控制斜率、非平衡观察和不同处理/控制比例均影响这一分解。
另一个FWL残差分数分解也保存在同一CSV；它的批次分数贡献不是四个独立因果效应，不能与上述b_g混用。

## 四、隐含的处理后权重与目标对照

令Z=[F,X]，r_D=M_ZD，S=r_D'r_D，则每条Y观测的签名权重w_i=r_Di/S。
β=Σw_iY_i；处理后观测上的w_i在适当识别假设下对应效应载荷；控制组和政策前的负签名权重是正常差分，不能误称为负处理效应权重。
包含控制变量时，这些是条件线性投影载荷，不是无条件认证的因果ATT权重。

{table(cg,['cohort_report_year','treated_firm_share','treated_post_obs_share','equal_cohort_share','conditional_treated_post_effect_weight','FWL_rd_variance_share'])}

其中FWL_rd_variance_share是残差化处理项平方和份额，不是ATT权重，也不是有效样本量。
实际处理后负权重观测数={m['negative_post_weights']}；完整签名权重及cohort×event×role单元见cohort_event_role_weights.csv。
各cohort×event的处理与控制签名权重和的最大绝对值为{target.set_index('metric').loc['max_cohort_event_treated_control_weight_imbalance','value']:.3g}，即数值精度内抵消。
因此没有从这次审计发现“同一stack同一事件期处理/控制趋势的载荷不匹配”这一特定问题。
但不同事件期的批次组成、公司观察完整性及目标ATT权重仍未必一致。

重要限定：Wing等的基础stacked估计警告不能不加区分地直接套在本项目。
作者公开示例的FE写法是treat与event_time；本项目是firm×stack与cohort×year，两者不同。
是否需要估计目标校正，必须根据上面的实际权重，而不是因为没到1%就自动套Q权重或熵平衡。

## 五、为什么静态显著、动态不显著：精确重建

原动态始终省略-3；令E_k=treated×1(event=k)，D=E_0+E_1+E_2。
因此a_k=r_D'E_k/S，β_static=Σa_k β_dynamic,k，这是有限样本恒等式。

{table(dec)}

政策后a之和=1，包含基准期在内的政策前a之和=-1。
正的政策前动态系数乘上负的政策前对比权重，会使静态前后差异更负；这不是在本轮改变基准或改模型。
不过相对单期-3的政策前系数也含抽样误差，不能从其代数贡献直接判定它是提前效应、数据错误或确定的趋势偏误。

### 同一个动态模型中的固定线性对比

{table(contrasts,['contrast','coefficient','SE','p','CI_low','CI_high'])}

- post_mean_vs_m3：三个政策后期等权均值，相对单独-3期。
- pre_mean_vs_m3：三个政策前期的均值相对-3，省略期自身系数为0。
- post_mean_minus_pre_mean：政策后均值减政策前均值，不是另换一个事件基准重新估计。
- exact_static_projection_dynamic_V：按上表实际a_k加权，点估计与原静态相同，但SE来自未约束动态模型的残差与协方差。

单期SE和均值/前后差异SE不能直接类比：各动态系数共享基准、相互相关。
dynamic_covariance.csv、dynamic_coefficient_correlation.csv和dynamic_contrast_variance_components.csv给出完整核对。
本次前期均值与后期均值的估计相关为{m['post_pre_mean_correlation']:.6f}；二者相减时共享基准的不确定性部分抵消。
这使本次前后差异的SE小于“后期均值相对单独-3”的SE，不能把三个后期系数当独立估计简单除以平方根3。
静态模型只估计一个共同政策后效应；政策后联合检验同时限制三个系数为0，检验维数与参照均不同。
因此p值不同是可解释的，不构成代码错误，也不能仅用静态p值断言存在稳定的逐期政策效果。

### 原动态和联合诊断

{table(ev.reset_index(),['event_time','coefficient','SE','p','CI_low','CI_high'])}

{table(jt)}

static_restrictions_joint同时检验两个前期为0、三个后期相等四个约束。
未拒绝这些约束不证明它们正确，尤其短窗趋势检验可能检验力不足。
这里保留原事件基准、窗口和所有批次，没有用更换基准制造“通过”。

## 六、样本与重复入栈

{table(target)}

{table(dup)}

{table(bal)}

同一firm-year在不同stack重复是设计行为，不是重复键错误；同一firm×stack×year重复才是错误。
本轮未发现后者。静态和动态实际e(sample)完全一致，所有48个cohort×event×role单元都有观测。
重复firm-year的冻结SYN及三控制完全一致；标准误始终按原始firm_id聚类，没有把复制行当独立公司。
这只是确认聚类实现与原设计一致，不等于认证公司聚类已覆盖所有行业/政策层面的相关冲击；本轮未更改推断层级。
面板完整性仅描述，没有据此筛选平衡样本或删批次。

## 七、是否发现足以解释不显著的数据/代码错误

本轮检查的时间与TreatPost编码、FE分组、动态交互项、基准、样本及线性代数恒等式均通过。
没有发现静态显著来自样本错配、动态项被吸收、错误遗漏事件期，或重复键造成的错误。
不能据此认定全部公司适用名单和清洁控制已完全正确：本轮没有重查全量政策证据，也没有重新扫描年报。
早期行业分类的30条不完整证据及不同有效周集合问题仍见上一轮报告；本轮未修改。

目前可以确认的是：前后平均差异与相对最早单期的后期效应不是同一个比较；后期逐期估计不精确；
各批次并非等权且贡献存在差异。不能把这些直接简化成“某一个批次数据坏了”。
其中2017批次在固定共同控制斜率的分解中贡献为负，2016批次贡献为正；不能把此前某批次p大解释为该批次数据错误。
本轮没有发现必须实施新权重才能修复的确定性错误；不自动进行Q加权或重新熵平衡。

## 八、统计解释检查（11/11）

|检查|处理|
|---|---|
|组成/辛普森|保留四批次，报告全部权重与贡献，不按方向剔除|
|生态推断|限公司收益同步性，不直接推断投资者学习|
|选择偏误|冻结原样本；共同完整样本的可推广性仍有限|
|碰撞变量|三控制不变，未把其因果角色重新认证|
|基率|非分类任务，不适用|
|均值回归|不按极端Y或系数筛选样本|
|幸存者|仅描述完整性，不新增存续筛选|
|多重检验|全部本轮诊断报告；p为名义值，不称已校正全部历史探索|
|分析路径|计划先固定；只原模型复现与确定性分解，无规格搜索|
|相关与因果|线性投影权重及pre不拒绝不等于因果识别认证|
|反向因果|时序冻结，未重新证明政策适用外生性|

## 九、验证、资源与停止

原结果数值复现、独立Python FE投影/OLS及{m['algebra_checks']}项代数检查全部通过；
{m['source_hash_checks']}份输入运行前后SHA256一致。
Python本阶段峰值RSS约{m['python_peak_RSS_MiB']:.1f}MiB；Stata单核；未加载周收益或年报库。
数值跨引擎核验使用明示绝对容差，不声称输出文件逐字节相同。
本轮不认为“必须加权才能得到显著”；若后续改变目标平均效应，需要先明确研究对象，再另行授权固定估计方案。
审计完成后停止，不实施再加权、不换控制、不删批次、不跑机制或异质性。

## 方法来源

- [Wing、Freedman、Hollingsworth：Stacked Difference-in-Differences](https://www.nber.org/papers/w32054)。一般问题依据；不是本模型自动有偏的证明。
- [作者公开示例与代码](https://github.com/hollina/stacked-did-weights/blob/main/stacked-example-r-and-stata.qmd)。用于核对其FE与本项目的区别；未运行外部代码。
- [Roth：Pretest with Caution](https://pubs.aeaweb.org/doi/10.1257/aeri.20210236)。趋势检验低检验力及按检验筛选的风险。
'''
    (OUT/'G1_estimand_weight_audit_report.md').write_text(report,encoding='utf-8')
    (OUT/'READ_FIRST.md').write_text('# 四批次G1估计目标审计\n\n先阅读G1_estimand_weight_audit_report.md。\n\n本轮未更换控制、未删批次、未实施新权重。逐观测审计CSV含CSMAR衍生数据，请勿上传公开GitHub。\n',encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=['prepare','compile'])
    args=parser.parse_args()
    if args.stage=='prepare': prepare()
    else: compile_audit()
