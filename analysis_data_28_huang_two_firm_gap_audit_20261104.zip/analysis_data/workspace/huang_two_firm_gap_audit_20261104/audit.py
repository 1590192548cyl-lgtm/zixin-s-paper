"""Targeted missing-SYN input eligibility audit; no fitting or SYN reconstruction."""
from pathlib import Path
from collections import Counter,defaultdict
import pandas as pd,numpy as np,sqlite3,json,hashlib,time,resource
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);D=W/'download_2008';D.mkdir(exist_ok=True);BASE=W.parent;ROOT=Path('/Users/macpro/Desktop/毕业论文');R=BASE/'huang_week_calendar_repair_20261103';B=BASE/'huang_basic_reconstruction_20261103';start=time.time()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def js(x,n):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def save(x,n):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
manifest=json.loads((BASE/'huang_preX_DR_feasibility_20261104/outputs/protected_before.json').read_text());assert all(sha(x['path'])==x['sha256'] for x in manifest)
prior=BASE/'huang_preX_DR_feasibility_20261104/outputs';extra=[prior/'missing_baseline_keys_private.csv',prior/'preX_DR_feasibility_report.md'];source_reads=json.loads((R/'outputs/source_reads.json').read_text())
for x in source_reads:assert sha(x['file'])==x['sha256'];extra.append(Path(x['file']))
known={x['path'] for x in manifest};manifest += [dict(path=str(p),sha256=sha(p)) for p in extra if str(p) not in known];js(manifest,'protected_before.json')
ipo=pd.read_stata(ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta',convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo=ipo.set_index('firm_id');marketpool=set(ipo.index[ipo.Listexg.eq('1')&ipo.Stkcd.str.startswith('6')])
parts=[]
for ch in pd.read_stata(ROOT/'原始数据/行业分类_新下载.dta',columns=['Symbol','EndDate','ShortName','IndustryClassificationID','IndustryCode2','IndustryName2'],chunksize=40000,convert_categoricals=False):
 yy=ch.EndDate.str[:4].astype(int);q=ch[ch.IndustryClassificationID.eq('P0207')&yy.between(2012,2014)].copy();q['firm_id']=q.Symbol.astype(int);q['year']=q.EndDate.str[:4].astype(int);parts.append(q)
ind=pd.concat(parts,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any();ind['SYN_group']=np.where(ind.IndustryCode2.str.startswith('C'),ind.IndustryCode2,ind.IndustryCode2.str[0]);im=ind.set_index(['firm_id','year']).SYN_group.to_dict()
def group(f,y):return im.get((int(f),max(int(y),2012)))
targets=[600763,601515];peerdetail=[]
for f in targets:
 for y in range(2009,2015):
  sy=max(y,2012);g=group(f,y);peers=ind[ind.year.eq(sy)&ind.SYN_group.eq(g)&ind.firm_id.ne(f)&ind.Symbol.str.startswith('6')]
  for r in peers.itertuples():peerdetail.append(dict(target_firm=f,research_year=y,classification_year=sy,industry_group=g,potential_peer=int(r.firm_id),peer_name=r.ShortName,in_IPO_based_market_pool=int(r.firm_id) in marketpool))
save(peerdetail,'classification_peer_candidates_private.csv');inspect_ids=set(targets)|{r['potential_peer'] for r in peerdetail};print('TARGET AND PEERS',sorted(inspect_ids),flush=True)
db=sqlite3.connect('file:'+str(R/'cache/weekly_corrected.sqlite')+'?mode=ro',uri=True);w=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',db);prev=dict(zip(w.week.to_numpy()[1:],w.week.to_numpy()[:-1]));wy=w.set_index('week').year.to_dict();cal=pd.read_csv(R/'outputs/confirmed_week_calendar.csv').set_index('week');own=[];yearchecks=[]
cached=pd.read_csv(R/'outputs/corrected_SYN_private.csv');mapping=pd.read_csv(B/'outputs/policy_mapping_private.csv').set_index('firm_id')
for y in range(2009,2015):
 first=int(w.loc[w.year.eq(y),'week'].min());lagfirst=int(prev[first]);z=pd.read_sql_query('SELECT firm_id,week,year FROM weekly WHERE year=? OR week=?',db,params=[y,lagfirst]);z['group']=[group(f,yy) for f,yy in zip(z.firm_id,z.year)];groups={(int(k),g):set(v.firm_id) for (k,g),v in z.dropna(subset=['group']).groupby(['week','group'])};wk_members={int(k):set(g.firm_id) for k,g in z.groupby('week')}
 for f in targets:
  q=z[z.firm_id.eq(f)&z.year.eq(y)];eligible=ipo.at[f,'Listdt']<f'{y}-05-01';curmissing=lagmissing=complete=0
  for row in q.itertuples():
   k=int(row.week);pk=int(prev[k]);gp=group(f,y);lg=group(f,wy[pk]);pn=groups.get((k,gp),set())-{f};ln=groups.get((pk,lg),set())-{f};cm=len(pn)==0;lm=len(ln)==0;good=gp is not None and lg is not None and len(pn)>0 and len(ln)>0 and pk in wk_members;curmissing+=int(cm);lagmissing+=int(lm);complete+=int(good)
   own.append(dict(firm_id=f,research_year=y,week=k,source_industry_year=max(y,2012),industry_group=gp,other_SSE_peers_current=len(pn),lag_week=pk,lag_industry_group=lg,other_SSE_peers_lag=len(ln),input_eligible_without_fitting=good))
  stored=cached[cached.firm_id.eq(f)&cached.year.eq(y)]
  if not len(q):reason='no_valid_own_week_before_listing_or_source'
  elif curmissing==len(q):reason='no_other_available_SSE_industry_peer'
  elif complete<30:reason='fewer_than_30_complete_input_weeks'
  elif not len(stored):reason='needs_existing_rank_or_cache_diagnostics_no_refit_performed'
  else:reason='stored_SYN_present'
  yearchecks.append(dict(firm_id=f,research_year=y,IPODate=ipo.at[f,'Listdt'],eligible_company_mapping=bool(mapping.at[f,'eligible']),IPO_before_research_May=eligible,valid_own_cached_weeks=len(q),no_current_industry_peer_weeks=curmissing,no_lag_industry_peer_weeks=lagmissing,complete_input_weeks_by_presence=complete,meets_30week_input_condition=complete>=30,stored_SYN_rows=len(stored),stored_SYN_valid=int(stored.SYN.notna().sum()),primary_input_reason=reason))
db.close();save(own,'target_week_peer_availability_private.csv');save(yearchecks,'two_firm_year_gap_diagnosis.csv')
# Check raw exports for both targets and every identified missing peer, four fields only.
rawcounts=Counter();rawvalid=Counter();rawsource=Counter();rawkeys=[];scan=[]
for x in source_reads:
 total=hits=0
 for ch in pd.read_stata(x['file'],columns=['Stkcd','Trdwnt','Wretwd','Wsmvosd'],chunksize=40000,convert_categoricals=False):
  total+=len(ch);fid=ch.Stkcd.astype(int);sub=ch[fid.isin(inspect_ids)]
  for r in sub.itertuples():
   f=int(r.Stkcd);k=int(r.Trdwnt.replace('-',''));y=wy.get(k);rawcounts[f,'all']+=1;rawsource[f,Path(x['file']).name]+=1;valid=pd.notna(r.Wretwd) and pd.notna(r.Wsmvosd) and r.Wsmvosd>0
   if y is not None and 2009<=y<=2014:
    rawcounts[f,y]+=1;rawvalid[f,y]+=int(valid);rawkeys.append(dict(firm_id=f,research_year=y,week=k,return_nonmissing=pd.notna(r.Wretwd),cap_positive=pd.notna(r.Wsmvosd) and r.Wsmvosd>0))
   hits+=1
 scan.append(dict(file=x['file'],rows_streamed=total,target_or_peer_rows=hits));print('RAW CHECK',Path(x['file']).name,hits,flush=True)
save(rawkeys,'raw_target_peer_week_keys_private.csv');save(scan,'raw_read_audit.csv');rr=[]
for f in sorted(inspect_ids):
 for y in range(2009,2015):rr.append(dict(firm_id=f,research_year=y,raw_rows=rawcounts[f,y],raw_valid_return_cap_rows=rawvalid[f,y],all_period_raw_rows=rawcounts[f,'all'],in_IPO_based_market_pool=f in marketpool))
save(rr,'raw_target_peer_coverage.csv')
# Separate user-facing 2008 download package. No baseline or analysis data construction.
miss=pd.read_csv(prior/'missing_baseline_keys_private.csv');gap=miss[miss.anchor_year.eq(2008)&miss.downloadable_gap.eq(True)].copy();name14=ind[ind.year.eq(2014)].set_index('firm_id').ShortName
needs={v:set(g.firm_id) for v,g in gap.groupby('variable')};allids=sorted(set(gap.firm_id));assert len(needs['Cent'])==526 and needs['Cent']==needs['Top10'];assert len(needs['Dual'])==19
rows=[]
for f in allids:rows.append({'股票代码':f'{f:06d}','2014年源简称':name14.get(f,''),'原IPO首次上市日期':ipo.at[f,'Listdt'],'截止日期':'2008-12-31','需前十大股东排名持股':int(f in needs['Cent']),'需两职合一':int(f in needs['Dual']),'需董事人数':int(f in needs['Board']),'需年度审计机构':int(f in needs['Big4']),'历史代码或主体需先核验':int(f==601607)})
table=pd.DataFrame(rows);table.to_csv(D/'2008_下载公司总清单_526家.csv',index=False,encoding='utf-8-sig');table[table['需两职合一'].eq(1)].to_csv(D/'2008_两职合一缺口_19家.csv',index=False,encoding='utf-8-sig');table[table['需董事人数'].eq(1)|table['需年度审计机构'].eq(1)].to_csv(D/'2008_董事审计历史主体核验_1家.csv',index=False,encoding='utf-8-sig')
(D/'CSMAR_股票代码_526家.txt').write_text('\n'.join(f'{f:06d}' for f in allids)+'\n',encoding='utf-8');(D/'CSMAR_两职合一代码_19家.txt').write_text('\n'.join(f'{f:06d}' for f in sorted(needs['Dual']))+'\n',encoding='utf-8')
save([dict(data='前十大股东',date='2008-12-31',firms=526,fields='Stkcd Reptdt S0306a S0304a',scope='排名1—10及持股比例，含单位；Cent与Top10同一份下载'),dict(data='两职合一',date='2008-12-31',firms=19,fields='Symbol Enddate ConcurrentPosition',scope='真实年末兼任标记，不插补'),dict(data='董事人数',date='2008-12-31',firms=1,fields='Symbol Enddate StatisticalCaliber DirectorNumber',scope='601607先核对历史代码主体；年末在职口径1'),dict(data='年度审计机构',date='2008-12-31',firms=1,fields='Symbol EndDate Source AccountingFirmName TerritoryForeignIdentity',scope='601607先核对主体；境内年度定期审计；尽量带报告公告/签发日期')],'2008_download_fields.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in manifest];assert all(r['unchanged'] for r in after);js(after,'protected_after.json');js(dict(regressions=0,SYN_recomputed=False,R2_computed=False,returns_recomputed=False,industry_peer_presence_only=True,sample_changed=False,original_G1_unchanged=True,download_company_count=526,duality_count=19,board_count=1,auditor_count=1,protected_files=len(manifest),peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'execution_audit.json')
print(pd.DataFrame(yearchecks).to_string(index=False));print(pd.DataFrame(rr).to_string(index=False));print((O/'execution_audit.json').read_text())
