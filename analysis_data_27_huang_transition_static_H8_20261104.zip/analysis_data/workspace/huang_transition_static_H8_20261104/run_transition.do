version 18
clear all
set more off
set varabbrev off
set processors 1
capture log close _all
local out "/Users/macpro/Documents/New project/huang_transition_static_H8_20261104/outputs"
local old "/Users/macpro/Documents/New project/huang_week_calendar_repair_20261103/fixed_rerun/outputs"
log using "`out'/transition_H8.log", text replace
which reghdfe
tempname bh eh jh oh
tempfile static events joint oldevents
postfile `bh' str20 model str24 term long N clusters treated_firms double coefficient SE t p CI_low CI_high using `static', replace
postfile `eh' str20 model int event_time long N clusters double coefficient SE p CI_low CI_high using `events', replace
postfile `jh' str28 model str24 test double F df_num df_den p using `joint', replace
postfile `oh' str28 model int event_time long N clusters double coefficient SE p CI_low CI_high using `oldevents', replace
* Restore old estimates only; no old model re-estimation.
estimates use "`old'/H8_event.ster"
local oldrss=e(rss)
local oldN=e(N)
local oldclusters=e(N_clust)
forvalues k=-6/6 {
 if `k'!=-2 {
  local term "D_p`k'"
  if `k'<0 local term "D_m`=abs(`k')'"
  local expr "`term' - D_m2"
  if `k'==-1 local expr "-D_m2"
  quietly lincom `expr'
  post `oh' ("old_H8_rebased2013") (`k') (`oldN') (`oldclusters') (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
 }
}
test (D_m6=D_m2) (D_m5=D_m2) (D_m4=D_m2) (D_m3=D_m2)
post `jh' ("old_H8_rebased2013") ("pre_2009_2012") (r(F)) (r(df)) (r(df_r)) (r(p))
test (D_p0=D_m2) (D_p1=D_m2) (D_p2=D_m2) (D_p3=D_m2) (D_p4=D_m2) (D_p5=D_m2) (D_p6=D_m2)
post `jh' ("old_H8_rebased2013") ("post_2015_2021") (r(F)) (r(df)) (r(df_r)) (r(p))
postclose `oh'
use "`old'/fixed_analysis.dta", clear
isid firm_id year
assert TreatPost==Treat*Post
assert Post==(year>=2015)
assert event_time==year-2015
local x "Size_w Age_w Lev_w Cent_w Top10_w Dual Board_w Big4"
gen byte TreatTransition=Treat==1 & year==2014
assert inlist(TreatTransition,0,1)
assert TreatTransition==0 if Treat==0 | year!=2014
quietly count if old_H8_sample==1
assert r(N)==7609
display as result "AUTHORIZED_STATIC_FIT_START"
reghdfe SYN_w TreatPost TreatTransition `x' if old_H8_sample==1, absorb(firm_id year) vce(cluster firm_id)
gen byte static_sample=e(sample)
preserve
 keep if old_H8_sample==1 & static_sample!=1
 export delimited firm_id year using "`out'/automatic_exclusions_private.csv", replace
restore
assert static_sample==old_H8_sample
assert e(N)==7609
local n=e(N)
local nc=e(N_clust)
local df=e(df_r)
egen byte tag_t=tag(firm_id) if static_sample & Treat==1
quietly count if tag_t==1
local nt=r(N)
foreach term in TreatPost TreatTransition {
 local b=_b[`term']
 local s=_se[`term']
 local c=invttail(`df',.025)
 post `bh' ("H8_transition") ("`term'") (`n') (`nc') (`nt') (`b') (`s') (`b'/`s') (2*ttail(`df',abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
}
estimates save "`out'/H8_transition_static.ster", replace
display as result "AUTHORIZED_STATIC_FIT_COMPLETE"
local terms ""
local preterms ""
local postterms ""
forvalues k=-6/6 {
 if `k'!=-2 {
  local term "D_p`k'"
  if `k'<0 local term "D_m`=abs(`k')'"
  gen byte `term'=Treat==1 & event_time==`k'
  assert `term'==0 if Treat==0 | event_time==-2
  local terms "`terms' `term'"
  if `k'<=-3 local preterms "`preterms' `term'"
  if `k'>=0 local postterms "`postterms' `term'"
 }
}
assert D_m1==TreatTransition
display as result "AUTHORIZED_EVENT_FIT_START"
reghdfe SYN_w `terms' `x' if static_sample==1, absorb(firm_id year) vce(cluster firm_id)
gen byte event_sample=e(sample)
assert event_sample==static_sample
assert e(N)==7609
local c=invttail(e(df_r),.025)
forvalues k=-6/6 {
 if `k'!=-2 {
  local term "D_p`k'"
  if `k'<0 local term "D_m`=abs(`k')'"
  local b=_b[`term']
  local s=_se[`term']
  assert `s'>0 & !missing(`s')
  post `eh' ("H8_transition") (`k') (e(N)) (e(N_clust)) (`b') (`s') (2*ttail(e(df_r),abs(`b'/`s'))) (`b'-`c'*`s') (`b'+`c'*`s')
 }
}
test `preterms'
post `jh' ("H8_transition") ("pre_2009_2012") (r(F)) (r(df)) (r(df_r)) (r(p))
test `postterms'
post `jh' ("H8_transition") ("post_2015_2021") (r(F)) (r(df)) (r(df_r)) (r(p))
estimates save "`out'/H8_transition_event.ster", replace
tempname fitcheck
file open `fitcheck' using "`out'/event_fit_invariance.csv", write text replace
file write `fitcheck' "old_rss,new_rss,old_N,new_N" _n
file write `fitcheck' "`oldrss'," (e(rss)) ",`oldN'," (e(N)) _n
file close `fitcheck'
display as result "AUTHORIZED_EVENT_FIT_COMPLETE"
preserve
 keep firm_id year Treat Post TreatPost event_time TreatTransition old_H8_sample static_sample event_sample
 export delimited using "`out'/actual_sample_keys_private.csv", replace
restore
postclose `bh'
postclose `eh'
postclose `jh'
use `static', clear
export delimited using "`out'/static_results.csv", replace
use `events', clear
export delimited using "`out'/event_results.csv", replace
use `joint', clear
export delimited using "`out'/joint_tests.csv", replace
use `oldevents', clear
export delimited using "`out'/old_event_rebased2013.csv", replace
display as result "H8_TRANSITION_TWO_AUTHORIZED_FITS_COMPLETE"
log close
exit, clear
