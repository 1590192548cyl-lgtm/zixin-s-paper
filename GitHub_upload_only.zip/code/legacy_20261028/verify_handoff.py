"""Read-only, streaming integrity check. Never executes research code."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify(root: Path) -> dict:
    manifest = root / "MANIFEST.sha256"
    if not manifest.is_file():
        return {"root": str(root), "ok": False, "error": "MANIFEST_MISSING"}
    checked, failures = 0, []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        try:
            expected, relative = line.split("  ", 1)
            candidate = (root / relative).resolve()
            if len(expected) != 64 or not candidate.is_relative_to(root.resolve()):
                raise ValueError("unsafe or malformed manifest row")
            if not candidate.is_file():
                failures.append({"file": relative, "reason": "missing"})
            elif sha256(candidate) != expected:
                failures.append({"file": relative, "reason": "hash_mismatch"})
            checked += 1
        except ValueError:
            failures.append({"reason": "malformed_manifest_row"})
    return {"root": str(root), "checked": checked, "ok": not failures, "failures": failures}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-root", required=True, type=Path)
    parser.add_argument("--public-only", action="store_true")
    args = parser.parse_args()
    roots = [args.bundle_root / "github_repo"]
    if not args.public_only:
        roots.append(args.bundle_root / "private_data")
    reports = [verify(root) for root in roots]
    print(json.dumps({"mode": "READ_ONLY", "research_executed": False, "reports": reports},
                     ensure_ascii=False, indent=2))
    return 0 if all(report["ok"] for report in reports) else 1


if __name__ == "__main__":
    raise SystemExit(main())
