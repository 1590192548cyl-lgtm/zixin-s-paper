from pathlib import Path
from zipfile import ZipFile
import tempfile,shutil,sys
import pandas as pd
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parent))
# Import only the already audited reader utility, not the top-level audit.
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows,norm
W=Path(__file__).resolve().parent;O=W/'outputs';R=Path('/Users/macpro/Desktop/毕业论文');B=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs';P=W.parent/'huang_posthoc_window_2012_2018_20261103/outputs'
targets={}
for label,folder,flag,name in [('full',B,'old','fixed_analysis.dta'),('posthoc',P,'window','window_analysis.dta')]:
 d=pd.read_stata(folder/name,convert_categoricals=False)
 for m in ['H0','H8']:targets[label+'_'+m]=set(map(tuple,d.loc[d[f'{flag}_{m}_sample'].eq(1),['firm_id','year']].to_numpy()))
natures=defaultdict(set);criteria=defaultdict(set);headers={}
zpath=next((R/'控制变量/黄文复现补充').glob('上市公司控制人*.zip'))
with ZipFile(zpath) as z:
 with tempfile.TemporaryFile() as tmp:
  with z.open('HLD_Contrshr.xlsx') as f:shutil.copyfileobj(f,tmp,1048576)
  tmp.seek(0)
  for sh,rn,vs in xml_rows(tmp):
   if rn==1:headers[sh]=vs
   if rn<4:continue
   r={name:vs.get(c,'') for c,name in headers[sh].items()};date=r.get('Reptdt','')
   if not date.endswith('-12-31') or not 2009<=int(date[:4])<=2021:continue
   k=(int(r['Stkcd']),int(date[:4]));criteria[k].add(norm(r.get('S0701a','')));v=norm(r.get('S0702b',''))
   if v:natures[k].add(v)
rows=[];summary=[]
for label,keys in targets.items():
 missing=[k for k in keys if not natures[k]];nzero=0
 for f,y in sorted(missing):
  crit=criteria[f,y];zero=crit=={'0'};nzero+=zero
  rows.append(dict(population=label,firm_id=f,year=y,source_criteria=';'.join(sorted(crit)),only_no_controlling_shareholding_criterion0=zero,note='diagnostic, no SOE code assigned'))
 summary.append(dict(population=label,no_nonempty_nature=len(missing),only_criterion0=nzero,other_missing_nature=len(missing)-nzero))
pd.DataFrame(rows).to_csv(O/'SOE_no_nature_keys_private.csv',index=False,encoding='utf-8-sig');pd.DataFrame(summary).to_csv(O/'SOE_no_nature_interpretation.csv',index=False);print(pd.DataFrame(summary).to_string(index=False))
