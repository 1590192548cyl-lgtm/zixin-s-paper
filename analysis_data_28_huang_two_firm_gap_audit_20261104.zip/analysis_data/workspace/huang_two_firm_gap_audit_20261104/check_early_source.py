from pathlib import Path
from collections import Counter
import sys,json,hashlib
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103');from audit_sources import xml_rows
W=Path(__file__).resolve().parent;O=W/'outputs';p=Path('/Users/macpro/Desktop/毕业论文/控制变量/2007-2009周个股回报率/TRD_Week.xlsx')
def sha():
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
h=sha();heads={};allc=Counter();target=Counter();n=0
for sh,rn,v in xml_rows(p):
 if rn==1:heads[sh]=v
 if rn<4:continue
 r={name:v.get(k,'') for k,name in heads[sh].items()};code=r.get('Stkcd','');wk=r.get('Trdwnt','');n+=1
 if len(wk)>=4 and wk[:4].isdigit():
  y=int(wk[:4]);allc[y]+=1
  if code in ['600763','600836','601515']:target[code,y]+=1
assert sha()==h
z=dict(path=str(p),sha256=h,unchanged=True,headers=heads,data_rows=n,calendar_year_counts=dict(allc),target_calendar_year_counts=[dict(firm_id=f,calendar_year=y,raw_rows=c) for (f,y),c in sorted(target.items())],note='additional early Excel not used by current Huang weekly cache; calendar years not research SYN years')
(O/'additional_early_weekly_source.json').write_text(json.dumps(z,ensure_ascii=False,indent=2),encoding='utf-8');print(z)
