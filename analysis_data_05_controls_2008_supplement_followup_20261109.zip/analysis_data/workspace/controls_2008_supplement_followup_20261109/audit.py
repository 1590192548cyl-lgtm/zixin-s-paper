"""Audit only: no merged analysis data, recoding, SYN fitting, or regressions."""
import csv, hashlib, json, math, re, resource, sys
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows, norm

ROOT=Path('/Users/macpro/Desktop/2008年控制变量下载清单_20261104')
OUT=Path(__file__).resolve().parent
PRIOR=Path('/Users/macpro/Documents/New project/controls_2008_supplement_audit_20261109')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
def js(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def rows(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def csvout(name,rs):
    if not rs:return
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def validnum(v):
    try: return math.isfinite(float(v))
    except (TypeError,ValueError): return False

old={r['path']:r for r in rows(PRIOR/'file_inventory.csv')}
protected=json.loads((PRIOR/'protected_after.json').read_text())
protected_before=[dict(path=r['path'],sha256=sha(r['path'])) for r in protected]
js('protected_before.json',protected_before)
inventory=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    h=sha(p); prev=old.get(str(p)); s=p.stat()
    inventory.append(dict(path=str(p),filename=p.name,bytes=s.st_size,
        modified_local=datetime.fromtimestamp(s.st_mtime).isoformat(),sha256=h,
        compared_with_prior='new' if prev is None else ('unchanged' if h==prev['sha256'] else 'changed')))
newdata={}; details=[]
for name in ['CG_Ybasic.xlsx','TRD_Week.xlsx']:
    pp=list(ROOT.rglob(name)); assert len(pp)==1,(name,pp)
    p=pp[0]; headers={}; desc={}; units={}; first=[]; cols=defaultdict(set);counts=Counter();data=[]
    for sheet,rn,v in xml_rows(p):
        counts[sheet]+=1;cols[sheet].update(k for k,x in v.items() if x!='')
        if len(first)<5:first.append(dict(sheet=sheet,row=rn,cells=v))
        if rn==1:headers[sheet]=v
        elif rn==2:desc[sheet]=v
        elif rn==3:units[sheet]=v
        else:data.append({field:v.get(col,'') for col,field in headers[sheet].items()})
    descriptor=p.with_name(p.stem+'[DES][xlsx].txt')
    details.append(dict(path=str(p),actual_nonempty_rows=dict(counts),data_rows=len(data),
        actual_nonempty_columns={k:len(v) for k,v in cols.items()},headers=headers,
        descriptions=desc,units=units,first_five_rows=first,descriptor_text=descriptor.read_text()))
    newdata[name]=data

targets=rows(ROOT/'2008_两职合一缺口_19家.csv')
codes={r['股票代码'] for r in targets}; assert len(codes)==19
dual=defaultdict(list); dualyears=Counter(); dualallcats=Counter()
for r in newdata['CG_Ybasic.xlsx']:
    dualyears[r['Reptdt'][:4]]+=1;dualallcats[norm(r['Y1001b'])]+=1
    if r['Reptdt']=='2008-12-31':dual[norm(r['Stkcd']).zfill(6)].append(norm(r['Y1001b']))
dualrows=[]
for code in sorted(codes):
    vv=dual[code]; vvset=set(vv);valid=len(vvset)==1 and next(iter(vvset),'') in {'1','2'}
    dualrows.append(dict(firm_id=code,date='2008-12-31',rows=len(vv),raw_Y1001b=';'.join(vv),
        valid_nonconflicting=valid,duplicate_rows=len(vv)>1,deferred_by_user=code=='601607'))

weekly=newdata['TRD_Week.xlsx']; keyrows=defaultdict(list);yearrows=defaultdict(list);bad=[]
for i,r in enumerate(weekly,4):
    code=norm(r['Stkcd']).zfill(6);w=r['Trdwnt'];keyrows[(code,w)].append(r);yearrows[w[:4]].append(r)
    if code!='600836' or not re.fullmatch(r'20\d{2}-\d{2}',w):bad.append(dict(row=i,reason='unexpected_identifier_or_week_format',record=r))
unique_valid=set(); duplicates=[]
for (code,w),rr in keyrows.items():
    vset={(r['Wretwd'],r['Wsmvosd']) for r in rr}
    if len(rr)>1:duplicates.append(dict(firm_id=code,week=w,rows=len(rr),conflict=len(vset)>1))
    if len(vset)==1 and validnum(rr[0]['Wretwd']) and float(rr[0]['Wretwd'])>=-1 and validnum(rr[0]['Wsmvosd']) and float(rr[0]['Wsmvosd'])>0 and code=='600836':
        unique_valid.add(int(w.replace('-','')))
calendar=rows('/Users/macpro/Documents/New project/huang_week_calendar_repair_20261103/outputs/confirmed_week_calendar.csv')
available_market={int(r['week']) for r in calendar}
calmap={int(r['week']):r for r in calendar}
weekyear=[];gaps=[]
for year in range(2012,2015):
    rr=yearrows[str(year)]; wk={int(r['Trdwnt'].replace('-','')) for r in rr}; expected={w for w in available_market if w//100==year}
    missing=sorted(expected-wk);extra=sorted(wk-expected)
    weekyear.append(dict(calendar_year=year,source_rows=len(rr),unique_weeks=len(wk),
        valid_return_and_positive_cap_weeks=len(wk&unique_valid),
        return_missing=sum(not validnum(r['Wretwd']) for r in rr),
        cap_missing_or_nonpositive=sum(not validnum(r['Wsmvosd']) or float(r['Wsmvosd'])<=0 for r in rr),
        first_week=min(wk) if wk else '',last_week=max(wk) if wk else '',
        current_market_pool_week_keys=len(expected),missing_vs_current_market_week_keys=len(missing),
        extra_vs_current_market_week_keys=len(extra)))
    gaps.extend(dict(calendar_year=year,week=w,kind='missing_vs_current_market_calendar') for w in missing)
    gaps.extend(dict(calendar_year=year,week=w,kind='extra_vs_current_market_calendar') for w in extra)

targetweeks=rows('/Users/macpro/Documents/New project/huang_two_firm_gap_audit_20261104/outputs/target_week_peer_availability_private.csv')
inputcounts=[]
for y in [2012,2013]:
    rr=[r for r in targetweeks if r['firm_id']=='601515' and int(r['research_year'])==y]
    cur=sum(int(r['week']) in unique_valid for r in rr)
    lag=sum(int(r['lag_week']) in unique_valid for r in rr)
    both=sum(int(r['week']) in unique_valid and int(r['lag_week']) in unique_valid for r in rr)
    inputcounts.append(dict(target_firm='601515',peer_firm='600836',research_year=y,
        frozen_target_valid_week_keys=len(rr),new_peer_current_week_available=cur,
        new_peer_lag_week_available=lag,new_peer_both_available=both,
        note='Availability only; not industry returns, matrix rank, SYN, or final model feasibility'))

summary=dict(folder=str(ROOT),new_files=[r['path'] for r in inventory if r['compared_with_prior']=='new'],
    governance_rows=len(newdata['CG_Ybasic.xlsx']),governance_year_counts=dict(dualyears),governance_raw_categories=dict(dualallcats),
    dual_2008_valid_all19=sum(r['valid_nonconflicting'] for r in dualrows),
    dual_2008_valid_excluding_601607=sum(r['valid_nonconflicting'] for r in dualrows if not r['deferred_by_user']),
    dual_2008_missing_excluding_601607=[r['firm_id'] for r in dualrows if not r['deferred_by_user'] and not r['valid_nonconflicting']],
    governance_definition='Y1001b: 1=same person; 2=different persons. This is not the original 0/1 coding. No formal recode performed.',
    week_rows=len(weekly),weekly_firms=sorted({norm(r['Stkcd']).zfill(6) for r in weekly}),
    weekly_duplicates=duplicates,weekly_bad_identifiers=bad,
    return_min=min(float(r['Wretwd']) for r in weekly if validnum(r['Wretwd'])),
    return_max=max(float(r['Wretwd']) for r in weekly if validnum(r['Wretwd'])),
    cap_min_thousand_CNY=min(float(r['Wsmvosd']) for r in weekly if validnum(r['Wsmvosd'])),
    cap_max_thousand_CNY=max(float(r['Wsmvosd']) for r in weekly if validnum(r['Wsmvosd'])),
    weekly_year_coverage=weekyear,target_peer_input_availability=inputcounts,
    deferred_601607=True,no_merge=True,no_formal_variable_construction=True,no_SYN_recalculation=True,no_regressions=True)
csvout('file_inventory.csv',inventory);js('new_workbook_details.json',details)
csvout('duality_2008_19_audit.csv',dualrows);csvout('600836_weekly_year_coverage.csv',weekyear)
csvout('600836_week_key_gaps.csv',gaps);csvout('601515_peer_input_availability.csv',inputcounts)
js('audit_summary.json',summary)
after=[dict(path=r['path'],sha256=sha(r['path'])) for r in protected]
js('protected_after.json',after)
changed=[r['path'] for r,s in zip(protected_before,after) if r!=s]
inputchanged=[r['path'] for r in inventory if sha(r['path'])!=r['sha256']]
js('execution_audit.json',dict(protected_files=len(protected),protected_changes=changed,
    input_changes=inputchanged,peak_memory_MB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1048576,
    no_DTA_created=True,no_source_writes=True,no_merge=True,no_recalculation=True,no_regressions=True))
assert not changed and not inputchanged
print(json.dumps(summary,ensure_ascii=False,indent=2))
