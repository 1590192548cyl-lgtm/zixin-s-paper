from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent;O=W/'outputs'
P=Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')
audit=json.loads((O/'pre_regression_audit.json').read_text())
models=pd.read_csv(O/'static_common_comparison.csv')
events=pd.read_csv(O/'event_study_comparison.csv')
joint=pd.read_csv(O/'event_joint_tests.csv')
oldfull=pd.read_csv(P/'four_cohort_G1_latest_recheck_20261028/G1_static_rerun_results.csv')
oldfull=oldfull.loc[oldfull.model.eq('latest_G1')].iloc[0]
d=pd.read_stata(O/'analysis_granularity_compare.dta',convert_categoricals=False)
q=d.loc[d.common_sample.eq(1)]
assert len(q)==audit['common_G1_N']
checks=[]
for version in ['old','new']:
    s=pd.read_csv(O/f'{version}_static_sample.csv')
    e=pd.read_csv(O/f'{version}_event_sample.csv')
    assert s.static_es.eq(s.common_sample).all() and e.event_es.eq(e.common_sample).all()
    assert s.static_es.sum()==len(q) and e.event_es.sum()==len(q)
    sk=s.loc[s.static_es.eq(1),['firm_id','stack_id','annual_report_year']].reset_index(drop=True)
    ek=e.loc[e.event_es.eq(1),['firm_id','stack_id','annual_report_year']].reset_index(drop=True)
    assert sk.equals(ek)
    if version=='old':reference=sk
    else:assert reference.equals(sk)
    checks.append({'check':f'{version}_static_event_and_frozen_common_sample','violations':0,'N':len(q)})
pd.DataFrame(checks).to_csv(O/'estimation_sample_verification.csv',index=False,encoding='utf-8-sig')
weekly=q.loc[q.n_weeks_CSRC_FAMILY.ne(q.n_weeks_huang_grain),['firm_id','stack_id','syn_year','cohort_report_year','event_time','n_weeks_CSRC_FAMILY','n_weeks_huang_grain']]
weekly.to_csv(O/'weekly_observation_count_changes.csv',index=False,encoding='utf-8-sig')
types=q[['firm_id','syn_year']].drop_duplicates()
allcomparison=pd.concat([pd.DataFrame([{**oldfull.to_dict(),'model':'original_full_G1','role':'Archived original full sample'}]),models.assign(role='Fixed common sample comparison')],ignore_index=True)
allcomparison.to_csv(O/'original_full_vs_common_comparison.csv',index=False,encoding='utf-8-sig')
o=models.set_index('model').loc['old_common_G1'];n=models.set_index('model').loc['new_common_G1']
decomp=pd.DataFrame([
 {'component':'sample_and_common_case_only','coefficient_change':o.TreatPost-oldfull.TreatPost},
 {'component':'new_measurement_on_same_annual_rows','coefficient_change':n.TreatPost-o.TreatPost},
 {'component':'total_new_common_minus_original_full','coefficient_change':n.TreatPost-oldfull.TreatPost}])
decomp.to_csv(O/'coefficient_change_decomposition.csv',index=False,encoding='utf-8-sig')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
manifest=json.loads((O/'input_manifest_before.json').read_text())
for r in manifest:
    r['sha256_final']=sha(r['file']);r['unchanged_final']=r['sha256_final']==r['sha256']
assert all(r['unchanged_final'] for r in manifest)
(O/'input_integrity_final.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
traces=json.loads((W/'trace_30_evidence.json').read_text())
ev=traces['historical_classification_events']
evs=pd.DataFrame(ev)
if len(evs):evs.to_csv(O/'historical_M_direct_evidence.csv',index=False,encoding='utf-8-sig')
known=len({r['firm_id'] for r in ev if r['code']=='M' and r['date'][:4]<='2011'})
assert known==10
summary={**audit,'weekly_counts_changed_stack_rows':len(weekly),
         'weekly_counts_changed_unique_firm_years':len(weekly[['firm_id','syn_year']].drop_duplicates()),
         'actual_samples_identical':True,'same_four_cohorts':True,'confirmed_M_firms':known,'not_yet_confirmed_firms':30-known,
         'source_integrity_final':True,'new_static_p':float(n.p),
         'new_pre_joint_p':float(joint.loc[joint.model.eq('new_common_G1')&joint.test.eq('pre_joint'),'p'].iloc[0]),
         'new_post_joint_p':float(joint.loc[joint.model.eq('new_common_G1')&joint.test.eq('post_joint'),'p'].iloc[0])}
(O/'final_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
def row(r,label):return f'|{label}|{r.TreatPost:.7f}|{r.SE:.7f}|{r.p:.7f}|{int(r.N):,}|{int(r.clusters):,}|{int(r.treated_firms):,}|{int(r.cohorts)}|'
table='\n'.join([row(oldfull,'原完整G1（归档）'),row(o,'旧口径／共同样本'),row(n,'新行业层级／共同样本')])
e_lines=[]
for model,label in [('old_common_G1','旧'),('new_common_G1','新')]:
    for r in events.loc[events.model.eq(model)].sort_values('event_time').itertuples():
        e_lines.append(f'|{label}|{int(r.event_time):+d}|{r.coefficient:.7f}|{r.SE:.7f}|{r.p:.7f}|{r.CI_low:.7f}|{r.CI_high:.7f}|')
j_lines=[]
for r in joint.itertuples():
    j_lines.append(f'|{r.model}|{r.test}|{r.F:.7f}|{int(r.df_num)}|{int(r.df_den)}|{r.p:.7f}|')
text=f'''# 固定四批次G1：行业分组层级敏感性检验

## Material Passport

- 日期：2026-10-30；状态：旧SYN数值复现通过，固定共同样本两次静态与两次动态已实际执行。
- 用户确认范围：先追溯30条，再只改行业收益分组层级；未转为黄文2015年重点行业改革。
- 方法依据：黄炳艺等（2025）第三节的非制造业一级、制造业二级；本项目仍继承P0201/P0207年度标准，故不是统一2012版全期或黄文全文复刻。
- 原始数据及旧结果只读；输入{len(manifest)}份运行前后指纹相同；无全量年报扫描，没有新增控制／权重／政策批次。
- 本轮方案在新SYN及系数之前保存。历史探索和p值已知，不称整项研究事前注册，也未校正全部历史规格选择。

## 一、结果与判断

|模型|TreatPost|SE|p|N|公司簇|处理公司|批次|
|---|---:|---:|---:|---:|---:|---:|---:|
{table}

新口径95%CI=[{n.CI_low:.7f}, {n.CI_high:.7f}]。同一共同样本下系数变化{n.TreatPost-o.TreatPost:+.7f}，SE变化{n.SE-o.SE:+.7f}；达到名义5%，没有达到1%。静态更负不等于识别更可信。

新口径政策前联合p={summary['new_pre_joint_p']:.7f}，5%不拒绝、10%拒绝；-2期系数0.0869068、p=.0353038（名义5%）。它比旧共同样本的前趋势更可疑，不能笼统写“平行趋势通过”。单期名义显著并非逻辑上证明平行趋势必然失败，但与联合p接近阈值一起构成风险。

新口径0/+1/+2均为负、均不显著，后联合p={summary['new_post_joint_p']:.7f}。不能认为换行业口径恢复了持续政策效果，不能只因静态p更小就自动升为正式主模型。

## 二、30条来源核验：修正先前风险解释

30条都在2013批次event_time=-3、syn_year=2011。原表仅下载IndustryCode2/Name2，字面None不能直接解释为公司真实行业未知。

旧CSMAR行业变更表中10家有截至2011年的P0201=M、综合类记录，记录日期及名称已逐行保存。说明至少这10家缺二级码属于特殊层级问题，不能全部判为“伪行业”或错误公司。另20家在现有文件中缺少可确认同期一级来源；未用后来分类或公司主营业务猜测回填。

已只读查阅原下载表头、旧变更表、2007—2008补充表和现有年报索引。30份2011报告在历史索引中，但原TXT均已删除；本轮没有重新下载或扫描全部年报。没有把未找到证据当成不适用，也没有永久删除任何公司。

原None池是否混入多个真实行业尚未获得充分证据。本轮没有证明原G1不显著主要由行业编码错误造成。新口径对无法确认完整成员的None组不生成正常行业SYN；10家已知M也没有在成员集合不完整时单独凑出一个M收益组。这个保守的可用性限制不是宣告这些公司不合格。

## 三、行业对照与冻结事项

源表IndustryCode2为有效字母加数字的年度分类：制造业保留原二级，非制造业聚合到一级前缀；年度P0201/P0207不变。未改Treat、clean control、stack、cohort、政策时点、event_time、三控制、FE、聚类、事件窗或权重。

市场收益、收益池、流通市值权重、留一法、滞后与30周规则沿用原实现。缺码公司仍按旧规则留在原市场收益池，避免同时改变市场因子。只对可验证行业组计算新行业因子。

冻结控制Size_w_exact、MB_parent_w_exact、Lev_w_exact；FE=firm_stack_id/cohort_year_id；cluster=firm_id；动态省略-3，不是-1。无熵平衡。不把黄文11个重点行业重定义为本项目Treat。

新SYN使用原冻结边界[{audit['fixed_syn_cutoffs'][0]:.10f},{audit['fixed_syn_cutoffs'][1]:.10f}]，未重算任何分位点；共同样本新SYN低端截尾{audit['new_low_clips_common']}条、高端{audit['new_high_clips_common']}条。

## 四、样本与周收益覆盖

原G1的24,659条仍完整保存，且原结果保持不变。替代SYN因源分类未完整确认缺少30条；公司600661在2013 stack失去唯一政策前观测后，原+2期1条也按原“至少一前一后”条件退出共同对照。最终共同N={len(q):,}，共少31条；无按结果筛公司或删cohort。

实际两类静态和两类动态e(sample)完全相同，Stata没有额外删除singleton；48个cohort×事件期×处理身份单元均有支持。处理公司636、公司簇1770，四批次保留。原始文件没有删行或覆写，新增DTA保留原字段及common_sample标记。

**同年度观测不等于同有效周观测。** 共同样本中{len(weekly)}条stack观测、{summary['weekly_counts_changed_unique_firm_years']}个唯一公司年度的新旧有效周数不同：聚合使部分小行业获得有效同行周收益；早期缺码行业与2012切换边界也可能丢失一期滞后因子。因此本轮是预设的可验证分类层级敏感性检验，不应把全部变化解释成在完全同一周集合上的纯分组效应。完整周数变化另列，不再为追求显著性运行第三个口径。

旧完整→旧共同的系数变化{o.TreatPost-oldfull.TreatPost:+.7f}反映共同样本／可用性变化；旧共同→新共同的变化{n.TreatPost-o.TreatPost:+.7f}反映本轮测量口径变化。二者不能混称为单纯行业分类贡献。

## 五、SYN复现与资源

先按旧代码函数及同源周收益重建全部2010—2020窗口，{audit['old_syn_reproduction_N']:,}个公司年度键和有效周数与原表一致；SYN最大绝对差{audit['old_syn_max_abs_difference']:.3g}，小于1e-8；R²小于1e-10。通过后才运行新口径和固定回归。

共同样本新旧原始SYN相关{audit['corr_raw_common']:.6f}，缩尾SYN相关{audit['corr_winsor_common']:.6f}。均值、标准差和中位数见outcome_descriptives_common.csv，截尾数量见本报告第三节。平均SYN降低不是TreatPost更负的充分条件，更不是更多有效信息进入价格的机制证明。

周收益按75,000行提取、按年度处理；Python峰值RSS约{audit['peak_RSS_MiB']:.1f} MiB，Stata单核。缓存留在本会话workspace/cache供断点恢复，不复制整套原始收益到项目。没有外部上传。

## 六、完整动态结果（-3唯一基准）

|口径|事件期|系数|SE|p|CI下限|CI上限|
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(e_lines)}

|模型|联合检验|F|分子df|分母df|p|
|---|---|---:|---:|---:|---:|
{chr(10).join(j_lines)}

图使用实际估计及95%公司聚类区间，-3系数为0且不虚构基准CI。没有为图形改系数、置信区间或事件窗。

## 七、统计解释检查（11/11）

|事项|结论／范围|
|---|---|
|辛普森／组成|同一年度键对照，另披露31条及有效周变化；不按cohort方向筛选|
|生态推断|不从SYN推断个人投资者或披露机制|
|选择偏误|缺码／综合类可用性导致研究对象限制，不能代表所有原样本|
|碰撞变量|三控制冻结，未重新认证全部因果角色|
|基率|非分类任务，不适用|
|均值回归|不按SYN极端值筛选公司|
|幸存者|不新增ST、退市或存续筛选|
|多重检验|名义p，历史规格选择未校正；所有本轮结果均报告|
|分析路径|预设单一新口径，未见结果后改分类、阈值或基准|
|相关与因果|更小静态p不等于更可靠因果证据；前趋势已显露风险|
|反向因果|政策时序冻结，不宣称重新证明资格外生性|

## 八、停止与后续资料

本轮完成后停止，没有新控制、权重、机制、异质性或其他行业标准搜索。新口径不自动替代旧正式候选。

若需要原24,659条完整年度样本的严格分类比较，应补下载2009—2011年同标准年度行业分类的一级代码／名称及股票代码或机构ID，同时保留二级字段；不只下二级，不把2001版称作2012版回溯。若坚持统一2012版全时期，另需真正的历史回溯分类来源。

## 九、关键文件

- original_full_vs_common_comparison.csv、event_study_comparison.csv、event_joint_tests.csv。
- industry_granularity_event_plot.png、estimation_sample_verification.csv。
- common_sample_attrition.csv、weekly_observation_count_changes.csv、historical_M_direct_evidence.csv。
- analysis_granularity_compare.dta（新对照数据，旧字段原样保留）。
- old_syn_reproduction_check.csv、input_integrity_final.json、fixed_granularity_stata.log及code/。
'''
(O/'huang_granularity_fixed_report.md').write_text(text,encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
