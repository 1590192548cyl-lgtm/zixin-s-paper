import ast,gc,hashlib,json,math,resource,shutil,sqlite3,sys,tempfile,time
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd
sys.path.insert(0,'/Users/macpro/Documents/New project/huang_replication_data_audit_20261103')
from audit_sources import xml_rows,sha,norm
W=Path(__file__).resolve().parent;O=W/'outputs';C=W/'cache';O.mkdir(exist_ok=True);C.mkdir(exist_ok=True)
R=Path('/Users/macpro/Desktop/毕业论文');P=R/'堆叠DID重跑';RAW=R/'控制变量';OR=R/'原始数据';start=time.time()
def log(s):print(time.strftime('%H:%M:%S'),s,flush=True)
def save(d,n):d.to_csv(O/n,index=False,encoding='utf-8-sig')
def js(o,n):(O/n).write_text(json.dumps(o,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def records(path):
 h={}
 for sheet,rn,vs in xml_rows(path):
  if rn==1:h[sheet]=vs
  if rn>=4:yield {name:vs.get(col,'') for col,name in h[sheet].items()}
def fnum(x):
 try:v=float(x);return v if math.isfinite(v) else np.nan
 except:return np.nan
def fy(r,date='Enddate',stock='Symbol'):
 d=r.get(date,'');c=norm(r.get(stock,''))
 return (int(c),int(d[:4])) if c.isdigit() and d.endswith('-12-31') and 2008<=int(d[:4])<=2021 else None
g1=P/'four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta'
files=[g1,W/'PRE_ANALYSIS_PLAN.md',OR/'公司基本信息/IPO_Cobasic.dta',OR/'公司基本信息/EVA_Co.xlsx',OR/'行业分类_新下载.dta',P/'gao_full_controls/gao_controls_firm_year_2009_2025.dta',RAW/'董事人数/CG_ManagerShareSalary.xlsx',RAW/'机构投资者持股比例_两职合一_独立董事占比/BDT_ManaGovAbil.xlsx']+sorted((RAW/'黄文复现补充').glob('*.zip'))+sorted((OR/'周度数据重下').glob('*.dta'))
manifest=[dict(file=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in files];js(manifest,'input_manifest.json')
ipo=pd.read_stata(OR/'公司基本信息/IPO_Cobasic.dta',convert_categoricals=False);ipo['firm_id']=ipo.Stkcd.astype(int)
save(ipo[ipo.firm_id.duplicated(False)],'IPO_multiple_listing_records_private.csv')
# Earliest listing, not latest relisting; preserve the historical-record audit.
ipo=ipo.sort_values('Listdt').drop_duplicates('firm_id',keep='first')
ipo=ipo[ipo.Listexg.eq('1')&ipo.Stkcd.str.startswith('6')].set_index('firm_id');pool=set(ipo.index)
listing=ipo.Listdt.str[:4].astype(int); eligible=set(ipo.index[ipo.Listdt.lt('2015-01-01')]);flow=[dict(stage='IPO_pre2015_SSE_A',firms=len(eligible))]
delisted=set()
for r in records(OR/'公司基本信息/EVA_Co.xlsx'):
 d=r.get('DelistedDate','')
 if d and d<='2021-12-31':delisted.add(int(r['Symbol']))
eligible-=delisted;flow.append(dict(stage='exclude_delisted_by2021',firms=len(eligible)))
frames=[];st=set()
for ch in pd.read_stata(OR/'行业分类_新下载.dta',chunksize=40000,convert_categoricals=False):
 y=ch.EndDate.str[:4].astype(int);fid=ch.Symbol.astype(int)
 st.update(fid[y.between(2009,2021)&ch.ShortName.str.upper().str.match(r'^(?:\*?ST|S\*?ST|PT)',na=False)])
 q=ch.loc[ch.IndustryClassificationID.eq('P0207')&y.between(2012,2021),['Symbol','EndDate','IndustryCode2','IndustryName2']].copy();q['firm_id']=q.Symbol.astype(int);q['year']=q.EndDate.str[:4].astype(int);frames.append(q)
ind=pd.concat(frames,ignore_index=True);assert not ind.duplicated(['firm_id','year']).any();del frames
ind['group']=np.where(ind.IndustryCode2.str.startswith('C'),ind.IndustryCode2,ind.IndustryCode2.str[0]);assert ind.group.notna().all()
code14=ind[ind.year.eq(2014)].set_index('firm_id').IndustryCode2
eligible-=st;flow.append(dict(stage='exclude_observed_ST_PT_2009_2021',firms=len(eligible)))
eligible&=set(code14.index);eligible-=set(code14.index[code14.str.startswith('J')]);flow.append(dict(stage='require_2014_industry_exclude_J',firms=len(eligible)))
treated=(code14.isin(['K70','C26','C27','F52']+[f'C{x}' for x in range(34,41)])|code14.str[0].isin(list('GBJIAD'))).astype(int)
save(pd.DataFrame({'firm_id':code14.index,'industry2014':code14.values,'Treat':treated.values,'eligible':code14.index.isin(eligible).astype(int)}),'policy_mapping_private.csv');save(pd.DataFrame(flow),'firm_filter_flow.csv')
early=ind[ind.year.eq(2012)].copy();extra=[]
for year in [2008,2009,2010,2011]:z=early.copy();z['year']=year;extra.append(z)
im=pd.concat([ind]+extra).set_index(['firm_id','year']).group
db=sqlite3.connect(C/'weekly.sqlite');db.execute('PRAGMA cache_size=-12000');db.execute('PRAGMA temp_store=FILE')
if not (C/'weekly_complete.json').exists():
 db.execute('CREATE TABLE weekly(firm_id INTEGER,week INTEGER,year INTEGER,ret REAL,cap REAL,PRIMARY KEY(firm_id,week))');audit=[]
 for path in sorted((OR/'周度数据重下').glob('*.dta')):
  n=kept=0
  for ch in pd.read_stata(path,columns=['Stkcd','Trdwnt','Wsmvosd','Wretwd'],chunksize=40000,convert_categoricals=False):
   n+=len(ch);fid=ch.Stkcd.astype(int);wk=ch.Trdwnt.str.replace('-','',regex=False).astype(int)
   anchor=pd.to_datetime(ch.Trdwnt+'-1',format='%G-%V-%u',errors='coerce');yy=anchor.dt.year-(anchor.dt.month<5).astype(int)
   mask=fid.isin(pool)&yy.between(2008,2021)&ch.Wretwd.notna()&ch.Wsmvosd.gt(0)&anchor.notna()
   z=pd.DataFrame(dict(firm_id=fid[mask],week=wk[mask],year=yy[mask].astype(int),ret=ch.Wretwd[mask],cap=ch.Wsmvosd[mask]))
   db.executemany('INSERT INTO weekly VALUES(?,?,?,?,?)',z.itertuples(index=False,name=None));kept+=len(z)
  db.commit();audit.append(dict(file=str(path),read=n,kept=kept));log(f'weekly {path.name}: {kept}')
 db.execute('CREATE INDEX yr ON weekly(year)');db.commit();js(audit,'weekly_read_audit.json');js({'complete':True},'../cache/weekly_complete.json')
weeks=pd.read_sql_query('SELECT DISTINCT week,year FROM weekly ORDER BY week',db);wk=weeks.week.to_numpy();prev=pd.Series(np.r_[np.nan,wk[:-1]],index=wk);yr=weeks.set_index('week').year
for year in range(2009,2022):
 path=C/f'syn_{year}.csv'
 if path.exists():continue
 first=weeks.loc[weeks.year.eq(year),'week'].min();pw=prev.loc[first]
 d=pd.read_sql_query('SELECT * FROM weekly WHERE year=? OR week=? ORDER BY firm_id,week',db,params=[year,int(pw)])
 d['group']=pd.MultiIndex.from_frame(d[['firm_id','year']]).map(im);d['num']=d.ret*d.cap;d['prev_week']=d.week.map(prev)
 m=d.groupby('week').agg(num=('num','sum'),cap=('cap','sum'));d['market']=d.week.map(m.num/m.cap);d['market_lag']=d.prev_week.map(m.num/m.cap)
 it=d.dropna(subset=['group']).groupby(['week','group']).agg(num=('num','sum'),cap=('cap','sum'))
 idx=pd.MultiIndex.from_frame(d[['week','group']]);inum=idx.map(it.num).to_numpy(dtype=float);icap=idx.map(it.cap).to_numpy(dtype=float)
 d['industry']=np.where(icap>d.cap,(inum-d.num)/(icap-d.cap),np.nan)
 ly=d.prev_week.map(yr);keys=pd.MultiIndex.from_arrays([d.firm_id,ly]);lg=keys.map(im)
 lix=pd.MultiIndex.from_arrays([d.prev_week,lg]);lnum=lix.map(it.num).to_numpy(dtype=float);lcap=lix.map(it.cap).to_numpy(dtype=float)
 own=d.set_index(['firm_id','week']);oidx=pd.MultiIndex.from_arrays([d.firm_id,d.prev_week]);oc=oidx.map(own.cap).to_numpy(dtype=float);on=oidx.map(own.num).to_numpy(dtype=float);og=oidx.map(own.group)
 same=np.asarray(og==lg)&np.isfinite(oc);oc=np.where(same,oc,0);on=np.where(same,on,0)
 d['industry_lag']=np.where(lcap>oc,(lnum-on)/(lcap-oc),np.nan)
 rows=[]
 for fid,g in d.loc[d.year.eq(year)].dropna(subset=['ret','market','market_lag','industry','industry_lag']).groupby('firm_id'):
  n=len(g)
  if n<30:continue
  y=g.ret.to_numpy();x=np.column_stack([np.ones(n),g[['market','market_lag','industry','industry_lag']].to_numpy()]);b,_,rank,_=np.linalg.lstsq(x,y,rcond=None);ss=((y-y.mean())**2).sum();r2=1-((y-x@b)**2).sum()/ss if ss>0 else np.nan
  if rank==5 and 0<r2<1:rows.append(dict(firm_id=int(fid),year=year,SYN=float(np.log(r2/(1-r2))),R2=r2,n_weeks=n))
 pd.DataFrame(rows).to_csv(path,index=False);log(f'SYN {year}: {len(rows)} firms');del d;gc.collect()
db.close();syn=pd.concat([pd.read_csv(C/f'syn_{year}.csv') for year in range(2009,2022)],ignore_index=True);save(syn,'syn_all_SSE_private.csv')
base=syn[syn.firm_id.isin(eligible)].copy();base=base[base.firm_id.map(ipo.Listdt).lt(base.year.astype(str)+'-05-01')];base['Treat']=base.firm_id.map(treated);base['Post']=(base.year>=2015).astype(int);base['TreatPost']=base.Treat*base.Post;base['event_time']=base.year-2015
conn=sqlite3.connect('file:/Users/macpro/Documents/New project/gao_full_controls_work/gao_controls_staging.sqlite?mode=ro',uri=True)
comp=pd.read_sql_query("SELECT variable,firm_id,year,value FROM num_values WHERE variable IN ('total_assets','total_liabilities') AND year BETWEEN 2008 AND 2021 AND conflict=0",conn);conn.close();comp['firm_id']=comp.firm_id.astype(int);comp=comp.pivot(index=['firm_id','year'],columns='variable',values='value');idx=pd.MultiIndex.from_frame(base[['firm_id','year']]);ixlag=pd.MultiIndex.from_arrays([base.firm_id,base.year-1]);assets=idx.map(comp.total_assets).to_numpy(dtype=float);lagassets=ixlag.map(comp.total_assets).to_numpy(dtype=float)
base['Size']=np.log(np.where(lagassets>0,lagassets,np.nan));base['Lev']=idx.map(comp.total_liabilities).to_numpy(dtype=float)/np.where(assets>0,assets,np.nan);base['Age']=np.log(base.year-base.firm_id.map(listing)+1)
for var,path,field,extra_filter in [('Dual',RAW/'机构投资者持股比例_两职合一_独立董事占比/BDT_ManaGovAbil.xlsx','ConcurrentPosition',None),('Board',RAW/'董事人数/CG_ManagerShareSalary.xlsx','DirectorNumber',('StatisticalCaliber','1'))]:
 vals={}
 for r in records(path):
  k=fy(r)
  if k and (extra_filter is None or norm(r.get(extra_filter[0],''))==extra_filter[1]):
   assert k not in vals;vals[k]=fnum(r.get(field,''))
 v=idx.map(pd.Series(vals)).to_numpy(dtype=float);base[var]=np.where(np.isin(v,[0,1]),v,np.nan) if var=='Dual' else np.log(np.where(v>0,v,np.nan))
big=pd.read_stata(P/'gao_full_controls/gao_controls_firm_year_2009_2025.dta',columns=['firm_id','year','Big4'],convert_categoricals=False);big['firm_id']=big.firm_id.astype(int);base['Big4']=idx.map(big.set_index(['firm_id','year']).Big4)
holders={}
zp=next((RAW/'黄文复现补充').glob('十大*.zip'))
with ZipFile(zp) as z:
 for name in sorted(z.namelist()):
  if not name.endswith('.xlsx'):continue
  with tempfile.TemporaryFile(suffix='.xlsx') as tmp:
   with z.open(name) as stream:shutil.copyfileobj(stream,tmp,1024*1024)
   tmp.seek(0)
   for r in records(tmp):
    k=fy(r,'Reptdt','Stkcd');rank=fnum(r.get('S0306a',''));v=fnum(r.get('S0304a',''))
    if k and k[0] in eligible and np.isfinite(rank) and int(rank)==rank and 1<=rank<=10:
     a=holders.setdefault(k,np.full(10,np.nan));assert np.isnan(a[int(rank)-1]);a[int(rank)-1]=v if 0<=v<=100 else np.nan
  log('shareholder fragment '+name)
cent={};top={}
for k,a in holders.items():
 cent[k]=a[1:5].sum()/a[0] if np.isfinite(a[:5]).all() and a[0]>0 else np.nan
 top[k]=a.sum()/100 if np.isfinite(a).all() else np.nan
base['Cent']=idx.map(pd.Series(cent));base['Top10']=idx.map(pd.Series(top));controls=['Size','Age','Lev','Cent','Top10','Dual','Board','Big4'];base['sample8']=base[controls].notna().all(axis=1).astype(int)
cuts=[]
for v in ['SYN']+controls:
 if v in ['Dual','Big4']:continue
 a=base[v] if v=='SYN' else base.loc[base.sample8.eq(1),v];lo,hi=a.quantile([.01,.99]);cuts.append(dict(variable=v,p1=lo,p99=hi));base[v+'_w']=base[v].clip(lo,hi)
save(pd.DataFrame(cuts),'frozen_winsor_cutoffs.csv');save(base.groupby(['year','Treat']).agg(N=('firm_id','size'),complete8=('sample8','sum')).reset_index(),'annual_sample_support.csv')
assert not base.duplicated(['firm_id','year']).any();base.to_stata(O/'analysis.dta',write_index=False,version=118);save(base,'analysis_private.csv')
after=[dict(**a,unchanged=sha(Path(a['file']))==a['sha256']) for a in manifest];assert all(x['unchanged'] for x in after);js(after,'input_integrity_after_build.json');js(dict(raw_SYN_rows=len(syn),eligible_firms=len(eligible),analysis_rows=len(base),complete8=int(base.sample8.sum()),peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'build_metrics.json');log('BUILD COMPLETE')
