# 四批次G1固定复核完成

先看final_fixed_G1_report.md。

静态和动态各执行一次；旧新全部b/V矩阵完全一致，样本不变。静态名义5%，未到1%。

input_snapshot为原分析数据逐字节快照；audit_evidence为完整原核验清单。含CSMAR衍生数据，不应公开上传GitHub。

本轮完成后停止，未搜索其他规格。
