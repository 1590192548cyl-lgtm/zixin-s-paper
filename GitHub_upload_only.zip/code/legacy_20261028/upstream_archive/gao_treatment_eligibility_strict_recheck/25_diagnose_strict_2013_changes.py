#!/usr/bin/env python3
"""Describe how the frozen 2013 eligibility correction changed the stack.

No regression is estimated here.  The outputs distinguish treatment-status
changes from row-composition changes and describe the added firms' raw SYN
paths.  They are diagnostic only and do not alter the inclusion decisions.
"""

from pathlib import Path

import pandas as pd


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work/outputs")
OLD = ROOT / "official_table3_rebuild/official_table3_stack_analysis.dta"
NEW_DIR = ROOT / "official_table3_business_manual_recheck"
NEW = NEW_DIR / "official_table3_stack_analysis.dta"
DECISIONS = NEW_DIR / "strict_2013_manual_eligibility_decisions.csv"


def read_stack(path: Path) -> pd.DataFrame:
    d = pd.read_stata(path, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.firm_id, errors="raise").astype(int)
    return d


def main() -> None:
    old = read_stack(OLD)
    new = read_stack(NEW)
    key = ["firm_id", "stack_id", "annual_report_year"]

    old_keys = old[key + ["treated_in_stack", "sample_g1"]].rename(
        columns={"treated_in_stack": "old_treated", "sample_g1": "old_sample_g1"}
    )
    new_keys = new[key + ["treated_in_stack", "sample_g1"]].rename(
        columns={"treated_in_stack": "new_treated", "sample_g1": "new_sample_g1"}
    )
    matched = old_keys.merge(new_keys, on=key, how="outer", indicator=True)
    matched["treatment_changed"] = (
        matched.old_treated.notna()
        & matched.new_treated.notna()
        & matched.old_treated.ne(matched.new_treated)
    )
    sample_change = pd.DataFrame(
        [
            {
                "old_rows": len(old),
                "new_rows": len(new),
                "common_rows": int(matched._merge.eq("both").sum()),
                "old_only_rows": int(matched._merge.eq("left_only").sum()),
                "new_only_rows": int(matched._merge.eq("right_only").sum()),
                "common_rows_with_treatment_changed": int(matched.treatment_changed.sum()),
                "old_g1_rows": int(old.sample_g1.sum()),
                "new_g1_rows": int(new.sample_g1.sum()),
            }
        ]
    )
    sample_change.to_csv(NEW_DIR / "strict_2013_stack_change_audit.csv", index=False)

    decisions = pd.read_csv(DECISIONS, dtype={"firm_id": "Int64"}, low_memory=False)
    additions = decisions.loc[decisions.strict_include.eq(1), ["firm_id", "company_name", "iidg_id"]].copy()
    o13 = old.loc[old.cohort_report_year.eq(2013)].copy()
    n13 = new.loc[new.cohort_report_year.eq(2013)].copy()

    rows = []
    for r in additions.itertuples(index=False):
        oq = o13.loc[o13.firm_id.eq(int(r.firm_id))]
        nq = n13.loc[n13.firm_id.eq(int(r.firm_id))]
        pre = nq.loc[nq.Post.eq(0), "SYN_CSRC_FAMILY_w_exact"]
        post = nq.loc[nq.Post.eq(1), "SYN_CSRC_FAMILY_w_exact"]
        rows.append(
            {
                "firm_id": int(r.firm_id),
                "company_name": r.company_name,
                "iidg_id": r.iidg_id,
                "old_stack_rows": len(oq),
                "old_treated": int(oq.treated_in_stack.max()) if len(oq) else None,
                "new_stack_rows": len(nq),
                "new_treated": int(nq.treated_in_stack.max()) if len(nq) else None,
                "new_g1_rows": int(nq.sample_g1.sum()) if len(nq) else 0,
                "pre_syn_mean": pre.mean(),
                "post_syn_mean": post.mean(),
                "raw_post_minus_pre": post.mean() - pre.mean(),
            }
        )
    firm_audit = pd.DataFrame(rows).sort_values(["iidg_id", "firm_id"])
    firm_audit.to_csv(NEW_DIR / "strict_2013_added_firm_diagnostics.csv", index=False)

    old_treated_2013 = set(o13.loc[o13.treated_in_stack.eq(1), "firm_id"].unique())
    n13["treated_group"] = "control"
    n13.loc[n13.treated_in_stack.eq(1), "treated_group"] = "existing_treated"
    n13.loc[
        n13.treated_in_stack.eq(1) & ~n13.firm_id.isin(old_treated_2013),
        "treated_group",
    ] = "newly_added_treated"
    path = (
        n13.groupby(["treated_group", "event_time"], dropna=False)
        .agg(
            observations=("SYN_CSRC_FAMILY_w_exact", "count"),
            firms=("firm_id", "nunique"),
            mean_syn=("SYN_CSRC_FAMILY_w_exact", "mean"),
            g1_observations=("sample_g1", "sum"),
        )
        .reset_index()
    )
    path.to_csv(NEW_DIR / "strict_2013_added_group_syn_path.csv", index=False)

    print(sample_change.to_string(index=False))
    print("\nAdded-firm audit")
    print(firm_audit.to_string(index=False))
    print("\nRaw SYN paths")
    print(path.to_string(index=False))


if __name__ == "__main__":
    main()
