#!/usr/bin/env python3
"""Build a treatment-corrected stack from a frozen, evidence-only 2013 audit.

The inclusion rule was fixed before any regression was run: an addition needs
issuer/subsidiary-specific operating disclosure matching the 2013 IIDG, or a
previously adjudicated 2013 main-business description.  Generic accounting
text, industry discussion, inputs, equipment, trading, parent operations,
planned acquisitions and inactive/exited operations are not sufficient.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
BASE_SCRIPT = ROOT / "15_build_official_table3_stack.py"
SOURCE_AUDIT = (
    ROOT
    / "outputs/official_table3_rebuild/treatment_eligibility_audit/"
    "targeted_2013_cninfo_rule_evidence.csv"
)
SOURCE_QUEUE = (
    ROOT
    / "outputs/official_table3_rebuild/treatment_eligibility_audit/"
    "archived_2013_new_strong_business_review_queue.csv"
)
OUT = ROOT / "outputs/official_table3_business_manual_recheck"
OUT.mkdir(parents=True, exist_ok=True)

# Frozen before outcome estimation.  Keys are (firm_id, IIDG).
INCLUDE = {
    # Real-estate project/operating disclosures or adjudicated 2013 business.
    (600068, "SSE-02"),
    (600153, "SSE-02"),
    (600168, "SSE-02"),
    (600170, "SSE-02"),
    (600177, "SSE-02"),
    (600193, "SSE-02"),
    (600238, "SSE-02"),
    (600241, "SSE-02"),
    (600260, "SSE-02"),
    (600502, "SSE-02"),
    (600730, "SSE-02"),
    (600734, "SSE-02"),
    (600755, "SSE-02"),
    (600836, "SSE-02"),
    (600846, "SSE-02"),
    (601186, "SSE-02"),
    (601618, "SSE-02"),
    # Own/subsidiary coal mines and mine-specific operations.
    (600367, "SSE-03"),
    (600381, "SSE-03"),
    (600803, "SSE-03"),
    (600997, "SSE-03"),
    (601991, "SSE-03"),
    # Own/controlled oil-gas exploration and production assets.
    (600175, "SSE-08"),
    (600256, "SSE-08"),
}


def load_base():
    spec = importlib.util.spec_from_file_location("official_table3_base", BASE_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def make_decisions() -> pd.DataFrame:
    queue = pd.read_csv(SOURCE_QUEUE, dtype={"firm_id": "Int64"}, low_memory=False)
    evidence = pd.read_csv(SOURCE_AUDIT, dtype={"firm_id": "Int64"}, low_memory=False)
    cols = [
        "firm_id", "iidg_id", "explicit_rule_hit", "policy_specific_hit",
        "policy_specific_context", "business_context", "negative_or_exit_context",
        "announcement_title", "report_url", "temporary_pdf_deleted",
    ]
    decisions = queue.merge(evidence[cols], on=["firm_id", "iidg_id"], how="left", validate="one_to_one")
    decisions["strict_include"] = [
        int((int(fid), iidg) in INCLUDE) for fid, iidg in zip(decisions.firm_id, decisions.iidg_id)
    ]
    decisions["decision_rule"] = np.where(
        decisions.strict_include.eq(1),
        "issuer_or_subsidiary_specific_current_IIDG_operations",
        "not_sufficient_for_strict_automatic_addition",
    )
    decisions["decision_blind_to_regression_outcome"] = 1
    decisions["treatment_modified_before_this_file"] = 0
    decisions.sort_values(["iidg_id", "firm_id"], inplace=True)
    decisions.to_csv(OUT / "strict_2013_manual_eligibility_decisions.csv", index=False)
    return decisions


def main() -> None:
    base = load_base()
    decisions = make_decisions()
    included = decisions.loc[decisions.strict_include.eq(1)].copy()

    base.OUT = OUT
    original_builder = base.build_candidate_mapping

    def augmented_builder(master: pd.DataFrame):
        candidates, policy = original_builder(master)
        additions = included.merge(
            master,
            on="firm_id",
            how="inner",
            validate="many_to_one",
        )
        additions["cohort_year"] = 2013
        additions.drop(columns=["iidg_name_official"], errors="ignore", inplace=True)
        additions = additions.merge(
            policy[["cohort_year", "iidg_id", "iidg_name_official"]],
            on=["cohort_year", "iidg_id"],
            how="inner",
            validate="many_to_one",
        )
        additions["candidate_source"] = "manual_2013_strict_annual_report_evidence"
        additions["evidence_year"] = 2013
        additions["evidence_status"] = "strict_current_operating_scope_confirmed"
        additions["industry_code_at_adoption"] = ""
        additions["industry_name_at_adoption"] = ""
        keep = [
            "firm_id", "StkShortName", "Conme", "Board", "exchange",
            "listing_date", "delisted_date", "cohort_year", "iidg_id",
            "iidg_name_official", "candidate_source", "evidence_year",
            "evidence_status", "industry_code_at_adoption",
            "industry_name_at_adoption",
        ]
        candidates = pd.concat([candidates[keep], additions[keep]], ignore_index=True)
        candidates.drop_duplicates(["firm_id", "cohort_year", "iidg_id"], keep="last", inplace=True)
        candidates["source_priority"] = candidates.candidate_source.map(
            {
                "direct_P0207_adoption_year": 0,
                "manual_2013_strict_annual_report_evidence": 1,
                "confirmed_business_mapping_by_adoption_year": 2,
            }
        ).fillna(3)
        candidates["evidence_priority"] = np.where(
            candidates.evidence_status.eq("strict_current_operating_scope_confirmed"), 0, 1
        )
        candidates.sort_values(
            ["firm_id", "cohort_year", "source_priority", "evidence_priority", "iidg_id"],
            inplace=True,
        )
        candidates["primary_policy"] = (
            ~candidates.duplicated(["firm_id", "cohort_year"], keep="first")
        ).astype(np.int8)
        candidates.to_csv(OUT / "official_table3_candidate_mapping.csv", index=False)
        return candidates, policy

    base.build_candidate_mapping = augmented_builder
    base.main()


if __name__ == "__main__":
    main()
