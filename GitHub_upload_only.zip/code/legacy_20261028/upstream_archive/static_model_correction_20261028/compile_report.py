from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

WORK = Path('/Users/macpro/Documents/New project/static_model_correction_20261028_work')
O = WORK/'outputs'
P = Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑')


def read(name, **kwargs): return pd.read_csv(O/name, **kwargs)
def save(d, name): d.to_csv(O/name, index=False, encoding='utf-8-sig')
def sha(f):
    h=hashlib.sha256()
    with Path(f).open('rb') as s:
        for b in iter(lambda:s.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def md(d, fs=None):
    fs=fs or {}
    rows=['|'+'|'.join(str(c) for c in d.columns)+'|','|'+'|'.join(['---']*len(d.columns))+'|']
    for _,r in d.iterrows():
        rows.append('|'+'|'.join(fs[c](r[c]) if c in fs else str(r[c]) for c in d.columns)+'|')
    return '\n'.join(rows)


summary=json.loads((O/'audit_summary.json').read_text())
models=read('fixed_static_model_results.csv')
events=read('fixed_W2_event_results.csv')
joint=read('fixed_W2_joint_tests.csv')
sa=read('sa_full_event_corrected_results.csv')
sa_joint=read('sa_full_path_joint_tests.csv')
for log,marker in [('static_correction_stata.log','ALL_FIXED_CORRECTION_MODELS_COMPLETE'),('sa_additional_joint_checks.log','SA_JOINT_CHECKS_COMPLETE_NO_REGRESSIONS_RERUN')]:
    content=(O/log).read_text()
    assert marker in content
    assert not any(x.startswith('r(') for x in content.splitlines()), log

original=pd.read_csv(P/'pretrend_balance_weighting/weighted_vs_unweighted.csv')
repro=[]
for model in ['W2','UW2']:
    old=original.loc[original.model.eq(model)].iloc[0]
    new=models.loc[models.model.eq('original_'+model)].iloc[0]
    for v,w in [('TreatPost','coefficient'),('SE','SE'),('p','p'),('N','N'),('clusters','clusters'),('treated_firms','treated_firms'),('cohorts','cohorts')]:
        diff=float(new[w])-float(old[v])
        repro.append({'model':model,'metric':v,'archived':old[v],'reproduced':new[w],'difference':diff,'pass':abs(diff)<1e-8})
        assert abs(diff)<1e-8, (model,v,diff)
old_events=pd.read_csv(P/'pretrend_balance_weighting/weighted_event_study.csv')
for _,r in events.loc[events.model.eq('original_W2')].iterrows():
    old=old_events.loc[old_events.model.eq('ES_W2')&old_events.statistic.eq('coefficient')&old_events.event_time.eq(r.event_time)].iloc[0]
    for v in ['coefficient','SE','p']:
        diff=float(r[v])-float(old[v])
        assert abs(diff)<1e-8
        repro.append({'model':f'ES_W2_{int(r.event_time)}','metric':v,'archived':old[v],'reproduced':r[v],'difference':diff,'pass':True})
for _,r in joint.loc[joint.model.eq('original_W2')].iterrows():
    old=old_events.loc[old_events.model.eq('ES_W2')&old_events.statistic.eq(r.test)].iloc[0]
    for v in ['F','p']:
        diff=float(r[v])-float(old[v])
        tolerance=2e-7 if v=='F' else 1e-8
        assert abs(diff)<tolerance
        repro.append({'model':'ES_W2_'+r.test,'metric':v,'archived':old[v],'reproduced':r[v],'difference':diff,'tolerance':tolerance,'pass':True})
for r in repro:
    r.setdefault('tolerance',1e-8)
save(pd.DataFrame(repro),'original_reproduction_check.csv')

models['control_timing']='syn_year-1'
models['controls']='Size_w Lev_w MB_w Age_w Turnover_w Stdret_w ROA_w Growth_w CFO_w Loss Tophold_w Instihold_w'
models['FE']='firm_stack_id + cohort_year_id'
models['cluster']='firm_cluster_id (one-to-one original firm_id)'
save(models,'static_original_vs_corrected.csv')
deltas=[]
for m in ['W2','UW2']:
    old=models.loc[models.model.eq('original_'+m)].iloc[0]
    new=models.loc[models.model.eq('corrected_'+m)].iloc[0]
    row={'model':m}
    for c in ['N','clusters','treated_firms','control_firms','cohorts','coefficient','SE','p']:
        row['delta_'+c]=new[c]-old[c]
    deltas.append(row)
save(pd.DataFrame(deltas),'static_changes.csv')

ex=read('excluded_observation_list.csv',dtype={'firm_id':str})
fg=read('firm_stack_policy_audit.csv',dtype={'firm_id':str})
company=[]
for firm,g in ex.groupby('firm_id'):
    company.append({'firm_id':firm,'excluded_rows':len(g),'original_complete_excluded':int(g.model_complete.sum()),
                    'firm_stacks':g.stack_id.nunique(),'cohorts':'|'.join(str(int(x)) for x in sorted(g.cohort_report_year.unique())),
                    'reasons':'|'.join(sorted(g.exclusion_reason.unique())),'evidence_ids':'|'.join(sorted(g.evidence_id.dropna().unique()))})
save(pd.DataFrame(company),'excluded_company_summary.csv')
es=read('estimation_sample_audit.csv',dtype={'firm_id':str})
assert (es.es_original_W2==es.es_original_UW2).all()
assert (es.es_corrected_W2==es.es_corrected_UW2).all()
assert (es.es_corrected_W2<=es.es_original_W2).all()
assert int(es.es_original_W2.sum()-es.es_corrected_W2.sum())==summary['excluded_complete_rows']==426
auto=[]
for st in ['original','corrected']:
    mask=es.model_complete.eq(1)&(es.objective_keep.eq(1) if st=='corrected' else True)&es['es_'+st+'_W2'].eq(0)
    t=es.loc[mask,['audit_row_id','firm_id','stack_id','syn_year','cohort_report_year']].copy()
    t['stage']=st
    t['reason']='reghdfe FE singleton; not investigator-selected'
    auto.append(t)
save(pd.concat(auto),'regression_automatic_omissions.csv')
analysis=pd.read_stata(O/'static_corrected_analysis.dta',convert_categoricals=False)
eligible=analysis.loc[analysis.objective_keep.eq(1)].copy()
eligible.to_stata(O/'static_eligible_stack.dta',write_index=False,version=118)
assert eligible[['firm_id','stack_id','syn_year']].duplicated().sum()==0
target_attrition=[]
for st in ['original','corrected']:
    pmask=analysis.event_time.eq(-1)&analysis.ebal_weight.notna()
    if st=='corrected': pmask &= analysis.objective_keep.eq(1)
    for (co,tr),g in analysis.loc[pmask].groupby(['cohort_report_year','treated_in_stack']):
        assert np.isfinite(g[[x for x in models.controls.iloc[0].split() if x!='Stdret_w']]).all().all()
        assert g.model_complete.eq(1).eq(g.Stdret_w.notna()).all()
        target_attrition.append({'stage':st,'cohort':int(co),'treated':int(tr),'weight_target_baseline_rows':len(g),'W2_complete_baseline_rows':int(g.model_complete.sum()),'missing_Stdret_at_baseline':int(g.Stdret_w.isna().sum())})
save(pd.DataFrame(target_attrition),'weight_target_vs_estimation_sample.csv')

# Audit actual final regression composition; these are descriptions, not new estimators.
composition=[]
actual_balance=[]
for st in ['original','corrected']:
    sample=analysis.loc[es['es_'+st+'_W2'].eq(1).to_numpy()]
    tot_t=sample.loc[sample.treated_in_stack.eq(1)].shape[0]
    tot_c=sample.loc[sample.treated_in_stack.eq(0)].shape[0]
    for co,g in sample.groupby('cohort_report_year'):
        t=g.loc[g.treated_in_stack.eq(1)]; c=g.loc[g.treated_in_stack.eq(0)]
        composition.append({'stage':st,'cohort':int(co),'N':len(g),'treated_rows':len(t),'control_rows':len(c),
                            'treated_firm_stacks':t.firm_id.nunique(),'control_firm_stacks':c.firm_id.nunique(),
                            'treated_row_share':len(t)/tot_t,'control_row_share':len(c)/tot_c,
                            'treated_weight_sum':t.ebal_weight.sum(),'control_weight_sum':c.ebal_weight.sum(),
                            'control_to_treated_weight_ratio':c.ebal_weight.sum()/t.ebal_weight.sum()})
        pt=t.loc[t.event_time.eq(-1)]; pc=c.loc[c.event_time.eq(-1)]
        for v in [x for x in models.controls.iloc[0].split() if x!='Stdret_w']:
            xt=pt[v].to_numpy(); xc=pc[v].to_numpy(); wt=pt.ebal_weight.to_numpy(); wc=pc.ebal_weight.to_numpy()
            mt=np.average(xt,weights=wt); mc=np.average(xc,weights=wc)
            def sd(xx,ww): return np.sqrt(np.dot(ww,(xx-np.average(xx,weights=ww))**2)/(ww.sum()-(ww@ww)/ww.sum()))
            smd=(mt-mc)/np.sqrt((sd(xt,wt)**2+sd(xc,wc)**2)/2)
            actual_balance.append({'stage':st,'cohort':int(co),'variable':v,'treated_mean':mt,'control_mean':mc,'SMD':smd,'treated_firms':len(pt),'control_firms':len(pc)})
save(pd.DataFrame(composition),'stack_aggregation_weight_audit.csv')
save(pd.DataFrame(actual_balance),'actual_regression_prebalance.csv')

# Verify SA corrected sample by reconstructing the unchanged complete-case/singleton rule.
alt=pd.read_stata(P/'modern_did_syn_extension/alternative_modern_master.dta',convert_categoricals=False)
mask=np.isfinite(alt[['SYN_MARKET_ONLY_w','Size_w','Lev_w','MB_w','Age_w']]).all(axis=1)
while True:
    active=alt.loc[mask]
    singleton=active.groupby('firm_id').firm_id.transform('size').eq(1)|active.groupby('syn_year').syn_year.transform('size').eq(1)
    if not singleton.any(): break
    mask.loc[singleton.index[singleton]]=False
actual=read('sa_corrected_estimation_sample.csv')
z=alt[['firm_id','syn_year']].copy(); z['expected_sample']=mask.astype(int)
z=z.merge(actual[['firm_id','syn_year','sa_corrected_es']],on=['firm_id','syn_year'],validate='one_to_one')
assert z.expected_sample.eq(z.sa_corrected_es).all()
assert int(mask.sum())==int(sa.N.iloc[0])==48435
save(pd.DataFrame([{'check':'unchanged_old_complete_case_and_singleton_rule','rows':len(z),'disagreements':int(z.expected_sample.ne(z.sa_corrected_es).sum()),'expected_N':int(mask.sum()),'actual_N':int(z.sa_corrected_es.sum())}]),'sa_sample_invariance_check.csv')
old_sa=pd.read_csv(P/'modern_did_syn_extension/modern_did_alternative_syn.csv')
old_sa=old_sa.loc[old_sa.estimator.eq('sun_abraham_CORE')].copy()
new_sa=sa.loc[sa.displayed.eq(1)].copy()
compar=[]
for _,old in old_sa.iterrows():
    new=new_sa.loc[new_sa.event_time.eq(old.event_time)].iloc[0]
    for stage,r in [('old_omitted_multiple_periods',old),('corrected_only_minus1_omitted',new)]:
        compar.append({'stage':stage,'event_time':int(r.event_time),'coefficient':r['estimate'] if stage.startswith('old_') else r.coefficient,
                       'SE':r['se'] if stage.startswith('old_') else r.SE,'p':r.p,'CI_low':r.ci_low if stage.startswith('old_') else r.CI_low,
                       'CI_high':r.ci_high if stage.startswith('old_') else r.CI_high,'N':r.N,
                       'clusters':r.firms if stage.startswith('old_') else r.clusters,'pre_joint_p':r.pre_joint_p,'post_joint_p':r.post_joint_p})
save(pd.DataFrame(compar),'sa_code_correction_comparison.csv')
shares=read('sa_cohort_shares_and_coefficients.csv')
assert shares.groupby('term').share.sum().sub(1).abs().max()<1e-6
sa_cells=actual.loc[actual.sa_corrected_es.eq(1)&actual.g.gt(0)].groupby(['g','event_time']).agg(N=('firm_id','size')).reset_index()
save(sa_cells,'sa_event_cohort_composition.csv')

manifest=read('input_manifest_sha256.csv')
manifest['sha256_after']=[sha(f) for f in manifest.path]
manifest['unchanged']=manifest.sha256.eq(manifest.sha256_after)
assert manifest.unchanged.all()
save(manifest,'input_integrity_after_run.csv')

f4=lambda x:f'{float(x):.4f}'
fi=lambda x:f'{int(x):,}'
display=models[['model','coefficient','SE','p','N','clusters','treated_firms','cohorts']].copy()
display.columns=['模型','TreatPost','SE','p','N','公司簇','处理公司','批次']
mt=md(display,{'TreatPost':f4,'SE':f4,'p':f4,'N':fi,'公司簇':fi,'处理公司':fi,'批次':fi})
ce=events.loc[events.model.eq('corrected_W2'),['event_time','coefficient','SE','p','CI_low','CI_high']].copy()
ce.columns=['事件期','系数','SE','p','CI下限','CI上限']
et=md(ce,{'事件期':lambda x:f'{int(x):+d}',**{c:f4 for c in ['系数','SE','p','CI下限','CI上限']}})
cw=models.loc[models.model.eq('corrected_W2')].iloc[0]
ow=models.loc[models.model.eq('original_W2')].iloc[0]
pre=joint.loc[joint.model.eq('corrected_W2')&joint.test.eq('pre_joint')].iloc[0]
post=joint.loc[joint.model.eq('corrected_W2')&joint.test.eq('post_joint')].iloc[0]
sp2=sa.loc[sa.event_time.eq(2)].iloc[0]
sp4=sa.loc[sa.event_time.eq(-4)].iloc[0]
sp3=sa.loc[sa.event_time.eq(3)].iloc[0]
preall=sa_joint.loc[sa_joint.test.eq('all_modeled_pre_periods')].iloc[0]
balance=read('frozen_weight_diagnostics.csv')
b18=balance.loc[balance.stage.eq('corrected')&balance.cohort.eq(2018)].iloc[0]
actual18=max(abs(x['SMD']) for x in actual_balance if x['stage']=='corrected' and x['cohort']==2018)
oldmax=max(abs(x['SMD']) for x in actual_balance if x['stage']=='original')
newmax=max(abs(x['SMD']) for x in actual_balance if x['stage']=='corrected')
sa_table=new_sa[['event_time','coefficient','SE','p','pre_joint_p','post_joint_p']].copy()
sa_table.columns=['事件期','系数','SE','p','短窗前联合p','短窗后联合p']
st=md(sa_table,{c:f4 for c in sa_table if c!='事件期'}|{'事件期':lambda x:f'{int(x):+d}'})
reason=ex.groupby(['exclusion_reason','treated_in_stack']).agg(观测数=('firm_id','size'),公司数=('firm_id','nunique'),原完整样本观测=('model_complete','sum')).reset_index()
reason.columns=['剔除依据','原处理身份','观测数','公司数','原完整样本观测']

report=f'''# 静态主回归代码与样本纠错报告

## Material Passport

- 日期：2026-10-28。
- 状态：VERIFIED（旧W2、UW2和W2事件系数复现；新固定模型实际执行并保存日志及估计样本）；统计识别假设仍须审慎解释。
- 范围：五批次固定W2静态模型、同样本UW2、对应W2事件研究，以及先前七批次Sun–Abraham代码纠错。没有新增控制组合、权重搜索或按结果删批次。
- 实施：单进程、Stata单核；本轮没有加载全部原始周收益或重新扫描年报，没有重算SYN。
- 方案：重跑前已保存PRE_ANALYSIS_PLAN.md。历史上已有多轮分析，本轮不能表述为整项研究的事前注册。

## 一、静态主模型和结论

保持SYN_w_Gao、TreatPost及原12项控制：Size_w、Lev_w、MB_w、Age_w、Turnover_w、Stdret_w、ROA_w、Growth_w、CFO_w、Loss、Tophold_w、Instihold_w。财务年度为syn_year-1；公司×stack及cohort×year固定效应；原始公司聚类；2015—2019五批次；[-3,+2]。权重为原冻结ebal_weight。

{mt}

纠错后W2：TreatPost={cw.coefficient:.7f}，SE={cw.SE:.7f}，p={cw.p:.7f}，95%CI=[{cw.CI_low:.7f}, {cw.CI_high:.7f}]。没有达到10%、5%或1%显著。

相对原W2，系数变化{cw.coefficient-ow.coefficient:+.7f}，标准误变化{cw.SE-ow.SE:+.7f}，N减少{int(ow.N-cw.N):,}，公司簇减少{int(ow.clusters-cw.clusters)}，处理公司减少{int(ow.treated_firms-cw.treated_firms)}。负效应绝对值减小且SE略升，数据纠错没有恢复静态主效应显著性。

原样本重跑与归档W2、UW2的系数、SE、p、N、公司簇和批次数均在1e-8容差内一致。原样本与纠错样本共同观测上的SYN、控制变量、TreatPost、FE、cluster和权重未变，因此本轮静态差异来自有依据的样本排除，没有用变量替换混入差异。

原W2事件系数及联合检验p值也复现；归档F值仅保存约8位有效数字，F值按2e-7绝对容差核验，最大差约9.2e-8，不涉及改动估计结果。

## 二、客观剔除依据及数量

政策证据仅取已完成的肯定映射、上交所直接行业与主营业务交叉确认、2013严格人工strict_include=1决定及57家公司已裁定的更早处理记录。每项证据记录来源文件、原表数据行、指引编号、年度、原文或决定依据。候选、可能适用、没有文本或strict_include=0不被当作确定否定证据。

控制组规则：已有确认处理的有效年不晚于stack既定窗口末年，排除该公司—stack的全部记录。处理组规则：已有确认适用报告年早于当前批次，排除该错误首次处理公司—stack。两类都不永久删除整家公司，不改Treat，不把公司转入其他批次。

共31家不同公司、80个公司—stack组合、458条stack记录；其中58个控制组合、22个处理组合。对原完整W2样本的影响为426条。

{md(reason)}

样本流程：34,116原stack行 → 原W2完整行25,985 → 原reghdfe删除6条singleton → 原N=25,979。

纠错流程：34,116 → 排除458条不合格stack行 → 保留33,658；完整行25,559 → reghdfe仍删除6条singleton → 新N=25,553。

6条singleton是固定效应自动处理，另列regression_automatic_omissions.csv；未将其混称为研究者剔除。五个批次均保留。角色不同的公司数不能直接相加，因为同一公司可在自己的stack为处理组、在更早stack为未来处理控制。

## 三、未发现的错误与未实施的删除

公司—stack—年度无重复；固定效应无碰撞；公司聚类与原股票代码一一对应；treated_in_stack在公司—stack内不变；控制年度、事件时间、post和TreatPost符合原公式；原始SYN与来源相等，logit(R2)一致，有效周数均不少于30。

所有SYN及12项控制与原始冻结stack逐值核对一致。本轮派生标识改值0条，未重新缩尾，未调整极端真实值，没有新增ST、IPO或退市剔除条件。不同公司—stack之间重复使用控制公司本身是stacked结构，不是错误重复，不据此删行。

## 四、固定权重的限制与聚合审计

清理后沿用原权重，避免同时改变样本和权重算法。2018批次原先的政策前均值平衡不再精确：最大绝对SMD={b18.max_abs_SMD:.4f}，控制/处理权重和比={b18.control_to_treated_weight_ratio:.4f}；其他批次最大绝对SMD小于0.04。因此本结果应称为“冻结原权重的静态纠错对照”，不能称为对新样本重新实现完整熵平衡。

上述数值对应原熵平衡基期资格集。进一步限制为W2实际e(sample)时，2018批次11项基期协变量最大绝对SMD为{actual18:.4f}，详见actual_regression_prebalance.csv，不能把原始完整11变量的平衡误当作最终回归样本的精确平衡。

这并非清理后才出现的全部问题：原W2实际基期样本最大绝对SMD已为{oldmax:.4f}（2019批次Age_w），清理后最大为{newmax:.4f}（2018批次Age_w）。直接核对发现，权重目标基期的11项协变量完整，但W2额外要求Stdret_w非缺失，完整样本选择再次改变了基期构成。例如原2019批次处理基期由79家减至61家、控制由1,191家减至892家。基期在已匹配权重记录中的W2样本损失恰由Stdret_w缺失解释，已逐批次输出weight_target_vs_estimation_sample.csv。这是样本与权重构造顺序问题，不能继续沿用“11项协变量在最终W2回归样本中完全平衡”的表述。

已输出各批次实际回归样本的处理/控制观测份额、权重和、ESS及SMD。熵平衡解决协变量分布问题，并不自动保证普通stacked的回归聚合就是预先定义的总体ATT。本轮没有引入新的Q权重、再优化熵权重或选择截尾阈值。该聚合目标尚未完成独立数学验证，不能宣称已解决全部权重识别问题。

## 五、纠错后W2事件研究

该stack原来已限制在[-3,+2]，此前W2事件研究没有发现七批次全时期模型的遗漏窗口问题。此次仅按同一客观合格样本重估。交互项始终为treated_in_stack×对应事件期，控制组全为0，唯一省略事件期为-1。五项系数均可估计，事件研究e(sample)与同阶段W2静态e(sample)完全相同。

{et}

短窗政策前联合检验F={pre.F:.5f}，p={pre.p:.7f}；政策后联合F={post.F:.5f}，p={post.p:.7f}。前检验不能拒绝这两个系数共同为0，但不证明平行趋势成立。+2仍显著为负；0和+1不显著。动态+2不能替代静态TreatPost，也不能证明持续性的政策后平均下降。

图：static_W2_event_comparison.png。图中系数和95%聚类置信区间均直接来自估计表，-1为0且不绘制虚构置信区间。

## 六、先前七批次Sun–Abraham图的代码修正

旧模型只放入-3、-2、0、+1、+2，但保留了窗口外处理期，导致-1并非唯一省略时期。本轮保持其全时期面板、市场模型SYN、Size/Lev/MB/Age控制、公司与年度FE、公司聚类及7批次不变，加入全部实际支持的-10至+12事件期，只省略-1。22个事件系数全部可估计；回归前完整样本和singleton规则复核无差异，最终N仍48,435，公司簇5,081，处理公司589。

{st}

关键更正：+2由旧-0.1180515（SE=0.0408311，p=0.0038375）变为{sp2.coefficient:.7f}（SE={sp2.SE:.7f}，p={sp2.p:.7f}），仅达到5%，不再达到1%。原先“正式动态主结果三星”的定位应撤回。

不能只看展示窗口：完整模型中-4期={sp4.coefficient:.7f}，p={sp4.p:.7f}；所有9个政策前时期联合p={preall.p:.7f}。短窗前联合p={sp2.pre_joint_p:.7f}不等于全时期前趋势均成立。+3期={sp3.coefficient:.7f}，p={sp3.p:.7f}，也未显示连续的负向延迟效应。已同时保留完整路径CSV与图，避免只展示有利时期。全路径远期的cohort组成会变化，不能简单看作同一批公司的永久效应。

该诊断的因变量和FE原本就与W2不同，不能把它与W2混称同一模型，更不能用修正后较低的某个p值更换静态主模型。

## 七、本轮能回答和仍不能回答的事

1. 发现并排除了实际的处理/控制污染记录，且发现先前七批次动态基准期实现错误。
2. W2静态实现本身未发现错年、错码或SYN值错误；其不显著不能简单归因于一个编码错误。
3. 客观纠错后静态结果更接近0，精度略差。这不支持“只要清理几个异常公司即可恢复三星”的判断。
4. +2的下降在五批次W2纠错后仍存在，但不能据此认定总体效应显著或有永久改善。批次构成、处理适用名单和同期行业冲击仍是识别限制。
5. 如后续继续，首先需要在合格样本上按已经固定的11项政策前协变量重新校准同一熵平衡算法，并明确目标ATT与聚合权重；这属于需要事先确定且完整披露的下一轮，本轮没有自动运行，更不保证显著。

## 八、统计解释核验（11/11检查）

|项目|本轮结论|
|---|---|
|辛普森悖论|历史批次方向有差异；本轮未以方向筛选批次，未证明严格反转|
|生态谬误|结论限定公司收益同步性，不从面板直接推断个别投资者行为|
|选择偏误|31家公司存在客观资格排除；未确认事项继续保留并列入复核表|
|碰撞变量|未重新审核全部12控制的因果角色，不能宣称该问题已排除|
|基率忽略|非分类问题，不适用|
|均值回归|没有用SYN极值、涨跌或回归贡献筛选公司|
|幸存者偏误|保留非平衡样本，不任意排除ST/退市/IPO|
|多重检验|报告所有本轮固定结果；单期p为未作跨历史规格校正的名义p|
|分析路径选择|不以本轮p值重新选权重、窗口或样本；历史多轮探索如实保留|
|相关与因果|DID因果解释仍依赖平行趋势与无同期混杂，前检验不构成证明|
|反向因果|政策时序保持，但资格选择与同期行业变化仍需制度证据支持|

## 九、保存和复现

原始输入14份SHA256在运行前后全部一致。新分析数据static_corrected_analysis.dta包含保留标识；static_eligible_stack.dta仅包含33,658条客观合格记录；实际回归样本见estimation_sample_audit.csv。原始文件没有被覆盖。

主要文件：static_original_vs_corrected.csv、fixed_W2_event_results.csv、fixed_W2_joint_tests.csv、excluded_observation_list.csv、excluded_company_summary.csv、confirmed_policy_evidence.csv、original_reproduction_check.csv、sa_code_correction_comparison.csv、sa_full_path_joint_tests.csv、input_integrity_after_run.csv、static_correction_stata.log。

方法来源：Sun的官方eventstudyinteract源码（https://github.com/lsun20/EventStudyInteract）；Wing/Freedman/Hollingsworth的stacked权重研究（https://www.nber.org/papers/w32054）；Roth的政策前检验解释（https://pubs.aeaweb.org/doi/10.1257/aeri.20210236）。

本轮固定纠错已完成，到此停止，没有机制、异质性、新控制组合或进一步显著性搜索。
'''
(O/'static_correction_report.md').write_text(report,encoding='utf-8')
print('Report complete; all original inputs unchanged:',manifest.unchanged.all())
print('Original models reproduced:',len(repro),'checks')
print('Corrected W2',cw[['coefficient','SE','p','N','clusters']].to_dict())
print('Corrected SA +2',sp2[['coefficient','SE','p']].to_dict())
