#!/usr/bin/env python3
"""Read-only, sequential Huang replication source audit; no analysis construction.

Writes only aggregate audit evidence beside this script. No regressions, merges,
treatment generation, sample dropping, or writes to original inputs.
"""
import csv
import hashlib
import json
import re
import resource
import time
from collections import Counter, defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import pandas as pd

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/macpro/Desktop/毕业论文')
RAW = ROOT / '控制变量'
ORIG = ROOT / '原始数据'
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
SOURCES = [
 ('balance', RAW/'资产合计负债合计所有者权益合计/FS_Combas.xlsx', 'Stkcd','Accper', ['A001000000','A002000000','A003000000','A003100000'], {'Typrep':'A'}),
 ('income', RAW/'营业利润净利润/FS_Comins.xlsx','Stkcd','Accper',['B001300000','B002000000'],{'Typrep':'A'}),
 ('market', RAW/'总市值/TRD_Year.xlsx','Stkcd','Trdynt',['Ysmvttl'],{}),
 ('turnover', RAW/'年个股换手率/LIQ_TOVER_Y.xlsx','Stkcd','Trdynt',['ToverTlY'],{}),
 ('largest_holder', RAW/'第一大股东持股比例/EN_EquityNatureAll.xlsx','Symbol','EndDate',['LargestHolderRate'],{}),
 ('duality', RAW/'机构投资者持股比例_两职合一_独立董事占比/BDT_ManaGovAbil.xlsx','Symbol','Enddate',['ConcurrentPosition'],{}),
 ('board', RAW/'董事人数/CG_ManagerShareSalary.xlsx','Symbol','Enddate',['DirectorNumber'],{'StatisticalCaliber':'1'}),
 ('controller', RAW/'实际控制人性质/HLD_Contrshr.xlsx','Stkcd','Reptdt',['S0702b'],{}),
 ('listing', RAW/'首次上市日期/STK_LISTEDCOINFOANL.xlsx','Symbol','EndDate',['LISTINGDATE'],{}),
 ('auditor', RAW/'审计机构/AR_LISTCOMPAUDIT.xlsx','Symbol','EndDate',['AccountingFirmName'],{'Source':'0','TerritoryForeignIdentity':'1'}),
 ('basic_info', ORIG/'公司基本信息/EVA_Co.xlsx','Symbol','IPODate',['IPODate','DelistedDate'],{}),
]

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def norm(v):
 v=str(v or '').strip()
 return v[:-2] if v.endswith('.0') else v

def xml_rows(path):
 """Read actual cells; ignore bad XLSX dimensions; release each parsed row."""
 with ZipFile(path) as z:
  ss=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   with z.open('xl/sharedStrings.xml') as f:
    for _,el in ET.iterparse(f,events=('end',)):
     if el.tag==NS+'si':
      ss.append(''.join(t.text or '' for t in el.iter(NS+'t'))); el.clear()
  sheet_files=sorted(n for n in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',n))
  for sf in sheet_files:
   with z.open(sf) as f:
    data_parent=None
    for event,el in ET.iterparse(f,events=('start','end')):
     if event=='start' and el.tag==NS+'sheetData': data_parent=el
     if event!='end' or el.tag!=NS+'row': continue
     vals={}
     for c in el.findall(NS+'c'):
      col=re.sub(r'\d','',c.get('r','')); kind=c.get('t','')
      if kind=='inlineStr': v=''.join(t.text or '' for t in c.iter(NS+'t'))
      else:
       v=c.findtext(NS+'v',default='')
       if kind=='s' and v: v=ss[int(v)]
      vals[col]=v
     rn=int(el.get('r','0'))
     if data_parent is not None: data_parent.remove(el)
     el.clear()
     if any(v!='' for v in vals.values()): yield sf,rn,vals

def write_csv(name,rows):
 if not rows: return
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)

def audit_xlsx(spec):
 sid,path,stock,date,fields,filters=spec
 before=(path.stat().st_size,path.stat().st_mtime_ns,sha(path))
 headers={}; first=[]; raw_by_year=Counter(); eligible_by_year=Counter()
 rows=0; firms=defaultdict(set); values=defaultdict(dict); duplicate_keys=Counter()
 raw_min=None; raw_max=None; selected=0; columns=set(); sheet_counts=Counter()
 cats=defaultdict(Counter)
 for sheet,rn,vs in xml_rows(path):
  sheet_counts[sheet]+=1;columns.update(col for col,v in vs.items() if v!='')
  if rn==1: headers[sheet]=vs
  if len(first)<5: first.append({'sheet':sheet,'row':rn,'cells':vs})
  if rn<4: continue
  rows+=1; rec={code:vs.get(col,'') for col,code in headers[sheet].items()}
  d=rec.get(date,''); m=re.match(r'^(19\d{2}|20\d{2})',d)
  if not m: continue
  y=int(m.group(1));raw_by_year[y]+=1
  code=norm(rec.get(stock,'')); code=code.zfill(6) if code.isdigit() else code
  if not re.fullmatch(r'\d{6}',code): continue
  if sid=='basic_info': annual=True
  else: annual=bool(re.fullmatch(r'\d{4}',d) or re.match(r'^\d{4}-12-31',d))
  if not annual or any(norm(rec.get(k,''))!=v for k,v in filters.items()): continue
  selected+=1; eligible_by_year[y]+=1;firms[y].add(code)
  if not 2007<=y<=2021: continue
  key=(code,y);duplicate_keys[key]+=1
  for field in fields:
   v=norm(rec.get(field,''))
   if v not in ('','nan','None','N/A','--','.'):
    values[field].setdefault(key,set()).add(v)
    if sid in ('controller','duality','board'):cats[field][v]+=1
 after=(path.stat().st_size,path.stat().st_mtime_ns,sha(path))
 assert before==after, f'Input changed during audit: {path}'
 yr_rows=[]
 for y in sorted(raw_by_year):
  for field in fields:
   valid={k[0] for k in values[field] if k[1]==y}
   conflicts=sum(len(v)>1 for k,v in values[field].items() if k[1]==y)
   yr_rows.append(dict(source=sid,year=y,field=field,raw_rows=raw_by_year[y],annual_filtered_rows=eligible_by_year[y],annual_unique_firms=len(firms[y]),nonmissing_firm_years=len(valid) if 2007<=y<=2021 else '',conflicting_firm_years=conflicts if 2007<=y<=2021 else ''))
 result=dict(source=sid,path=str(path),size_bytes=before[0],mtime_ns=before[1],sha256=before[2],input_unchanged=True,
  data_rows=rows,actual_sheet_nonempty_rows=dict(sheet_counts),actual_nonempty_columns=len(columns),headers=headers,first_five_rows=first,
  raw_year_min=min(raw_by_year) if raw_by_year else None,raw_year_max=max(raw_by_year) if raw_by_year else None,raw_years=sorted(raw_by_year),
  annual_filter=filters,annual_rows=selected,annual_years=sorted(eligible_by_year),
  repeated_company_year_keys_2007_2021=sum(n>1 for n in duplicate_keys.values()),
  conflicting_fields_2007_2021={f:sum(len(v)>1 for v in values[f].values()) for f in fields},categories={f:dict(c) for f,c in cats.items()},
  note='basic_info years represent IPO year, NOT annual panel coverage' if sid=='basic_info' else 'Nonmissing/conflict counters audited for 2007-2021 only; no sample merging')
 print(sid,rows,result['raw_year_min'],result['raw_year_max'],flush=True)
 return result,yr_rows

def industry_audit():
 path=ORIG/'行业分类_新下载.dta'; before=sha(path)
 groups=defaultdict(set); names=defaultdict(set); lookup=defaultdict(set);rows=Counter()
 duplicates=Counter(); code_conflicts=defaultdict(set)
 for chunk in pd.read_stata(path,chunksize=25000,convert_categoricals=False):
  for r in chunk.itertuples(index=False):
   cls=str(r.IndustryClassificationID);y=int(str(r.EndDate)[:4]);code=str(r.Symbol)
   if cls not in ('P0201','P0207'):continue
   groups[cls,y].add(code);rows[cls,y]+=1;names[cls].add(str(r.IndustryClassification))
   if cls=='P0207' and y==2014:
    lookup[str(r.IndustryCode2),str(r.IndustryName2)].add(code)
    duplicates[code]+=1;code_conflicts[code].add(str(r.IndustryCode2))
 assert sha(path)==before
 cov=[dict(classification_id=c,classification_name=';'.join(sorted(names[c])),year=y,rows=rows[c,y],unique_firms=len(v)) for (c,y),v in sorted(groups.items())]
 codes=[dict(code=c,industry_name=n,firms_2014_all_exchanges=len(v),source=str(path),classification='P0207') for (c,n),v in sorted(lookup.items())]
 return cov,codes,dict(path=str(path),sha256=before,input_unchanged=True,P0207_2014_duplicate_firms=sum(v>1 for v in duplicates.values()),P0207_2014_conflicting_codes=sum(len(v)>1 for v in code_conflicts.values()))

def new_industry_audit():
 out=[]
 for path in sorted(RAW.glob('*/STK_IndustryClassAnl.xlsx')):
  headers={};groups=defaultdict(set);institutions=defaultdict(set);names=defaultdict(set);rowcount=Counter();h=sha(path)
  for sheet,rn,vs in xml_rows(path):
   if rn==1:headers[sheet]=vs
   if rn<4:continue
   rec={code:vs.get(col,'') for col,code in headers[sheet].items()}
   d=rec.get('EndDate','');m=re.match(r'^(20\d{2}|19\d{2})',d)
   if not m:continue
   y=int(m.group(1));cls=rec.get('IndustryClassificationID','');stock=rec.get('Symbol','')
   groups[cls,y]  # Retain the group even if the stock-code column is absent.
   if stock: groups[cls,y].add(stock)
   inst=rec.get('InstitutionID','')
   if inst: institutions[cls,y].add(inst)
   rowcount[cls,y]+=1;names[cls].add(rec.get('IndustryClassification',''))
  assert h==sha(path)
  for (cls,y),stocks in sorted(groups.items()):out.append(dict(path=str(path),sha256=h,classification_id=cls,classification_name=';'.join(sorted(names[cls])),year=y,rows=rowcount[cls,y],unique_nonmissing_stock_codes=len(stocks),unique_nonmissing_institution_ids=len(institutions[cls,y]),note='分类名称或股票代码原字段未提供时留空/计0；不把空代码算作一家公司'))
 return out

def main():
 start=time.time();g1=ROOT/'堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta';g1h=sha(g1)
 results=[];years=[]
 for spec in SOURCES:
  a,b=audit_xlsx(spec);results.append(a);years.extend(b)
  (OUT/'source_audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
  write_csv('source_year_coverage.csv',years)
 cov,codes,meta=industry_audit();write_csv('industry_classification_coverage.csv',cov);write_csv('observed_2014_P0207_codebook.csv',codes)
 write_csv('additional_industry_files_coverage.csv',new_industry_audit())
 # IPO file is used only for an audit count, not a treatment or final sample.
 ip=ORIG/'公司基本信息/IPO_Cobasic.dta';ih=sha(ip);df=pd.read_stata(ip,convert_categoricals=False)
 pre=(df.Listexg.astype(str).eq('1') & df.Listdt.astype(str).lt('2015-01-01') & df.Stkcd.astype(str).str.startswith('6'))
 meta['pre2015_SSE_A_IPO_audit_count']=int(df.loc[pre,'Stkcd'].nunique())
 meta['IPO_file_sha256']=ih;meta['IPO_caveat']='Historical IPO records; includes subsequent delisting/ST/financial firms; not final sample, no use of IPO-time industry as current industry.'
 assert sha(ip)==ih and sha(g1)==g1h
 meta.update(original_G1_path=str(g1),original_G1_sha256_before=g1h,original_G1_sha256_after=sha(g1),regressions_run=0,new_analysis_variables=0,source_merges=0,seconds=time.time()-start,peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
 (OUT/'execution_audit.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(meta,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
