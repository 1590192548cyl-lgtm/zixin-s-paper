from pathlib import Path
import json

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs" / "targeted_supplement"

SYN = WORK / "outputs/syn_csrc_family_2010_2020.dta"
FIRST = OUT / "gao_firm_first_treat_supplemented.csv"
CONTROLS = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_full_controls/"
    "gao_controls_firm_year_2009_2025.dta"
)
DELIST = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_replication_refinement/"
    "official_delisting_dates_combined.csv"
)

COHORTS = [2012, 2015, 2016, 2017]
PAPER_LABEL = {2012: 2013, 2015: 2015, 2016: 2016, 2017: 2017}
PAPER_COUNTS = {
    2012: {(0, 0): 2952, (0, 1): 2778, (1, 0): 326, (1, 1): 347},
    2015: {(0, 0): 2886, (0, 1): 2806, (1, 0): 1017, (1, 1): 995},
    2016: {(0, 0): 3115, (0, 1): 2841, (1, 0): 419, (1, 1): 408},
    2017: {(0, 0): 3343, (0, 1): 2959, (1, 0): 164, (1, 1): 162},
}


def norm_id(series):
    return pd.to_numeric(series, errors="coerce").astype("Int64")


def main():
    syn = pd.read_stata(SYN, convert_categoricals=False)
    syn["firm_id"] = norm_id(syn["firm_int"])
    syn = syn[["firm_id", "syn_year", "SYN_CSRC_FAMILY", "R2_CSRC_FAMILY", "n_weeks_CSRC_FAMILY"]]

    first = pd.read_csv(FIRST, low_memory=False)
    first["firm_id"] = norm_id(first["firm_id"])
    first["first_treat_year_supplemented"] = pd.to_numeric(
        first["first_treat_year_supplemented"], errors="coerce"
    )
    first["eligible_as_clean_control_supplemented"] = pd.to_numeric(
        first["eligible_as_clean_control_supplemented"], errors="coerce"
    ).fillna(0).astype(int)

    controls = pd.read_stata(CONTROLS, convert_categoricals=False)
    controls["firm_id"] = norm_id(controls["firm_id"])
    controls["fiscal_year"] = pd.to_numeric(controls["fiscal_year"], errors="coerce").astype("Int64")
    controls = controls[["firm_id", "fiscal_year", "industry_code", "industry_name"]]

    delist = pd.read_csv(DELIST, low_memory=False)
    delist["firm_id"] = norm_id(delist["firm_id"])
    delist["delisting_date"] = pd.to_datetime(delist["delisting_date"], errors="coerce")
    excluded_delist = set(
        delist.loc[
            delist["delisting_date"].between("2009-01-01", "2019-12-31"), "firm_id"
        ].dropna().astype(int)
    )

    rows = []
    selection = []
    for cohort in COHORTS:
        treated_ids = set(
            first.loc[first["first_treat_year_supplemented"].eq(cohort), "firm_id"]
            .dropna().astype(int)
        )
        future_clean = first["first_treat_year_supplemented"].ge(cohort + 3)
        never_clean = (
            first["first_treat_year_supplemented"].isna()
            & first["eligible_as_clean_control_supplemented"].eq(1)
        )
        control_ids = set(first.loc[future_clean | never_clean, "firm_id"].dropna().astype(int))
        control_ids -= treated_ids

        q = syn[
            syn["syn_year"].between(cohort - 2, cohort + 3)
            & syn["firm_id"].isin(treated_ids | control_ids)
            & ~syn["firm_id"].isin(excluded_delist)
        ].copy()
        q["annual_report_year"] = q["syn_year"] - 1
        q["cohort_report_year"] = cohort
        q["gao_cohort_label"] = PAPER_LABEL[cohort]
        q["event_time"] = q["annual_report_year"] - cohort
        q["treated_in_stack"] = q["firm_id"].isin(treated_ids).astype(np.int8)
        q["Post"] = q["annual_report_year"].ge(cohort).astype(np.int8)
        q["TreatPost"] = (q["treated_in_stack"] * q["Post"]).astype(np.int8)
        q = q.merge(
            controls,
            left_on=["firm_id", "annual_report_year"],
            right_on=["firm_id", "fiscal_year"],
            how="left",
            validate="many_to_one",
        )
        q = q[~q["industry_name"].fillna("").str.contains(r"银行|证券|保险|金融|信托", regex=True)].copy()
        group = q.groupby("firm_id")
        has_pre = group["Post"].transform(lambda x: x.eq(0).any())
        has_post = group["Post"].transform(lambda x: x.eq(1).any())
        q = q[has_pre & has_post].copy()
        q["stack_id"] = COHORTS.index(cohort) + 1
        rows.append(q)

        selection.append({
            "cohort_report_year": cohort,
            "gao_cohort_label": PAPER_LABEL[cohort],
            "treated_ids_before_data": len(treated_ids),
            "clean_control_ids_before_data": len(control_ids),
            "stack_rows": len(q),
            "treated_firms": int(q.loc[q["treated_in_stack"].eq(1), "firm_id"].nunique()),
            "control_firms": int(q.loc[q["treated_in_stack"].eq(0), "firm_id"].nunique()),
        })

    stack = pd.concat(rows, ignore_index=True)
    stack["firm_stack_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["firm_id"].astype(str), sort=True
    )[0] + 1
    stack["cohort_year_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["annual_report_year"].astype(str), sort=True
    )[0] + 1
    if stack.duplicated(["firm_id", "stack_id", "annual_report_year"]).any():
        raise AssertionError("Duplicate firm-stack-year rows")

    counts = (
        stack.groupby(["cohort_report_year", "treated_in_stack", "Post"])
        .size().rename("supplemented_rows").reset_index()
    )
    paper_rows = []
    for cohort, cells in PAPER_COUNTS.items():
        for (treated, post), value in cells.items():
            paper_rows.append({
                "cohort_report_year": cohort,
                "treated_in_stack": treated,
                "Post": post,
                "gao_paper_rows": value,
            })
    counts = counts.merge(
        pd.DataFrame(paper_rows),
        on=["cohort_report_year", "treated_in_stack", "Post"],
        how="outer",
    )
    counts["row_gap_supplemented_minus_paper"] = counts["supplemented_rows"] - counts["gao_paper_rows"]

    stack.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    stack["firm_id"] = stack["firm_id"].astype(np.int32)
    stack.to_csv(OUT / "gao_targeted_sse_supplemented_stack.csv", index=False)
    stack.to_stata(OUT / "gao_targeted_sse_supplemented_stack.dta", write_index=False, version=118)
    pd.DataFrame(selection).to_csv(OUT / "supplemented_stack_selection_audit.csv", index=False)
    counts.to_csv(OUT / "supplemented_stack_vs_gao_table1.csv", index=False)

    meta = {
        "rows": int(len(stack)),
        "unique_firms": int(stack["firm_id"].nunique()),
        "treated_firms_across_stacks": int(stack.loc[stack["treated_in_stack"].eq(1), "firm_id"].nunique()),
        "cohorts": COHORTS,
        "duplicate_firm_stack_year": 0,
        "regressions_run": False,
        "raw_files_modified": False,
    }
    (OUT / "supplemented_stack_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print(pd.DataFrame(selection).to_string(index=False))
    print(counts.to_string(index=False))


if __name__ == "__main__":
    main()
