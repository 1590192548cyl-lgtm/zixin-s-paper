from pathlib import Path
import sqlite3,pandas as pd,numpy as np
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent/'huang_basic_reconstruction_20261103'
codes=pd.read_csv(O/'legacy2011_backcast2012_2014_codes_private.csv').set_index('firm_id')
d=pd.read_stata(B/'outputs/final_analysis.dta',convert_categoricals=False);s=pd.read_csv(B/'outputs/H8_sample_private.csv');keys=pd.MultiIndex.from_frame(s.loc[s.static_sample.eq(1),['firm_id','year']]);q=d.set_index(['firm_id','year']).loc[keys].reset_index();both=set(q.loc[q.year.eq(2011),'firm_id'])&set(q.loc[q.year.eq(2014),'firm_id'])
rows=[]
for label,ids in [('all_paired',both),('same_code_2012_2014',both&set(codes.index[codes['2012'].eq(codes['2014'])])),('changed_code_2012_2014',both&set(codes.index[codes['2012'].ne(codes['2014'])]))]:
 z=q[q.firm_id.isin(ids)&q.year.isin([2011,2014])];a=z.groupby(['year','Treat']).SYN_w.mean()
 rows.append(dict(group=label,firms=len(ids),treated=z.loc[z.Treat.eq(1),'firm_id'].nunique(),gap2011=a.get((2011,1),np.nan)-a.get((2011,0),np.nan),gap2014=a.get((2014,1),np.nan)-a.get((2014,0),np.nan),note='descriptive only; 2012/2014 stability cannot establish true 2011 classification'))
pd.DataFrame(rows).to_csv(O/'stable_code_descriptive_check.csv',index=False)
c=sqlite3.connect('file:'+str(B/'cache/weekly.sqlite')+'?mode=ro',uri=True);out=[]
for year in [2009,2010,2011,2012,2013,2014]:
 z=pd.read_sql_query('SELECT firm_id,week,cap FROM weekly WHERE year=?',c,params=[year]);yy=2012 if year<=2011 else year
 # All source firms for the relevant year, not only final regression firms.
 ids=set()
 for ch in pd.read_stata('/Users/macpro/Desktop/毕业论文/原始数据/行业分类_新下载.dta',columns=['Symbol','EndDate','IndustryClassificationID'],chunksize=40000,convert_categoricals=False):
  ids.update(ch.loc[ch.IndustryClassificationID.eq('P0207')&ch.EndDate.str.startswith(str(yy)),'Symbol'].astype(int))
 ok=z.firm_id.isin(ids)
 out.append(dict(year=year,classification_source_year=yy,weekly_rows=len(z),missing_industry_rows=int((~ok).sum()),weekly_firms=z.firm_id.nunique(),firms_without_industry=z.loc[~ok,'firm_id'].nunique(),unclassified_cap_share=z.loc[~ok,'cap'].sum()/z.cap.sum()))
pd.DataFrame(out).to_csv(O/'industry_pool_coverage.csv',index=False);print(pd.DataFrame(rows).to_string(index=False));print(pd.DataFrame(out).to_string(index=False))
