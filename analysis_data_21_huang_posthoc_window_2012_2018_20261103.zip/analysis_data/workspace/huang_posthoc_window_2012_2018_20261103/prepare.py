from pathlib import Path
import pandas as pd,json,hashlib
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);B=W.parent/'huang_week_calendar_repair_20261103/fixed_rerun/outputs'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert not (W/'run_started.json').exists(),'Do not repeat the authorized fixed analysis'
paths=[B/'fixed_analysis.dta',B/'static_results.csv',B/'event_results.csv',B/'joint_tests.csv',W/'POSTHOC_PLAN.md',Path('/Users/macpro/Desktop/毕业论文/堆叠DID重跑/four_cohort_G1_latest_recheck_20261028/latest_G1_analysis.dta')]+list(B.glob('*.ster'))
(O/'protected_inputs.json').write_text(json.dumps([dict(file=str(p),sha256=sha(p)) for p in paths],ensure_ascii=False,indent=2),encoding='utf-8')
d=pd.read_stata(B/'fixed_analysis.dta',convert_categoricals=False);q=d[d.year.between(2012,2018)].copy();assert not q.duplicated(['firm_id','year']).any();assert q.event_time.eq(q.year-2015).all();assert q.TreatPost.eq(q.Treat*q.Post).all()
rows=[]
for m in ['H0','H8']:
 q[f'window_{m}_sample']=q[f'old_{m}_sample'];s=q[q[f'window_{m}_sample'].eq(1)];assert s.SYN_w.notna().all()
 assert len(s.groupby(['year','Treat']))==14
 rows.append(dict(model=m,full_N=int(d[f'old_{m}_sample'].sum()),window_input_N=len(s),firms=s.firm_id.nunique(),treated_firms=s.loc[s.Treat.eq(1),'firm_id'].nunique(),single_observation_firms=int(s.groupby('firm_id').size().eq(1).sum())))
pd.DataFrame(rows).to_csv(O/'pre_regression_sample_check.csv',index=False);q.to_stata(O/'window_analysis.dta',write_index=False,version=118)
q[['firm_id','year','window_H0_sample','window_H8_sample']].to_csv(O/'window_input_keys_private.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
