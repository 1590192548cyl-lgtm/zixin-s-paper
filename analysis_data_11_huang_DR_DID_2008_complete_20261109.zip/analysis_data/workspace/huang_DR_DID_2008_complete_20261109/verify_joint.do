version 18
clear all
set more off
capture log close _all
log using "outputs/joint_test_validation.log", text replace
import delimited using "outputs/drdid_joint_tests.csv", clear varnames(1) asdouble
assert abs(p-chi2tail(df,chi2))<1e-12
assert _N==2
list test chi2 df p, noobs
display "JOINT_PVALUES_INDEPENDENTLY_VERIFIED_NO_REFITS"
log close
