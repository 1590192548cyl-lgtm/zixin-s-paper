"""Read-only formal policy exposure counts. No return/SYN calculation or regression."""
from pathlib import Path
from datetime import date,timedelta
from collections import Counter
import pandas as pd,numpy as np,json,hashlib,sqlite3,time,resource
W=Path(__file__).resolve().parent;O=W/'outputs';O.mkdir(exist_ok=True);BASE=W.parent;R=BASE/'huang_week_calendar_repair_20261103';start=time.time();policy=date(2015,1,5)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(x,n):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
def js(x,n):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
m=json.loads((BASE/'huang_mapping_SYN_lineage_audit_20261104/outputs/protected_before.json').read_text());assert all(sha(r['path'])==r['sha256'] for r in m)
extra=[R/'outputs/confirmed_week_calendar.csv',BASE/'huang_industry_review_20261030/huang2025_fresh_text.txt'];m += [dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in extra];js(m,'protected_before.json')
c=pd.read_csv(R/'outputs/confirmed_week_calendar.csv');c=c[c.year.between(2009,2021)].copy();assert not c.week.duplicated().any()
weekrows=[]
for r in c.itertuples():
 a=date.fromisoformat(r.start);b=date.fromisoformat(r.end);days=[a+timedelta(days=i) for i in range((b-a).days+1)];weekdays=[dt for dt in days if dt.weekday()<5];assert weekdays
 sunday=a-timedelta(days=(a.weekday()+1)%7);anchor=sunday+timedelta(days=1);assert str(anchor)==r.Monday_anchor;assert anchor.year-int(anchor.month<5)==r.year
 calstate='pre' if b<policy else 'post' if a>=policy else 'crosses_calendar_date'
 state='pre' if max(weekdays)<policy else 'post' if min(weekdays)>=policy else 'mixed'
 # The only threshold-crossing segment is Sunday Jan4-Jan10; Jan4 is officially closed.
 if calstate=='crosses_calendar_date':assert a==date(2015,1,4) and state=='post'
 weekrows.append(dict(syn_year=r.year,week=r.week,calendar_start=str(a),calendar_end=str(b),Sunday_bucket=str(sunday),Monday_anchor=r.Monday_anchor,calendar_date_class=calstate,trading_side_class=state,original_Post=int(r.year>=2015),original_event_time=r.year-2015,note='observed CSMAR source segment; calendar bounds are not verified first/last trading dates'))
save(weekrows,'observed_week_exposure.csv');w=pd.DataFrame(weekrows);state=w.set_index('week').trading_side_class.to_dict();annual=[]
for y,g in w.groupby('syn_year'):
 n=len(g);pre=int(g.trading_side_class.eq('pre').sum());post=int(g.trading_side_class.eq('post').sum());mix=int(g.trading_side_class.eq('mixed').sum());assert pre+post+mix==n
 annual.append(dict(syn_year=y,nominal_window_start=f'{y}-05-01',nominal_window_end=f'{y+1}-04-30',first_observed_source_segment=int(g.week.min()),last_observed_source_segment=int(g.week.max()),source_calendar_span_start=g.calendar_start.min(),source_calendar_span_end=g.calendar_end.max(),observed_source_week_segments=n,distinct_Sunday_week_buckets=g.Sunday_bucket.nunique(),pre_policy_segments=pre,post_policy_segments=post,mixed_trading_segments=mix,calendar_date_crossing_segments=int(g.calendar_date_class.eq('crosses_calendar_date').sum()),post_segment_share=post/n,original_Post=int(y>=2015),original_event_time=y-2015,formal_exposure_type='mixed_year' if pre and post else 'post_only' if post else 'pre_only'))
save(annual,'annual_policy_week_exposure.csv')
dup=w[w.duplicated(['syn_year','Sunday_bucket'],False)];save(dup,'cross_calendar_year_split_segments.csv')
d=pd.read_stata(R/'fixed_rerun/outputs/fixed_analysis.dta',columns=['firm_id','year','Treat','Post','event_time','old_H0_sample','old_H8_sample','n_weeks'],convert_categoricals=False)
assert d.Post.eq(d.year.ge(2015)).all() and d.event_time.eq(d.year-2015).all();assert d.loc[d.year.eq(2014),'event_time'].eq(-1).all()
db=sqlite3.connect('file:'+str(R/'cache/weekly_corrected.sqlite')+'?mode=ro',uri=True);firmrows=[]
for y in range(2009,2022):
 q=pd.read_sql_query('SELECT firm_id,week FROM weekly WHERE year=?',db,params=[y]);counts=Counter((int(f),state[int(k)]) for f,k in q.itertuples(index=False,name=None))
 for r in d[d.year.eq(y)&d.old_H0_sample.eq(1)].itertuples():
  pre=counts[r.firm_id,'pre'];post=counts[r.firm_id,'post'];mix=counts[r.firm_id,'mixed'];N=int(r.n_weeks);assert N<=pre+post+mix
  lo=max(0,N-pre-mix);hi=min(N,post)
  firmrows.append(dict(firm_id=r.firm_id,syn_year=y,Treat=r.Treat,in_H8=r.old_H8_sample,original_Post=r.Post,event_time=r.event_time,available_own_return_pre_segments=pre,available_own_return_post_segments=post,available_own_return_mixed_segments=mix,stored_SYN_complete_weeks=N,complete_post_weeks_lower_bound=lo,complete_post_weeks_upper_bound=hi,post_presence_in_complete_SYN_proven=lo>0,note='own valid-return/cap weeks are not all complete regression weeks; post complete-week counts bounded, not reconstructed'))
db.close();save(firmrows,'firm_year_exposure_bounds_private.csv');fr=pd.DataFrame(firmrows);agg=[]
for model,z in [('H0',fr),('H8',fr[fr.in_H8.eq(1)])]:
 for (y,t),g in z.groupby(['syn_year','Treat']):agg.append(dict(model=model,syn_year=y,Treat=t,company_years=len(g),companies_with_own_post_weeks=int(g.available_own_return_post_segments.gt(0).sum()),companies_with_proven_complete_post_weeks=int(g.post_presence_in_complete_SYN_proven.sum()),own_pre_week_rows=int(g.available_own_return_pre_segments.sum()),own_post_week_rows=int(g.available_own_return_post_segments.sum()),stored_complete_week_rows=int(g.stored_SYN_complete_weeks.sum()),complete_post_week_rows_lower_bound=int(g.complete_post_weeks_lower_bound.sum()),complete_post_week_rows_upper_bound=int(g.complete_post_weeks_upper_bound.sum())))
save(agg,'sample_exposure_by_year_group.csv')
base=fr[fr.syn_year.eq(2014)];details=[]
for model,z in [('H0',base),('H8',base[base.in_H8.eq(1)])]:details.append(dict(model=model,baseline_company_years=len(z),Post_values=';'.join(map(str,sorted(z.original_Post.unique()))),event_time_values=';'.join(map(str,sorted(z.event_time.unique()))),company_years_with_available_post_weeks=int(z.available_own_return_post_segments.gt(0).sum()),company_years_with_proven_complete_post_weeks=int(z.post_presence_in_complete_SYN_proven.sum()),min_complete_post_lower_bound=int(z.complete_post_weeks_lower_bound.min()),max_complete_post_upper_bound=int(z.complete_post_weeks_upper_bound.max()),sum_complete_post_lower_bound=int(z.complete_post_weeks_lower_bound.sum()),sum_complete_post_upper_bound=int(z.complete_post_weeks_upper_bound.sum())))
save(details,'baseline_2014_exposure_summary.csv')
after=[dict(**r,unchanged=sha(r['path'])==r['sha256']) for r in m];assert all(r['unchanged'] for r in after);js(after,'protected_after.json');js(dict(policy_formal_effective_date=str(policy),announcement_date='2015-01-04',policy_date_source='SSE Q&A, 2015-01-04',holiday_source='SSE 2015 annual holiday notice, published 2014-12-24',regressions_run=0,SYN_recomputed=False,Post_modified=False,event_time_modified=False,baseline_modified=False,sample_modified=False,new_analysis_DTA=0,weekly_raw_DTA_scanned=False,protected_files=len(m),peak_RSS_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,seconds=time.time()-start),'execution_audit.json')
print(pd.DataFrame(annual).to_string(index=False));print(pd.DataFrame(details).to_string(index=False));print((O/'execution_audit.json').read_text())
