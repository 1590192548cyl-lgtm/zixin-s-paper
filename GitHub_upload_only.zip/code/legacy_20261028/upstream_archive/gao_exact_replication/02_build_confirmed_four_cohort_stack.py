from pathlib import Path
import json

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

SYN = OUT / "syn_csrc_family_2010_2020.dta"
FIRST = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/年报指引识别/"
    "final_mapping/gao_firm_first_treat_core.csv"
)
CONTROLS = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_full_controls/"
    "gao_controls_firm_year_2009_2025.dta"
)
DELIST = Path(
    "/Users/macpro/Desktop/毕业论文/堆叠DID重跑/gao_replication_refinement/"
    "official_delisting_dates_combined.csv"
)

# Annual-report adoption years. The paper labels the first cohort 2013 because
# the two initial guidelines became effective on 7 January 2013, but explicitly
# states that the 2012 annual reports were the first reports subject to them.
COHORTS = [2012, 2015, 2016, 2017]
PAPER_LABEL = {2012: 2013, 2015: 2015, 2016: 2016, 2017: 2017}
PAPER_COUNTS = {
    2012: {"control_pre": 2952, "control_post": 2778, "treated_pre": 326, "treated_post": 347},
    2015: {"control_pre": 2886, "control_post": 2806, "treated_pre": 1017, "treated_post": 995},
    2016: {"control_pre": 3115, "control_post": 2841, "treated_pre": 419, "treated_post": 408},
    2017: {"control_pre": 3343, "control_post": 2959, "treated_pre": 164, "treated_post": 162},
}


def norm_id(s):
    return pd.to_numeric(s, errors="coerce").astype("Int64")


def main():
    syn = pd.read_stata(SYN, convert_categoricals=False)
    syn["firm_id"] = norm_id(syn["firm_int"])
    syn = syn[["firm_id", "syn_year", "SYN_CSRC_FAMILY", "R2_CSRC_FAMILY", "n_weeks_CSRC_FAMILY"]]

    first = pd.read_csv(FIRST, low_memory=False)
    first["firm_id"] = norm_id(first["firm_id"])
    first["first_treat_year_core"] = pd.to_numeric(first["first_treat_year_core"], errors="coerce")
    first["eligible_as_clean_control"] = pd.to_numeric(
        first["eligible_as_clean_control"], errors="coerce"
    ).fillna(0).astype(int)

    ctrl = pd.read_stata(CONTROLS, convert_categoricals=False)
    ctrl["firm_id"] = norm_id(ctrl["firm_id"])
    ctrl["fiscal_year"] = pd.to_numeric(ctrl["fiscal_year"], errors="coerce").astype("Int64")
    keep_ctrl = [
        "firm_id", "fiscal_year", "industry_standard_id", "industry_code", "industry_name",
        "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
        "Length_AR_chars", "Stdret", "d_Instihold", "Instihold", "Analyst",
        "Indsize_candidate", "Subs", "Big4", "Tophold", "Tophold2",
    ]
    ctrl = ctrl[keep_ctrl].copy()

    de = pd.read_csv(DELIST, low_memory=False)
    de["firm_id"] = norm_id(de["firm_id"])
    de["delisting_date"] = pd.to_datetime(de["delisting_date"], errors="coerce")
    excluded_delist = set(
        de.loc[de["delisting_date"].between("2009-01-01", "2019-12-31"), "firm_id"]
        .dropna().astype(int).tolist()
    )

    rows = []
    selection = []
    for c in COHORTS:
        treated_ids = set(
            first.loc[first["first_treat_year_core"].eq(c), "firm_id"].dropna().astype(int)
        )
        future_clean = first["first_treat_year_core"].ge(c + 3)
        never_clean = first["first_treat_year_core"].isna() & first["eligible_as_clean_control"].eq(1)
        control_ids = set(first.loc[future_clean | never_clean, "firm_id"].dropna().astype(int))
        control_ids -= treated_ids
        allowed = treated_ids | control_ids

        q = syn[
            syn["syn_year"].between(c - 2, c + 3)
            & syn["firm_id"].isin(allowed)
            & ~syn["firm_id"].isin(excluded_delist)
        ].copy()
        q["annual_report_year"] = q["syn_year"] - 1
        q["cohort_report_year"] = c
        q["gao_cohort_label"] = PAPER_LABEL[c]
        q["event_time"] = q["annual_report_year"] - c
        q["treated_in_stack"] = q["firm_id"].isin(treated_ids).astype(np.int8)
        q["Post"] = q["annual_report_year"].ge(c).astype(np.int8)
        q["TreatPost"] = (q["treated_in_stack"] * q["Post"]).astype(np.int8)
        q = q.merge(
            ctrl,
            left_on=["firm_id", "annual_report_year"],
            right_on=["firm_id", "fiscal_year"],
            how="left",
            validate="many_to_one",
        )
        # Gao excludes financial-industry observations.
        q = q[~q["industry_name"].fillna("").str.contains(r"银行|证券|保险|金融|信托", regex=True)].copy()

        # The paper requires at least one pre- and one post-adoption observation
        # per firm within each cohort. This is imposed after the dependent
        # variable and annual-report-year industry screen are available.
        g = q.groupby("firm_id")
        has_pre = g["Post"].transform(lambda x: (x == 0).any())
        has_post = g["Post"].transform(lambda x: (x == 1).any())
        q = q[has_pre & has_post].copy()

        q["stack_id"] = COHORTS.index(c) + 1
        q["firm_stack_id"] = pd.factorize(
            q["stack_id"].astype(str) + "_" + q["firm_id"].astype(str), sort=True
        )[0] + 1
        q["cohort_year_id"] = pd.factorize(
            q["stack_id"].astype(str) + "_" + q["annual_report_year"].astype(str), sort=True
        )[0] + 1
        rows.append(q)

        selection.append(
            {
                "cohort_report_year": c,
                "gao_cohort_label": PAPER_LABEL[c],
                "confirmed_treated_ids_before_data": len(treated_ids),
                "clean_control_ids_before_data": len(control_ids),
                "stack_rows_after_syn_industry_prepost": len(q),
                "treated_firms_after_syn_industry_prepost": int(q.loc[q.treated_in_stack.eq(1), "firm_id"].nunique()),
                "control_firms_after_syn_industry_prepost": int(q.loc[q.treated_in_stack.eq(0), "firm_id"].nunique()),
            }
        )

    stack = pd.concat(rows, ignore_index=True)
    # IDs must be globally unique across stacks, not factorized separately.
    stack["firm_stack_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["firm_id"].astype(str), sort=True
    )[0] + 1
    stack["cohort_year_id"] = pd.factorize(
        stack["stack_id"].astype(str) + "_" + stack["annual_report_year"].astype(str), sort=True
    )[0] + 1
    if stack.duplicated(["firm_id", "stack_id", "annual_report_year"]).any():
        raise AssertionError("duplicate firm-stack-year rows")
    if not stack["event_time"].between(-3, 2).all():
        raise AssertionError("event window differs from [-3,+2]")

    counts = (
        stack.groupby(["cohort_report_year", "treated_in_stack", "Post"])
        .size().rename("project_rows").reset_index()
    )
    paper_rows = []
    for c, z in PAPER_COUNTS.items():
        for treated, role in [(0, "control"), (1, "treated")]:
            for post, period in [(0, "pre"), (1, "post")]:
                paper_rows.append(
                    {
                        "cohort_report_year": c,
                        "treated_in_stack": treated,
                        "Post": post,
                        "gao_paper_rows": z[f"{role}_{period}"],
                    }
                )
    counts = counts.merge(pd.DataFrame(paper_rows), on=["cohort_report_year", "treated_in_stack", "Post"], how="outer")
    counts["row_gap_project_minus_paper"] = counts["project_rows"] - counts["gao_paper_rows"]
    counts.to_csv(OUT / "confirmed_stack_vs_gao_table1.csv", index=False)
    pd.DataFrame(selection).to_csv(OUT / "confirmed_stack_selection_audit.csv", index=False)

    stack.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    stack["firm_id"] = stack["firm_id"].astype(np.int32)
    stack.to_stata(OUT / "gao_confirmed_four_cohort_stack.dta", write_index=False, version=118)
    stack.to_csv(OUT / "gao_confirmed_four_cohort_stack.csv", index=False)
    meta = {
        "rows": int(len(stack)),
        "unique_firms": int(stack.firm_id.nunique()),
        "treated_firms": int(stack.loc[stack.treated_in_stack.eq(1), "firm_id"].nunique()),
        "cohorts": COHORTS,
        "paper_labels": PAPER_LABEL,
        "duplicate_firm_stack_year": int(stack.duplicated(["firm_id", "stack_id", "annual_report_year"]).sum()),
        "delisted_2009_2019_excluded_ids": len(excluded_delist),
        "note": "Formula/sample-window replication using only currently confirmed firm-IIDG mapping; not claimed to reproduce Gao's unpublished firm-level treatment list.",
    }
    (OUT / "confirmed_stack_build_audit.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print(counts.to_string(index=False))


if __name__ == "__main__":
    main()
