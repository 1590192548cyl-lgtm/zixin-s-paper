from pathlib import Path
import json

import numpy as np
import pandas as pd


WORK = Path("/Users/macpro/Documents/New project/gao_exact_replication_work")
OUT = WORK / "outputs"
STACK = OUT / "gao_confirmed_four_cohort_stack.dta"
MDA = OUT / "length_mda_exact_stack_firm_year.csv"
FUNDCORR = OUT / "fundcorr_firm_year_2009_2019.dta"

CONTINUOUS = [
    "SYN_CSRC_FAMILY", "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS",
    "abs_Accruals", "Length_MDA", "Length_AR", "Stdret", "FundCorr",
    "d_Instihold", "Instihold", "Analyst", "Indsize", "Subs", "Tophold", "Tophold2",
]
FULL_CONTROLS = [
    "Size", "MB_parent", "Lev", "Stdroa", "abs_dEPS", "abs_Accruals", "Loss",
    "Length_MDA", "Length_AR", "Stdret", "FundCorr", "d_Instihold", "Instihold",
    "Analyst", "Indsize", "Subs", "Big4", "Tophold", "Tophold2",
]


def impose_prepost(df, base_flag, out_flag):
    df[out_flag] = 0
    q = df[df[base_flag].eq(1)].copy()
    g = q.groupby(["stack_id", "firm_id"], sort=False)
    ok = g.Post.transform(lambda x: (x.eq(0).any() and x.eq(1).any()))
    df.loc[q.index[ok], out_flag] = 1


def main():
    d = pd.read_stata(STACK, convert_categoricals=False)
    d["firm_id"] = pd.to_numeric(d.firm_id, errors="raise").astype(int)
    d["annual_report_year"] = pd.to_numeric(d.annual_report_year, errors="raise").astype(int)

    m = pd.read_csv(MDA, low_memory=False)
    m["firm_id"] = pd.to_numeric(m.firm_id, errors="coerce").astype("Int64")
    m["report_year"] = pd.to_numeric(m.report_year, errors="coerce").astype("Int64")
    m = m[["firm_id", "report_year", "Length_MDA", "extraction_status"]].drop_duplicates(
        ["firm_id", "report_year"], keep="last"
    )
    d = d.merge(
        m,
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "report_year"],
        how="left",
        validate="many_to_one",
    )

    f = pd.read_stata(FUNDCORR, convert_categoricals=False)
    f["firm_id"] = pd.to_numeric(f.firm_id, errors="coerce").astype("Int64")
    f["fiscal_year"] = pd.to_numeric(f.fiscal_year, errors="coerce").astype("Int64")
    d = d.merge(
        f[["firm_id", "fiscal_year", "FundCorr"]],
        left_on=["firm_id", "annual_report_year"],
        right_on=["firm_id", "fiscal_year"],
        how="left",
        validate="many_to_one",
        suffixes=("", "_fund"),
    )
    if "fiscal_year_fund" in d:
        d.drop(columns=["fiscal_year_fund"], inplace=True)

    d["Length_AR"] = np.log(pd.to_numeric(d.Length_AR_chars, errors="coerce").where(lambda x: x > 0))
    d["industry_for_size"] = d.industry_standard_id.astype(str) + "|" + d.industry_code.astype(str)
    d["Indsize_count"] = d.groupby(
        ["stack_id", "annual_report_year", "industry_for_size"], dropna=False
    ).firm_id.transform("nunique")
    d["Indsize"] = np.log(d.Indsize_count.where(d.industry_code.notna() & d.Indsize_count.gt(0)))

    d["sample_formula_base"] = 1
    d["sample_g1_raw"] = d[["SYN_CSRC_FAMILY", "TreatPost", "Size", "MB_parent", "Lev"]].notna().all(axis=1).astype(int)
    d["sample_full_raw"] = d[["SYN_CSRC_FAMILY", "TreatPost"] + FULL_CONTROLS].notna().all(axis=1).astype(int)
    impose_prepost(d, "sample_g1_raw", "sample_g1")
    impose_prepost(d, "sample_full_raw", "sample_full")

    # Winsorization is frozen at 1/99 for all continuous variables, using the
    # final complete-case full-control stacked sample exactly once.
    cuts = []
    full = d.sample_full.eq(1)
    for v in CONTINUOUS:
        s = pd.to_numeric(d.loc[full, v], errors="coerce").dropna()
        lo, hi = float(s.quantile(0.01)), float(s.quantile(0.99))
        d[v + "_w_exact"] = pd.to_numeric(d[v], errors="coerce").clip(lo, hi)
        cuts.append(
            {
                "variable": v,
                "N_cutoff_sample": len(s),
                "p1": lo,
                "p99": hi,
                "below_p1_all_stack": int((pd.to_numeric(d[v], errors="coerce") < lo).sum()),
                "above_p99_all_stack": int((pd.to_numeric(d[v], errors="coerce") > hi).sum()),
            }
        )
    pd.DataFrame(cuts).to_csv(OUT / "exact_replication_winsor_cutoffs.csv", index=False)

    missing = []
    for v in ["SYN_CSRC_FAMILY"] + FULL_CONTROLS:
        for c, g in d.groupby("cohort_report_year"):
            missing.append(
                {
                    "variable": v,
                    "cohort_report_year": int(c),
                    "stack_rows": len(g),
                    "missing_rows": int(g[v].isna().sum()),
                    "missing_rate": float(g[v].isna().mean()),
                    "missing_treated_rows": int(g.loc[g.treated_in_stack.eq(1), v].isna().sum()),
                    "missing_control_rows": int(g.loc[g.treated_in_stack.eq(0), v].isna().sum()),
                }
            )
    pd.DataFrame(missing).to_csv(OUT / "exact_replication_missingness.csv", index=False)

    sample_rows = []
    for name in ["sample_formula_base", "sample_g1", "sample_full"]:
        z = d[d[name].eq(1)]
        sample_rows.append(
            {
                "sample": name,
                "rows": len(z),
                "firms": int(z.firm_id.nunique()),
                "clusters": int(z.firm_id.nunique()),
                "treated_firms": int(z.loc[z.treated_in_stack.eq(1), "firm_id"].nunique()),
                "cohorts": int(z.cohort_report_year.nunique()),
                "treated_rows": int(z.treated_in_stack.sum()),
                "pre_rows": int(z.Post.eq(0).sum()),
                "post_rows": int(z.Post.eq(1).sum()),
            }
        )
    pd.DataFrame(sample_rows).to_csv(OUT / "exact_replication_sample_sizes.csv", index=False)

    desc = []
    z = d[d.sample_full.eq(1)]
    desc_vars = ["SYN_CSRC_FAMILY", "treated_in_stack", "Post"] + FULL_CONTROLS
    for v in desc_vars:
        s = z[v].dropna()
        desc.append(
            {
                "variable": v,
                "N": len(s),
                "mean": float(s.mean()),
                "median": float(s.median()),
                "sd": float(s.std()),
                "min": float(s.min()),
                "p25": float(s.quantile(.25)),
                "p75": float(s.quantile(.75)),
                "max": float(s.max()),
            }
        )
    pd.DataFrame(desc).to_csv(OUT / "exact_replication_descriptives.csv", index=False)

    d.sort_values(["stack_id", "firm_id", "annual_report_year"], inplace=True)
    d.to_stata(OUT / "gao_exact_available_analysis.dta", write_index=False, version=118)
    meta = {
        "stack_rows": len(d),
        "sample_formula_base": int(d.sample_formula_base.sum()),
        "sample_g1": int(d.sample_g1.sum()),
        "sample_full": int(d.sample_full.sum()),
        "full_control_count": len(FULL_CONTROLS),
        "full_controls": FULL_CONTROLS,
        "winsor_rule": "1st/99th percentile on final full-control complete-case stacked sample",
        "length_ar_correction": "natural log of annual-report character count before winsorization",
        "indsize_correction": "natural log of unique firms in CSRC industry x cohort stack x annual-report year",
    }
    (OUT / "exact_model_preparation_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(meta, ensure_ascii=False, indent=2), flush=True)
    print(pd.DataFrame(sample_rows).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
