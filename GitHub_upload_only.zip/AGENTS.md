# Repository handoff rules

Read README.md, START_HERE.md and docs/CURRENT_STATE.md first. Snapshot date is 2026-11-12; latest empirical audit ended 2026-11-09.

- This repository is a handoff, NOT permission to run models. Only tools/verify_package.py is a safe default entry point.
- Preserve G1, H8 and DR-DID separately. No p-value-driven samples, controls, cohorts, industry maps, windows or thresholds.
- No imputation; missing source rows do not imply zero, never-ST or not-dual.
- Do not upload private_data_DO_NOT_UPLOAD, CSMAR microdata, company weights/lists, PDFs or full annual reports.
- No global annual-report rescan. Use frozen files, streaming/chunked reads, one process, one BLAS thread.
- Historical scripts use absolute paths, once-only guards and local archives. Inspect dependencies and request explicit analysis authorization before any replay.
- Do not overwrite original inputs/results. Proposed data repair needs objective evidence and an exclusion/change ledger.
- Frozen G1 event reference=-3. Latest H8 reference=2013; 2014 is transition. DR reference=2013 and excludes 2014 from pre/post comparison.
- A non-rejected pretrend test is not proof of parallel trends; significance is not causal identification.
