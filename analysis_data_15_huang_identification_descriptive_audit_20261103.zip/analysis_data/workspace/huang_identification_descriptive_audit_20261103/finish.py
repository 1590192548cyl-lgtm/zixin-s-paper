from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
from PIL import Image,ImageDraw,ImageFont
W=Path(__file__).resolve().parent;O=W/'outputs';B=W.parent
def save(d,n):pd.DataFrame(d).to_csv(O/n,index=False,encoding='utf-8-sig')
d=pd.read_stata(B/'huang_week_calendar_repair_20261103/fixed_rerun/outputs/fixed_analysis.dta',convert_categoricals=False)
s=d[d.old_H8_sample.eq(1)]
comparison=[dict(metric='observations',paper=7227,current_H8=len(s),note='paper 13 controls vs current 8, not same complete-case population'),dict(metric='firms',paper=625,current_H8=s.firm_id.nunique(),note='cannot recover author company list from aggregate counts'),dict(metric='Treat_observation_share',paper=.532,current_H8=s.Treat.mean(),note='same observation-weighted definition, paper rounded to 3 decimals'),dict(metric='Post_observation_share',paper=.558,current_H8=s.Post.mean(),note='not firm share')]
comparison += [dict(metric='SYN_mean',paper=-1.569,current_H8=s.SYN_w.mean(),note='paper Table2 vs current frozen SYN_w; populations and winsorization reference samples differ'),dict(metric='SYN_sd',paper=1.283,current_H8=s.SYN_w.std(),note='descriptive comparison only, not evidence sufficient to change SYN')]
save(comparison,'paper_sample_comparison.csv')
f=pd.read_csv(O/'year_change_composition_identity.csv');out=[]
for m,g in f.groupby('model'):
 a=g[g.Treat.eq(1)].set_index('year');b=g[g.Treat.eq(0)].set_index('year')
 for y in a.index:
  row=dict(model=m,year=y)
  for v in ['total_mean_change','common_firm_change','entry_composition','exit_composition']:row[v]=a.loc[y,v]-b.loc[y,v]
  row['composition_total']=row['entry_composition']+row['exit_composition'];assert abs(row['total_mean_change']-row['common_firm_change']-row['composition_total'])<1e-12;out.append(row)
save(out,'treatment_control_change_identity.csv')
fields=[('main_sample','confirmed','2009—2021；625家；7227公司年','原文研究设计、表2/3'),('baseline','confirmed','2014即事件-1省略','原文图1注释及动态检验段落'),('displayed_event_terms','confirmed','-3 -2 0 +1 +2 +3','本次重新渲染原PDF图1核验'),('interaction','confirmed','年份虚拟变量与处理组交互','原文动态检验段落'),('estimation_window','not_reported','图示范围不能推出估计窗口','原文未报告事件研究N或截样本命令'),('tail_handling','not_reported','未知是全部单列仅展示部分、端点合并、截样本或其他','没有作者程序；没有试跑候选实现'),('joint_pretest','not_reported','未提供联合F或p','图示前两项不等于全部事前年份联合检验'),('CI_level','not_reported','图中误差线置信水平未明示','不从图反推精确p值'),('current_short_window','confirmed_reconstruction_only','2012—2018确实截样本','run_window.do；不是作者实现已确认'),('current_full_window','confirmed_reconstruction_only','2009—2021全部12个非基准动态交互项','run_fixed.do；-6至+6，省略-1')]
save([dict(item=a,status=b,finding=c,evidence=e) for a,b,c,e in fields],'figure_implementation_audit.csv')
# No file is read through Excel; figures show descriptive summaries, not new estimates.
font='/System/Library/Fonts/Supplemental/Arial.ttf';F=lambda n:ImageFont.truetype(font,n)
im=Image.new('RGB',(1660,1100),'white');draw=ImageDraw.Draw(im)
draw.text((65,30),'Frozen H8 sample: descriptive trends, not regression estimates',fill='#17212e',font=F(31))
draw.text((65,77),'No industries or years removed. Annual SYN_w values and original sample flags are unchanged.',fill='#526174',font=F(21))
gaps=pd.read_csv(O/'annual_treatment_control_gaps.csv');annual=pd.read_csv(O/'annual_group_means.csv');pairs=pd.read_csv(O/'same_firm_change_vs_2014.csv')
def panel(rect,title,series,ylim):
 x0,y0,x1,y1=rect;draw.text((x0,y0-50),title,fill='#17212e',font=F(23))
 def px(x):return x0+(x-2009)/12*(x1-x0)
 def py(y):return y1-(y-ylim[0])/(ylim[1]-ylim[0])*(y1-y0)
 for tick in np.linspace(*ylim,5):
  yy=py(tick);draw.line((x0,yy,x1,yy),fill='#e1e7ee',width=1);draw.text((x0-58,yy-10),f'{tick:.2f}',fill='#526174',font=F(16))
 draw.rectangle((x0,y0,x1,y1),outline='#94a3b8',width=1)
 if ylim[0]<0<ylim[1]:draw.line((x0,py(0),x1,py(0)),fill='#8793a1',width=2)
 xx=px(2015)
 for yy in range(int(y0),int(y1),13):draw.line((xx,yy,xx,min(yy+6,y1)),fill='#888888',width=1)
 for y in range(2009,2022,2):draw.text((px(y)-21,y1+10),str(y),fill='#526174',font=F(16))
 for j,(label,df,col,color) in enumerate(series):
  pts=[(px(r.year),py(getattr(r,col))) for r in df.itertuples()]
  if len(pts)>1:draw.line(pts,fill=color,width=3)
  for x,y in pts:draw.ellipse((x-3,y-3,x+3,y+3),fill=color)
  yy=y1+43+26*j;draw.line((x0,yy+10,x0+25,yy+10),fill=color,width=3);draw.text((x0+34,yy),label,fill='#354355',font=F(17))
a=annual.query('model=="H8" and roster=="frozen_original"')
panel((100,180,760,450),'A. Annual group means', [('Key regulated',a[a.Treat.eq(1)],'SYN_w_mean','#1765aa'),('Other regulated',a[a.Treat.eq(0)],'SYN_w_mean','#c46a24')],(-1.1,.7))
q=gaps.query('model=="H8" and roster=="frozen_original"');p=gaps.query('model=="H8" and roster=="pre2009_2014_complete_roster"')
panel((940,180,1600,450),'B. Treated minus control gap', [('Original available observations',q,'gap_treated_minus_control','#1765aa'),('Fixed pre-period roster; post availability varies',p,'gap_treated_minus_control','#c46a24')],(-.25,.25))
q=pairs.query('model=="H8"').copy();q=pd.concat([q,pd.DataFrame([dict(year=2014,difference_in_changes=0)])]).sort_values('year')
panel((100,700,760,970),'C. Same-firm changes relative to 2014', [('Same firms in each year/2014 pair',q,'difference_in_changes','#1765aa')],(-.35,.15))
q=pd.DataFrame(out).query('model=="H8"')
panel((940,700,1600,970),'D. Annual change in group gap', [('Common-firm component',q,'common_firm_change','#1765aa'),('Entry + exit composition',q,'composition_total','#c46a24')],(-.3,.15))
im.save(O/'descriptive_trends.png')
sources={'checked_on':'2026-11-03','scope':'bounded public search; no author contacted; no absence-of-code proof','queries':['exact Chinese title','exact title + 代码','exact title + 附录','exact title + replication/data','exact title site:ckyk.cn'],'pages':[{'url':'https://scholar.xmu.edu.cn/Authors/Index?id=HuangBingYi','result':'author institutional publication listing; no target replication link observed'},{'url':'https://cas.xmu.edu.cn/info/1025/2668.htm','result':'author institutional profile; no target replication link observed'},{'url':'https://shisu.dps.qikan.cn/pc/maga/text-read?id=ckyx20250314','result':'title/authors and trial text; no implementation details retrieved'},{'url':'https://doi.org/10.19641/j.cnki.42-1290/f.2025.06.014','result':'not accessible via web tool; not evidence of invalid DOI'}],'local_pdf':'user-provided original PDF, 8 pages; source fingerprint protected; page4 freshly rendered and visually inspected','structural_preflight':'existing sidecar UNAVAILABLE with trailing-data/duplicate MediaBox warnings, not upgraded to PASS; rendering succeeded'}
(O/'public_source_search_log.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
print(pd.DataFrame(comparison).to_string(index=False));print('Chart and supplemental audit tables completed')
