clear all
set more off
local out "/Users/macpro/Documents/New project/huang_basic_reconstruction_20261103/outputs"
import delimited "`out'/event_results.csv", varnames(1) case(preserve) clear
set obs 26
replace model="H0" in 25
replace model="H8" in 26
replace event_time=-1 if missing(event_time)
replace coefficient=0 if event_time==-1
sort model event_time
twoway (rcap CI_low CI_high event_time,lcolor(navy)) (connected coefficient event_time,lcolor(navy) mcolor(navy) msymbol(O)), by(model,cols(2) title("Huang-style basic reconstruction",size(medium)) note("H0: no controls; H8: eight controls. Not author-confirmed. 95% firm-clustered CI.",size(vsmall))) xlabel(-6(1)6,labsize(small)) xline(-.5,lpattern(dash) lcolor(gs8)) yline(0,lcolor(gs10)) xtitle("Event time (2014 = -1 reference)",size(small)) ytitle("SYN coefficient",size(small)) legend(off) graphregion(color(white)) xsize(12) ysize(5)
graph export "`out'/event_study_plot.png", width(2400) replace
display "PLOT_COMPLETE_NO_REGRESSION"
exit, clear
