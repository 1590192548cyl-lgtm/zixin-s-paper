version 18
clear all
set more off
capture log close _all
local out "/Users/macpro/Documents/New project/static_model_correction_20261028_work/outputs"
log using "`out'/sa_additional_joint_checks.log", text replace
estimates use "`out'/sa_full_event_corrected.ster"
matrix BB=e(b_iw)
matrix VV=e(V_iw)
local names: colnames BB
display "`names'"
assert colsof(BB)==22
matrix P=BB[1,1..9]
matrix V=VV[1..9,1..9]
matrix W=P*syminv(V)*P'
scalar pre_all_p=chi2tail(9,W[1,1])
scalar pre_all_chi2=W[1,1]
matrix P=BB[1,10..22]
matrix V=VV[10..22,10..22]
matrix W=P*syminv(V)*P'
scalar post_all_p=chi2tail(13,W[1,1])
scalar post_all_chi2=W[1,1]
clear
set obs 2
gen str24 test="all_modeled_pre_periods" in 1
replace test="all_modeled_post_periods" in 2
gen double chi2=pre_all_chi2 in 1
replace chi2=post_all_chi2 in 2
gen int df=9 in 1
replace df=13 in 2
gen double p=pre_all_p in 1
replace p=post_all_p in 2
export delimited using "`out'/sa_full_path_joint_tests.csv", replace
list, noobs
display as result "SA_JOINT_CHECKS_COMPLETE_NO_REGRESSIONS_RERUN"
log close
exit, clear
