from pathlib import Path
import subprocess,json,time,resource
W=Path(__file__).resolve().parent;O=W/'outputs'
pstatus=O/'stata_execution.json'
with pstatus.open('x') as f:json.dump({'status':'STARTED','models':'fixed drimp only','attempt':1},f)
start=time.monotonic()
p=subprocess.Popen(['/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp','-b','do','run_fixed.do'],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
print('Stata started, pid',p.pid,flush=True)
stdout,stderr=p.communicate(timeout=600)
body=(O/'drdid_fixed.log').read_text(errors='replace') if (O/'drdid_fixed.log').exists() else ''
meta=dict(status='COMPLETE' if p.returncode==0 and '\nALL_FIXED_DRDID_COMPLETE\n' in body else 'FAILED_INSPECT_NO_AUTOMATIC_REFIT',exit_code=p.returncode,completed_pairs=len(list(O.glob('*_done.txt'))),elapsed_seconds=time.monotonic()-start,Stata_peak_RSS_MiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss/1024**2,stderr=stderr[-1500:],stdout=stdout[-1500:])
pstatus.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(meta,ensure_ascii=False,indent=2),flush=True)
