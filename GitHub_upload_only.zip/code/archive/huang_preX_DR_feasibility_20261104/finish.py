from pathlib import Path
import pandas as pd,numpy as np,json
W=Path(__file__).resolve().parent;O=W/'outputs';BASE=W.parent;ROOT=Path('/Users/macpro/Desktop/毕业论文')
def save(x,n):pd.DataFrame(x).to_csv(O/n,index=False,encoding='utf-8-sig')
src=BASE/'huang_week_calendar_repair_20261103/fixed_rerun/outputs/fixed_analysis.dta'
k=pd.read_stata(src,columns=['firm_id','year','Treat','old_H0_sample','old_H8_sample'],convert_categoricals=False);u=k[k.old_H8_sample.eq(1)][['firm_id','Treat']].drop_duplicates().set_index('firm_id');ids=set(u.index)
ipo=pd.read_stata(ROOT/'原始数据/公司基本信息/IPO_Cobasic.dta',columns=['Stkcd','Listdt'],convert_categoricals=False).sort_values('Listdt').drop_duplicates('Stkcd');ipo['firm_id']=ipo.Stkcd.astype(int);ipo=ipo.set_index('firm_id').Listdt
row=[]
for f in sorted(ids):
 q=k[k.firm_id.eq(f)&k.year.le(2013)];h0=q[q.old_H0_sample.eq(1)];h8=q[q.old_H8_sample.eq(1)]
 row.append(dict(firm_id=f,Treat=int(u.at[f,'Treat']),IPODate=ipo[f],pure_pre_H8_years=len(h8),pure_pre_H0_years=len(h0),has_H8_2013=bool((h8.year==2013).any()),has_H0_2013=bool((h0.year==2013).any()),no_pure_pre_H8=len(h8)==0,no_pure_pre_H0=len(h0)==0,listed_2014=ipo[f].startswith('2014')))
avail=pd.DataFrame(row);save(avail,'pure_pre_outcome_availability_private.csv');save(avail.groupby('Treat').agg(firms=('firm_id','size'),no_pure_pre_H8=('no_pure_pre_H8','sum'),no_pure_pre_H0=('no_pure_pre_H0','sum'),has_H8_2013=('has_H8_2013','sum'),has_H0_2013=('has_H0_2013','sum'),listed_2014=('listed_2014','sum')).reset_index(),'pure_pre_outcome_availability_summary.csv')
timing=[('Size','期初总资产，ln资产_y-1','前一年12月31日，早于本年5月窗口','未知','基线取ln资产_b；不是把H8年度标签直接搬到b'),('Age','ln(年度减首次上市年+1)','上市日期已知、年数为确定性时钟','上市日有源','基线按截至b上市年数；未上市不填0'),('Lev','年末负债/资产','本年12月31日位于May_y-Apr_y+1窗口内','未知','基线取负债_b/资产_b'),('Cent','年末第2—5/第1持股','年末位于本年收益窗口内','未知','需要b年12月31日真实排名1—5'),('Top10','年末前10持股合计','年末位于本年收益窗口内','未知','需要b年12月31日真实排名1—10'),('Dual','年末兼任标志','年末位于本年收益窗口内','未知','用b年年末真实二元值'),('Board','ln年末在职董事数','年末位于本年收益窗口内','未知','在职口径1，b年末值'),('Big4','该年度境内定期审计机构','会计年度与委任/报告签发时点不同','未知','b年度审计信息的实际确定/披露时点需单列')]
save([dict(variable=a,current_H8_definition=b,measurement_timing=c,actual_disclosure_timing=d,baseline_audit_rule=e) for a,b,c,d,e in timing],'covariate_timing_audit.csv')
miss=pd.read_csv(O/'missing_baseline_keys_private.csv');downloads=[]
for b in [2008,2010,2012]:
 z=miss[(miss.anchor_year==b)&miss.downloadable_gap.eq(True)]
 for v,g in z.groupby('variable'):
  task='排名1—10及持股比例，用于Cent和Top10' if v in ['Cent','Top10'] else '两职合一ConcurrentPosition' if v=='Dual' else '年末在职董事人数口径1' if v=='Board' else '境内定期报告审计事务所名称及日期' if v=='Big4' else '真实同口径源字段'
  downloads.append(dict(priority='完整前期基线所需' if b==2008 else '仅对应后续基线可用性场景，未采纳',anchor_year=b,variable=v,already_listed_firms_missing=g.firm_id.nunique(),content=task,company_key_list='missing_baseline_keys_private.csv',note='Cent和Top10是一份下载，勿重复；不下载不存在的上市前记录'))
save(downloads,'download_checklist.csv')
print(pd.read_csv(O/'pure_pre_outcome_availability_summary.csv').to_string(index=False));print(pd.DataFrame(downloads).to_string(index=False));print('Missing2008 distinct company counts',miss.query('anchor_year==2008 and downloadable_gap==True').groupby('variable').firm_id.nunique().to_dict())
